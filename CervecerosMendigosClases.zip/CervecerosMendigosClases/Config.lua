-- Configuracion del addon grande CervecerosMendigosClases (ayudas para cada clase).
-- Cada modulo dice su clase (def.clase): el Hub solo carga los de la clase del personaje.
local ADDON, ns = ...
ns.HubConfig = {
    title = "CervecerosMendigosClases",
    subtitle = "Ayudas para tu clase",
    slashes = { "cmclases" },
    svName = "CervecerosMendigosClasesHubDB",
    logo = "Interface\\AddOns\\" .. ADDON .. "\\logo.tga",
    minimapIcon = "Interface\\AddOns\\" .. ADDON .. "\\badge.tga",
    angleBase = 75, angleStep = 12,
    soloClases = true,
    intro = "Ayudas para cada clase de WoW Forever. El addon mira la clase de tu personaje y solo carga sus módulos: con otra clase ni se activan ni avisan de nada (ni siquiera aparecen sus pestañas). Cada clase tiene un módulo común (con el selector de rol: automático por talentos o a mano) y uno por rol, que solo se enciende con el tuyo. Pícaro: Picaroor (venenos, robar bolsillos, cajas), Control y Energía. Druida: Druida, Feral, Sanador (y Energía en forma felina). Paladín: Paladín, Sagrado, Protección, Reprensión. Chamán: Chamán (tótems y conjuntos), Elemental, Mejora, Restauración. Cazador: Cazador (mascota, munición, disparo automático), Bestias, Puntería, Supervivencia. Guerrero: Guerrero, Armas, Furia, Protección. Mago: Mago (agua, comida, gema), Arcano, Fuego, Escarcha. Brujo: Brujo (demonio, piedras, fragmentos), Aflicción, Demonología, Destrucción. Sacerdote: Sacerdote, Disciplina, Sagrado, Sombras. Cada pestaña de la izquierda es un módulo con su propia configuración; puedes activarlo o desactivarlo sin tocar los demás.",
}
