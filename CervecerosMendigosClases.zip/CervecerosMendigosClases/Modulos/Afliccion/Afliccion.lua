-- Aflicción (CervecerosMendigos Clases, brujo): solo con rol aflicción.
--   Aviso de Trance de las Sombras (Anochecer), Succionar vida en el objetivo y Amplificar maldición en grande.
local ADDON, ns = ...
local U = ns.CU

U.Modulo{
    key = "afliccion", dir = "Afliccion", name = "Aflicción", clase = "WARLOCK", slash = { "cmafliccion" }, rolDe = "brujo", rol = "afliccion",
    desc = "Brujo de aflicción (solo con ese rol): aviso de Trance de las Sombras (Descarga de las Sombras instantánea), "
        .. "tu Succionar vida en el objetivo y Amplificar maldición en grande.",
    procs = { { "trance", { 17941 }, "Trance de las Sombras", si = { 18094, 18095 } } },
    objetivo = { { "succionar", { 18265, 18879, 18880, 18881 }, "Succionar vida" } },
    cds = { { "amplificar", { 18288 }, "Amplificar maldición" } },
}
