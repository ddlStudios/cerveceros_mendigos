-- Paladín (CervecerosMendigos Clases): lo de cualquier paladín.
--   * Rol: automático (por talentos), sagrado, protección o reprensión. Lo usan Sagrado, Protección y Reprensión.
--   * Barra de auras (clic para cambiar) y aviso si vas sin aura.
--   * Bendiciones: una por clase (a tu gusto), a quién le falta y botón para ponérsela; Símbolos de reyes.
--   * Sello activo y aviso si peleas sin sello; Abstinencia (no puedes usar Escudo divino) con su tiempo.
--   * Enfriamientos grandes con anuncio a quién se los lanzas (Imposición de manos, Bendición de protección...).
local ADDON, ns = ...
local Hub = ns.Hub
local U = ns.CU
local Num, Str = U.Num, U.Str
local P = {}
ns.Paladin = P

local AURAS = {
    { 465, 10290, 643, 10291, 1032, 10292, 10293 },       -- Aura de devoción
    { 7294, 10298, 10299, 10300, 10301 },                  -- Aura de reprensión
    { 19746 },                                             -- Aura de concentración
    { 19876, 19895, 19896 }, { 19888, 19897, 19898 }, { 19891, 19899, 19900 },   -- resistencias
    { 20218 },                                             -- Aura de santidad
}
P.BENDICIONES = {
    { "poderio", "Poderío", { 19740, 19834, 19835, 19836, 19837, 19838, 25291 }, { 25782, 25916 } },
    { "sabiduria", "Sabiduría", { 19742, 19850, 19852, 19853, 19854, 25290 }, { 25894, 25918 } },
    { "reyes", "Reyes", { 20217 }, { 25898 } },
    { "salvacion", "Salvación", { 1038 }, { 25895 } },
    { "luz", "Luz", { 19977, 19978, 19979 }, { 25890 } },
    { "santuario", "Santuario", { 20911, 20912, 20913, 20914 }, { 25899 } },
}
local BEND = {}
for _, b in ipairs(P.BENDICIONES) do BEND[b[1]] = b end
local SIMBOLO = 21177
P.SELLOS = { 21084, 20375, 21082, 20164, 20165, 20166 }   -- rectitud, orden, cruzado, justicia, luz, sabiduría
local ABSTINENCIA = 25771
-- Enfriamientos: { clave, rangos, anunciable, nombre de repuesto, enfriamiento por defecto (s) }
local CDS = {
    { "manos", { 633, 2800, 10310 }, true, "Imposición de manos", 3600 },
    { "escudo", { 642, 1020 }, false, "Escudo divino", 300 },
    { "proteccionDivina", { 498, 5573 }, false, "Protección divina", 300 },
    { "proteccion", { 1022, 5599, 10278 }, true, "Bendición de protección", 300 },
    { "libertad", { 1044 }, true, "Bendición de libertad", 20 },
    { "martillo", { 853, 5588, 5589, 10308 }, false, "Martillo de justicia", 60 },
    { "intervencion", { 19752 }, true, "Intervención divina", 3600 },
}
local CLASES = { "WARRIOR", "ROGUE", "HUNTER", "MAGE", "WARLOCK", "PRIEST", "DRUID", "SHAMAN", "PALADIN" }
local NOMBRE_CLASE = { WARRIOR = "Guerrero", ROGUE = "Pícaro", HUNTER = "Cazador", MAGE = "Mago", WARLOCK = "Brujo",
    PRIEST = "Sacerdote", DRUID = "Druida", SHAMAN = "Chamán", PALADIN = "Paladín" }

local DEFAULTS = {
    rol = "auto",
    escala = 1, opacidad = 1, bloquear = false, fondo = true,
    -- Auras
    auras = true, tamAura = 28, avisoSinAura = true,
    -- Bendiciones
    bendiciones = true, banda = false, minutosBendicion = 1, soloFueraCombate = true, avisoBendicion = true,
    repetirBendicion = 5, botonBendicion = true, superiores = false, minSimbolos = 10, verSimbolos = true,
    porClase = { WARRIOR = "poderio", ROGUE = "poderio", HUNTER = "poderio", MAGE = "sabiduria", WARLOCK = "sabiduria",
                 PRIEST = "sabiduria", DRUID = "sabiduria", SHAMAN = "sabiduria", PALADIN = "sabiduria" },
    -- Sellos
    verSello = true, avisoSinSello = true, sinSelloSagrado = false,
    -- Abstinencia y enfriamientos
    verAbstinencia = true, enfriamientos = true, tamIcono = 30,
    cds = { manos = true, escudo = true, proteccionDivina = false, proteccion = true, libertad = false, martillo = true, intervencion = false },
    anunciar = true, canal = "auto", textoAnuncio = "%h en %t",
    -- Avisos
    avisoTexto = true, avisoChat = false, avisoSonido = true, avisoKit = "RAID_WARNING",
    pos = {},
}

local mod, db, marco
local mover, pendiente = false, false
local avisos = { aura = false, sello = false, bendicion = 0, simbolos = false }
local enviado = {}

----------------------------------------------------------------------
-- Rol
----------------------------------------------------------------------
-- Talentos que delatan el rol (de más a menos profundos en el árbol).
local PISTAS = {
    { "sagrado", { 20473, 20929, 20930 } }, { "proteccion", { 20925, 20927, 20928 } }, { "reprension", { 20066 } },
    { "sagrado", { 20216 } }, { "proteccion", { 20911, 20912, 20913, 20914 } }, { "reprension", { 20375 } },
}
function P.Rol()
    local d = db or (Hub.byKey.paladin and Hub.byKey.paladin.db)
    local rol = d and d.rol or "auto"
    if rol ~= "auto" then return rol end
    for _, p in ipairs(PISTAS) do if U.ConoceAlguno(p[2]) then return p[1] end end
    return "ninguno"
end
function P.EsPaladin()
    local ok, _, c = pcall(UnitClass, "player")
    return ok and c == "PALADIN"
end

-- Nombre del sello activo (o nil / false si no hay; nil = no se sabe).
function P.SelloActivo()
    local dudoso = false
    for _, id in ipairs(P.SELLOS) do
        local fin = U.Aura("player", U.Nombre(id), "HELPFUL")
        if fin then return U.Nombre(id), fin end
        if fin == nil then dudoso = true end
    end
    if dudoso then return nil end
    return false
end

-- Panel sencillo, perjuicios en el objetivo y si hay enemigo: en las utilidades comunes (ComunClases).
P.Panel, P.PintarPanel, P.EnObjetivo, P.HayEnemigo = U.Panel, U.PintarPanel, U.EnObjetivo, U.HayEnemigo

----------------------------------------------------------------------
-- Auras (barra de botones)
----------------------------------------------------------------------
local function AurasConocidas()
    local lista = {}
    for _, ids in ipairs(AURAS) do
        local id = U.Mejor(ids)
        if id then lista[#lista + 1] = { id = id, base = ids[1] } end
    end
    return lista
end
local function AuraActiva()
    local dudoso = false
    for _, ids in ipairs(AURAS) do
        local fin = U.Aura("player", U.Nombre(ids[1]), "HELPFUL")
        if fin then return ids[1] end
        if fin == nil then dudoso = true end
    end
    if dudoso then return nil end
    return false
end

local function CrearAuras()
    if not marco then return end
    if U.EnCombate() then pendiente = true; return end
    pendiente = false
    marco.auras = marco.auras or {}
    local lista = AurasConocidas()
    for i, x in ipairs(lista) do
        local b = marco.auras[i]
        if not b then
            b = CreateFrame("Button", "CMPaladinAura" .. i, marco, "SecureActionButtonTemplate")
            b:RegisterForClicks("AnyUp", "AnyDown")
            b.tex = b:CreateTexture(nil, "ARTWORK"); b.tex:SetAllPoints()
            b.activa = b:CreateTexture(nil, "OVERLAY"); b.activa:SetAllPoints()
            b.activa:SetTexture("Interface\\Buttons\\CheckButtonHilight"); b.activa:SetBlendMode("ADD")
            b:SetScript("OnEnter", function(self) GameTooltip:SetOwner(self, "ANCHOR_TOP"); GameTooltip:SetText(U.Nombre(self.id)); GameTooltip:Show() end)
            b:SetScript("OnLeave", function() GameTooltip:Hide() end)
            marco.auras[i] = b
        end
        b.id, b.base = x.id, x.base
        b:SetAttribute("type", "macro")
        b:SetAttribute("macrotext", "/cast " .. U.Nombre(x.id))
        b.tex:SetTexture(U.Icono(x.id))
        b:Show()
    end
    for i = #lista + 1, #marco.auras do marco.auras[i]:Hide() end
    marco.nAuras = #lista
end

----------------------------------------------------------------------
-- Bendiciones
----------------------------------------------------------------------
-- Para cada miembro, la bendición que le toca por su clase y si le falta.
local function FaltanBendiciones()
    local faltan, primero = {}, nil
    local lim = GetTime() + db.minutosBendicion * 60
    for _, u in ipairs(U.Miembros(db.banda)) do
        local okc, _, clase = pcall(UnitClass, u)
        clase = okc and Str(clase)
        local b = clase and BEND[db.porClase[clase] or ""]
        local okv, muerto = pcall(UnitIsDeadOrGhost, u)
        if b and U.ConoceAlguno(b[3]) and not (okv and muerto and not U.issecret(muerto)) then
            local fin = U.Aura(u, U.Nombre(b[3][1]), "HELPFUL")
            if not fin then fin = U.Aura(u, U.Nombre(b[4][1]), "HELPFUL") or fin end
            if fin ~= nil and ((not fin) or (fin ~= math.huge and fin < lim)) then
                local okn, nombre = pcall(UnitName, u)
                nombre = okn and Str(nombre) or u
                faltan[#faltan + 1] = ("%s: %s"):format(b[2], nombre)
                primero = primero or { u, b, nombre }
            end
        end
    end
    return faltan, primero
end

----------------------------------------------------------------------
-- Enfriamientos y anuncios
----------------------------------------------------------------------
local function Canal()
    if db.canal ~= "auto" then return db.canal end
    local okr, banda = pcall(IsInRaid)
    if okr and banda and not U.issecret(banda) then return "RAID" end
    local okg, grupo = pcall(IsInGroup)
    if okg and grupo and not U.issecret(grupo) then return "PARTY" end
end

local function AlLanzar(unidad, hechizo)
    if unidad ~= "player" then return end
    hechizo = Num(hechizo)
    if not hechizo then return end
    for _, c in ipairs(CDS) do
        for _, id in ipairs(c[2]) do
            if id == hechizo then
                db.lanzado = db.lanzado or {}
                db.lanzado[c[1]] = time()
                local quien = enviado[hechizo]
                enviado[hechizo] = nil
                if c[3] and db.anunciar and quien then
                    local canal = Canal()
                    if canal then
                        local txt = db.textoAnuncio:gsub("%%h", U.Nombre(c[2][1], c[4])):gsub("%%t", quien)
                        pcall(SendChatMessage, txt, canal)
                    end
                end
                return
            end
        end
    end
end

local function Queda(c)
    local id = U.Mejor(c[2])
    if not id then return nil end
    local q = U.Enfriamiento(id)
    if q then return q, id end
    local t = db.lanzado and db.lanzado[c[1]]
    if t then return math.max(0, c[5] - (time() - t)), id end
    return 0, id
end

----------------------------------------------------------------------
-- Marco
----------------------------------------------------------------------
local function Crear()
    if marco then return end
    marco = mod:Frame("Frame", "CMPaladin", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    marco:SetSize(220, 40)
    U.Movil(mod, marco, "paladin", function() return db.bloquear and not mover end)
    if marco.SetBackdrop then
        marco:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                            edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    end
    marco.cds = CreateFrame("Frame", nil, marco)
    marco.texto = marco:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    marco.texto:SetJustifyH("LEFT")
    marco.boton = CreateFrame("Button", "CMPaladinBendicion", marco, "SecureActionButtonTemplate, UIPanelButtonTemplate")
    marco.boton:SetSize(200, 20)
    marco.boton:RegisterForClicks("AnyUp", "AnyDown")
    CrearAuras()
end

local function Pintar()
    local combate = U.EnCombate()
    if not (mod and mod:IsEnabled() and P.EsPaladin()) then
        if marco and not combate then marco:Hide() end
        return
    end
    if not marco and combate then return end
    Crear()
    if pendiente and not combate then CrearAuras() end
    marco:SetScale(db.escala); marco:SetAlpha(db.opacidad)
    if marco.SetBackdropColor then
        marco:SetBackdropColor(0, 0, 0, db.fondo and 0.7 or 0)
        marco:SetBackdropBorderColor(1, 1, 1, db.fondo and 0.5 or 0)
    end
    local y, ancho = -6, 200
    local lineas = {}
    -- Auras.
    local activa = AuraActiva()
    if db.auras and marco.nAuras and marco.nAuras > 0 then
        local t = db.tamAura
        for i = 1, marco.nAuras do
            local b = marco.auras[i]
            if not combate then b:SetSize(t, t); b:ClearAllPoints(); b:SetPoint("TOPLEFT", marco, "TOPLEFT", 6 + (i - 1) * (t + 4), y); b:Show() end
            b.activa:SetShown(activa == b.base)
        end
        ancho = math.max(ancho, 12 + marco.nAuras * (t + 4))
        y = y - t - 6
    elseif marco.auras and not combate then
        for _, b in ipairs(marco.auras) do b:Hide() end
    end
    if db.avisoSinAura and activa == false and marco.nAuras and marco.nAuras > 0 then
        lineas[#lineas + 1] = "|cffff5555Sin aura|r"
        if not avisos.aura then avisos.aura = true; U.Avisar(mod, "Vas sin aura", true) end
    elseif activa then
        avisos.aura = false
    end
    -- Sello.
    local rol = P.Rol()
    local sello = P.SelloActivo()
    if db.verSello then
        if sello then lineas[#lineas + 1] = "|cffffd100" .. sello .. "|r"
        elseif sello == false then lineas[#lineas + 1] = "|cff999999Sin sello|r" end
    end
    if db.avisoSinSello and combate and sello == false and (rol ~= "sagrado" or db.sinSelloSagrado) then
        if not avisos.sello then avisos.sello = true; U.Avisar(mod, "Peleando sin sello", true, 1, 0.82, 0) end
    elseif sello then
        avisos.sello = false
    end
    -- Abstinencia.
    if db.verAbstinencia then
        local fin = U.Aura("player", U.Nombre(ABSTINENCIA, "Abstinencia"), "HARMFUL")
        if fin and fin ~= math.huge then
            lineas[#lineas + 1] = ("|cffff7755%s %s|r"):format(U.Nombre(ABSTINENCIA, "Abstinencia"), U.Tiempo(math.max(0, fin - GetTime())))
        end
    end
    -- Enfriamientos.
    if db.enfriamientos then
        local lista = {}
        for _, c in ipairs(CDS) do
            if db.cds[c[1]] then
                local q, id = Queda(c)
                if id then lista[#lista + 1] = { icono = U.Icono(id), queda = q } end
            end
        end
        if #lista > 0 then
            marco.cds:ClearAllPoints(); marco.cds:SetPoint("TOPLEFT", marco, "TOPLEFT", 6, y)
            marco.cds:SetSize(#lista * (db.tamIcono + 6), db.tamIcono)
            U.Iconos(marco.cds, lista, db.tamIcono)
            marco.cds:Show()
            ancho = math.max(ancho, #lista * (db.tamIcono + 6))
            y = y - db.tamIcono - 6
        else
            marco.cds:Hide()
        end
    else
        marco.cds:Hide()
    end
    -- Símbolos de reyes (bendiciones superiores).
    if db.verSimbolos and db.superiores then
        local n = U.ContarObjeto(SIMBOLO)
        lineas[#lineas + 1] = (n < db.minSimbolos and "|cffff5555%d|r %s" or "%d %s"):format(n, U.NombreObjeto(SIMBOLO))
        if n < db.minSimbolos and not avisos.simbolos then avisos.simbolos = true; U.Avisar(mod, "Te quedan pocos " .. U.NombreObjeto(SIMBOLO), false)
        elseif n >= db.minSimbolos then avisos.simbolos = false end
    end
    -- Bendiciones.
    local primero
    if db.bendiciones and (not combate or not db.soloFueraCombate) then
        local faltan
        faltan, primero = FaltanBendiciones()
        for i = 1, math.min(#faltan, 6) do lineas[#lineas + 1] = "|cffffaa33" .. faltan[i] .. "|r" end
        if #faltan > 6 then lineas[#lineas + 1] = ("y %d más..."):format(#faltan - 6) end
        if #faltan > 0 and db.avisoBendicion and not combate and GetTime() - avisos.bendicion > db.repetirBendicion * 60 then
            avisos.bendicion = GetTime()
            U.Avisar(mod, "Falta " .. faltan[1] .. (#faltan > 1 and (" y %d más"):format(#faltan - 1) or ""), true, 0.6, 1, 0.6)
        end
    end
    if #lineas > 0 then
        marco.texto:ClearAllPoints(); marco.texto:SetPoint("TOPLEFT", marco, "TOPLEFT", 8, y)
        marco.texto:SetWidth(ancho)
        marco.texto:SetText(table.concat(lineas, "\n"))
        marco.texto:Show()
        y = y - 13 * #lineas - 4
    else
        marco.texto:Hide()
    end
    if combate then return end
    if db.botonBendicion and primero then
        local b = primero[2]
        local ids = (db.superiores and U.ConoceAlguno(b[4])) and b[4] or b[3]
        marco.boton:SetAttribute("type", "macro")
        marco.boton:SetAttribute("macrotext", ("/cast [@%s] %s"):format(primero[1], U.Nombre(U.Mejor(ids) or ids[1])))
        marco.boton:SetText(b[2] .. " » " .. primero[3])
        marco.boton:ClearAllPoints(); marco.boton:SetPoint("TOPLEFT", marco, "TOPLEFT", 8, y)
        marco.boton:Show()
        y = y - 24
    else
        marco.boton:Hide()
    end
    if y >= -8 and not mover then marco:Hide(); return end
    marco:SetSize(ancho + 12, -y + 4)
    if not marco.colocado then U.Colocar(mod, marco, "paladin", 0, 200); marco.colocado = true end
    marco:EnableMouse(mover or not db.bloquear)
    marco:Show()
end

----------------------------------------------------------------------
-- Registro
----------------------------------------------------------------------
local ROLES = { { "auto", "Automático (por talentos)" }, { "sagrado", "Sagrado (sanador)" }, { "proteccion", "Protección (tanque)" },
                { "reprension", "Reprensión (daño)" } }
local OPC_BEND = { { "", "Ninguna" } }
for _, b in ipairs(P.BENDICIONES) do OPC_BEND[#OPC_BEND + 1] = { b[1], b[2] } end
local acum = 0
mod = Hub:Register{
    key = "paladin", dir = "Paladin", name = "Paladín", clase = "PALADIN",
    desc = "Para cualquier paladín: elige tu rol (sagrado, protección o reprensión), barra de auras, la bendición que "
        .. "quieres para cada clase con aviso y botón para ponérsela a quien le falte, tu sello, Abstinencia y tus "
        .. "enfriamientos grandes con anuncio al grupo.",
    defaults = DEFAULTS,
    slash = { "cmpaladin" },
    Init = function(m)
        db = m.db
        m:Event("UPDATE_SHAPESHIFT_FORMS", function() CrearAuras(); Pintar() end)
        m:Event("LEARNED_SPELL_IN_TAB", function() CrearAuras(); Pintar() end)
        m:Event("SPELLS_CHANGED", function() CrearAuras() end)
        m:Event("PLAYER_REGEN_ENABLED", function() avisos.sello = false; Pintar() end)
        m:Event("PLAYER_REGEN_DISABLED", Pintar)
        m:Event("UNIT_SPELLCAST_SENT", function(_, _, unidad, objetivo, _, hechizo)
            if unidad == "player" and Num(hechizo) then enviado[hechizo] = Str(objetivo) end
        end)
        m:Event("UNIT_SPELLCAST_SUCCEEDED", function(_, _, unidad, _, hechizo) AlLanzar(unidad, hechizo) end)
        m:Event("GROUP_ROSTER_UPDATE", Pintar)
        m:Event("BAG_UPDATE_DELAYED", Pintar)
        m:OnUpdate(function(_, e)
            acum = acum + e
            if acum >= 0.5 then acum = 0; Pintar() end
        end)
    end,
    Enable = function(m) db = m.db; Pintar() end,
    Disable = function() if marco and not U.EnCombate() then marco:Hide() end end,
    OnReset = function() if marco then marco.colocado = false end end,
    OnSlash = function(m, msg)
        msg = (msg or ""):lower()
        if msg == "mover" then mover = not mover; Pintar()
        elseif msg == "rol" then m:Print("rol: " .. P.Rol() .. " (ajuste: " .. db.rol .. ")")
        else Hub:Open("paladin") end
    end,
    BuildConfig = function(m, L)
        db = m.db
        local function G(k) return function() return db[k] end end
        local function S(k) return function(v) db[k] = v; Pintar() end end
        if not P.EsPaladin() then L:Text("|cffff7755Este personaje no es paladín.|r", true) end

        L:Header("Rol")
        L:Text("Los módulos Sagrado, Protección y Reprensión solo se encienden con su rol. En automático se mira qué "
            .. "talentos conoces (Choque sagrado / Favor divino = sagrado; Escudo sagrado / Bendición de santuario = "
            .. "protección; Arrepentimiento / Sello de orden = reprensión).", true)
        L:Choice("Rol", ROLES, G("rol"), function(v) db.rol = v; Pintar(); m:Print("rol: " .. P.Rol()) end)
        L:Button("¿Qué rol tengo ahora?", 180, function() m:Print("rol: " .. P.Rol() .. " (ajuste: " .. db.rol .. ")") end)

        L:Header("Marco")
        L:Button("Mover", 90, function() mover = not mover; Pintar() end)
        L:Button("Volver a su sitio", 140, function() db.pos.paladin = nil; if marco then marco.colocado = false end; Pintar() end, true)
        L:Check("Bloquear la posición", G("bloquear"), S("bloquear"))
        L:Check("Fondo y borde", G("fondo"), S("fondo"))
        L:Slider("Escala", 0.5, 2, 0.05, G("escala"), S("escala"), "%.2f")
        L:Slider("Opacidad", 0.2, 1, 0.05, G("opacidad"), S("opacidad"), "%.2f")

        L:Header("Auras")
        L:Check("Barra de auras (clic para cambiar)", G("auras"), S("auras"))
        L:Slider("  Tamaño de los botones", 18, 50, 1, G("tamAura"), S("tamAura"))
        L:Check("Aviso si vas sin aura", G("avisoSinAura"), S("avisoSinAura"))

        L:Header("Bendiciones")
        L:Check("Avisar de a quién le falta su bendición", G("bendiciones"), S("bendiciones"))
        L:Check("  También a toda la banda", G("banda"), S("banda"))
        L:Slider("  Avisar cuando le queden menos de (minutos)", 0, 10, 1, G("minutosBendicion"), S("minutosBendicion"))
        L:Check("  Solo fuera de combate", G("soloFueraCombate"), S("soloFueraCombate"))
        L:Check("  Aviso (texto/sonido)", G("avisoBendicion"), S("avisoBendicion"))
        L:Slider("  Repetir el aviso cada (minutos)", 1, 30, 1, G("repetirBendicion"), S("repetirBendicion"))
        L:Check("  Botón para ponérsela al primero que le falte", G("botonBendicion"), S("botonBendicion"))
        L:Check("  Usar las bendiciones superiores (gastan Símbolos de reyes)", G("superiores"), S("superiores"))
        L:Check("  Contar Símbolos de reyes", G("verSimbolos"), S("verSimbolos"))
        L:Slider("    En rojo y aviso por debajo de", 0, 100, 5, G("minSimbolos"), S("minSimbolos"))
        L:Text("Bendición para cada clase:", true)
        for _, c in ipairs(CLASES) do
            L:Choice("  " .. NOMBRE_CLASE[c], OPC_BEND, function() return db.porClase[c] or "" end,
                function(v) db.porClase[c] = v; Pintar() end)
        end

        L:Header("Sellos y Abstinencia")
        L:Check("Mostrar el sello activo", G("verSello"), S("verSello"))
        L:Check("Aviso si peleas sin sello", G("avisoSinSello"), S("avisoSinSello"))
        L:Check("  También con rol sagrado", G("sinSelloSagrado"), S("sinSelloSagrado"))
        L:Check("Mostrar el tiempo de Abstinencia", G("verAbstinencia"), S("verAbstinencia"))

        L:Header("Enfriamientos")
        L:Check("Iconos con el enfriamiento", G("enfriamientos"), S("enfriamientos"))
        L:Slider("  Tamaño", 20, 60, 1, G("tamIcono"), S("tamIcono"))
        for _, c in ipairs(CDS) do
            L:Check("  " .. U.Nombre(c[2][1], c[4]), function() return db.cds[c[1]] end, function(v) db.cds[c[1]] = v; Pintar() end)
        end
        L:Check("Anunciar a quién le lanzas Imposición de manos, Bendición de protección, de libertad o Intervención", G("anunciar"), S("anunciar"))
        L:Choice("  Canal", { { "auto", "Banda o grupo (según estés)" }, { "PARTY", "Grupo" }, { "RAID", "Banda" }, { "SAY", "Decir" }, { "YELL", "Gritar" } },
            G("canal"), S("canal"))
        L:Edit("  Texto (%h = hechizo, %t = objetivo)", G("textoAnuncio"), function(v) if type(v) == "string" then db.textoAnuncio = v:gsub("|", "") end end, "text", 220)

        L:Header("Cómo avisa")
        L:Check("Texto grande", G("avisoTexto"), S("avisoTexto"))
        L:Check("Línea en el chat", G("avisoChat"), S("avisoChat"))
        L:Check("Sonido", G("avisoSonido"), S("avisoSonido"))
        L:Choice("  Sonido", U.KITS, G("avisoKit"), function(v) db.avisoKit = v; U.Sonar(v) end)
    end,
}
