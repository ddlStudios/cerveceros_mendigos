-- Elemental (CervecerosMendigos Clases, chamán): solo se enciende si tu rol de chamán es elemental.
--   * Libre lanzamiento (Foco elemental): aviso e icono mientras dura.
--   * Maestría elemental: enfriamiento en grande y aviso cuando vuelve a estar lista.
--   * Maná con la regla de los 5 segundos y aviso de maná bajo.
local ADDON, ns = ...
local Hub = ns.Hub
local U = ns.CU
local C = ns.Chaman

local LIBRE = 16246
local MAESTRIA = 16166

local DEFAULTS = {
    escala = 1, opacidad = 1, bloquear = false, tamIcono = 36,
    libre = true, libreSonido = true, maestria = true, avisoMaestria = true,
    mana = true, cincoSegundos = true, avisoMana = true, porcentajeMana = 20,
    avisoTexto = true, avisoChat = false, avisoSonido = true, avisoKit = "RAID_WARNING",
    pos = {},
}

local mod, db, marco
local mover = false
local libreActivo, maestriaLista, manaAvisado = false, nil, false
local ultimoGasto = 0

local function Activo() return mod and mod:IsEnabled() and C.EsChaman() and C.Rol() == "elemental" end

local function Pintar()
    if not Activo() then if marco then marco:Hide() end return end
    marco = marco or U.Panel(mod, "CMElemental", "elemental", function() return mover end)
    local lineas, iconos = {}, {}
    if db.libre then
        local nombre = U.Nombre(LIBRE, "Libre lanzamiento")
        local fin = U.Aura("player", nombre, "HELPFUL")
        if fin ~= nil then
            if fin and not libreActivo then
                U.Aviso("¡" .. nombre .. "!", 0.4, 0.8, 1)
                if db.libreSonido then U.Sonar(db.avisoKit) end
            end
            libreActivo = fin and true or false
        end
        if libreActivo then lineas[#lineas + 1] = "|cff66ccff" .. nombre .. "|r"; iconos[#iconos + 1] = { icono = U.Icono(LIBRE), queda = 0 } end
    end
    if db.maestria and U.Conoce(MAESTRIA) then
        local q = U.Enfriamiento(MAESTRIA)
        if q then
            if q == 0 and maestriaLista == false and db.avisoMaestria then U.Avisar(mod, U.Nombre(MAESTRIA, "Maestría elemental") .. " lista", true, 0.4, 1, 0.4) end
            maestriaLista = q == 0
        end
        iconos[#iconos + 1] = { icono = U.Icono(MAESTRIA), queda = q or 0 }
    end
    local mana, maxMana = U.Mana()
    if db.mana and mana and maxMana and maxMana > 0 then
        local pc = mana / maxMana * 100
        lineas[#lineas + 1] = ("Maná %d%%"):format(pc)
        if db.cincoSegundos then
            local resto = 5 - (GetTime() - ultimoGasto)
            lineas[#lineas + 1] = resto > 0 and ("|cffffaa33Regla de 5 s: %.1f|r"):format(resto) or "|cff66ff66Regenerando maná|r"
        end
        if db.avisoMana and pc < db.porcentajeMana and not manaAvisado then
            manaAvisado = true; U.Avisar(mod, ("Maná bajo (%d%%)"):format(pc), true, 0.4, 0.6, 1)
        elseif pc > db.porcentajeMana + 10 then manaAvisado = false end
    end
    U.PintarPanel(mod, marco, lineas, iconos, mover, 0, -260)
end

local acum = 0
mod = Hub:Register{
    key = "elemental", dir = "Elemental", name = "Elemental", clase = "SHAMAN",
    desc = "Chamán elemental (solo con ese rol): aviso de Libre lanzamiento, Maestría elemental en grande con aviso "
        .. "cuando está lista, y maná con la regla de los 5 segundos.",
    defaults = DEFAULTS,
    slash = { "cmelemental" },
    Init = function(m)
        db = m.db
        m:Event("UNIT_SPELLCAST_SUCCEEDED", function(_, _, unidad, _, hechizo)
            if unidad == "player" and U.Num(hechizo) then local c = U.Coste(hechizo); if c and c > 0 then ultimoGasto = GetTime() end end
        end)
        m:OnUpdate(function(_, e) acum = acum + e; if acum >= 0.1 then acum = 0; Pintar() end end)
    end,
    Enable = function(m) db = m.db; Pintar() end,
    Disable = function() if marco then marco:Hide() end end,
    OnReset = function() if marco then marco.colocado = false end end,
    OnSlash = function(m, msg) if (msg or ""):lower() == "mover" then mover = not mover; Pintar() else Hub:Open("elemental") end end,
    BuildConfig = function(m, L)
        db = m.db
        local function G(k) return function() return db[k] end end
        local function S(k) return function(v) db[k] = v; Pintar() end end
        L:Text("Solo funciona si tu rol de chamán (pestaña Chamán) es elemental. Ahora: |cffffd100" .. C.Rol() .. "|r.", true)
        L:Button("Mover", 90, function() mover = not mover; Pintar() end)
        L:Button("Volver a su sitio", 140, function() db.pos.elemental = nil; if marco then marco.colocado = false end; Pintar() end, true)
        L:Check("Bloquear la posición", G("bloquear"), S("bloquear"))
        L:Slider("Escala", 0.5, 2, 0.05, G("escala"), S("escala"), "%.2f")
        L:Slider("Opacidad", 0.2, 1, 0.05, G("opacidad"), S("opacidad"), "%.2f")
        L:Slider("Tamaño de los iconos", 20, 70, 1, G("tamIcono"), S("tamIcono"))
        L:Header("Qué enseña")
        L:Check("Aviso e icono de " .. U.Nombre(LIBRE, "Libre lanzamiento"), G("libre"), S("libre"))
        L:Check("  Con sonido", G("libreSonido"), S("libreSonido"))
        L:Check(U.Nombre(MAESTRIA, "Maestría elemental") .. " en grande", G("maestria"), S("maestria"))
        L:Check("  Aviso cuando vuelve a estar lista", G("avisoMaestria"), S("avisoMaestria"))
        L:Check("Maná", G("mana"), S("mana"))
        L:Check("  Regla de los 5 segundos", G("cincoSegundos"), S("cincoSegundos"))
        L:Check("  Aviso de maná bajo", G("avisoMana"), S("avisoMana"))
        L:Slider("    Por debajo de (%)", 5, 60, 5, G("porcentajeMana"), S("porcentajeMana"))
        L:Header("Cómo avisa")
        L:Check("Texto grande", G("avisoTexto"), S("avisoTexto"))
        L:Check("Línea en el chat", G("avisoChat"), S("avisoChat"))
        L:Check("Sonido", G("avisoSonido"), S("avisoSonido"))
        L:Choice("  Sonido", U.KITS, G("avisoKit"), function(v) db.avisoKit = v; U.Sonar(v) end)
    end,
}
