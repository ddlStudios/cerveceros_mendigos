-- Fuego (CervecerosMendigos Clases, mago): solo con rol fuego.
--   Combustión y Ola explosiva en grande; Vulnerabilidad al Fuego (Agostar mejorado) en el objetivo.
local ADDON, ns = ...
local U = ns.CU

U.Modulo{
    key = "fuego", dir = "Fuego", name = "Fuego", clase = "MAGE", slash = { "cmfuego" }, rolDe = "mago", rol = "fuego",
    desc = "Mago de fuego (solo con ese rol): Combustión y Ola explosiva en grande, y las cargas de Vulnerabilidad al "
        .. "Fuego en el objetivo (aviso si faltan).",
    objetivo = { { "vulnerabilidad", { 22959 }, "Vulnerabilidad al Fuego", propio = false, cargas = 5, falta = true, si = { 11095, 12872, 12873 } } },
    procs = { { "combustion", { 11129 }, "Combustión" } },
    cds = { { "combustion", { 11129 }, "Combustión" }, { "ola", { 11113, 13018, 13019, 13020, 13021 }, "Ola explosiva", avisoListo = false },
            { "explosion", { 2136, 2137, 2138, 8412, 8413, 10197, 10199 }, "Explosión de fuego", avisoListo = false } },
}
