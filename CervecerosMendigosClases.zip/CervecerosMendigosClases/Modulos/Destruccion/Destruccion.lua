-- Destrucción (CervecerosMendigos Clases, brujo): solo con rol destrucción.
--   Quemadura de las Sombras y Conflagrar en grande (aviso cuando puedes Conflagrar), y las cargas de
--   Vulnerabilidad a las Sombras (Descarga de las Sombras mejorada) en el objetivo.
local ADDON, ns = ...
local U = ns.CU

U.Modulo{
    key = "destruccion", dir = "Destruccion", name = "Destrucción", clase = "WARLOCK", slash = { "cmdestruccion" }, rolDe = "brujo", rol = "destruccion",
    desc = "Brujo de destrucción (solo con ese rol): Quemadura de las Sombras y Conflagrar en grande, aviso cuando puedes "
        .. "Conflagrar, y las cargas de Vulnerabilidad a las Sombras en el objetivo.",
    objetivo = { { "vulnerabilidad", { 17800 }, "Vulnerabilidad a las Sombras", propio = false, cargas = 4, si = { 17793, 17796, 17801, 17802, 17803 } } },
    usables = { { "conflagrar", { 17962, 18930, 18931, 18932 }, "Conflagrar" } },
    cds = { { "quemadura", { 17877, 18867, 18868, 18869, 18870, 18871 }, "Quemadura de las Sombras", avisoListo = false },
            { "conflagrar", { 17962, 18930, 18931, 18932 }, "Conflagrar", avisoListo = false } },
}
