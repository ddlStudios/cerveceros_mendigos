-- Guerrero (CervecerosMendigos Clases): lo de cualquier guerrero (montado con el motor de ComunClases).
--   Rol (armas, furia, protección), barra de actitudes, Grito de batalla al grupo, tus perjuicios en el
--   objetivo (Hender armadura, Grito desmoralizador, Atronar, Desgarrar, Seccionar), avisos de Ejecutar y
--   Abrumar cuando se pueden usar, y enfriamientos.
local ADDON, ns = ...
local U = ns.CU

U.Modulo{
    key = "guerrero", dir = "Guerrero", name = "Guerrero", clase = "WARRIOR", slash = { "cmguerrero" },
    desc = "Para cualquier guerrero: elige tu rol, barra de actitudes, a quién le falta tu Grito de batalla, tus "
        .. "perjuicios en el objetivo, avisos de Ejecutar y Abrumar y tus enfriamientos.",
    roles = { { "armas", "Armas" }, { "furia", "Furia" }, { "proteccion", "Protección" } },
    pistas = { { "armas", { 12294, 21551, 21552, 21553 } }, { "furia", { 23881, 23892, 23893, 23894 } },
               { "proteccion", { 23922, 23923, 23924, 23925 } }, { "armas", { 12292 } }, { "furia", { 12328 } },
               { "proteccion", { 12975, 12809 } } },
    barra = { "Actitudes", { { "batalla", { 2457 } }, { "defensiva", { 71 } }, { "rabia", { 2458 } } },
        activa = function(id)
            local ok, n = pcall(GetNumShapeshiftForms)
            for i = 1, ok and U.Num(n) or 0 do
                local r = { pcall(GetShapeshiftFormInfo, i) }
                if r[1] and r[3] and not U.issecret(r[3]) and U.Num(r[5]) == id then return true end
            end
            return false
        end },
    beneficios = { { "grito", { 6673, 5242, 6192, 11549, 11550, 11551, 25289 }, "Grito de batalla" } },
    objetivo = {
        { "hender", { 7386, 7405, 8380, 11596, 11597 }, "Hender armadura", propio = false },
        { "desmoralizador", { 1160, 6190, 11554, 11555, 11556 }, "Grito desmoralizador", propio = false },
        { "atronar", { 6343, 8198, 8204, 8205, 11580, 11581 }, "Atronar", propio = false },
        { "desgarrar", { 772, 6546, 6547, 6548, 11572, 11573, 11574 }, "Desgarrar" },
        { "seccionar", { 1715, 7372, 7373 }, "Seccionar" },
    },
    usables = { { "ejecutar", { 5308, 20658, 20660, 20661, 20662 }, "Ejecutar" }, { "abrumar", { 7384, 7887, 11584, 11585 }, "Abrumar" } },
    cds = {
        { "cargar", { 100, 6178, 11578 }, "Cargar" }, { "interceptar", { 20252, 20616, 20617 }, "Interceptar" },
        { "puno", { 6552, 6554 }, "Puño" }, { "golpeEscudo", { 72, 1671, 1672 }, "Golpe con escudo", defecto = false },
        { "sangre", { 2687 }, "Furia sangrienta" }, { "rabiaRabiosa", { 18499 }, "Ira rabiosa" },
        { "intimidar", { 5246 }, "Grito intimidatorio", defecto = false }, { "temeridad", { 1719 }, "Temeridad" },
        { "represalia", { 20230 }, "Represalia", defecto = false },
    },
}
