-- Picaroor · Venenos: tiempo y cargas del veneno de cada arma, avisos, recuento de materiales,
-- «para cuántos te llega» y reponer en el vendedor.
local ADDON, ns = ...
local P = ns.Picaroor
local Num, Str = P.Num, P.Str

local ARMAS = { { 16, "Mano derecha", "md" }, { 17, "Mano izquierda", "mi" } }
local estado = { md = {}, mi = {} }   -- por arma: tenia, avisadoTiempo, avisadoCargas, ultimaExp
local marco

----------------------------------------------------------------------
-- Lectura
----------------------------------------------------------------------
-- ¿Hay un arma (no escudo ni objeto de mano izquierda) en ese hueco?
local function EsArma(hueco)
    local ok, id = pcall(GetInventoryItemID, "player", hueco)
    id = ok and Num(id)
    if not id then return false end
    if C_Item and C_Item.GetItemInfoInstant then
        local r = { pcall(C_Item.GetItemInfoInstant, id) }
        if r[1] and Num(r[7]) then return r[7] == 2 end
    end
    if GetItemInfoInstant then
        local r = { pcall(GetItemInfoInstant, id) }
        if r[1] and Num(r[7]) then return r[7] == 2 end
    end
    return true
end

-- Nombre del veneno que pone el tooltip del arma («Veneno instantáneo II (29 min)»).
local function NombreVeneno(hueco)
    if not (C_TooltipInfo and C_TooltipInfo.GetInventoryItem) then return nil end
    local ok, datos = pcall(C_TooltipInfo.GetInventoryItem, "player", hueco)
    if not ok or type(datos) ~= "table" or type(datos.lines) ~= "table" then return nil end
    for _, l in ipairs(datos.lines) do
        local t = Str(l.leftText)
        if t then
            local n = t:match("^(.-) %(%d+ ?[%a]+%)$")
            if n and n ~= "" then return n end
        end
    end
end

-- { md = { tiene, segundos, cargas, nombre, arma }, mi = {...} }
function P.LeerVenenos()
    local r = { pcall(GetWeaponEnchantInfo) }
    local ok = table.remove(r, 1)
    local out = {}
    for i, a in ipairs(ARMAS) do
        local b = (i - 1) * 4
        local tiene = ok and r[b + 1] and not P.issecret(r[b + 1]) and true or false
        local ms, cargas = ok and Num(r[b + 2]), ok and Num(r[b + 3])
        out[a[3]] = { tiene = tiene, seg = ms and ms / 1000, cargas = cargas, arma = EsArma(a[1]), hueco = a[1],
                      nombre = tiene and NombreVeneno(a[1]) or nil }
    end
    return out
end

----------------------------------------------------------------------
-- Avisos
----------------------------------------------------------------------
local function Avisar(texto, sonido)
    local db = P.Opt()
    if db.avisoTexto then P.Aviso(texto, 1, 0.55, 0.1) end
    if db.avisoChat then P.Print(texto) end
    if db.avisoSonido and sonido ~= false then P.Sonar(db.avisoKit) end
end

local function Faltan(v)
    local faltan = {}
    for _, a in ipairs(ARMAS) do
        local x = v[a[3]]
        if x.arma and not x.tiene and (a[3] == "md" or P.Opt().vigilarIzquierda) then faltan[#faltan + 1] = a[2] end
    end
    return faltan
end

-- Comprobación periódica: se ha acabado, queda poco tiempo, quedan pocas cargas.
local function Vigilar(v)
    local db = P.Opt()
    for _, a in ipairs(ARMAS) do
        local x, e = v[a[3]], estado[a[3]]
        if a[3] == "md" or db.vigilarIzquierda then
            if e.tenia and not x.tiene and x.arma and db.avisoAgotado then
                Avisar("¡Veneno agotado! " .. a[2])
            end
            if x.tiene then
                -- Veneno nuevo (el tiempo ha subido): se rearman los avisos.
                if x.seg and (not e.ultimaSeg or x.seg > e.ultimaSeg + 5) then e.avisadoTiempo, e.avisadoCargas = false, false end
                if db.avisoPocoTiempo and x.seg and x.seg < db.minutosAviso * 60 and not e.avisadoTiempo then
                    e.avisadoTiempo = true
                    Avisar(("Veneno de %s: quedan %d min"):format(a[2]:lower(), math.ceil(x.seg / 60)))
                end
                if db.avisoPocasCargas and x.cargas and x.cargas > 0 and x.cargas < db.cargasAviso and not e.avisadoCargas then
                    e.avisadoCargas = true
                    Avisar(("Veneno de %s: quedan %d cargas"):format(a[2]:lower(), x.cargas))
                end
            end
            e.tenia, e.ultimaSeg = x.tiene, x.seg
        end
    end
end

-- Al entrar en una mazmorra / campo de batalla o al empezar a pelear, si falta veneno.
function P.ComprobarSinVeneno(motivo)
    if not (P.Activo() and P.EsPicaro() and P.Conoce(P.HECHIZO_VENENOS)) then return end
    local db = P.Opt()
    if motivo == "combate" and not db.avisoCombate then return end
    if motivo == "instancia" and not db.avisoInstancia then return end
    local faltan = Faltan(P.LeerVenenos())
    if #faltan > 0 then Avisar("Sin veneno: " .. table.concat(faltan, " y ")) end
end

----------------------------------------------------------------------
-- Materiales y recetas
----------------------------------------------------------------------
-- Objetos que se vigilan en la barra: polvos, herramientas y los venenos que llevas.
function P.Recuento()
    local db = P.Opt()
    local cuenta = P.Bolsas()
    local lineas = {}
    if db.verPolvo then
        local n = cuenta[P.POLVO_DESTELLO] or 0
        local col = n < db.minPolvo and "|cffff5555" or "|cffffffff"
        lineas[#lineas + 1] = ("%s%d|r %s"):format(col, n, P.NombreObjeto(P.POLVO_DESTELLO))
    end
    if db.verCegador then
        lineas[#lineas + 1] = ("%d %s"):format(cuenta[P.POLVO_CEGADOR] or 0, P.NombreObjeto(P.POLVO_CEGADOR))
    end
    if db.verVenenosBolsa then
        for _, r in ipairs(P.D.recetas) do
            local n = cuenta[r[2]]
            if n and n > 0 and r[2] ~= P.POLVO_CEGADOR then lineas[#lineas + 1] = ("%d %s"):format(n, P.NombreObjeto(r[2])) end
        end
    end
    return lineas, cuenta
end

-- Recetas que conoces: cuántas tienes hechas y para cuántas te llegan los materiales.
function P.Recetas()
    local cuenta = P.Bolsas()
    local out = {}
    for _, r in ipairs(P.D.recetas) do
        if P.Conoce(r[1]) then
            local puedes, falta = math.huge, {}
            for _, m in ipairs(r[4]) do
                local tienes = cuenta[m[1]] or 0
                puedes = math.min(puedes, math.floor(tienes / m[2]))
                if tienes < m[2] then falta[#falta + 1] = ("%d %s"):format(m[2] - tienes, P.NombreObjeto(m[1])) end
            end
            out[#out + 1] = { hechizo = r[1], objeto = r[2], hechos = cuenta[r[2]] or 0,
                              puedes = puedes == math.huge and 0 or puedes, falta = falta, mats = r[4] }
        end
    end
    return out
end

----------------------------------------------------------------------
-- Barra en pantalla
----------------------------------------------------------------------
local function Tiempo(seg)
    if not seg then return "" end
    if seg >= 60 then return ("%d:%02d"):format(math.floor(seg / 60), math.floor(seg % 60)) end
    return ("%ds"):format(math.floor(seg))
end

local function Crear()
    if marco then return end
    marco = P.mod:Frame("Frame", "CMPicaroorVenenos", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    marco:SetSize(230, 60)
    marco:SetClampedToScreen(true)
    P.Mover(marco, "venenos")
    if marco.SetBackdrop then
        marco:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                            edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    end
    marco.filas = {}
    for i = 1, 2 do
        local f = CreateFrame("Frame", nil, marco)
        f:SetSize(220, 22)
        f.icono = f:CreateTexture(nil, "ARTWORK")
        f.icono:SetSize(20, 20); f.icono:SetPoint("LEFT", 4, 0)
        f.texto = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        f.texto:SetPoint("LEFT", f.icono, "RIGHT", 6, 0)
        f.texto:SetPoint("RIGHT", f, "RIGHT", -4, 0)
        f.texto:SetJustifyH("LEFT")
        marco.filas[i] = f
    end
    marco.extra = marco:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    marco.extra:SetJustifyH("LEFT")
    marco:SetScript("OnEnter", function(self)
        if not P.Opt().tooltipBarra then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:AddLine("Venenos (Picaroor)", 1, 0.82, 0)
        local rec = P.Recetas()
        if #rec == 0 then GameTooltip:AddLine("Aún no conoces recetas de venenos.", 1, 1, 1) end
        for _, r in ipairs(rec) do
            GameTooltip:AddDoubleLine(P.NombreObjeto(r.objeto), ("tienes %d · te llega para %d"):format(r.hechos, r.puedes),
                1, 1, 1, r.puedes > 0 and 0.4 or 1, r.puedes > 0 and 1 or 0.4, 0.4)
        end
        GameTooltip:AddLine("Arrastra para mover (si no está bloqueada).", 0.6, 0.6, 0.6)
        GameTooltip:Show()
    end)
    marco:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

function P.PintarVenenos()
    local db = P.Opt()
    local mostrar = P.Activo() and db.barra and P.EsPicaro() and (P.Conoce(P.HECHIZO_VENENOS) or db.barraSiempre)
    if not mostrar then if marco then marco:Hide() end return end
    Crear()
    local v = P.LeerVenenos()
    Vigilar(v)
    local combate = InCombatLockdown and InCombatLockdown()
    if db.soloSiFalta and not combate then
        local falta = #Faltan(v) > 0
        local corto = false
        for _, k in ipairs({ "md", "mi" }) do
            local x = v[k]
            if x.tiene and ((x.seg and x.seg < db.minutosAviso * 60) or (x.cargas and x.cargas > 0 and x.cargas < db.cargasAviso)) then corto = true end
        end
        if not (falta or corto) then marco:Hide(); return end
    end
    marco:SetScale(db.escala)
    marco:SetAlpha(db.opacidad)
    if marco.SetBackdropColor then
        marco:SetBackdropColor(0, 0, 0, db.fondo and 0.75 or 0)
        marco:SetBackdropBorderColor(1, 1, 1, db.fondo and 0.6 or 0)
    end
    marco:EnableMouse(not db.bloquear or db.tooltipBarra)
    local y, usadas = -6, 0
    for i, a in ipairs(ARMAS) do
        local x, fila = v[a[3]], marco.filas[i]
        if x.arma and (a[3] == "md" or db.vigilarIzquierda) then
            usadas = usadas + 1
            fila:ClearAllPoints(); fila:SetPoint("TOPLEFT", 4, y)
            fila.icono:SetTexture(GetInventoryItemTexture and GetInventoryItemTexture("player", a[1]) or nil)
            local txt
            if x.tiene then
                local poco = (x.seg and x.seg < db.minutosAviso * 60) or (x.cargas and x.cargas > 0 and x.cargas < db.cargasAviso)
                txt = (poco and "|cffffaa33" or "|cff66ff66") .. ((db.verNombre and x.nombre) or a[2]) .. "|r  " .. Tiempo(x.seg)
                if x.cargas and x.cargas > 0 then txt = txt .. ("  · %d cargas"):format(x.cargas) end
            else
                txt = "|cffff5555SIN VENENO|r  " .. a[2]
            end
            fila.texto:SetText(txt)
            fila:Show()
            y = y - 24
        else
            fila:Hide()
        end
    end
    local lineas = P.Recuento()
    if #lineas > 0 then
        marco.extra:ClearAllPoints(); marco.extra:SetPoint("TOPLEFT", 8, y - 2)
        marco.extra:SetText(table.concat(lineas, "\n"))
        marco.extra:Show()
        y = y - 2 - 13 * #lineas
    else
        marco.extra:Hide()
    end
    if usadas == 0 and #lineas == 0 then marco:Hide(); return end
    marco:SetHeight(-y + 6)
    if not marco.colocado then P.Colocar(marco, "venenos", 0, -180); marco.colocado = true end
    marco:Show()
end

function P.RecolocarVenenos() if marco then marco.colocado = false end end
function P.OcultarVenenos() if marco then marco:Hide() end end

-- Aviso de polvo de destello bajo (una vez hasta que vuelvas a tener suficiente).
local avisadoPolvo = false
function P.VigilarPolvo()
    local db = P.Opt()
    if not (P.Activo() and P.EsPicaro() and db.avisoPolvo) then return end
    local n = (P.Bolsas())[P.POLVO_DESTELLO] or 0
    if n < db.minPolvo then
        if not avisadoPolvo then
            avisadoPolvo = true
            Avisar(("Te quedan %d %s"):format(n, P.NombreObjeto(P.POLVO_DESTELLO)), false)
        end
    else
        avisadoPolvo = false
    end
end

----------------------------------------------------------------------
-- Vendedor: reponer
----------------------------------------------------------------------
-- Objetos que se pueden reponer (los materiales de las recetas y los polvos).
function P.Reponibles()
    local lista, visto = {}, {}
    local function Add(id) if not visto[id] then visto[id] = true; lista[#lista + 1] = id end end
    Add(P.POLVO_DESTELLO); Add(P.POLVO_CEGADOR); Add(P.HERRAMIENTAS)
    for id in pairs(P.D.compra) do Add(id) end
    table.sort(lista, function(a, b) return a < b end)
    return lista
end

local function ObjetoVendedor(i)
    if GetMerchantItemID then local ok, id = pcall(GetMerchantItemID, i); if ok and Num(id) then return id end end
    if GetMerchantItemLink then
        local ok, l = pcall(GetMerchantItemLink, i)
        l = ok and Str(l)
        local id = l and tonumber(l:match("item:(%d+)"))
        if id then return id end
    end
end

local function PrecioVendedor(i)
    if C_MerchantFrame and C_MerchantFrame.GetItemInfo then
        local ok, info = pcall(C_MerchantFrame.GetItemInfo, i)
        if ok and type(info) == "table" then return Num(info.price), Num(info.stackCount) or 1 end
    end
    if GetMerchantItemInfo then
        local r = { pcall(GetMerchantItemInfo, i) }
        if r[1] then return Num(r[4]), Num(r[5]) or 1 end
    end
end

-- Compra lo que falte hasta el objetivo de cada objeto. Devuelve lo comprado (texto) y el coste.
function P.Reponer(silencio)
    local db = P.Opt()
    if not (GetMerchantNumItems and BuyMerchantItem) then return end
    local ok, n = pcall(GetMerchantNumItems)
    n = ok and Num(n) or 0
    local cuenta = P.Bolsas()
    local hecho, coste = {}, 0
    local dinero = Num(GetMoney and GetMoney()) or 0
    for i = 1, n do
        local id = ObjetoVendedor(i)
        local objetivo = id and db.reponer[id]
        if objetivo and objetivo > 0 then
            local falta = objetivo - (cuenta[id] or 0)
            if falta > 0 then
                local precio, monton = PrecioVendedor(i)
                monton = math.max(1, monton or 1)
                local unidad = precio and precio / monton or 0
                local maxPila = 1
                if GetMerchantItemMaxStack then local okm, m = pcall(GetMerchantItemMaxStack, i); maxPila = okm and Num(m) or 1 end
                local comprados = 0
                while falta > 0 do
                    local q = math.min(falta, math.max(1, maxPila))
                    local gasto = unidad * q
                    if gasto > dinero - db.reservaOro * 10000 then break end
                    pcall(BuyMerchantItem, i, q)
                    dinero, coste = dinero - gasto, coste + gasto
                    falta, comprados = falta - q, comprados + q
                end
                if comprados > 0 then hecho[#hecho + 1] = ("%d %s"):format(comprados, P.NombreObjeto(id)) end
            end
        end
    end
    if not silencio then
        if #hecho > 0 then P.Print("repuesto: " .. table.concat(hecho, ", ") .. " (" .. P.Dinero(coste) .. ")")
        else P.Print("no falta nada de tu lista en este vendedor.") end
    end
    return hecho, coste
end

local botonVendedor
function P.AlAbrirVendedor()
    if not (P.Activo() and P.EsPicaro()) then return end
    local db = P.Opt()
    -- ¿Vende algo de la lista?
    local ok, n = pcall(GetMerchantNumItems)
    n = ok and Num(n) or 0
    local vende = false
    for i = 1, n do local id = ObjetoVendedor(i); if id and (db.reponer[id] or 0) > 0 then vende = true end end
    if not vende then if botonVendedor then botonVendedor:Hide() end return end
    if db.reponerSolo then P.Reponer(false) end
    if db.botonVendedor and MerchantFrame then
        if not botonVendedor then
            botonVendedor = CreateFrame("Button", "CMPicaroorReponer", MerchantFrame, "UIPanelButtonTemplate")
            botonVendedor:SetSize(110, 22)
            botonVendedor:SetPoint("TOPRIGHT", MerchantFrame, "TOPRIGHT", -40, -30)
            botonVendedor:SetText("Reponer pícaro")
            botonVendedor:SetScript("OnClick", function() if P.Activo() then P.Reponer(false) end end)
            P.mod:Track(botonVendedor)
        end
        botonVendedor:Show()
    end
end
function P.AlCerrarVendedor() if botonVendedor then botonVendedor:Hide() end end
