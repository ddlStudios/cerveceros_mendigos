-- Picaroor (CervecerosMendigos Clases): ayudas comunes de las dos partes (Venenos.lua y Robos.lua).
-- Todo lo que se lee del juego pasa por Num/Str: en el cliente moderno algunos valores pueden ser
-- «secretos» (no se pueden comparar ni sumar) y se tratan como desconocidos.
local ADDON, ns = ...
local P = {}
ns.Picaroor = P
P.D = ns.PicaroorDatos or { recetas = {}, compra = {}, cajas = {} }

local issecret = issecretvalue or function() return false end
P.issecret = issecret
function P.Num(v) if type(v) ~= "number" or issecret(v) then return nil end return v end
function P.Str(v) if type(v) ~= "string" or issecret(v) then return nil end return v end
function P.Opt() return P.mod.db end
function P.Print(m) if P.mod then P.mod:Print(m) end end
function P.Activo() return P.mod and P.mod:IsEnabled() end

-- Objetos y hechizos de pícaro que usa el módulo.
P.POLVO_DESTELLO, P.POLVO_CEGADOR, P.HERRAMIENTAS = 5140, 5530, 5060
P.HECHIZO_VENENOS, P.HECHIZO_ROBAR, P.HECHIZO_GANZUA = 2842, 921, 1804
P.HABILIDAD_GANZUA, P.HABILIDAD_VENENOS = 633, 40

function P.EsPicaro()
    local ok, _, clase = pcall(UnitClass, "player")
    return ok and clase == "ROGUE"
end

function P.Conoce(hechizo)
    if IsPlayerSpell then
        local ok, v = pcall(IsPlayerSpell, hechizo)
        if ok and v and not issecret(v) then return true end
    end
    if IsSpellKnown then
        local ok, v = pcall(IsSpellKnown, hechizo)
        if ok and v and not issecret(v) then return true end
    end
    return false
end

function P.NombreObjeto(id)
    local n
    if C_Item and C_Item.GetItemNameByID then n = P.Str(C_Item.GetItemNameByID(id)) end
    if not n and GetItemInfo then local ok, x = pcall(GetItemInfo, id); n = ok and P.Str(x) or nil end
    if not n and C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, id) end
    return n or ("objeto " .. id)
end

function P.IconoObjeto(id)
    if C_Item and C_Item.GetItemIconByID then local ok, i = pcall(C_Item.GetItemIconByID, id); if ok and i then return i end end
    if GetItemIcon then local ok, i = pcall(GetItemIcon, id); if ok and i then return i end end
    return "Interface\\Icons\\INV_Misc_QuestionMark"
end

-- Precio de venta de un objeto (enlace o id), en cobre; nil si el juego aún no lo tiene cargado.
function P.PrecioVenta(objeto)
    local ok, r = pcall(function() return { GetItemInfo(objeto) } end)
    if ok and r then return P.Num(r[11]) end
end

function P.NombreHechizo(id)
    if C_Spell and C_Spell.GetSpellName then local ok, n = pcall(C_Spell.GetSpellName, id); if ok and P.Str(n) then return n end end
    if GetSpellInfo then local ok, n = pcall(GetSpellInfo, id); if ok and P.Str(n) then return n end end
end

-- 12345 -> "1o 23p 45c" con colores de oro, plata y cobre.
function P.Dinero(c)
    c = math.floor(tonumber(c) or 0)
    local o, p, b = math.floor(c / 10000), math.floor(c / 100) % 100, c % 100
    local t = {}
    if o > 0 then t[#t + 1] = "|cffffd700" .. o .. "o|r" end
    if p > 0 then t[#t + 1] = "|cffc7c7cf" .. p .. "p|r" end
    if b > 0 or #t == 0 then t[#t + 1] = "|cffeda55f" .. b .. "c|r" end
    return table.concat(t, " ")
end

-- Bolsas: devuelve { [objeto] = cantidad } y la lista de huecos { bolsa, hueco, objeto, cantidad, enlace }.
-- Se guarda hasta que cambian las bolsas (P.InvalidarBolsas en BAG_UPDATE_DELAYED).
local cache
function P.InvalidarBolsas() cache = nil end
function P.Bolsas()
    if cache then return cache[1], cache[2] end
    local cuenta, huecos = P.LeerBolsas()
    cache = { cuenta, huecos }
    return cuenta, huecos
end
function P.LeerBolsas()
    local cuenta, huecos = {}, {}
    if not (C_Container and C_Container.GetContainerNumSlots and C_Container.GetContainerItemInfo) then return cuenta, huecos end
    for bolsa = 0, (NUM_BAG_SLOTS or 4) do
        local ok, n = pcall(C_Container.GetContainerNumSlots, bolsa)
        n = ok and P.Num(n) or 0
        for hueco = 1, n do
            local ok2, info = pcall(C_Container.GetContainerItemInfo, bolsa, hueco)
            local id = ok2 and info and P.Num(info.itemID)
            if id then
                local q = P.Num(info.stackCount) or 1
                cuenta[id] = (cuenta[id] or 0) + q
                huecos[#huecos + 1] = { bolsa = bolsa, hueco = hueco, id = id, n = q, enlace = P.Str(info.hyperlink) }
            end
        end
    end
    return cuenta, huecos
end

-- Rango de una habilidad (Abrir cerraduras = 633, Venenos = 40). En Forever están en C_SkillInfo.
function P.Habilidad(skillID, hechizoNombre)
    local c = C_SkillInfo
    local function pick(n)
        if type(_G[n]) == "function" then return _G[n] end
        if type(c) == "table" and type(c[n]) == "function" then return c[n] end
    end
    local num, info = pick("GetNumSkillLines"), pick("GetSkillLineInfo")
    if not (num and info) then return nil end
    local ok, n = pcall(num)
    if not ok or not P.Num(n) then return nil end
    local buscado = hechizoNombre and P.NombreHechizo(hechizoNombre)
    for i = 1, n do
        local r = { pcall(info, i) }
        if r[1] then
            local id, rango, nombre
            if type(r[2]) == "table" then id, rango, nombre = r[2].skillID, r[2].rank or r[2].skillRank, r[2].name or r[2].skillName
            else nombre, rango = r[2], r[5] end
            if (P.Num(id) and id == skillID) or (buscado and P.Str(nombre) and nombre == buscado) then
                return P.Num(rango)
            end
        end
    end
    return nil
end

-- Avisos: texto grande en el centro y sonido.
P.KITS = { { "RAID_WARNING", "Aviso de banda" }, { "ALARM_CLOCK_WARNING_3", "Alarma" }, { "IG_PVP_UPDATE", "Aviso JcJ" },
           { "READY_CHECK", "Comprobación de listos" }, { "IG_QUEST_LIST_COMPLETE", "Misión completada" } }
local NUM_KIT = { RAID_WARNING = 8959, ALARM_CLOCK_WARNING_3 = 12889, IG_PVP_UPDATE = 8174, READY_CHECK = 8960, IG_QUEST_LIST_COMPLETE = 878 }
function P.Sonar(kit)
    local id = (SOUNDKIT and SOUNDKIT[kit]) or NUM_KIT[kit]
    if id then pcall(PlaySound, id, "Master") end
end
function P.Aviso(texto, r, g, b)
    if RaidNotice_AddMessage and RaidWarningFrame then
        pcall(RaidNotice_AddMessage, RaidWarningFrame, texto, { r = r or 1, g = g or 0.8, b = b or 0.2 })
    elseif UIErrorsFrame and UIErrorsFrame.AddMessage then
        UIErrorsFrame:AddMessage(texto, r or 1, g or 0.8, b or 0.2)
    end
end

-- Marco móvil propio con posición guardada en db.pos[clave].
function P.Mover(f, clave)
    local db = P.Opt()
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(self) if not db.bloquear then self:StartMoving() end end)
    f:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local l, t = self:GetLeft(), self:GetTop()
        if l and t then db.pos[clave] = { l, t } end
    end)
end
function P.Colocar(f, clave, x, y)
    local p = P.Opt().pos[clave]
    f:ClearAllPoints()
    if p then f:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", p[1], p[2])
    else f:SetPoint("CENTER", UIParent, "CENTER", x, y) end
end
