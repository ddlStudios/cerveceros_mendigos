-- Picaroor (CervecerosMendigos Clases, pícaro) para WoW Forever: ayudas de pícaro fuera de combate.
--   * Venenos: tiempo y cargas de cada arma, avisos, materiales, recetas y reponer en el vendedor.
--   * Robar bolsillos: botín por sesión, total y zona; quién ya está robado (tooltip y placas).
--   * Abrir cerraduras: cajas de tus bolsas con botón para abrirlas y anuncio en Comercio.
-- Solo hace algo si juegas con un pícaro. Todo se configura en su pestaña (/picaroor).
local ADDON, ns = ...
local Hub = ns.Hub
local P = ns.Picaroor

local DEFAULTS = {
    -- Barra de venenos
    barra = true, barraSiempre = false, soloSiFalta = false, vigilarIzquierda = true, verNombre = true,
    escala = 1, opacidad = 1, fondo = true, bloquear = false, tooltipBarra = true,
    -- Avisos de venenos
    avisoAgotado = true, avisoPocoTiempo = true, minutosAviso = 5, avisoPocasCargas = true, cargasAviso = 10,
    avisoInstancia = true, avisoCombate = true,
    avisoTexto = true, avisoChat = false, avisoSonido = true, avisoKit = "RAID_WARNING",
    -- Materiales
    verPolvo = true, minPolvo = 5, avisoPolvo = true, verCegador = false, verVenenosBolsa = false,
    -- Vendedor
    reponer = { [5140] = 20 }, reponerSolo = false, botonVendedor = true, reservaOro = 0,
    -- Robar bolsillos
    robosChat = true, robosChatSesion = true, maxUltimos = 50, minutosRobado = 10,
    tooltipRobo = true, placas = true, placasSoloSigilo = true, tamPlaca = 18, altoPlaca = 4,
    -- Cajas y anuncio
    avisoCaja = true, canal = "Comercio", anuncioPausa = 60,
    anuncio = "Abro cajas con cerradura (Abrir cerraduras %h). Susurradme, propina voluntaria.",
    pos = {},
}

-- Datos que no son ajustes («Restaurar valores» no los borra).
local function DatosPropios(db)
    db.robos = db.robos or { n = 0, dinero = 0, valor = 0 }
    db.robosZona = db.robosZona or {}
    db.ultimosRobos = db.ultimosRobos or {}
    db.robados = db.robados or {}
end

local ticker = 0
local function Refrescar()
    P.PintarVenenos()
end

local tooltipHecho = false
local function EngancharTooltip()
    if tooltipHecho then return end
    tooltipHecho = true
    local function Linea(tt)
        if not P.Activo() or tt ~= GameTooltip or not tt.GetUnit then return end
        local ok, _, unidad = pcall(tt.GetUnit, tt)
        if ok and unidad and not P.issecret(unidad) then pcall(P.LineaTooltip, tt, unidad) end
    end
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Unit, Linea)
    elseif GameTooltip and GameTooltip.HookScript then
        pcall(GameTooltip.HookScript, GameTooltip, "OnTooltipSetUnit", Linea)
    end
end

local function Resumen(t)
    return ("%d robos · %s en dinero · %s en objetos"):format(t.n, P.Dinero(t.dinero), P.Dinero(t.valor))
end

local function MejoresZonas(n)
    local arr = {}
    for z, d in pairs(P.Opt().robosZona) do arr[#arr + 1] = { z, d } end
    table.sort(arr, function(a, b) return (a[2].dinero + a[2].valor) / math.max(1, a[2].n) > (b[2].dinero + b[2].valor) / math.max(1, b[2].n) end)
    local out = {}
    for i = 1, math.min(n, #arr) do
        local z, d = arr[i][1], arr[i][2]
        out[#out + 1] = ("%s: %d robos, %s por robo"):format(z, d.n, P.Dinero((d.dinero + d.valor) / math.max(1, d.n)))
    end
    return out
end

local mod = Hub:Register{
    key = "picaroor", dir = "Picaroor", name = "Picaroor", clase = "ROGUE",
    desc = "Para pícaros: tiempo y cargas de tus venenos con avisos, materiales y recetas, reponer en el vendedor, "
        .. "lo que sacas robando bolsillos (por sesión y por zona) y tus cajas con cerradura con botón para abrirlas.",
    defaults = DEFAULTS,
    slash = { "picaroor", "cmpicaro" },
    Init = function(m)
        P.mod = m
        DatosPropios(m.db)
        m:Event("UNIT_INVENTORY_CHANGED", function(_, _, u) if u == "player" then Refrescar() end end)
        m:Event("PLAYER_EQUIPMENT_CHANGED", Refrescar)
        m:Event("BAG_UPDATE_DELAYED", function() P.InvalidarBolsas(); Refrescar(); P.VigilarPolvo(); P.VigilarCajas() end)
        m:Event("PLAYER_ENTERING_WORLD", function()
            P.InvalidarBolsas(); Refrescar(); P.VigilarCajas()
            local ok, dentro, tipo = pcall(IsInInstance)
            if ok and dentro and not P.issecret(dentro) and (tipo == "party" or tipo == "raid" or tipo == "pvp" or tipo == "arena") then
                C_Timer.After(3, function() P.ComprobarSinVeneno("instancia") end)
            end
        end)
        m:Event("PLAYER_REGEN_DISABLED", function() P.ComprobarSinVeneno("combate") end)
        m:Event("PLAYER_REGEN_ENABLED", function() P.FinCombate(); Refrescar() end)
        m:Event("MERCHANT_SHOW", function() P.InvalidarBolsas(); P.AlAbrirVendedor() end)
        m:Event("MERCHANT_CLOSED", P.AlCerrarVendedor)
        m:Event("UNIT_SPELLCAST_SUCCEEDED", function(_, _, unidad, _, hechizo) P.AlLanzar(unidad, hechizo) end)
        m:Event("LOOT_OPENED", P.AlAbrirBotin)
        m:Event("LOOT_CLOSED", P.AlCerrarBotin)
        m:Event("NAME_PLATE_UNIT_ADDED", function(_, _, u) P.MarcarPlaca(u) end)
        m:Event("NAME_PLATE_UNIT_REMOVED", function(_, _, u) P.QuitarPlaca(u) end)
        m:Event("UPDATE_STEALTH", P.RefrescarPlacas)
        m:Event("PLAYER_TARGET_CHANGED", P.RefrescarPlacas)
        m:OnUpdate(function(_, e)
            ticker = ticker + e
            if ticker >= 0.5 then ticker = 0; Refrescar() end
        end)
        EngancharTooltip()
    end,
    Enable = function(m)
        P.mod = m
        DatosPropios(m.db)
        P.LimpiarRobados()
        P.InvalidarBolsas()
        Refrescar()
    end,
    Disable = function()
        P.OcultarVenenos()
        P.OcultarPlacas()
    end,
    OnReset = function()
        P.RecolocarVenenos()
        Refrescar()
    end,
    OnSlash = function(m, msg)
        local cmd = (msg or ""):lower():match("^(%S*)")
        if cmd == "cajas" then P.AbrirCajas()
        elseif cmd == "reponer" then P.Reponer(false)
        elseif cmd == "anunciar" then P.Anunciar()
        elseif cmd == "robos" then
            m:Print("sesión: " .. Resumen(P.sesion))
            m:Print("total: " .. Resumen(m.db.robos))
            for _, l in ipairs(MejoresZonas(5)) do m:Print("  " .. l) end
        elseif cmd == "venenos" then
            local rec = P.Recetas()
            if #rec == 0 then m:Print("aún no conoces recetas de venenos.") end
            for _, r in ipairs(rec) do
                m:Print(("%s: tienes %d, te llega para %d%s"):format(P.NombreObjeto(r.objeto), r.hechos, r.puedes,
                    #r.falta > 0 and (" (falta " .. table.concat(r.falta, ", ") .. ")") or ""))
            end
        elseif cmd == "" then Hub:Open("picaroor")
        else m:Print("comandos: cajas, venenos, robos, reponer, anunciar.") end
    end,
    BuildConfig = function(m, L)
        P.mod = m
        local db = m.db
        DatosPropios(db)
        local function G(k) return function() return db[k] end end
        local function S(k) return function(v) db[k] = v; Refrescar() end end
        if not P.EsPicaro() then
            L:Text("|cffff7755Este personaje no es pícaro: el módulo no hace nada con él.|r Los ajustes valen para tus pícaros.", true)
        end
        L:Button("Cajas con cerradura", 160, function() P.AbrirCajas() end)
        L:Button("Venenos que puedo hacer", 190, function() mod.def.OnSlash(m, "venenos") end, true)
        L:Button("Mis robos", 100, function() mod.def.OnSlash(m, "robos") end, true)
        L:Text("También: /picaroor cajas · venenos · robos · reponer · anunciar", true)

        L:Header("Barra de venenos")
        L:Check("Mostrar la barra de venenos", G("barra"), S("barra"))
        L:Check("  Mostrarla aunque aún no sepas hacer venenos", G("barraSiempre"), S("barraSiempre"))
        L:Check("  Fuera de combate, solo si falta veneno o queda poco", G("soloSiFalta"), S("soloSiFalta"))
        L:Check("  Vigilar también la mano izquierda", G("vigilarIzquierda"), S("vigilarIzquierda"))
        L:Check("  Nombre del veneno (si no, el de la mano)", G("verNombre"), S("verNombre"))
        L:Check("  Fondo y borde", G("fondo"), S("fondo"))
        L:Check("  Tooltip con tus recetas al pasar el ratón", G("tooltipBarra"), S("tooltipBarra"))
        L:Check("  Bloquear la posición", G("bloquear"), S("bloquear"))
        L:Slider("  Escala", 0.5, 2, 0.05, G("escala"), S("escala"), "%.2f")
        L:Slider("  Opacidad", 0.2, 1, 0.05, G("opacidad"), S("opacidad"), "%.2f")
        L:Button("Volver a su sitio", 140, function() db.pos.venenos = nil; P.RecolocarVenenos(); Refrescar() end)

        L:Header("Avisos de venenos")
        L:Check("Cuando se acaba el veneno de un arma", G("avisoAgotado"), S("avisoAgotado"))
        L:Check("Cuando queda poco tiempo", G("avisoPocoTiempo"), S("avisoPocoTiempo"))
        L:Slider("  Minutos", 1, 30, 1, G("minutosAviso"), S("minutosAviso"))
        L:Check("Cuando quedan pocas cargas", G("avisoPocasCargas"), S("avisoPocasCargas"))
        L:Slider("  Cargas", 1, 60, 1, G("cargasAviso"), S("cargasAviso"))
        L:Check("Al entrar en mazmorra, banda o campo de batalla sin veneno", G("avisoInstancia"), S("avisoInstancia"))
        L:Check("Al empezar a pelear sin veneno", G("avisoCombate"), S("avisoCombate"))
        L:Check("Aviso con texto grande", G("avisoTexto"), S("avisoTexto"))
        L:Check("Aviso en el chat", G("avisoChat"), S("avisoChat"))
        L:Check("Aviso con sonido", G("avisoSonido"), S("avisoSonido"))
        L:Choice("  Sonido", P.KITS, G("avisoKit"), function(v) db.avisoKit = v; P.Sonar(v) end)

        L:Header("Materiales")
        L:Check("En la barra: " .. P.NombreObjeto(P.POLVO_DESTELLO), G("verPolvo"), S("verPolvo"))
        L:Slider("  En rojo y aviso por debajo de", 0, 40, 1, G("minPolvo"), S("minPolvo"))
        L:Check("  Avisar cuando baje de ahí", G("avisoPolvo"), S("avisoPolvo"))
        L:Check("En la barra: " .. P.NombreObjeto(P.POLVO_CEGADOR), G("verCegador"), S("verCegador"))
        L:Check("En la barra: los venenos que llevas en las bolsas", G("verVenenosBolsa"), S("verVenenosBolsa"))

        L:Header("Reponer en el vendedor")
        L:Text("Cuántos quieres llevar de cada cosa (0 = no comprar). Al abrir un vendedor que lo venda, "
            .. "el botón «Reponer pícaro» compra lo que falte.", true)
        L:Check("Botón «Reponer pícaro» en la ventana del vendedor", G("botonVendedor"), S("botonVendedor"))
        L:Check("Reponer solo al abrir el vendedor (sin pulsar)", G("reponerSolo"), S("reponerSolo"))
        L:Slider("No gastar si me quedaría con menos de (oro)", 0, 100, 1, G("reservaOro"), S("reservaOro"))
        for _, id in ipairs(P.Reponibles()) do
            L:Slider("  " .. P.NombreObjeto(id), 0, 100, 1, function() return db.reponer[id] or 0 end,
                function(v) db.reponer[id] = v > 0 and v or nil end)
        end

        L:Header("Robar bolsillos")
        L:Check("Línea en el chat con lo que robas", G("robosChat"), S("robosChat"))
        L:Check("  Con el total de la sesión", G("robosChatSesion"), S("robosChatSesion"))
        L:Check("«Ya robado / Sin robar» en el tooltip de los humanoides", G("tooltipRobo"), S("tooltipRobo"))
        L:Check("Moneda encima de los que aún no has robado", G("placas"), function(v) db.placas = v; P.RefrescarPlacas() end)
        L:Check("  Solo mientras estás en sigilo", G("placasSoloSigilo"), function(v) db.placasSoloSigilo = v; P.RefrescarPlacas() end)
        L:Slider("  Tamaño de la moneda", 10, 40, 1, G("tamPlaca"), function(v) db.tamPlaca = v; P.RefrescarPlacas() end)
        L:Slider("  Altura sobre la placa", -10, 30, 1, G("altoPlaca"), function(v) db.altoPlaca = v; P.RefrescarPlacas() end)
        L:Slider("Recordar a quién robé durante (minutos)", 1, 60, 1, G("minutosRobado"), S("minutosRobado"))
        L:Slider("Últimos objetos robados guardados", 10, 200, 10, G("maxUltimos"), S("maxUltimos"))
        L:Button("Mis robos", 100, function() mod.def.OnSlash(m, "robos") end)
        L:Button("Nueva sesión", 120, function() P.sesion = { n = 0, dinero = 0, valor = 0 }; m:Print("sesión de robos a cero.") end, true)
        L:Button("Borrar todo el historial", 180, function()
            if IsShiftKeyDown and IsShiftKeyDown() then
                db.robos = { n = 0, dinero = 0, valor = 0 }; db.robosZona = {}; db.ultimosRobos = {}
                m:Print("historial de robos borrado.")
            else m:Print("Mayús+clic para borrar el historial de robos.") end
        end, true)

        L:Header("Cajas con cerradura")
        L:Check("Avisar en el chat cuando recibes una caja que ya puedes abrir", G("avisoCaja"), S("avisoCaja"))
        L:Edit("Anuncio (%h = tu habilidad)", G("anuncio"), function(v) if type(v) == "string" and not P.issecret(v) then db.anuncio = v:gsub("|", "") end end, "text", 300)
        L:Edit("Canal del anuncio", G("canal"), function(v) if type(v) == "string" and v ~= "" then db.canal = v end end, "text", 140)
        L:Slider("Pausa mínima entre anuncios (segundos)", 10, 600, 10, G("anuncioPausa"), S("anuncioPausa"))
        L:Button("Anunciar ahora", 140, function() P.Anunciar() end)
        L:Button("Cajas con cerradura", 160, function() P.AbrirCajas() end, true)
    end,
}
P.mod = mod
