-- Picaroor · Robar bolsillos y Abrir cerraduras: botín de cada robo (sesión, total y por zona),
-- marca de quién ya has robado, cajas con cerradura de tus bolsas y anuncio en Comercio.
local ADDON, ns = ...
local P = ns.Picaroor
local Num, Str = P.Num, P.Str

----------------------------------------------------------------------
-- Robar bolsillos
----------------------------------------------------------------------
local robando = 0           -- GetTime() del último Robar bolsillos
local dineroAntes           -- dinero al abrir el botín de un robo
local robo                  -- robo en curso { objetos = {}, valor = 0 }
P.sesion = { n = 0, dinero = 0, valor = 0, inicio = nil }

local function Zona() return Str(GetRealZoneText and GetRealZoneText()) or "?" end

function P.AlLanzar(unidad, hechizo)
    if unidad ~= "player" or Num(hechizo) ~= P.HECHIZO_ROBAR then return end
    robando = GetTime()
    local ok, guid = pcall(UnitGUID, "target")
    guid = ok and Str(guid)
    if guid then P.Opt().robados[guid] = time() end
    if P.RefrescarPlacas then P.RefrescarPlacas() end
end

function P.AlAbrirBotin()
    if GetTime() - robando > 3 then return end
    robando = 0
    robo = { objetos = {}, valor = 0, zona = Zona() }
    dineroAntes = Num(GetMoney and GetMoney())
    local ok, n = pcall(GetNumLootItems)
    n = ok and Num(n) or 0
    for i = 1, n do
        local okl, enlace = pcall(GetLootSlotLink, i)
        enlace = okl and Str(enlace)
        if enlace then
            local r = { pcall(GetLootSlotInfo, i) }
            local q = r[1] and Num(r[4]) or 1
            robo.objetos[#robo.objetos + 1] = { enlace, q }
            local precio = P.PrecioVenta(enlace)
            if precio then robo.valor = robo.valor + precio * q end
        end
    end
end

function P.AlCerrarBotin()
    if not robo then return end
    local db = P.Opt()
    local dinero = 0
    local ahora = Num(GetMoney and GetMoney())
    if ahora and dineroAntes and ahora > dineroAntes then dinero = ahora - dineroAntes end
    local r = robo
    robo, dineroAntes = nil, nil
    local s, t = P.sesion, db.robos
    s.inicio = s.inicio or time()
    s.n, s.dinero, s.valor = s.n + 1, s.dinero + dinero, s.valor + r.valor
    t.n, t.dinero, t.valor = t.n + 1, t.dinero + dinero, t.valor + r.valor
    local z = db.robosZona[r.zona] or { n = 0, dinero = 0, valor = 0 }
    db.robosZona[r.zona] = z
    z.n, z.dinero, z.valor = z.n + 1, z.dinero + dinero, z.valor + r.valor
    for _, o in ipairs(r.objetos) do
        table.insert(db.ultimosRobos, 1, { o[1], o[2], time(), r.zona })
    end
    while #db.ultimosRobos > db.maxUltimos do table.remove(db.ultimosRobos) end
    if db.robosChat then
        local partes = {}
        if dinero > 0 then partes[#partes + 1] = P.Dinero(dinero) end
        for _, o in ipairs(r.objetos) do partes[#partes + 1] = o[1] .. (o[2] > 1 and (" x" .. o[2]) or "") end
        P.Print("robado: " .. (#partes > 0 and table.concat(partes, ", ") or "nada") ..
            (db.robosChatSesion and ("  |cff999999(sesión: %d robos, %s)|r"):format(s.n, P.Dinero(s.dinero + s.valor)) or ""))
    end
end

-- Robados que ya han caducado (vuelven a aparecer los PNJ y se les puede robar otra vez).
function P.LimpiarRobados()
    local db = P.Opt()
    local lim = time() - db.minutosRobado * 60
    for guid, t in pairs(db.robados) do if t < lim then db.robados[guid] = nil end end
end

local HUMANOIDE = { Humanoide = true, Humanoid = true, ["Humanoïde"] = true }
-- ¿Se le puede robar? PNJ humanoide atacable. Devuelve robable, tiempo desde el robo (o nil).
function P.Robable(unidad)
    local ok, esJug = pcall(UnitIsPlayer, unidad)
    if not ok or P.issecret(esJug) or esJug then return false end
    local ok2, atacable = pcall(UnitCanAttack, "player", unidad)
    if not ok2 or P.issecret(atacable) or not atacable then return false end
    local ok3, tipo = pcall(UnitCreatureType, unidad)
    tipo = ok3 and Str(tipo)
    if not (tipo and HUMANOIDE[tipo]) then return false end
    local okg, guid = pcall(UnitGUID, unidad)
    guid = okg and Str(guid)
    local t = guid and P.Opt().robados[guid]
    if t and time() - t > P.Opt().minutosRobado * 60 then t = nil end
    return true, t and (time() - t) or nil
end

function P.LineaTooltip(tt, unidad)
    local db = P.Opt()
    if not (P.Activo() and P.EsPicaro() and db.tooltipRobo) then return end
    local robable, hace = P.Robable(unidad)
    if not robable then return end
    if hace then tt:AddLine(("Ya robado (hace %d min)"):format(math.floor(hace / 60)), 0.6, 0.6, 0.6)
    else tt:AddLine("Sin robar", 1, 0.82, 0) end
    tt:Show()
end

-- Moneda sobre la placa de los humanoides que aún no has robado (solo en sigilo, si se quiere).
local marcas = {}
local function Placa(unidad)
    if not (C_NamePlate and C_NamePlate.GetNamePlateForUnit) then return nil end
    local ok, p = pcall(C_NamePlate.GetNamePlateForUnit, unidad)
    if not ok or not p or P.issecret(p) then return nil end
    if p.IsForbidden and p:IsForbidden() then return nil end
    return p
end
function P.MarcarPlaca(unidad)
    local db = P.Opt()
    local p = Placa(unidad)
    if not p then return end
    local f = marcas[p]
    local enSigilo = IsStealthed and IsStealthed()
    local poner = P.Activo() and P.EsPicaro() and db.placas and (enSigilo or not db.placasSoloSigilo)
    if poner then
        local robable, hace = P.Robable(unidad)
        poner = robable and not hace
    end
    if not poner then if f then f:Hide() end return end
    if not f then
        f = CreateFrame("Frame", nil, p)
        f.tex = f:CreateTexture(nil, "OVERLAY")
        f.tex:SetAllPoints()
        f.tex:SetTexture("Interface\\MoneyFrame\\UI-GoldIcon")
        marcas[p] = f
    end
    f:SetSize(db.tamPlaca, db.tamPlaca)
    f:ClearAllPoints()
    f:SetPoint("BOTTOM", p, "TOP", 0, db.altoPlaca)
    f:Show()
end
function P.QuitarPlaca(unidad)
    local p = Placa(unidad)
    if p and marcas[p] then marcas[p]:Hide() end
end
function P.RefrescarPlacas()
    for i = 1, 40 do
        local u = "nameplate" .. i
        local ok, existe = pcall(UnitExists, u)
        if ok and existe and not P.issecret(existe) then P.MarcarPlaca(u) end
    end
end
function P.OcultarPlacas() for _, f in pairs(marcas) do f:Hide() end end

----------------------------------------------------------------------
-- Cajas con cerradura
----------------------------------------------------------------------
local CAJA = {}
for _, c in ipairs(P.D.cajas) do CAJA[c[1]] = c[2] end
P.CAJA = CAJA

-- Cajas en las bolsas: { bolsa, hueco, id, pide, enlace }
function P.Cajas()
    local _, huecos = P.Bolsas()
    local out = {}
    for _, h in ipairs(huecos) do
        local pide = CAJA[h.id]
        if pide then out[#out + 1] = { bolsa = h.bolsa, hueco = h.hueco, id = h.id, pide = pide, enlace = h.enlace } end
    end
    table.sort(out, function(a, b) if a.pide ~= b.pide then return a.pide < b.pide end return a.id < b.id end)
    return out
end

function P.MiGanzua() return P.Habilidad(P.HABILIDAD_GANZUA, P.HECHIZO_GANZUA) end

-- Aviso al recibir una caja que ya puedes abrir.
local cajasVistas
function P.VigilarCajas()
    local db = P.Opt()
    if not (P.Activo() and P.EsPicaro()) then return end
    local cajas = P.Cajas()
    local ahora = {}
    for _, c in ipairs(cajas) do ahora[c.bolsa .. ":" .. c.hueco .. ":" .. c.id] = c end
    if cajasVistas and db.avisoCaja then
        local mia = P.MiGanzua()
        for k, c in pairs(ahora) do
            if not cajasVistas[k] and mia and mia >= c.pide then
                P.Print(("tienes una caja que ya puedes abrir: %s (pide %d, tienes %d)."):format(c.enlace or P.NombreObjeto(c.id), c.pide, mia))
            end
        end
    end
    cajasVistas = ahora
    if P.RefrescarVentanaCajas then P.RefrescarVentanaCajas() end
end

-- Ventana de cajas: un botón seguro por caja (clic izquierdo = Abrir cerradura, derecho = abrirla).
local ventana, pendiente = nil, false
local FILAS = 12
local function CrearVentana()
    if ventana then return end
    local UI = ns.Hub.UI
    ventana = UI.MakeWindow("CMPicaroorCajas", "Cajas con cerradura", 380, 120 + FILAS * 26)
    P.mod:Track(ventana)
    ventana.info = ventana:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    ventana.info:SetPoint("TOPLEFT", 18, -32); ventana.info:SetWidth(340); ventana.info:SetJustifyH("LEFT")
    ventana.filas = {}
    for i = 1, FILAS do
        local b = CreateFrame("Button", "CMPicaroorCaja" .. i, ventana, "SecureActionButtonTemplate")
        b:SetSize(340, 24)
        b:SetPoint("TOPLEFT", 18, -64 - (i - 1) * 26)
        b:RegisterForClicks("AnyUp", "AnyDown")
        b:SetAttribute("type1", "macro"); b:SetAttribute("type2", "macro")
        b.icono = b:CreateTexture(nil, "ARTWORK"); b.icono:SetSize(22, 22); b.icono:SetPoint("LEFT", 0, 0)
        b.texto = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        b.texto:SetPoint("LEFT", 28, 0); b.texto:SetPoint("RIGHT", 0, 0); b.texto:SetJustifyH("LEFT")
        b.luz = b:CreateTexture(nil, "HIGHLIGHT"); b.luz:SetAllPoints(); b.luz:SetColorTexture(1, 1, 1, 0.08)
        ventana.filas[i] = b
    end
    ventana.vacia = ventana:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    ventana.vacia:SetPoint("TOP", 0, -80)
    ventana.vacia:SetText("No llevas cajas con cerradura.")
    UI.NewButton(ventana, "Anunciar en Comercio", 170, "BOTTOMLEFT", 18, 14, function() P.Anunciar() end)
    ventana:SetScript("OnShow", function() P.RefrescarVentanaCajas() end)
end

function P.RefrescarVentanaCajas()
    if not (ventana and ventana:IsShown()) then return end
    if InCombatLockdown and InCombatLockdown() then pendiente = true; return end
    pendiente = false
    local mia = P.MiGanzua()
    local cajas = P.Cajas()
    local cuenta = P.Bolsas()
    local herr = (cuenta[P.HERRAMIENTAS] or 0) > 0
    ventana.info:SetText(("Abrir cerraduras: %s%s\nClic izquierdo: abrir la cerradura · clic derecho: abrir la caja"):format(
        mia and tostring(mia) or "?", herr and "" or ("  |cffff5555(no llevas " .. P.NombreObjeto(P.HERRAMIENTAS) .. ")|r")))
    local ganzua = P.NombreHechizo(P.HECHIZO_GANZUA) or "Abrir cerradura"
    for i, b in ipairs(ventana.filas) do
        local c = cajas[i]
        if c then
            local usar = ("/use %d %d"):format(c.bolsa, c.hueco)
            b:SetAttribute("macrotext1", "/cast " .. ganzua .. "\n" .. usar)
            b:SetAttribute("macrotext2", usar)
            b.icono:SetTexture(P.IconoObjeto(c.id))
            local puede = mia and mia >= c.pide
            b.texto:SetText(("%s  %spide %d|r"):format(c.enlace or P.NombreObjeto(c.id), puede and "|cff66ff66" or "|cffff5555", c.pide))
            b:Show()
        else
            b:Hide()
        end
    end
    ventana.vacia:SetShown(#cajas == 0)
end

function P.FinCombate() if pendiente then P.RefrescarVentanaCajas() end end

function P.AbrirCajas()
    if InCombatLockdown and InCombatLockdown() then P.Print("en combate no se puede abrir la ventana de cajas."); return end
    CrearVentana()
    if ventana:IsShown() and ventana.abierta then ventana:Hide(); ventana.abierta = false
    else ventana:Show(); ventana.abierta = true; P.RefrescarVentanaCajas() end
end

----------------------------------------------------------------------
-- Anuncio en Comercio
----------------------------------------------------------------------
local ultimoAnuncio = 0
function P.TextoAnuncio()
    local db = P.Opt()
    local mia = P.MiGanzua()
    return (db.anuncio:gsub("%%h", mia and tostring(mia) or "?"))
end
function P.Anunciar()
    local db = P.Opt()
    local ahora = GetTime()
    if ahora - ultimoAnuncio < db.anuncioPausa then
        P.Print(("espera %d s para volver a anunciar."):format(math.ceil(db.anuncioPausa - (ahora - ultimoAnuncio))))
        return
    end
    local id = GetChannelName and GetChannelName(db.canal)
    id = Num(id)
    if not id or id == 0 then P.Print("no estás en el canal «" .. db.canal .. "» (entra en una ciudad o cambia el canal en la configuración)."); return end
    ultimoAnuncio = ahora
    pcall(SendChatMessage, P.TextoAnuncio(), "CHANNEL", nil, id)
end
