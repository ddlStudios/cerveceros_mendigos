-- Brujo (CervecerosMendigos Clases): lo de cualquier brujo (montado con el motor de ComunClases).
--   Rol (aflicción, demonología, destrucción), barra para invocar demonios, tu demonio (vida, aviso si no lo
--   llevas), aviso si vas sin Piel/Armadura demoníaca, fragmentos de alma, piedras de salud y de alma con botón
--   para crearlas, tus perjuicios y maldiciones en el objetivo, consejo de Transfusión de vida, maná y enfriamientos.
local ADDON, ns = ...
local U = ns.CU

local DEMONIOS = { { "diablillo", { 688 } }, { "abisario", { 697 } }, { "sucubo", { 712 } }, { "manafago", { 691 } } }
local avisadoDemonio = false

U.Modulo{
    key = "brujo", dir = "Brujo", name = "Brujo", clase = "WARLOCK", slash = { "cmbrujo" },
    desc = "Para cualquier brujo: elige tu rol, invoca demonios con un clic, tu demonio y su vida, aviso si vas sin "
        .. "armadura, fragmentos de alma y piedras de salud y de alma (con botón para crearlas), tus perjuicios y "
        .. "maldiciones en el objetivo, consejo de Transfusión de vida, maná y enfriamientos.",
    roles = { { "afliccion", "Aflicción" }, { "demonologia", "Demonología" }, { "destruccion", "Destrucción" } },
    pistas = { { "afliccion", { 18265, 18879, 18880, 18881 } }, { "demonologia", { 19028, 18788 } }, { "destruccion", { 17962, 18930, 18931, 18932 } },
               { "afliccion", { 18288 } }, { "demonologia", { 18708 } }, { "destruccion", { 17877, 18867, 18868, 18869, 18870, 18871 } } },
    barra = { "Invocar demonio", DEMONIOS,
        activa = function(id)
            local ok, fam = pcall(UnitCreatureFamily, "pet")
            fam = ok and U.Str(fam)
            if not fam then return false end
            return U.Nombre(id):lower():find(fam:lower(), 1, true) ~= nil
        end },
    propios = { { "armadura", { { 687, 696 }, { 706, 1086, 11733, 11734, 11735 } }, "Piel o Armadura demoníaca" } },
    materiales = {
        { "fragmentos", { 6265 }, nil, 5 },
        { "salud", { 5512, 19004, 19005, 5511, 19006, 19007, 5509, 19008, 19009, 5510, 19010, 19011, 9421, 19012, 19013 }, "Piedra de salud", 1,
          crear = { 6201, 6202, 5699, 11729, 11730 } },
        { "alma", { 5232, 16892, 16893, 16895, 16896 }, "Piedra de alma", 1, crear = { 693, 20752, 20755, 20756, 20757 } },
        { "infernal", { 5565 }, nil, 1, si = { 1122 } },
        { "figurilla", { 16583 }, nil, 1, si = { 18540 } },
    },
    objetivo = {
        { "corrupcion", { 172, 6222, 6223, 7648, 11671, 11672, 25311 }, "Corrupción" },
        { "agonia", { 980, 1014, 6217, 11711, 11712, 11713 }, "Maldición de agonía" },
        { "inmolar", { 348, 707, 1094, 2941, 11665, 11667, 11668, 25309 }, "Inmolar" },
        { "elementos", { 1490, 11721, 11722 }, "Maldición de los elementos" },
        { "sombras", { 17862, 17937 }, "Maldición de las Sombras" },
        { "temeridad", { 704, 7658, 7659, 11717 }, "Maldición de temeridad", defecto = false },
        { "debilidad", { 702, 1108, 6205, 7646, 11707, 11708 }, "Maldición de debilidad", defecto = false },
        { "lenguas", { 1714, 11719 }, "Maldición de lenguas", defecto = false },
        { "miedo", { 5782, 6213, 6215 }, "Miedo" },
        { "desterrar", { 710, 18647 }, "Desterrar" },
    },
    cds = { { "espiral", { 6789, 17925, 17926 }, "Espiral de la muerte" }, { "aullido", { 5484, 17928 }, "Aullido de terror" } },
    mana = true,
    defaults = { demonio = true, avisoSinDemonio = true, vidaDemonio = 30, transfusion = true, transfusionMana = 30, transfusionVida = 70 },
    extra = function(c)
        local db, l = c.db, c.lineas
        if not c.combate then avisadoDemonio = false end
        if db.demonio then
            local ok, hay = pcall(UnitExists, "pet")
            if ok and hay and not U.issecret(hay) then
                local okh, h = pcall(UnitHealth, "pet"); local okm, hm = pcall(UnitHealthMax, "pet")
                local okn, n = pcall(UnitName, "pet")
                local pc = okh and okm and U.Num(h) and U.Num(hm) and hm > 0 and h / hm * 100
                l[#l + 1] = ("%s%s%s|r"):format(pc and pc < db.vidaDemonio and "|cffff5555" or "|cffffffff", okn and U.Str(n) or "Demonio",
                    pc and (" %d%%"):format(pc) or "")
            else
                l[#l + 1] = "|cff999999Sin demonio|r"
                if c.combate and db.avisoSinDemonio and not avisadoDemonio then
                    avisadoDemonio = true
                    U.Avisar(c.mod, "Peleando sin demonio", true, 1, 0.5, 0.2)
                end
            end
        end
        if db.transfusion then
            local m, mx = U.Mana()
            local okh, h = pcall(UnitHealth, "player"); local okm, hm = pcall(UnitHealthMax, "player")
            h, hm = okh and U.Num(h), okm and U.Num(hm)
            if m and mx and mx > 0 and h and hm and hm > 0 and m / mx * 100 < db.transfusionMana and h / hm * 100 > db.transfusionVida then
                l[#l + 1] = "|cff66ff66" .. U.Nombre(1454, "Transfusión de vida") .. ": te sobra vida|r"
            end
        end
    end,
    config = function(m, L)
        local db = m.db
        L:Header("Demonio y Transfusión de vida")
        L:Check("Tu demonio y su vida", function() return db.demonio end, function(v) db.demonio = v end)
        L:Slider("  En rojo por debajo de (% de vida)", 0, 90, 5, function() return db.vidaDemonio end, function(v) db.vidaDemonio = v end)
        L:Check("  Aviso si peleas sin demonio", function() return db.avisoSinDemonio end, function(v) db.avisoSinDemonio = v end)
        L:Check("Consejo de Transfusión de vida (poco maná y mucha vida)", function() return db.transfusion end, function(v) db.transfusion = v end)
        L:Slider("  Cuando el maná baje del (%)", 5, 80, 5, function() return db.transfusionMana end, function(v) db.transfusionMana = v end)
        L:Slider("  y la vida esté por encima del (%)", 30, 100, 5, function() return db.transfusionVida end, function(v) db.transfusionVida = v end)
    end,
}
