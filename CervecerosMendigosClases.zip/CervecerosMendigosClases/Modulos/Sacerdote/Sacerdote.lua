-- Sacerdote (CervecerosMendigos Clases): lo de cualquier sacerdote (montado con el motor de ComunClases).
--   Rol (disciplina, sagrado, sombras), aviso si vas sin Fuego interno, Palabra de poder: entereza, Espíritu
--   divino y Protección contra las Sombras al grupo (con botón), velas, tu Encadenar no-muerto en el objetivo,
--   maná con la regla de los 5 segundos y enfriamientos (Desvanecerse, Alarido psíquico, Resguardo de miedo...).
local ADDON, ns = ...
local U = ns.CU

U.Modulo{
    key = "sacerdote", dir = "Sacerdote", name = "Sacerdote", clase = "PRIEST", slash = { "cmsacerdote" },
    desc = "Para cualquier sacerdote: elige tu rol, aviso si vas sin Fuego interno, a quién le falta Entereza, Espíritu "
        .. "divino o Protección contra las Sombras (con botón), tus velas, Encadenar no-muerto en el objetivo, maná con "
        .. "la regla de los 5 segundos y tus enfriamientos.",
    roles = { { "disciplina", "Disciplina" }, { "sagrado", "Sagrado" }, { "sombras", "Sombras" } },
    pistas = { { "disciplina", { 10060 } }, { "sagrado", { 724, 27870, 27871 } }, { "sombras", { 15473 } },
               { "disciplina", { 14751, 14752, 14818, 14819, 27841 } }, { "sagrado", { 15237, 15430, 15431, 27799, 27800, 27801 } },
               { "sombras", { 15286, 15487 } } },
    propios = { { "fuego", { { 588, 7128, 602, 1006, 10951, 10952 } }, "Fuego interno" } },
    beneficios = {
        { "entereza", { 1243, 1244, 1245, 2791, 10937, 10938 }, "Palabra de poder: entereza", grupo = { 21562, 21564 } },
        { "espiritu", { 14752, 14818, 14819, 27841 }, "Espíritu divino", grupo = { 27681 }, soloMana = true },
        { "sombras", { 976, 10957, 10958 }, "Protección contra las Sombras", grupo = { 27683 }, defecto = false },
    },
    materiales = { { "velaSagrada", { 17028 }, nil, 5, si = { 21562 } }, { "velaBendita", { 17029 }, nil, 5, si = { 21564, 27681, 27683 } } },
    objetivo = { { "encadenar", { 9484, 9485, 10955 }, "Encadenar no-muerto" } },
    cds = { { "desvanecerse", { 586, 9578, 9579, 9592, 10941, 10942 }, "Desvanecerse" }, { "alarido", { 8122, 8124, 10888, 10890 }, "Alarido psíquico" },
            { "resguardo", { 6346 }, "Resguardo de miedo", anunciar = true }, { "plegaria", { 13908, 19236, 19238, 19240, 19241, 19242, 19243 }, "Rezo desesperado" } },
    mana = true,
}
