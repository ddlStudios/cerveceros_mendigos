-- Druida (CervecerosMendigos Clases): lo de cualquier druida.
--   * Rol: automático (por talentos y forma), feral, sanador o ambos. Lo usan los módulos Feral y Sanador.
--   * Barra de formas con lo que cuesta cada cambio y aviso si no te llega el maná para volver a la forma.
--   * Beneficios: a quién le falta (o se le acaba) Marca de lo Salvaje y Espinas, con botón para ponérselo.
--   * Materiales (bayas, raíces y semillas) con aviso, y enfriamientos de Renacer y Estimular con anuncio.
local ADDON, ns = ...
local Hub = ns.Hub
local D = ns.Druida
local Num, Str = D.Num, D.Str

local MARCA = { 1126, 5232, 6756, 5234, 8907, 9884, 9885 }
local DON = { 21849, 21850 }
local ESPINAS = { 467, 782, 1075, 8914, 9756, 9910 }
local RENACER = { 20484, 20739, 20742, 20747, 20748 }
local ESTIMULAR = { 29166 }
local SEMILLAS = { 17034, 17035, 17036, 17037, 17038 }        -- una por rango de Renacer
local BAYAS = { 17021, 17026 }                                   -- Don de lo Salvaje rango 1 y 2
local ENFRIA = { renacer = 1800, estimular = 360 }

local DEFAULTS = {
    rol = "auto",
    -- Marco
    escala = 1, opacidad = 1, bloquear = false, fondo = true,
    -- Formas
    formas = true, formasCoste = true, tamForma = 30, avisoManaForma = true, avisoHumanoide = false,
    -- Beneficios
    beneficios = true, marcaGrupo = true, marcaBanda = false, espinasYo = true, espinasGrupo = false,
    minutosBeneficio = 2, avisoBeneficios = true, repetirBeneficios = 5, botonBeneficio = true, soloFueraCombate = true,
    -- Materiales
    verMateriales = true, minSemillas = 2, minBayas = 5, avisoMateriales = true,
    -- Enfriamientos
    enfriamientos = true, tamIcono = 32, verRenacer = true, verEstimular = true,
    anunciar = true, canal = "auto", textoRenacer = "Renacer en %t", textoEstimular = "Estimular en %t",
    avisoListo = false,
    -- Avisos
    avisoTexto = true, avisoChat = false, avisoSonido = true, avisoKit = "RAID_WARNING",
    pos = {},
}

local mod, db, marco
local avisos = { manaForma = false, beneficios = 0, materiales = false }
local objetivoLanzado = {}   -- castGUID / hechizo -> nombre del objetivo (UNIT_SPELLCAST_SENT)
local mover = false

----------------------------------------------------------------------
-- Formas
----------------------------------------------------------------------
local pendiente = false
local function CrearFormas()
    if not marco then return end
    if InCombatLockdown and InCombatLockdown() then pendiente = true; return end
    pendiente = false
    marco.formas = marco.formas or {}
    local lista = {}
    local ok, n = pcall(GetNumShapeshiftForms)
    n = ok and Num(n) or 0
    for i = 1, n do
        local r = { pcall(GetShapeshiftFormInfo, i) }
        local id = r[1] and Num(r[5])
        if id then lista[#lista + 1] = { id = id, icono = r[2] } end
    end
    -- Botón para volver a humanoide.
    lista[#lista + 1] = { id = 0, icono = "Interface\\Icons\\Ability_Druid_Mangle", humano = true }
    for i, x in ipairs(lista) do
        local b = marco.formas[i]
        if not b then
            b = CreateFrame("Button", "CMDruidaForma" .. i, marco, "SecureActionButtonTemplate")
            b:RegisterForClicks("AnyUp", "AnyDown")
            b.tex = b:CreateTexture(nil, "ARTWORK"); b.tex:SetAllPoints()
            b.coste = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); b.coste:SetPoint("BOTTOM", 0, 1)
            b.rojo = b:CreateTexture(nil, "OVERLAY"); b.rojo:SetAllPoints(); b.rojo:SetColorTexture(1, 0, 0, 0.35)
            b.activa = b:CreateTexture(nil, "OVERLAY"); b.activa:SetAllPoints()
            b.activa:SetTexture("Interface\\Buttons\\CheckButtonHilight"); b.activa:SetBlendMode("ADD")
            b:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_TOP")
                GameTooltip:SetText(self.humano and "Volver a humanoide" or D.Nombre(self.id))
                if self.costeN then GameTooltip:AddLine(("Cuesta %d de maná"):format(self.costeN), 0.5, 0.7, 1) end
                GameTooltip:Show()
            end)
            b:SetScript("OnLeave", function() GameTooltip:Hide() end)
            marco.formas[i] = b
        end
        b.id, b.humano = x.id, x.humano
        b:SetAttribute("type", "macro")
        b:SetAttribute("macrotext", x.humano and "/cancelform" or ("/cast " .. D.Nombre(x.id)))
        b.tex:SetTexture(x.icono)
        b:Show()
    end
    for i = #lista + 1, #marco.formas do marco.formas[i]:Hide() end
    marco.nFormas = #lista
end

----------------------------------------------------------------------
-- Beneficios
----------------------------------------------------------------------
local function FaltanBeneficios()
    local faltan, primero = {}, nil
    local nMarca, nDon, nEsp = D.Nombre(MARCA[1]), D.Nombre(DON[1]), D.Nombre(ESPINAS[1])
    local conoceMarca, conoceEsp = D.ConoceAlguno(MARCA), D.ConoceAlguno(ESPINAS)
    local lim = GetTime() + db.minutosBeneficio * 60
    local function Falta(u, nombre, otro)
        local fin = D.Aura(u, nombre)
        if fin == nil then return false end      -- no se sabe: no molestar
        if not fin and otro then fin = D.Aura(u, otro) end
        return (not fin) or (fin ~= math.huge and fin < lim)
    end
    local miembros = db.marcaGrupo and D.Miembros(db.marcaBanda) or { "player" }
    for _, u in ipairs(miembros) do
        local okv, vivo = pcall(UnitIsDeadOrGhost, u)
        local okr, cerca = pcall(UnitInRange, u)
        local valido = not (okv and vivo and not D.issecret(vivo)) and (u == "player" or not okr or D.issecret(cerca) or cerca ~= false)
        if valido then
            local okn, nombre = pcall(UnitName, u)
            nombre = okn and Str(nombre) or u
            if conoceMarca and Falta(u, nMarca, nDon) then
                faltan[#faltan + 1] = nMarca .. ": " .. nombre
                primero = primero or { u, MARCA, nombre }
            end
            if conoceEsp and ((u == "player" and db.espinasYo) or (u ~= "player" and db.espinasGrupo)) and Falta(u, nEsp) then
                faltan[#faltan + 1] = nEsp .. ": " .. nombre
                primero = primero or { u, ESPINAS, nombre }
            end
        end
    end
    return faltan, primero
end

----------------------------------------------------------------------
-- Materiales y enfriamientos
----------------------------------------------------------------------
local function Materiales()
    local out, bajo = {}, false
    local _, rRen = D.Mejor(RENACER)
    if rRen then
        local id = SEMILLAS[rRen]
        local n = D.ContarObjeto(id)
        if n < db.minSemillas then bajo = true end
        out[#out + 1] = (n < db.minSemillas and "|cffff5555%d|r %s" or "%d %s"):format(n, D.NombreObjeto(id))
    end
    local _, rDon = D.Mejor(DON)
    if rDon then
        local id = BAYAS[rDon]
        local n = D.ContarObjeto(id)
        if n < db.minBayas then bajo = true end
        out[#out + 1] = (n < db.minBayas and "|cffff5555%d|r %s" or "%d %s"):format(n, D.NombreObjeto(id))
    end
    return out, bajo
end

local function Queda(clave, ids)
    local id = D.Mejor(ids)
    if not id then return nil end
    local q = D.Enfriamiento(id)
    if q then return q, id end
    local t = db.lanzado and db.lanzado[clave]
    if t then return math.max(0, ENFRIA[clave] - (time() - t)), id end
    return 0, id
end

local function Canal()
    if db.canal ~= "auto" then return db.canal end
    local okr, banda = pcall(IsInRaid)
    if okr and banda and not D.issecret(banda) then return "RAID" end
    local okg, grupo = pcall(IsInGroup)
    if okg and grupo and not D.issecret(grupo) then return "PARTY" end
    return nil
end

local function AlLanzar(unidad, hechizo)
    if unidad ~= "player" then return end
    hechizo = Num(hechizo)
    if not hechizo then return end
    local clave
    for _, id in ipairs(RENACER) do if id == hechizo then clave = "renacer" end end
    if hechizo == ESTIMULAR[1] then clave = "estimular" end
    if not clave then return end
    db.lanzado = db.lanzado or {}
    db.lanzado[clave] = time()
    local quien = objetivoLanzado[hechizo] or "?"
    objetivoLanzado[hechizo] = nil
    if db.anunciar then
        local canal = Canal()
        local txt = (clave == "renacer" and db.textoRenacer or db.textoEstimular):gsub("%%t", quien)
        if canal then pcall(SendChatMessage, txt, canal) end
    end
end

----------------------------------------------------------------------
-- Marco y pintado
----------------------------------------------------------------------
local function Crear()
    if marco then return end
    marco = mod:Frame("Frame", "CMDruida", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    marco:SetSize(220, 40)
    D.Movil(mod, marco, "druida", function() return db.bloquear and not mover end)
    if marco.SetBackdrop then
        marco:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                            edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    end
    marco.cds = CreateFrame("Frame", nil, marco)
    marco.texto = marco:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    marco.texto:SetJustifyH("LEFT")
    marco.boton = CreateFrame("Button", "CMDruidaBeneficio", marco, "SecureActionButtonTemplate, UIPanelButtonTemplate")
    marco.boton:SetSize(200, 20)
    marco.boton:RegisterForClicks("AnyUp", "AnyDown")
    CrearFormas()
end

local function Pintar()
    -- El marco lleva botones seguros: en combate no se puede mostrar, ocultar ni mover.
    if not (mod and mod:IsEnabled() and D.EsDruida()) then
        if marco and not D.EnCombate() then marco:Hide() end
        return
    end
    if not marco and D.EnCombate() then return end
    Crear()
    local combate = D.EnCombate()
    if pendiente and not combate then CrearFormas() end
    marco:SetScale(db.escala); marco:SetAlpha(db.opacidad)
    if marco.SetBackdropColor then
        marco:SetBackdropColor(0, 0, 0, db.fondo and 0.7 or 0)
        marco:SetBackdropBorderColor(1, 1, 1, db.fondo and 0.5 or 0)
    end
    local y, ancho = -6, 200
    -- Formas.
    local forma, idxForma = D.Forma()
    local mana = D.Mana()
    if db.formas and marco.nFormas then
        local t = db.tamForma
        for i = 1, marco.nFormas do
            local b = marco.formas[i]
            if not combate then
                b:SetSize(t, t); b:ClearAllPoints(); b:SetPoint("TOPLEFT", marco, "TOPLEFT", 6 + (i - 1) * (t + 4), y)
            end
            local coste = not b.humano and D.Coste(b.id) or nil
            b.costeN = coste
            b.coste:SetText(db.formasCoste and coste and tostring(coste) or "")
            b.rojo:SetShown(coste and mana and mana < coste or false)
            b.activa:SetShown((b.humano and not forma) or (idxForma == i))
            if not combate then b:Show() end
        end
        ancho = math.max(ancho, 12 + marco.nFormas * (t + 4))
        y = y - t - 6
    elseif marco.formas and not combate then
        for _, b in ipairs(marco.formas) do b:Hide() end
    end
    -- Aviso: en forma y sin maná para volver a ella.
    if db.avisoManaForma and forma and (forma == "gato" or forma == "oso") and mana then
        local ids = forma == "gato" and { 768 } or { 5487, 9634 }
        local coste = D.Coste(D.Mejor(ids) or ids[1])
        if coste and mana < coste then
            if not avisos.manaForma then
                avisos.manaForma = true
                D.Avisar(mod, "Sin maná para volver a la forma si sales", true, 0.4, 0.6, 1)
            end
        else
            avisos.manaForma = false
        end
    end
    -- Enfriamientos.
    if db.enfriamientos then
        local lista = {}
        local function Add(clave, ids, ver, etiqueta)
            if not ver then return end
            local q, id = Queda(clave, ids)
            if id then lista[#lista + 1] = { icono = D.Icono(id), queda = q, etiqueta = etiqueta } end
        end
        Add("renacer", RENACER, db.verRenacer, "Renacer")
        Add("estimular", ESTIMULAR, db.verEstimular, "Estimular")
        if #lista > 0 then
            marco.cds:ClearAllPoints(); marco.cds:SetPoint("TOPLEFT", marco, "TOPLEFT", 6, y)
            marco.cds:SetSize(#lista * (db.tamIcono + 6), db.tamIcono)
            D.Iconos(marco.cds, lista, db.tamIcono)
            marco.cds:Show()
            y = y - db.tamIcono - 16
        else
            marco.cds:Hide()
        end
    else
        marco.cds:Hide()
    end
    -- Materiales y beneficios.
    local lineas = {}
    if db.verMateriales then
        local m, bajo = Materiales()
        for _, l in ipairs(m) do lineas[#lineas + 1] = l end
        if bajo and db.avisoMateriales and not avisos.materiales then
            avisos.materiales = true
            D.Avisar(mod, "Te quedan pocos materiales de druida", false)
        elseif not bajo then
            avisos.materiales = false
        end
    end
    local primero
    if db.beneficios and (not combate or not db.soloFueraCombate) then
        local faltan
        faltan, primero = FaltanBeneficios()
        for i = 1, math.min(#faltan, 6) do lineas[#lineas + 1] = "|cffffaa33" .. faltan[i] .. "|r" end
        if #faltan > 6 then lineas[#lineas + 1] = ("y %d más..."):format(#faltan - 6) end
        if #faltan > 0 and db.avisoBeneficios and not combate and GetTime() - avisos.beneficios > db.repetirBeneficios * 60 then
            avisos.beneficios = GetTime()
            D.Avisar(mod, "Falta " .. faltan[1] .. (#faltan > 1 and (" y %d más"):format(#faltan - 1) or ""), true, 0.6, 1, 0.6)
        end
    end
    if #lineas > 0 then
        marco.texto:ClearAllPoints(); marco.texto:SetPoint("TOPLEFT", marco, "TOPLEFT", 8, y)
        marco.texto:SetWidth(ancho)
        marco.texto:SetText(table.concat(lineas, "\n"))
        marco.texto:Show()
        y = y - 13 * #lineas - 4
    else
        marco.texto:Hide()
    end
    -- Botón para poner el beneficio que falta (solo fuera de combate: los botones seguros no se tocan en combate).
    if not combate then
        if db.botonBeneficio and primero then
            local id = D.Mejor(primero[2])
            marco.boton:SetAttribute("type", "macro")
            marco.boton:SetAttribute("macrotext", ("/cast [@%s] %s"):format(primero[1], D.Nombre(id)))
            marco.boton:SetText(D.Nombre(primero[2][1]) .. " » " .. primero[3])
            marco.boton:ClearAllPoints(); marco.boton:SetPoint("TOPLEFT", marco, "TOPLEFT", 8, y)
            marco.boton:Show()
            y = y - 24
        else
            marco.boton:Hide()
        end
    elseif marco.boton:IsShown() then
        y = y - 24
    end
    if combate then return end
    if y >= -8 and not mover then marco:Hide(); return end
    do
        marco:SetSize(ancho + 12, -y + 4)
        if not marco.colocado then D.Colocar(mod, marco, "druida", 0, 200); marco.colocado = true end
        marco:EnableMouse(mover or not db.bloquear)
    end
    marco:Show()
end
ns.Druida.PintarDruida = function() Pintar() end

----------------------------------------------------------------------
-- Registro
----------------------------------------------------------------------
local ROLES = { { "auto", "Automático (talentos y forma)" }, { "feral", "Feral" }, { "sanador", "Sanador" }, { "ambos", "Feral y sanador" } }
local acum = 0
mod = Hub:Register{
    key = "druida", dir = "Druida", name = "Druida", clase = "DRUID",
    desc = "Para cualquier druida: elige si vas de feral o de sanador, barra de formas con su coste en maná, a quién le "
        .. "falta Marca de lo Salvaje o Espinas (con botón para ponérsela), tus materiales y los enfriamientos de Renacer "
        .. "y Estimular con anuncio al grupo.",
    defaults = DEFAULTS,
    slash = { "cmdruida" },
    Init = function(m)
        db = m.db
        m:Event("UPDATE_SHAPESHIFT_FORMS", function() CrearFormas(); Pintar() end)
        m:Event("UPDATE_SHAPESHIFT_FORM", function() Pintar(); if ns.Druida.AlCambiarForma then ns.Druida.AlCambiarForma() end end)
        m:Event("PLAYER_REGEN_ENABLED", Pintar)
        m:Event("PLAYER_REGEN_DISABLED", function()
            if db.avisoHumanoide and not D.Forma() and D.EsFeral() then D.Avisar(mod, "Entras en combate en forma humanoide") end
            Pintar()
        end)
        m:Event("UNIT_SPELLCAST_SENT", function(_, _, unidad, objetivo, _, hechizo)
            if unidad == "player" and Num(hechizo) then objetivoLanzado[hechizo] = Str(objetivo) end
        end)
        m:Event("UNIT_SPELLCAST_SUCCEEDED", function(_, _, unidad, _, hechizo) AlLanzar(unidad, hechizo) end)
        m:Event("GROUP_ROSTER_UPDATE", Pintar)
        m:Event("BAG_UPDATE_DELAYED", Pintar)
        m:OnUpdate(function(_, e)
            acum = acum + e
            if acum >= 0.5 then acum = 0; Pintar() end
        end)
    end,
    Enable = function(m) db = m.db; Pintar() end,
    Disable = function() if marco then marco:Hide() end end,
    OnReset = function() if marco then marco.colocado = false end end,
    OnSlash = function(m, msg)
        msg = (msg or ""):lower()
        if msg == "mover" then mover = not mover; Pintar()
        elseif msg == "rol" then m:Print("rol: " .. D.Rol() .. " (ajuste: " .. db.rol .. ")")
        else Hub:Open("druida") end
    end,
    BuildConfig = function(m, L)
        db = m.db
        local function G(k) return function() return db[k] end end
        local function S(k) return function(v) db[k] = v; Pintar() end end
        if not D.EsDruida() then L:Text("|cffff7755Este personaje no es druida.|r", true) end

        L:Header("Rol")
        L:Text("Los módulos Feral y Sanador solo se encienden si tu rol coincide. En automático se mira qué talentos "
            .. "conoces (Carga feral o Líder de la manada = feral; Rapidez de la Naturaleza o Alivio presto = sanador) "
            .. "y, en forma de gato u oso, cuenta como feral.", true)
        L:Choice("Rol", ROLES, G("rol"), function(v) db.rol = v; Pintar(); m:Print("rol: " .. D.Rol()) end)
        L:Button("¿Qué rol tengo ahora?", 180, function() m:Print("rol: " .. D.Rol() .. " (ajuste: " .. db.rol .. ")") end)

        L:Header("Marco")
        L:Button("Mover", 90, function() mover = not mover; Pintar() end)
        L:Button("Volver a su sitio", 140, function() db.pos.druida = nil; if marco then marco.colocado = false end; Pintar() end, true)
        L:Check("Bloquear la posición", G("bloquear"), S("bloquear"))
        L:Check("Fondo y borde", G("fondo"), S("fondo"))
        L:Slider("Escala", 0.5, 2, 0.05, G("escala"), S("escala"), "%.2f")
        L:Slider("Opacidad", 0.2, 1, 0.05, G("opacidad"), S("opacidad"), "%.2f")

        L:Header("Formas")
        L:Check("Barra de formas (clic para cambiar)", G("formas"), S("formas"))
        L:Check("  Coste en maná debajo de cada forma (en rojo si no te llega)", G("formasCoste"), S("formasCoste"))
        L:Slider("  Tamaño de los botones", 20, 50, 1, G("tamForma"), S("tamForma"))
        L:Check("Aviso si en gato u oso ya no te llega el maná para volver a la forma", G("avisoManaForma"), S("avisoManaForma"))
        L:Check("Aviso si entras en combate en forma humanoide (feral)", G("avisoHumanoide"), S("avisoHumanoide"))

        L:Header("Beneficios")
        L:Check("Avisar de a quién le falta o se le acaba", G("beneficios"), S("beneficios"))
        L:Check("  Marca de lo Salvaje al grupo (si no, solo a ti)", G("marcaGrupo"), S("marcaGrupo"))
        L:Check("  También a toda la banda", G("marcaBanda"), S("marcaBanda"))
        L:Check("  Espinas en ti", G("espinasYo"), S("espinasYo"))
        L:Check("  Espinas en el grupo", G("espinasGrupo"), S("espinasGrupo"))
        L:Slider("  Avisar cuando le queden menos de (minutos)", 0, 15, 1, G("minutosBeneficio"), S("minutosBeneficio"))
        L:Check("  Solo fuera de combate", G("soloFueraCombate"), S("soloFueraCombate"))
        L:Check("  Aviso (texto/sonido)", G("avisoBeneficios"), S("avisoBeneficios"))
        L:Slider("  Repetir el aviso cada (minutos)", 1, 30, 1, G("repetirBeneficios"), S("repetirBeneficios"))
        L:Check("  Botón para ponérselo al primero que le falte", G("botonBeneficio"), S("botonBeneficio"))

        L:Header("Materiales")
        L:Check("Semillas de Renacer y bayas de Don de lo Salvaje en el marco", G("verMateriales"), S("verMateriales"))
        L:Slider("  Semillas: en rojo por debajo de", 0, 20, 1, G("minSemillas"), S("minSemillas"))
        L:Slider("  Bayas / raíces: en rojo por debajo de", 0, 40, 1, G("minBayas"), S("minBayas"))
        L:Check("  Aviso cuando bajen de ahí", G("avisoMateriales"), S("avisoMateriales"))

        L:Header("Renacer y Estimular")
        L:Check("Iconos con el enfriamiento", G("enfriamientos"), S("enfriamientos"))
        L:Check("  Renacer", G("verRenacer"), S("verRenacer"))
        L:Check("  Estimular", G("verEstimular"), S("verEstimular"))
        L:Slider("  Tamaño", 20, 60, 1, G("tamIcono"), S("tamIcono"))
        L:Check("Anunciar a quién se lo lanzas", G("anunciar"), S("anunciar"))
        L:Choice("  Canal", { { "auto", "Banda o grupo (según estés)" }, { "PARTY", "Grupo" }, { "RAID", "Banda" }, { "SAY", "Decir" }, { "YELL", "Gritar" } },
            G("canal"), S("canal"))
        L:Edit("  Texto de Renacer (%t = objetivo)", G("textoRenacer"), function(v) if type(v) == "string" then db.textoRenacer = v:gsub("|", "") end end, "text", 220)
        L:Edit("  Texto de Estimular (%t = objetivo)", G("textoEstimular"), function(v) if type(v) == "string" then db.textoEstimular = v:gsub("|", "") end end, "text", 220)

        L:Header("Cómo avisa")
        L:Check("Texto grande", G("avisoTexto"), S("avisoTexto"))
        L:Check("Línea en el chat", G("avisoChat"), S("avisoChat"))
        L:Check("Sonido", G("avisoSonido"), S("avisoSonido"))
        L:Choice("  Sonido", D.KITS, G("avisoKit"), function(v) db.avisoKit = v; D.Sonar(v) end)
    end,
}
