-- Chamán (CervecerosMendigos Clases): lo de cualquier chamán.
--   * Rol: automático (por talentos), elemental, mejora o restauración. Lo usan Elemental, Mejora y Restauración.
--   * Tótems: lo que le queda a cada uno (fuego, tierra, agua, aire), aviso al acabarse o si lo rompen, y quién
--     del grupo no recibe su efecto (fuera de rango).
--   * Conjuntos de tótems: varios juegos con nombre; un botón por elemento y otro que los pone en orden.
--   * Arma imbuida: tiempo y cargas en cada arma, con avisos.
--   * Escudo de relámpagos (cargas), Reencarnación con los Ankh, y choques (enfriamiento y Choque de llamas).
local ADDON, ns = ...
local Hub = ns.Hub
local U = ns.CU
local Num, Str = U.Num, U.Str
local C = {}
ns.Chaman = C

-- Tótems por elemento: { clave, rangos, hechizo del efecto en el grupo (para el rango) o nil }.
-- Huecos de GetTotemInfo: 1 fuego, 2 tierra, 3 agua, 4 aire.
C.ELEMENTOS = {
    { "fuego", "Fuego", 1, {
        { "abrasador", { 3599, 6363, 6364, 6365, 10437, 10438 } },
        { "nova", { 1535, 8498, 8499, 11314, 11315 } },
        { "magma", { 8190, 10585, 10586, 10587 } },
        { "lenguaFuego", { 8227, 8249, 10526, 16387 } },
        { "resEscarcha", { 8181, 10478, 10479 }, 8182 },
    } },
    { "tierra", "Tierra", 2, {
        { "fuerza", { 8075, 8160, 8161, 10442, 25361 }, 8076 },
        { "pielPiedra", { 8071, 8154, 8155, 10406, 10407, 10408 }, 8072 },
        { "temblor", { 8143 } },
        { "nexoTierra", { 2484 } },
        { "garraPiedra", { 5730, 6390, 6391, 6392, 10427, 10428 } },
    } },
    { "agua", "Agua", 3, {
        { "manantial", { 5675, 10495, 10496, 10497 }, 5677 },
        { "corriente", { 5394, 6375, 6377, 10462, 10463 } },
        { "limpiaVeneno", { 8166 } },
        { "limpiaEnfermedad", { 8170 } },
        { "resFuego", { 8184, 10537, 10538 }, 8185 },
        { "marea", { 16190, 17354, 17359 } },
    } },
    { "aire", "Aire", 4, {
        { "vientoFurioso", { 8512, 10613, 10614 } },
        { "gracia", { 8835, 10627, 25359 }, 8836 },
        { "toma", { 8177 } },
        { "resNaturaleza", { 10595, 10600, 10601 }, 10596 },
        { "muroViento", { 15107, 15111, 15112 } },
        { "aireTranquilo", { 25908 }, 25909 },
    } },
}
local TOTEM = {}
for _, e in ipairs(C.ELEMENTOS) do for _, t in ipairs(e[4]) do TOTEM[t[1]] = t; t.elemento = e[1] end end
C.TOTEM = TOTEM

local IMBUIR = { { 8017, 8018, 8019, 10399, 16314, 16315, 16316 }, { 8024, 8027, 8030, 16339, 16341, 16342 },
                 { 8033, 8038, 10456, 16355, 16356 }, { 8232, 8235, 10486, 16362 } }
local ESCUDO = { 324, 325, 905, 945, 8134, 10431, 10432 }
local REENCARNACION, ANKH = 20608, 17030
local CHOQUE_TIERRA = { 8042, 8044, 8045, 8046, 10412, 10413, 10414 }
local CHOQUE_LLAMAS = { 8050, 8052, 8053, 10447, 10448, 29228 }
local CHOQUE_ESCARCHA = { 8056, 8058, 10472, 10473 }

local DEFAULTS = {
    rol = "auto",
    escala = 1, opacidad = 1, bloquear = false, fondo = true,
    -- Tótems
    totems = true, tamTotem = 30, avisoTotem = true, avisoRoto = true, segundosTotem = 5, rango = true, rangoSoloFuera = false,
    -- Conjuntos
    conjuntos = true, conjunto = 1, botonTodos = true, reinicioSecuencia = 8,
    listaConjuntos = {
        { nombre = "Mazmorra", fuego = "abrasador", tierra = "fuerza", agua = "manantial", aire = "gracia" },
        { nombre = "Banda", fuego = "lenguaFuego", tierra = "fuerza", agua = "manantial", aire = "vientoFurioso" },
        { nombre = "JcJ", fuego = "abrasador", tierra = "temblor", agua = "limpiaVeneno", aire = "toma" },
    },
    -- Arma imbuida
    imbuir = true, imbuirIzquierda = true, minutosImbuir = 1, cargasImbuir = 10, avisoImbuir = true,
    avisoImbuirCombate = true, avisoImbuirInstancia = true,
    -- Escudo y Reencarnación
    escudo = true, avisoEscudo = false, cargasEscudo = 1,
    reencarnacion = true, mejoraReencarnacion = 0, minAnkh = 2, avisoAnkh = true,
    -- Choques
    choques = true, choqueLlamas = true,
    -- Avisos
    avisoTexto = true, avisoChat = false, avisoSonido = true, avisoKit = "RAID_WARNING",
    pos = {},
}

local mod, db, marco
local mover, pendiente = false, false
local avisos = { escudo = false, ankh = false }
local totemVisto = {}       -- hueco -> { nombre, fin }
local estadoImbuir = { md = {}, mi = {} }

----------------------------------------------------------------------
-- Rol
----------------------------------------------------------------------
local PISTAS = {
    { "mejora", { 17364 } }, { "restauracion", { 16190, 17354, 17359 } }, { "elemental", { 16166 } },
    { "restauracion", { 16188 } }, { "mejora", { 16268 } }, { "elemental", { 16164 } },
}
function C.Rol()
    local d = db or (Hub.byKey.chaman and Hub.byKey.chaman.db)
    local rol = d and d.rol or "auto"
    if rol ~= "auto" then return rol end
    for _, p in ipairs(PISTAS) do if U.ConoceAlguno(p[2]) then return p[1] end end
    return "ninguno"
end
function C.EsChaman()
    local ok, _, c = pcall(UnitClass, "player")
    return ok and c == "SHAMAN"
end

----------------------------------------------------------------------
-- Tótems activos
----------------------------------------------------------------------
-- { hueco = { nombre, queda, icono } } de los tótems puestos.
function C.Totems()
    local out = {}
    if not GetTotemInfo then return out end
    for _, e in ipairs(C.ELEMENTOS) do
        local r = { pcall(GetTotemInfo, e[3]) }
        if r[1] and r[2] and not U.issecret(r[2]) then
            local nombre, inicio, dur = Str(r[3]), Num(r[4]), Num(r[5])
            local queda = inicio and dur and dur > 0 and math.max(0, inicio + dur - GetTime()) or nil
            out[e[3]] = { nombre = nombre, queda = queda, icono = r[6], elemento = e }
        end
    end
    return out
end
-- Tótem de la lista que corresponde a un nombre puesto (para saber su efecto en el grupo).
local function TotemPorNombre(nombre)
    if not nombre then return nil end
    for _, t in pairs(TOTEM) do
        for _, id in ipairs(t[2]) do if U.Nombre(id) == nombre then return t end end
        if nombre:find(U.Nombre(t[2][1]), 1, true) then return t end
    end
end

local function VigilarTotems(activos)
    for _, e in ipairs(C.ELEMENTOS) do
        local h = e[3]
        local x, antes = activos[h], totemVisto[h]
        if antes and not x then
            -- Desaparece: si le quedaba tiempo, lo han roto (o lo has quitado tú).
            if antes.fin and antes.fin - GetTime() > 1.5 then
                if db.avisoRoto then U.Avisar(mod, ("Tótem de %s caído: %s"):format(e[2]:lower(), antes.nombre or "?"), true, 1, 0.5, 0.2) end
            end
            totemVisto[h] = nil
        elseif x then
            local nuevo = not antes or antes.nombre ~= x.nombre or (x.queda and antes.fin and x.queda + GetTime() > antes.fin + 2)
            if nuevo then totemVisto[h] = { nombre = x.nombre, fin = x.queda and GetTime() + x.queda, dur = x.queda, avisado = false } end
            local v = totemVisto[h]
            if x.queda then v.fin = GetTime() + x.queda end
            -- Solo avisa de los que duran bastante más que el aviso (no de los de pocos segundos).
            if db.avisoTotem and x.queda and x.queda <= db.segundosTotem and not v.avisado and v.dur and v.dur > db.segundosTotem + 2 then
                v.avisado = true
                U.Avisar(mod, ("%s: quedan %d s"):format(x.nombre or e[2], math.ceil(x.queda)), true)
            end
        end
    end
end

-- Quién del grupo no tiene el efecto de un tótem puesto (fuera de rango).
local function FueraDeRango(activos)
    local out = {}
    for _, x in pairs(activos) do
        local t = TotemPorNombre(x.nombre)
        if t and t[3] then
            local efecto = U.Nombre(t[3])
            local faltan = {}
            for _, u in ipairs(U.Miembros(false)) do
                local fin = U.Aura(u, efecto, "HELPFUL")
                if fin == false then
                    local okn, n = pcall(UnitName, u)
                    faltan[#faltan + 1] = okn and Str(n) or u
                end
            end
            if #faltan > 0 then out[#out + 1] = ("%s: %s"):format(x.nombre or "?", table.concat(faltan, ", ")) end
        end
    end
    return out
end

----------------------------------------------------------------------
-- Conjuntos de tótems (botones seguros)
----------------------------------------------------------------------
local function NombreTotem(clave)
    local t = TOTEM[clave]
    local id = t and U.Mejor(t[2])
    return id and U.Nombre(id) or nil
end
function C.ConjuntoActual()
    local lista = db.listaConjuntos
    return lista[math.min(math.max(1, db.conjunto), #lista)]
end

local function PrepararConjunto()
    if not marco then return end
    if U.EnCombate() then pendiente = true; return end
    pendiente = false
    local cj = C.ConjuntoActual()
    marco.botones = marco.botones or {}
    local nombres = {}
    for i, e in ipairs(C.ELEMENTOS) do
        local b = marco.botones[i]
        if not b then
            b = CreateFrame("Button", "CMChamanTotem" .. i, marco, "SecureActionButtonTemplate")
            b:RegisterForClicks("AnyUp", "AnyDown")
            b.tex = b:CreateTexture(nil, "ARTWORK"); b.tex:SetAllPoints()
            b.tiempo = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); b.tiempo:SetPoint("CENTER")
            b.puesto = b:CreateTexture(nil, "OVERLAY"); b.puesto:SetAllPoints()
            b.puesto:SetTexture("Interface\\Buttons\\CheckButtonHilight"); b.puesto:SetBlendMode("ADD")
            b:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_TOP")
                GameTooltip:SetText(self.nombreTotem or self.elemento)
                GameTooltip:AddLine("Clic: poner el tótem de " .. self.elemento:lower() .. " del conjunto", 1, 1, 1)
                GameTooltip:Show()
            end)
            b:SetScript("OnLeave", function() GameTooltip:Hide() end)
            marco.botones[i] = b
        end
        local n = cj and NombreTotem(cj[e[1]])
        b.elemento, b.nombreTotem = e[2], n
        b:SetAttribute("type", "macro")
        b:SetAttribute("macrotext", n and ("/cast " .. n) or "")
        local t = cj and TOTEM[cj[e[1]]]
        b.tex:SetTexture(t and U.Icono(U.Mejor(t[2]) or t[2][1]) or "Interface\\Icons\\INV_Misc_QuestionMark")
        b.tex:SetDesaturated(n == nil)
        if n then nombres[#nombres + 1] = n end
    end
    if not marco.todos then
        marco.todos = CreateFrame("Button", "CMChamanTotems", marco, "SecureActionButtonTemplate, UIPanelButtonTemplate")
        marco.todos:RegisterForClicks("AnyUp", "AnyDown")
        marco.todos:SetSize(30, 30)
        marco.todos:SetText("»")
    end
    marco.todos:SetAttribute("type", "macro")
    marco.todos:SetAttribute("macrotext", #nombres > 0 and ("/castsequence reset=%d %s"):format(db.reinicioSecuencia, table.concat(nombres, ", ")) or "")
    marco.cambiar = marco.cambiar or CreateFrame("Button", nil, marco, "UIPanelButtonTemplate")
    marco.cambiar:SetSize(120, 18)
    marco.cambiar:SetScript("OnClick", function()
        if U.EnCombate() then return end
        db.conjunto = db.conjunto % #db.listaConjuntos + 1
        PrepararConjunto(); C.Pintar()
    end)
    marco.cambiar:SetText(cj and cj.nombre or "?")
end
C.PrepararConjunto = function() PrepararConjunto() end

----------------------------------------------------------------------
-- Arma imbuida
----------------------------------------------------------------------
local function LeerArmas()
    local r = { pcall(GetWeaponEnchantInfo) }
    local ok = table.remove(r, 1)
    local out = {}
    for i, a in ipairs({ { 16, "md", "Mano derecha" }, { 17, "mi", "Mano izquierda" } }) do
        local b = (i - 1) * 4
        local okid, id = pcall(GetInventoryItemID, "player", a[1])
        local arma = okid and Num(id) ~= nil
        if arma and C_Item and C_Item.GetItemInfoInstant then
            local ri = { pcall(C_Item.GetItemInfoInstant, id) }
            if ri[1] and Num(ri[7]) then arma = ri[7] == 2 end
        end
        local ms = ok and Num(r[b + 2])
        out[a[2]] = { tiene = ok and r[b + 1] and not U.issecret(r[b + 1]) and true or false, seg = ms and ms / 1000,
                      cargas = ok and Num(r[b + 3]), arma = arma, nombre = a[3] }
    end
    return out
end
local function FaltaImbuir(v)
    local f = {}
    for _, k in ipairs({ "md", "mi" }) do
        local x = v[k]
        if x.arma and not x.tiene and (k == "md" or db.imbuirIzquierda) then f[#f + 1] = x.nombre end
    end
    return f
end
function C.ComprobarImbuir(motivo)
    if not (mod and mod:IsEnabled() and C.EsChaman() and db.imbuir) then return end
    if not U.ConoceAlguno(IMBUIR[1]) then return end
    if motivo == "combate" and not db.avisoImbuirCombate then return end
    if motivo == "instancia" and not db.avisoImbuirInstancia then return end
    local f = FaltaImbuir(LeerArmas())
    if #f > 0 then U.Avisar(mod, "Arma sin imbuir: " .. table.concat(f, " y "), true) end
end

----------------------------------------------------------------------
-- Marco
----------------------------------------------------------------------
local function Crear()
    if marco then return end
    marco = mod:Frame("Frame", "CMChaman", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    marco:SetSize(220, 40)
    U.Movil(mod, marco, "chaman", function() return db.bloquear and not mover end)
    if marco.SetBackdrop then
        marco:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                            edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    end
    marco.texto = marco:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    marco.texto:SetJustifyH("LEFT")
    marco.cds = CreateFrame("Frame", nil, marco)
    PrepararConjunto()
end

local function Pintar()
    local combate = U.EnCombate()
    if not (mod and mod:IsEnabled() and C.EsChaman()) then
        if marco and not combate then marco:Hide() end
        return
    end
    if not marco and combate then return end
    Crear()
    if pendiente and not combate then PrepararConjunto() end
    marco:SetScale(db.escala); marco:SetAlpha(db.opacidad)
    if marco.SetBackdropColor then
        marco:SetBackdropColor(0, 0, 0, db.fondo and 0.7 or 0)
        marco:SetBackdropBorderColor(1, 1, 1, db.fondo and 0.5 or 0)
    end
    local y, ancho = -6, 200
    local lineas = {}
    local activos = C.Totems()
    VigilarTotems(activos)
    -- Fila de tótems: un botón por elemento (con lo que le queda al puesto) y el de «todos».
    local verFila = db.totems or db.conjuntos
    if verFila and marco.botones then
        local t = db.tamTotem
        for i, e in ipairs(C.ELEMENTOS) do
            local b = marco.botones[i]
            local x = activos[e[3]]
            b.tiempo:SetText(db.totems and x and x.queda and U.Tiempo(x.queda) or "")
            b.puesto:SetShown(db.totems and x ~= nil)
            if db.totems and x and x.icono then b.tex:SetTexture(x.icono); b.tex:SetDesaturated(false) end
            if not combate then
                b:SetSize(t, t); b:ClearAllPoints(); b:SetPoint("TOPLEFT", marco, "TOPLEFT", 6 + (i - 1) * (t + 4), y)
                b:EnableMouse(db.conjuntos)
                b:Show()
            end
        end
        if not combate then
            marco.todos:SetShown(db.conjuntos and db.botonTodos)
            marco.todos:SetSize(t, t); marco.todos:ClearAllPoints(); marco.todos:SetPoint("TOPLEFT", marco, "TOPLEFT", 6 + 4 * (t + 4), y)
            marco.cambiar:SetShown(db.conjuntos)
            marco.cambiar:ClearAllPoints(); marco.cambiar:SetPoint("TOPLEFT", marco, "TOPLEFT", 6, y - t - 2)
        end
        ancho = math.max(ancho, 12 + 5 * (t + 4))
        y = y - t - 6 - (db.conjuntos and 20 or 0)
    elseif marco.botones and not combate then
        for _, b in ipairs(marco.botones) do b:Hide() end
        marco.todos:Hide(); marco.cambiar:Hide()
    end
    if db.totems and db.rango and (not combate or not db.rangoSoloFuera) then
        for _, l in ipairs(FueraDeRango(activos)) do lineas[#lineas + 1] = "|cffffaa33Fuera de rango · " .. l .. "|r" end
    end
    -- Arma imbuida.
    if db.imbuir and U.ConoceAlguno(IMBUIR[1]) then
        local v = LeerArmas()
        for _, k in ipairs({ "md", "mi" }) do
            local x, e = v[k], estadoImbuir[k]
            if x.arma and (k == "md" or db.imbuirIzquierda) then
                if x.tiene then
                    local poco = (x.seg and x.seg < db.minutosImbuir * 60) or (x.cargas and x.cargas > 0 and x.cargas < db.cargasImbuir)
                    lineas[#lineas + 1] = ("%s%s: %s%s|r"):format(poco and "|cffffaa33" or "|cff66ff66", x.nombre, U.Tiempo(x.seg),
                        x.cargas and x.cargas > 0 and (" · " .. x.cargas .. " cargas") or "")
                    if x.seg and (not e.seg or x.seg > e.seg + 5) then e.avisado = false end
                    if poco and db.avisoImbuir and not e.avisado then e.avisado = true; U.Avisar(mod, x.nombre .. ": se acaba el imbuido", true) end
                else
                    lineas[#lineas + 1] = "|cffff5555" .. x.nombre .. ": sin imbuir|r"
                    if e.tenia and db.avisoImbuir then U.Avisar(mod, x.nombre .. ": imbuido agotado", true) end
                end
                e.tenia, e.seg = x.tiene, x.seg
            end
        end
    end
    -- Escudo de relámpagos.
    if db.escudo and U.ConoceAlguno(ESCUDO) then
        local nombre = U.Nombre(ESCUDO[1], "Escudo de relámpagos")
        local fin, _, cargas = U.Aura("player", nombre, "HELPFUL")
        if fin then
            lineas[#lineas + 1] = ("%s: %d cargas"):format(nombre, cargas or 0)
            if db.avisoEscudo and cargas and cargas <= db.cargasEscudo and not avisos.escudo then
                avisos.escudo = true; U.Avisar(mod, nombre .. ": quedan " .. cargas .. " cargas", true)
            elseif cargas and cargas > db.cargasEscudo then avisos.escudo = false end
        elseif fin == false then
            lineas[#lineas + 1] = "|cff999999Sin " .. nombre .. "|r"
            if db.avisoEscudo and combate and not avisos.escudo then avisos.escudo = true; U.Avisar(mod, "Sin " .. nombre, true) end
        end
    end
    -- Reencarnación y Ankh.
    local iconos = {}
    if db.reencarnacion and U.Conoce(REENCARNACION) then
        local q = U.Enfriamiento(REENCARNACION)
        if not q and db.lanzadoReencarnacion then
            q = math.max(0, (3600 - 600 * db.mejoraReencarnacion) - (time() - db.lanzadoReencarnacion))
        end
        iconos[#iconos + 1] = { icono = U.Icono(REENCARNACION), queda = q or 0 }
        local n = U.ContarObjeto(ANKH)
        lineas[#lineas + 1] = (n < db.minAnkh and "|cffff5555%d|r %s" or "%d %s"):format(n, U.NombreObjeto(ANKH))
        if n < db.minAnkh and db.avisoAnkh and not avisos.ankh then avisos.ankh = true; U.Avisar(mod, "Te quedan pocos " .. U.NombreObjeto(ANKH), false)
        elseif n >= db.minAnkh then avisos.ankh = false end
    end
    -- Choques.
    if db.choques then
        local id = U.Mejor(CHOQUE_TIERRA) or U.Mejor(CHOQUE_LLAMAS) or U.Mejor(CHOQUE_ESCARCHA)
        if id then iconos[#iconos + 1] = { icono = U.Icono(id), queda = U.Enfriamiento(id) or 0 } end
        if db.choqueLlamas and U.ConoceAlguno(CHOQUE_LLAMAS) then
            local fin = U.Aura("target", U.Nombre(CHOQUE_LLAMAS[1], "Choque de llamas"), "HARMFUL|PLAYER")
            if fin and fin ~= math.huge then
                lineas[#lineas + 1] = ("%s %s"):format(U.Nombre(CHOQUE_LLAMAS[1], "Choque de llamas"), U.Tiempo(math.max(0, fin - GetTime())))
            end
        end
    end
    if #iconos > 0 then
        marco.cds:ClearAllPoints(); marco.cds:SetPoint("TOPLEFT", marco, "TOPLEFT", 6, y)
        marco.cds:SetSize(#iconos * 36, 30)
        U.Iconos(marco.cds, iconos, 30)
        marco.cds:Show()
        y = y - 36
    else
        marco.cds:Hide()
    end
    if #lineas > 0 then
        marco.texto:ClearAllPoints(); marco.texto:SetPoint("TOPLEFT", marco, "TOPLEFT", 8, y)
        marco.texto:SetWidth(ancho + 60)
        marco.texto:SetText(table.concat(lineas, "\n"))
        marco.texto:Show()
        y = y - 13 * #lineas - 4
    else
        marco.texto:Hide()
    end
    if combate then return end
    if y >= -8 and not mover then marco:Hide(); return end
    marco:SetSize(ancho + 70, -y + 4)
    if not marco.colocado then U.Colocar(mod, marco, "chaman", 0, 200); marco.colocado = true end
    marco:EnableMouse(mover or not db.bloquear)
    marco:Show()
end
C.Pintar = function() Pintar() end

----------------------------------------------------------------------
-- Registro
----------------------------------------------------------------------
local ROLES = { { "auto", "Automático (por talentos)" }, { "elemental", "Elemental" }, { "mejora", "Mejora" }, { "restauracion", "Restauración" } }
local acum = 0
mod = Hub:Register{
    key = "chaman", dir = "Chaman", name = "Chamán", clase = "SHAMAN",
    desc = "Para cualquier chamán: elige tu rol, tus tótems con lo que les queda, quién está fuera de su alcance y "
        .. "avisos si caen; conjuntos de tótems con botones; arma imbuida con avisos; Escudo de relámpagos; "
        .. "Reencarnación con tus Ankh y los choques.",
    defaults = DEFAULTS,
    slash = { "cmchaman" },
    Init = function(m)
        db = m.db
        m:Event("PLAYER_TOTEM_UPDATE", Pintar)
        m:Event("SPELLS_CHANGED", function() PrepararConjunto() end)
        m:Event("PLAYER_REGEN_ENABLED", function() avisos.escudo = false; Pintar() end)
        m:Event("PLAYER_REGEN_DISABLED", function() C.ComprobarImbuir("combate"); Pintar() end)
        m:Event("PLAYER_ENTERING_WORLD", function()
            local ok, dentro, tipo = pcall(IsInInstance)
            if ok and dentro and not U.issecret(dentro) and (tipo == "party" or tipo == "raid" or tipo == "pvp" or tipo == "arena") then
                C_Timer.After(3, function() C.ComprobarImbuir("instancia") end)
            end
        end)
        m:Event("UNIT_SPELLCAST_SUCCEEDED", function(_, _, unidad, _, hechizo)
            if unidad == "player" and Num(hechizo) == REENCARNACION then db.lanzadoReencarnacion = time() end
        end)
        m:Event("UNIT_INVENTORY_CHANGED", function(_, _, u) if u == "player" then Pintar() end end)
        m:Event("GROUP_ROSTER_UPDATE", Pintar)
        m:Event("BAG_UPDATE_DELAYED", Pintar)
        m:OnUpdate(function(_, e) acum = acum + e; if acum >= 0.25 then acum = 0; Pintar() end end)
    end,
    Enable = function(m) db = m.db; Pintar() end,
    Disable = function() if marco and not U.EnCombate() then marco:Hide() end end,
    OnReset = function() if marco then marco.colocado = false end; PrepararConjunto() end,
    OnSlash = function(m, msg)
        msg = (msg or ""):lower()
        local n = tonumber(msg:match("^conjunto%s+(%d+)$") or "")
        if msg == "mover" then mover = not mover; Pintar()
        elseif msg == "rol" then m:Print("rol: " .. C.Rol() .. " (ajuste: " .. db.rol .. ")")
        elseif n and db.listaConjuntos[n] then
            if U.EnCombate() then m:Print("en combate no se puede cambiar de conjunto."); return end
            db.conjunto = n; PrepararConjunto(); Pintar(); m:Print("conjunto: " .. db.listaConjuntos[n].nombre)
        else Hub:Open("chaman") end
    end,
    BuildConfig = function(m, L)
        db = m.db
        local function G(k) return function() return db[k] end end
        local function S(k) return function(v) db[k] = v; PrepararConjunto(); Pintar() end end
        if not C.EsChaman() then L:Text("|cffff7755Este personaje no es chamán.|r", true) end

        L:Header("Rol")
        L:Text("Los módulos Elemental, Mejora y Restauración solo se encienden con su rol. En automático se mira qué "
            .. "talentos conoces (Ataque de tormenta = mejora; Tótem de marea de maná o Rapidez de la Naturaleza = "
            .. "restauración; Maestría elemental = elemental).", true)
        L:Choice("Rol", ROLES, G("rol"), function(v) db.rol = v; Pintar(); m:Print("rol: " .. C.Rol()) end)
        L:Button("¿Qué rol tengo ahora?", 180, function() m:Print("rol: " .. C.Rol() .. " (ajuste: " .. db.rol .. ")") end)

        L:Header("Marco")
        L:Button("Mover", 90, function() mover = not mover; Pintar() end)
        L:Button("Volver a su sitio", 140, function() db.pos.chaman = nil; if marco then marco.colocado = false end; Pintar() end, true)
        L:Check("Bloquear la posición", G("bloquear"), S("bloquear"))
        L:Check("Fondo y borde", G("fondo"), S("fondo"))
        L:Slider("Escala", 0.5, 2, 0.05, G("escala"), S("escala"), "%.2f")
        L:Slider("Opacidad", 0.2, 1, 0.05, G("opacidad"), S("opacidad"), "%.2f")

        L:Header("Tótems")
        L:Check("Lo que le queda a cada tótem puesto", G("totems"), S("totems"))
        L:Slider("  Tamaño", 20, 50, 1, G("tamTotem"), S("tamTotem"))
        L:Check("  Aviso cuando se va a acabar", G("avisoTotem"), S("avisoTotem"))
        L:Slider("    Segundos antes", 1, 20, 1, G("segundosTotem"), S("segundosTotem"))
        L:Check("  Aviso si lo rompen (desaparece antes de tiempo)", G("avisoRoto"), S("avisoRoto"))
        L:Check("  Quién del grupo no recibe su efecto (fuera de rango)", G("rango"), S("rango"))
        L:Check("    Solo fuera de combate", G("rangoSoloFuera"), S("rangoSoloFuera"))

        L:Header("Conjuntos de tótems")
        L:Text("Un botón por elemento pone el tótem del conjunto elegido; el botón » los pone en orden (un clic por "
            .. "tótem). El botón con el nombre cambia de conjunto (fuera de combate). También: /cmchaman conjunto 2.", true)
        L:Check("Botones del conjunto", G("conjuntos"), S("conjuntos"))
        L:Check("  Botón » para ponerlos todos en orden", G("botonTodos"), S("botonTodos"))
        L:Slider("  La secuencia vuelve a empezar tras (segundos sin pulsar)", 3, 30, 1, G("reinicioSecuencia"), S("reinicioSecuencia"))
        local opcConj = {}
        for i, c in ipairs(db.listaConjuntos) do opcConj[#opcConj + 1] = { i, c.nombre } end
        L:Choice("Conjunto en uso", opcConj, G("conjunto"), S("conjunto"))
        for i, c in ipairs(db.listaConjuntos) do
            L:Edit("Nombre del conjunto " .. i, function() return c.nombre end,
                function(v) if type(v) == "string" and v ~= "" then c.nombre = v:gsub("|", "") end; PrepararConjunto() end, "text", 160)
            for _, e in ipairs(C.ELEMENTOS) do
                local opc = { { "", "Ninguno" } }
                for _, t in ipairs(e[4]) do opc[#opc + 1] = { t[1], U.Nombre(t[2][1]) } end
                L:Choice("  " .. e[2], opc, function() return c[e[1]] or "" end, function(v) c[e[1]] = v ~= "" and v or nil; PrepararConjunto(); Pintar() end)
            end
        end

        L:Header("Arma imbuida")
        L:Check("Tiempo y cargas del imbuido de cada arma", G("imbuir"), S("imbuir"))
        L:Check("  También la mano izquierda", G("imbuirIzquierda"), S("imbuirIzquierda"))
        L:Slider("  Aviso cuando queden menos de (minutos)", 0, 10, 1, G("minutosImbuir"), S("minutosImbuir"))
        L:Slider("  o menos de (cargas)", 0, 60, 1, G("cargasImbuir"), S("cargasImbuir"))
        L:Check("  Avisos de que se acaba / se ha acabado", G("avisoImbuir"), S("avisoImbuir"))
        L:Check("  Aviso al empezar a pelear sin imbuir", G("avisoImbuirCombate"), S("avisoImbuirCombate"))
        L:Check("  Aviso al entrar en mazmorra o campo de batalla sin imbuir", G("avisoImbuirInstancia"), S("avisoImbuirInstancia"))

        L:Header("Escudo de relámpagos y Reencarnación")
        L:Check("Cargas del Escudo de relámpagos", G("escudo"), S("escudo"))
        L:Check("  Aviso si se acaba o te quedan pocas cargas", G("avisoEscudo"), S("avisoEscudo"))
        L:Slider("    Cargas", 0, 5, 1, G("cargasEscudo"), S("cargasEscudo"))
        L:Check("Reencarnación (enfriamiento) y Ankh", G("reencarnacion"), S("reencarnacion"))
        L:Slider("  Talento Reencarnación mejorada (puntos)", 0, 2, 1, G("mejoraReencarnacion"), S("mejoraReencarnacion"))
        L:Slider("  Ankh: en rojo y aviso por debajo de", 0, 20, 1, G("minAnkh"), S("minAnkh"))
        L:Check("  Aviso de pocos Ankh", G("avisoAnkh"), S("avisoAnkh"))

        L:Header("Choques")
        L:Check("Enfriamiento de los choques", G("choques"), S("choques"))
        L:Check("Choque de llamas en el objetivo", G("choqueLlamas"), S("choqueLlamas"))

        L:Header("Cómo avisa")
        L:Check("Texto grande", G("avisoTexto"), S("avisoTexto"))
        L:Check("Línea en el chat", G("avisoChat"), S("avisoChat"))
        L:Check("Sonido", G("avisoSonido"), S("avisoSonido"))
        L:Choice("  Sonido", U.KITS, G("avisoKit"), function(v) db.avisoKit = v; U.Sonar(v) end)
    end,
}
