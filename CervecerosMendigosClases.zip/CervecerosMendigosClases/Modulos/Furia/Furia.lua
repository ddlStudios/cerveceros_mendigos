-- Furia (CervecerosMendigos Clases, guerrero): solo con rol furia.
--   Sed de sangre, Deseo de la muerte y Torbellino en grande; cuánto mantienes Arrebato y Enfurecer.
local ADDON, ns = ...
local U = ns.CU

U.Modulo{
    key = "furia", dir = "Furia", name = "Furia", clase = "WARRIOR", slash = { "cmfuria" }, rolDe = "guerrero", rol = "furia",
    desc = "Guerrero de furia (solo con ese rol): Sed de sangre, Deseo de la muerte y Torbellino en grande, y cuánto "
        .. "mantienes Arrebato y Enfurecer en cada pelea.",
    cds = { { "sed", { 23881, 23892, 23893, 23894 }, "Sed de sangre", avisoListo = false }, { "deseo", { 12328 }, "Deseo de la muerte" },
            { "torbellino", { 1680 }, "Torbellino", avisoListo = false } },
    uptime = { { "arrebato", { 12966, 12967, 12968, 12969, 12970 }, "Arrebato", si = { 12319, 12971, 12972, 12973, 12974 } },
               { "enfurecer", { 12880, 14201, 14202, 14203, 14204 }, "Enfurecer", si = { 12317, 13045, 13046, 13047, 13048 } } },
}
