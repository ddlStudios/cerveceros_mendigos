-- Combate (CervecerosMendigos Clases, pícaro): solo con rol combate.
--   Subidón de adrenalina y Flujo de cuchillas en grande con aviso cuando están listos, aviso de Respuesta
--   cuando la puedes usar (después de parar un golpe) y % de la pelea con Hacer picadillo.
local ADDON, ns = ...
local U = ns.CU

U.Modulo{
    key = "combate", dir = "Combate", name = "Combate", clase = "ROGUE", slash = { "cmcombate" }, rolDe = "picaro", rol = "combate",
    desc = "Pícaro de combate (solo con ese rol): Subidón de adrenalina y Flujo de cuchillas en grande, aviso de Respuesta "
        .. "cuando la puedes usar y qué parte de la pelea mantienes Hacer picadillo y Flujo de cuchillas.",
    usables = { { "respuesta", { 14251 }, "Respuesta" } },
    uptime = { { "picadillo", { 5171, 6774 }, "Hacer picadillo" }, { "flujo", { 13877 }, "Flujo de cuchillas" } },
    cds = { { "adrenalina", { 13750 }, "Subidón de adrenalina" }, { "flujoCd", { 13877 }, "Flujo de cuchillas" },
            { "respuestaCd", { 14251 }, "Respuesta", avisoListo = false } },
}
