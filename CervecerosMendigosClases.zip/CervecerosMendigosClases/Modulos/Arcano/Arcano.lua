-- Arcano (CervecerosMendigos Clases, mago): solo con rol arcano.
--   Presencia mental y Poder arcano en grande; aviso de Libre lanzamiento (Concentración arcana).
local ADDON, ns = ...
local U = ns.CU

U.Modulo{
    key = "arcano", dir = "Arcano", name = "Arcano", clase = "MAGE", slash = { "cmarcano" }, rolDe = "mago", rol = "arcano",
    desc = "Mago arcano (solo con ese rol): Presencia mental y Poder arcano en grande con aviso cuando están listos, y "
        .. "aviso de Libre lanzamiento.",
    procs = { { "libre", { 12536 }, "Libre lanzamiento", si = { 11213, 12574, 12575, 12576, 12577 } } },
    cds = { { "presencia", { 12043 }, "Presencia mental" }, { "poder", { 12042 }, "Poder arcano" } },
}
