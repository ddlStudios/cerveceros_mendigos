-- Sutileza (CervecerosMendigos Clases, pícaro): solo con rol sutileza.
--   Preparación, Premeditación, Golpe fantasmal y Paso de las Sombras en grande, tu Hemorragia en el
--   objetivo y % de la pelea con Golpe fantasmal.
local ADDON, ns = ...
local U = ns.CU

U.Modulo{
    key = "sutileza", dir = "Sutileza", name = "Sutileza", clase = "ROGUE", slash = { "cmsutileza" }, rolDe = "picaro", rol = "sutileza",
    desc = "Pícaro de sutileza (solo con ese rol): Preparación, Premeditación, Golpe fantasmal y Paso de las Sombras en "
        .. "grande, tu Hemorragia en el objetivo y qué parte de la pelea mantienes Golpe fantasmal.",
    objetivo = { { "hemorragia", { 16511, 17347, 17348 }, "Hemorragia" } },
    uptime = { { "fantasmal", { 14278 }, "Golpe fantasmal" } },
    cds = { { "preparacion", { 14185 }, "Preparación" }, { "premeditacion", { 14183 }, "Premeditación" },
            { "fantasmalCd", { 14278 }, "Golpe fantasmal", avisoListo = false }, { "paso", { 36554 }, "Paso de las Sombras" } },
}
