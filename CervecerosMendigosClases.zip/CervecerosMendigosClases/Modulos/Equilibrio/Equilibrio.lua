-- Equilibrio (CervecerosMendigos Clases, druida): solo se enciende si tu rol de druida es equilibrio
-- (montado con el motor de ComunClases; el rol lo elige el módulo Druida).
--   Aviso si vas sin Forma de lechúcico lunar, tus Fuego lunar y Enjambre de insectos en el objetivo,
--   Fuego feérico, Raíces enredadoras e Hibernar, avisos de Gracia de la Naturaleza y Libre lanzamiento,
--   maná con la regla de los 5 segundos y enfriamientos (Huracán, Rapidez de la Naturaleza...).
local ADDON, ns = ...
local U = ns.CU
local D = ns.Druida

U.Modulo{
    key = "equilibrio", dir = "Equilibrio", name = "Equilibrio", clase = "DRUID", slash = { "cmequilibrio" },
    activo = function() return D.EsEquilibrio() end,
    textoRol = function() return "Solo funciona si tu rol de druida (pestaña Druida) es equilibrio. Ahora: |cffffd100" .. D.Rol() .. "|r." end,
    desc = "Druida de equilibrio (solo con ese rol): aviso si vas sin Forma de lechúcico lunar, tus Fuego lunar y Enjambre "
        .. "de insectos en el objetivo, avisos de Gracia de la Naturaleza y Libre lanzamiento, maná con la regla de los "
        .. "5 segundos y tus enfriamientos.",
    propios = { { "lechucico", { { 24858 } }, "Forma de lechúcico lunar" } },
    objetivo = {
        { "lunar", { 8921, 8924, 8925, 8926, 8927, 8928, 8929, 9833, 9834, 9835 }, "Fuego lunar" },
        { "enjambre", { 5570, 24974, 24975, 24976, 24977 }, "Enjambre de insectos" },
        { "feerico", { 770, 778, 9749, 9907 }, "Fuego feérico", propio = false },
        { "raices", { 339, 1062, 5195, 5196, 9852, 9853 }, "Raíces enredadoras", defecto = false },
        { "hibernar", { 2637, 18657, 18658 }, "Hibernar", defecto = false },
    },
    procs = { { "gracia", { 16886 }, "Gracia de la Naturaleza", si = { 16880 } },
              { "libre", { 16870 }, "Libre lanzamiento", si = { 16864 } } },
    cds = { { "huracan", { 16914, 17401, 17402 }, "Huracán" }, { "rapidez", { 17116 }, "Rapidez de la Naturaleza" },
            { "ciclon", { 33786 }, "Ciclón", defecto = false } },
    mana = true,
}
