-- Sanador (CervecerosMendigos Clases, druida): solo se enciende si tu rol de druida es sanador (o ambos).
--   * Lista del grupo con la vida de cada uno y lo que les queda a TUS Rejuvenecimiento y Recrecimiento.
--     Clic izquierdo / derecho en una fila lanza el hechizo que elijas sobre esa persona.
--   * Maná con la regla de los 5 segundos (cuándo vuelves a regenerar) y aviso de maná bajo.
--   * Rapidez de la Naturaleza: enfriamiento en grande, aviso cuando está lista y cuando está activa.
-- Si el juego oculta las auras en combate, el tiempo de las curas se calcula desde que las lanzaste.
local ADDON, ns = ...
local Hub = ns.Hub
local D = ns.Druida
local Num, Str = D.Num, D.Str

local REJUV = { 774, 1058, 1430, 2090, 2091, 3627, 8910, 9839, 9840, 9841, 25299 }
local RECRE = { 8936, 8938, 8939, 8940, 8941, 9750, 9856, 9857, 9858 }
local TOQUE = { 5185, 5186, 5187, 5188, 5189, 6778, 8903, 9758, 9888, 9889, 25297 }
local ALIVIO = { 18562 }
local MALDICION = { 2782 }
local VENENO = { 2893 }
local RAPIDEZ = 17116
local ESTIMULAR = 29166
local DURACION = { rejuv = 12, recre = 21 }
-- Hechizos que se pueden poner en los clics.
local CLICS = { { "rejuv", "Rejuvenecimiento", REJUV }, { "recre", "Recrecimiento", RECRE }, { "toque", "Toque de sanación", TOQUE },
                { "alivio", "Alivio presto", ALIVIO }, { "maldicion", "Eliminar maldición", MALDICION },
                { "veneno", "Suprimir veneno", VENENO }, { "nada", "Nada" } }
local CLIC = {}
for _, c in ipairs(CLICS) do CLIC[c[1]] = c end

local DEFAULTS = {
    escala = 1, opacidad = 1, bloquear = false, fondo = true,
    -- Lista del grupo
    lista = true, banda = false, maxFilas = 10, anchoFila = 180, altoFila = 22,
    clicIzq = "rejuv", clicDer = "recre", clicMayus = "toque",
    verRejuv = true, verRecre = true, colorRejuv = { 0.3, 1, 0.3 }, colorRecre = { 0.3, 0.7, 1 },
    colorClase = true, avisoAcaba = false, segundosAcaba = 2,
    -- Maná
    mana = true, cincoSegundos = true, anchoMana = 180, colorMana = { 0.2, 0.4, 1 },
    avisoMana = true, porcentajeMana = 25, sugerirEstimular = true,
    -- Rapidez de la Naturaleza
    rapidez = true, tamRapidez = 40, avisoRapidezLista = true, avisoRapidezActiva = true,
    -- Avisos
    avisoTexto = true, avisoChat = false, avisoSonido = true, avisoKit = "RAID_WARNING",
    pos = {},
}

local mod, db, marco
local mover = false
local enviado = {}          -- hechizo -> nombre del objetivo (UNIT_SPELLCAST_SENT)
local lanzados = {}         -- [nombre] = { rejuv = fin, recre = fin } (si no se pueden leer las auras)
local ultimoGasto = 0       -- GetTime() del último hechizo con coste de maná
local manaAvisado, rapidezLista, rapidezActiva = false, nil, false
local acabaAvisado = {}

local function Activo() return mod and mod:IsEnabled() and D.EsDruida() and D.EsSanador() end
local function Contiene(lista, id) for _, x in ipairs(lista) do if x == id then return true end end return false end

----------------------------------------------------------------------
-- Curas en el tiempo
----------------------------------------------------------------------
-- Segundos que le quedan a tu cura en esa unidad (aura si se puede, si no lo apuntado al lanzar).
local function QuedaHot(unidad, clave)
    local ids = clave == "rejuv" and REJUV or RECRE
    local fin = D.Aura(unidad, D.Nombre(ids[1]), "HELPFUL|PLAYER")
    if fin == false then return nil end
    if fin and fin ~= math.huge then return math.max(0, fin - GetTime()) end
    local okn, nombre = pcall(UnitName, unidad)
    nombre = okn and Str(nombre)
    local x = nombre and lanzados[nombre] and lanzados[nombre][clave]
    if x and x > GetTime() then return x - GetTime() end
end

local function AlLanzar(unidad, hechizo)
    if unidad ~= "player" then return end
    hechizo = Num(hechizo)
    if not hechizo then return end
    local coste = D.Coste(hechizo)
    if coste and coste > 0 then ultimoGasto = GetTime() end
    local clave = (Contiene(REJUV, hechizo) and "rejuv") or (Contiene(RECRE, hechizo) and "recre")
    local quien = enviado[hechizo]
    enviado[hechizo] = nil
    if clave and quien then
        lanzados[quien] = lanzados[quien] or {}
        lanzados[quien][clave] = GetTime() + DURACION[clave]
    end
end

----------------------------------------------------------------------
-- Marco
----------------------------------------------------------------------
local function Macro(clave)
    local c = CLIC[clave]
    if not c or clave == "nada" then return nil end
    local id = D.Mejor(c[3])
    return id and D.Nombre(id) or nil
end

local function Unidades()
    local okr, banda = pcall(IsInRaid)
    if db.banda and okr and banda and not D.issecret(banda) then
        local u = {}
        for i = 1, db.maxFilas do u[#u + 1] = "raid" .. i end
        return u
    end
    return { "player", "party1", "party2", "party3", "party4" }
end

local function PrepararFilas()
    if not marco or D.EnCombate() then return end
    marco.filas = marco.filas or {}
    local unidades = Unidades()
    for i = 1, math.max(#unidades, #marco.filas) do
        local u = unidades[i]
        local b = marco.filas[i]
        if u and not b then
            b = CreateFrame("Button", "CMSanadorFila" .. i, marco, "SecureUnitButtonTemplate")
            b:RegisterForClicks("AnyUp", "AnyDown")
            b.vida = b:CreateTexture(nil, "BACKGROUND")
            b.vida:SetPoint("TOPLEFT"); b.vida:SetPoint("BOTTOMLEFT")
            b.fondo = b:CreateTexture(nil, "BACKGROUND", nil, -1); b.fondo:SetAllPoints(); b.fondo:SetColorTexture(0, 0, 0, 0.55)
            b.nombre = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); b.nombre:SetPoint("LEFT", 4, 0)
            b.hots = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); b.hots:SetPoint("RIGHT", -4, 0)
            b.luz = b:CreateTexture(nil, "HIGHLIGHT"); b.luz:SetAllPoints(); b.luz:SetColorTexture(1, 1, 1, 0.12)
            marco.filas[i] = b
        end
        if b then
            if u then
                b.unidad = u
                b:SetAttribute("unit", u)
                for boton, clave in pairs({ [1] = db.clicIzq, [2] = db.clicDer }) do
                    local n = Macro(clave)
                    b:SetAttribute("type" .. boton, n and "spell" or nil)
                    b:SetAttribute("spell" .. boton, n)
                end
                local nm = Macro(db.clicMayus)
                b:SetAttribute("shift-type1", nm and "spell" or nil)
                b:SetAttribute("shift-spell1", nm)
                b:SetSize(db.anchoFila, db.altoFila)
                b:ClearAllPoints(); b:SetPoint("TOPLEFT", marco, "TOPLEFT", 6, -6 - (i - 1) * (db.altoFila + 2))
            else
                b.unidad = nil
                b:Hide()
            end
        end
    end
end

local function Crear()
    if marco then return end
    marco = mod:Frame("Frame", "CMSanador", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    marco:SetSize(200, 60)
    D.Movil(mod, marco, "sanador", function() return db.bloquear and not mover end)
    if marco.SetBackdrop then
        marco:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                            edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    end
    marco.mana = CreateFrame("StatusBar", nil, marco)
    marco.mana:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    marco.mana.fondo = marco.mana:CreateTexture(nil, "BACKGROUND"); marco.mana.fondo:SetAllPoints(); marco.mana.fondo:SetColorTexture(0, 0, 0, 0.6)
    marco.mana.texto = marco.mana:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); marco.mana.texto:SetPoint("CENTER")
    marco.cinco = marco:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    marco.rapidez = CreateFrame("Frame", nil, marco)
    PrepararFilas()
end

local function ColorClase(u)
    local ok, _, c = pcall(UnitClass, u)
    local cc = ok and RAID_CLASS_COLORS and RAID_CLASS_COLORS[c]
    if cc then return cc.r, cc.g, cc.b end
    return 0.3, 0.8, 0.3
end

local function Pintar()
    local combate = D.EnCombate()
    if not Activo() then
        if marco and not combate then marco:Hide() end
        return
    end
    if not marco and combate then return end
    Crear()
    marco:SetScale(db.escala); marco:SetAlpha(db.opacidad)
    if marco.SetBackdropColor then
        marco:SetBackdropColor(0, 0, 0, db.fondo and 0.6 or 0)
        marco:SetBackdropBorderColor(1, 1, 1, db.fondo and 0.5 or 0)
    end
    if not combate then PrepararFilas() end
    local y = -6
    -- Lista del grupo.
    for _, b in ipairs(marco.filas) do
        local u = b.unidad
        local ok, existe = pcall(UnitExists, u or "none")
        existe = ok and existe and not D.issecret(existe)
        if db.lista and u and existe then
            local okn, nombre = pcall(UnitName, u)
            b.nombre:SetText(okn and Str(nombre) or "?")
            local okh, h = pcall(UnitHealth, u)
            local okm, hm = pcall(UnitHealthMax, u)
            local fr = okh and okm and Num(h) and Num(hm) and hm > 0 and h / hm
            b.vida:SetWidth(math.max(1, db.anchoFila * (fr or 1)))
            local r, g, bl = 0.3, 0.8, 0.3
            if db.colorClase then r, g, bl = ColorClase(u) end
            b.vida:SetColorTexture(r, g, bl, fr and 0.55 or 0.25)
            local partes = {}
            for _, k in ipairs({ "rejuv", "recre" }) do
                if (k == "rejuv" and db.verRejuv) or (k == "recre" and db.verRecre) then
                    local q = QuedaHot(u, k)
                    if q then
                        local c = k == "rejuv" and db.colorRejuv or db.colorRecre
                        partes[#partes + 1] = ("|cff%02x%02x%02x%s|r"):format(c[1] * 255, c[2] * 255, c[3] * 255, D.Tiempo(q))
                        local clave = u .. k
                        if db.avisoAcaba and q <= db.segundosAcaba and not acabaAvisado[clave] then
                            acabaAvisado[clave] = true
                            D.Avisar(mod, ("%s se acaba en %s"):format(k == "rejuv" and "Rejuvenecimiento" or "Recrecimiento", okn and Str(nombre) or u), true, 0.4, 1, 0.4)
                        elseif q > db.segundosAcaba then
                            acabaAvisado[clave] = nil
                        end
                    end
                end
            end
            b.hots:SetText(table.concat(partes, "  "))
            if not combate then b:Show() end
            y = y - db.altoFila - 2
        else
            if not combate then b:Hide() end
        end
    end
    -- Maná y regla de los 5 segundos.
    local mana, maxMana = D.Mana()
    if db.mana then
        local b = marco.mana
        b:SetSize(db.anchoMana, 12)
        b:ClearAllPoints(); b:SetPoint("TOPLEFT", marco, "TOPLEFT", 6, y - 2)
        local okm, mx = pcall(UnitPowerMax, "player", 0)
        local okv, v = pcall(UnitPower, "player", 0)
        if okm then pcall(b.SetMinMaxValues, b, 0, mx) end
        if okv then pcall(b.SetValue, b, v) end
        local c = db.colorMana
        b:SetStatusBarColor(c[1], c[2], c[3])
        b.texto:SetText(mana and maxMana and maxMana > 0 and ("%d%%"):format(mana / maxMana * 100) or "")
        b:Show()
        y = y - 16
        if db.cincoSegundos then
            local resto = 5 - (GetTime() - ultimoGasto)
            marco.cinco:ClearAllPoints(); marco.cinco:SetPoint("TOPLEFT", marco, "TOPLEFT", 8, y)
            marco.cinco:SetText(resto > 0 and ("|cffffaa33Regla de 5 s: %.1f|r"):format(resto) or "|cff66ff66Regenerando maná|r")
            marco.cinco:Show()
            y = y - 14
        else
            marco.cinco:Hide()
        end
    else
        marco.mana:Hide(); marco.cinco:Hide()
    end
    if db.avisoMana and mana and maxMana and maxMana > 0 then
        if mana / maxMana * 100 < db.porcentajeMana then
            if not manaAvisado then
                manaAvisado = true
                local extra = ""
                if db.sugerirEstimular and D.Conoce(ESTIMULAR) and (D.Enfriamiento(ESTIMULAR) or 1) == 0 then extra = " · usa " .. D.Nombre(ESTIMULAR, "Estimular") end
                D.Avisar(mod, ("Maná bajo (%d%%)%s"):format(mana / maxMana * 100, extra), true, 0.4, 0.6, 1)
            end
        elseif mana / maxMana * 100 > db.porcentajeMana + 10 then
            manaAvisado = false
        end
    end
    -- Rapidez de la Naturaleza.
    if db.rapidez and D.Conoce(RAPIDEZ) then
        local q = D.Enfriamiento(RAPIDEZ)
        local activa = D.Aura("player", D.Nombre(RAPIDEZ), "HELPFUL")
        if activa ~= nil then
            activa = activa and true or false
            if activa and not rapidezActiva and db.avisoRapidezActiva then
                D.Aviso(D.Nombre(RAPIDEZ) .. " activa: tu próxima cura es instantánea", 0.4, 1, 0.4)
            end
            rapidezActiva = activa
        end
        if q then
            if q == 0 and rapidezLista == false and db.avisoRapidezLista then
                D.Avisar(mod, D.Nombre(RAPIDEZ) .. " lista", true, 0.4, 1, 0.4)
            end
            rapidezLista = q == 0
        end
        marco.rapidez:ClearAllPoints(); marco.rapidez:SetPoint("TOPLEFT", marco, "TOPLEFT", 6, y - 2)
        marco.rapidez:SetSize(db.tamRapidez, db.tamRapidez)
        D.Iconos(marco.rapidez, { { icono = D.Icono(RAPIDEZ), queda = q or 0, etiqueta = rapidezActiva and "|cff66ff66ACTIVA|r" or nil } }, db.tamRapidez)
        marco.rapidez:Show()
        y = y - db.tamRapidez - 18
    else
        marco.rapidez:Hide()
    end
    if combate then return end
    if y >= -8 and not mover then marco:Hide(); return end
    marco:SetSize(math.max(db.anchoFila, db.anchoMana) + 12, -y + 4)
    if not marco.colocado then D.Colocar(mod, marco, "sanador", -300, 0); marco.colocado = true end
    marco:EnableMouse(mover or not db.bloquear)
    marco:Show()
end

local acum = 0
local OPC_CLIC = {}
for _, c in ipairs(CLICS) do OPC_CLIC[#OPC_CLIC + 1] = { c[1], c[2] } end
mod = Hub:Register{
    key = "sanador", dir = "Sanador", name = "Sanador", clase = "DRUID",
    desc = "Druida sanador (solo si tu rol de druida es sanador): lista del grupo con lo que les queda a tus "
        .. "Rejuvenecimiento y Recrecimiento (clic para lanzar), maná con la regla de los 5 segundos y aviso de maná "
        .. "bajo, y Rapidez de la Naturaleza en grande.",
    defaults = DEFAULTS,
    slash = { "cmsanador" },
    Init = function(m)
        db = m.db
        m:Event("UNIT_SPELLCAST_SENT", function(_, _, unidad, objetivo, _, hechizo)
            if unidad == "player" and Num(hechizo) then enviado[hechizo] = Str(objetivo) end
        end)
        m:Event("UNIT_SPELLCAST_SUCCEEDED", function(_, _, unidad, _, hechizo) AlLanzar(unidad, hechizo) end)
        m:Event("GROUP_ROSTER_UPDATE", function() PrepararFilas(); Pintar() end)
        m:Event("PLAYER_REGEN_ENABLED", function() PrepararFilas(); Pintar() end)
        m:OnUpdate(function(_, e)
            acum = acum + e
            if acum >= 0.1 then acum = 0; Pintar() end
        end)
    end,
    Enable = function(m) db = m.db; Pintar() end,
    Disable = function() if marco and not D.EnCombate() then marco:Hide() end end,
    OnReset = function() if marco then marco.colocado = false end end,
    OnSlash = function(m, msg)
        if (msg or ""):lower() == "mover" then mover = not mover; Pintar() else Hub:Open("sanador") end
    end,
    BuildConfig = function(m, L)
        db = m.db
        local function G(k) return function() return db[k] end end
        local function S(k) return function(v) db[k] = v; PrepararFilas(); Pintar() end end
        local function Col(k) return function() local c = db[k]; return c[1], c[2], c[3] end end
        local function SetCol(k) return function(r, g, b) db[k] = { r, g, b }; Pintar() end end
        L:Text("Solo funciona si tu rol de druida (pestaña Druida) es sanador o ambos. Ahora: |cffffd100" .. D.Rol() .. "|r. "
            .. "Los cambios de los clics se aplican fuera de combate.", true)
        L:Button("Mover", 90, function() mover = not mover; Pintar() end)
        L:Button("Volver a su sitio", 140, function() db.pos.sanador = nil; if marco then marco.colocado = false end; Pintar() end, true)
        L:Check("Bloquear la posición", G("bloquear"), S("bloquear"))
        L:Check("Fondo y borde", G("fondo"), S("fondo"))
        L:Slider("Escala", 0.5, 2, 0.05, G("escala"), S("escala"), "%.2f")
        L:Slider("Opacidad", 0.2, 1, 0.05, G("opacidad"), S("opacidad"), "%.2f")

        L:Header("Lista del grupo")
        L:Check("Mostrar la lista", G("lista"), S("lista"))
        L:Check("  En banda, toda la banda (si no, tu grupo)", G("banda"), S("banda"))
        L:Slider("  Filas como máximo en banda", 5, 40, 1, G("maxFilas"), S("maxFilas"))
        L:Slider("  Ancho de fila", 120, 320, 5, G("anchoFila"), S("anchoFila"))
        L:Slider("  Alto de fila", 14, 40, 1, G("altoFila"), S("altoFila"))
        L:Check("  Vida con el color de la clase", G("colorClase"), S("colorClase"))
        L:Check("  Tu Rejuvenecimiento", G("verRejuv"), S("verRejuv"))
        L:Color("    Color", Col("colorRejuv"), SetCol("colorRejuv"))
        L:Check("  Tu Recrecimiento", G("verRecre"), S("verRecre"))
        L:Color("    Color", Col("colorRecre"), SetCol("colorRecre"))
        L:Choice("  Clic izquierdo", OPC_CLIC, G("clicIzq"), S("clicIzq"))
        L:Choice("  Clic derecho", OPC_CLIC, G("clicDer"), S("clicDer"))
        L:Choice("  Mayús + clic izquierdo", OPC_CLIC, G("clicMayus"), S("clicMayus"))
        L:Check("  Aviso cuando una de tus curas está a punto de acabar", G("avisoAcaba"), S("avisoAcaba"))
        L:Slider("    Segundos antes", 1, 6, 1, G("segundosAcaba"), S("segundosAcaba"))

        L:Header("Maná")
        L:Check("Barra de maná", G("mana"), S("mana"))
        L:Slider("  Ancho", 100, 320, 5, G("anchoMana"), S("anchoMana"))
        L:Color("  Color", Col("colorMana"), SetCol("colorMana"))
        L:Check("  Regla de los 5 segundos (cuándo vuelves a regenerar)", G("cincoSegundos"), S("cincoSegundos"))
        L:Check("Aviso de maná bajo", G("avisoMana"), S("avisoMana"))
        L:Slider("  Por debajo de (%)", 5, 60, 5, G("porcentajeMana"), S("porcentajeMana"))
        L:Check("  Sugerir Estimular si lo tienes listo", G("sugerirEstimular"), S("sugerirEstimular"))

        L:Header(D.Nombre(RAPIDEZ, "Rapidez de la Naturaleza"))
        L:Check("Icono con su enfriamiento", G("rapidez"), S("rapidez"))
        L:Slider("  Tamaño", 20, 80, 1, G("tamRapidez"), S("tamRapidez"))
        L:Check("  Aviso cuando vuelve a estar lista", G("avisoRapidezLista"), S("avisoRapidezLista"))
        L:Check("  Aviso cuando la activas", G("avisoRapidezActiva"), S("avisoRapidezActiva"))

        L:Header("Cómo avisa")
        L:Check("Texto grande", G("avisoTexto"), S("avisoTexto"))
        L:Check("Línea en el chat", G("avisoChat"), S("avisoChat"))
        L:Check("Sonido", G("avisoSonido"), S("avisoSonido"))
        L:Choice("  Sonido", D.KITS, G("avisoKit"), function(v) db.avisoKit = v; D.Sonar(v) end)
    end,
}
