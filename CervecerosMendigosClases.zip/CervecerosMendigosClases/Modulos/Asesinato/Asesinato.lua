-- Asesinato (CervecerosMendigos Clases, pícaro): solo con rol asesinato.
--   Sangre fría en grande con aviso cuando vuelve a estar lista, tu Garrote y Desgarrar en el objetivo,
--   cargas de Veneno mortal (en rojo con menos de 5) y aviso de Ataques despiadados.
local ADDON, ns = ...
local U = ns.CU

U.Modulo{
    key = "asesinato", dir = "Asesinato", name = "Asesinato", clase = "ROGUE", slash = { "cmasesinato" }, rolDe = "picaro", rol = "asesinato",
    desc = "Pícaro de asesinato (solo con ese rol): Sangre fría en grande, tu Garrote, Desgarrar y las cargas de Veneno "
        .. "mortal en el objetivo, y aviso de Ataques despiadados.",
    objetivo = {
        { "garrote", { 703, 8631, 8632, 8633, 11289, 11290 }, "Garrote" },
        { "desgarrar", { 1943, 8639, 8640, 11273, 11274, 11275 }, "Desgarrar" },
        { "mortal", { 2818, 2819, 11353, 11354, 25349 }, "Veneno mortal", cargas = 5, si = { 2835, 2837, 11357, 11358, 25347 } },
    },
    procs = { { "despiadados", { 14143, 14149 }, "Ataques despiadados", si = { 14144, 14148 } } },
    cds = { { "sangreFria", { 14177 }, "Sangre fría" }, { "envenenar", { 32645, 32684 }, "Envenenar", avisoListo = false } },
}
