-- Reprensión (CervecerosMendigos Clases, paladín): solo se enciende si tu rol de paladín es reprensión.
--   * Sentencia en grande y tu sello.
--   * Sentencia del cruzado en el objetivo: lo que le queda y aviso cuando se va a acabar.
--   * Martillo de cólera: aviso cuando el objetivo baja del 20 % y lo tienes listo.
--   * Venganza (talento): lo que le queda. Enfriamientos de Consagración y Arrepentimiento.
local ADDON, ns = ...
local Hub = ns.Hub
local U = ns.CU
local P = ns.Paladin

local SENTENCIA = { 20271 }
local CRUZADO = { 21183, 20188, 20300, 20301, 20302, 20303 }
local MARTILLO = { 24275, 24274, 24239 }
local VENGANZA = { 20050, 20052, 20053, 20054, 20055 }
local CONSAGRACION = { 26573, 20116, 20922, 20923, 20924 }
local ARREPENTIMIENTO = { 20066 }

local DEFAULTS = {
    escala = 1, opacidad = 1, bloquear = false, tamIcono = 36,
    cdSentencia = true, cdConsagracion = false, cdArrepentimiento = true, cdMartillo = true,
    verSello = true, cruzado = true, segundosCruzado = 5, avisoCruzado = true,
    martillo = true, porcentajeMartillo = 20, venganza = true,
    avisoTexto = true, avisoChat = false, avisoSonido = true, avisoKit = "RAID_WARNING",
    pos = {},
}

local mod, db, marco
local mover = false
local avisadoCruzado, avisadoMartillo = {}, {}

local function Activo() return mod and mod:IsEnabled() and P.EsPaladin() and P.Rol() == "reprension" end

local function Pintar()
    if not Activo() then if marco then marco:Hide() end return end
    marco = marco or P.Panel(mod, "CMReprension", "reprension", function() return mover end)
    local combate = U.EnCombate()
    local lineas, iconos = {}, {}
    if db.verSello then
        local sello = P.SelloActivo()
        if sello then lineas[#lineas + 1] = "|cffffd100" .. sello .. "|r"
        elseif sello == false then lineas[#lineas + 1] = "|cffff5555Sin sello|r" end
    end
    local hay = P.HayEnemigo()
    local okg, guid = pcall(UnitGUID, "target")
    guid = okg and U.Str(guid) or "?"
    if db.cruzado and hay and U.Conoce(SENTENCIA[1]) then
        local q = P.EnObjetivo(CRUZADO)
        local nombre = U.Nombre(CRUZADO[1], "Sentencia del cruzado")
        if q and q ~= false then
            lineas[#lineas + 1] = (q <= db.segundosCruzado and "|cffff5555%s %s|r" or "%s %s"):format(nombre, U.Tiempo(q))
            if q <= db.segundosCruzado and db.avisoCruzado and combate and not avisadoCruzado[guid] then
                avisadoCruzado[guid] = true
                U.Avisar(mod, nombre .. ": quedan " .. math.ceil(q) .. " s", true)
            elseif q > db.segundosCruzado then
                avisadoCruzado[guid] = nil
            end
        end
    end
    if db.martillo and hay and U.ConoceAlguno(MARTILLO) then
        local okh, h = pcall(UnitHealth, "target")
        local okm, hm = pcall(UnitHealthMax, "target")
        h, hm = okh and U.Num(h), okm and U.Num(hm)
        local q = U.Enfriamiento(U.Mejor(MARTILLO))
        if h and hm and hm > 0 and h / hm * 100 < db.porcentajeMartillo and q == 0 then
            local nombre = U.Nombre(MARTILLO[1], "Martillo de cólera")
            lineas[#lineas + 1] = "|cff66ff66¡" .. nombre .. "!|r"
            if not avisadoMartillo[guid] then avisadoMartillo[guid] = true; U.Avisar(mod, "¡" .. nombre .. "!", true, 1, 0.82, 0) end
        end
    end
    if db.venganza and U.ConoceAlguno(VENGANZA) then
        local fin = U.Aura("player", U.Nombre(VENGANZA[1], "Venganza"), "HELPFUL")
        if fin and fin ~= math.huge then lineas[#lineas + 1] = ("%s %s"):format(U.Nombre(VENGANZA[1], "Venganza"), U.Tiempo(math.max(0, fin - GetTime()))) end
    end
    for _, x in ipairs({ { db.cdSentencia, SENTENCIA }, { db.cdMartillo, MARTILLO }, { db.cdConsagracion, CONSAGRACION }, { db.cdArrepentimiento, ARREPENTIMIENTO } }) do
        local id = x[1] and U.Mejor(x[2])
        if id then iconos[#iconos + 1] = { icono = U.Icono(id), queda = U.Enfriamiento(id) or 0 } end
    end
    P.PintarPanel(mod, marco, lineas, iconos, mover, 0, -260)
end

local acum = 0
mod = Hub:Register{
    key = "reprension", dir = "Reprension", name = "Reprensión", clase = "PALADIN",
    desc = "Paladín de reprensión (solo con ese rol): Sentencia en grande, tu sello, lo que le queda a la Sentencia del "
        .. "cruzado en el objetivo, aviso de Martillo de cólera cuando baja del 20 %, Venganza y tus enfriamientos.",
    defaults = DEFAULTS,
    slash = { "cmreprension" },
    Init = function(m)
        db = m.db
        m:Event("PLAYER_TARGET_CHANGED", Pintar)
        m:OnUpdate(function(_, e) acum = acum + e; if acum >= 0.1 then acum = 0; Pintar() end end)
    end,
    Enable = function(m) db = m.db; Pintar() end,
    Disable = function() if marco then marco:Hide() end end,
    OnReset = function() if marco then marco.colocado = false end end,
    OnSlash = function(m, msg) if (msg or ""):lower() == "mover" then mover = not mover; Pintar() else Hub:Open("reprension") end end,
    BuildConfig = function(m, L)
        db = m.db
        local function G(k) return function() return db[k] end end
        local function S(k) return function(v) db[k] = v; Pintar() end end
        L:Text("Solo funciona si tu rol de paladín (pestaña Paladín) es reprensión. Ahora: |cffffd100" .. P.Rol() .. "|r.", true)
        L:Button("Mover", 90, function() mover = not mover; Pintar() end)
        L:Button("Volver a su sitio", 140, function() db.pos.reprension = nil; if marco then marco.colocado = false end; Pintar() end, true)
        L:Check("Bloquear la posición", G("bloquear"), S("bloquear"))
        L:Slider("Escala", 0.5, 2, 0.05, G("escala"), S("escala"), "%.2f")
        L:Slider("Opacidad", 0.2, 1, 0.05, G("opacidad"), S("opacidad"), "%.2f")
        L:Header("Qué enseña")
        L:Check("Tu sello", G("verSello"), S("verSello"))
        L:Check(U.Nombre(CRUZADO[1], "Sentencia del cruzado") .. " en el objetivo", G("cruzado"), S("cruzado"))
        L:Slider("  En rojo cuando quedan (segundos)", 0, 15, 1, G("segundosCruzado"), S("segundosCruzado"))
        L:Check("  Aviso en combate cuando se va a acabar", G("avisoCruzado"), S("avisoCruzado"))
        L:Check("Aviso de " .. U.Nombre(MARTILLO[1], "Martillo de cólera"), G("martillo"), S("martillo"))
        L:Slider("  Cuando el objetivo baja del (%)", 5, 35, 1, G("porcentajeMartillo"), S("porcentajeMartillo"))
        L:Check(U.Nombre(VENGANZA[1], "Venganza") .. " (talento): lo que le queda", G("venganza"), S("venganza"))
        L:Header("Enfriamientos")
        L:Check("  " .. U.Nombre(SENTENCIA[1], "Sentencia"), G("cdSentencia"), S("cdSentencia"))
        L:Check("  " .. U.Nombre(MARTILLO[1], "Martillo de cólera"), G("cdMartillo"), S("cdMartillo"))
        L:Check("  " .. U.Nombre(CONSAGRACION[1], "Consagración"), G("cdConsagracion"), S("cdConsagracion"))
        L:Check("  " .. U.Nombre(ARREPENTIMIENTO[1], "Arrepentimiento"), G("cdArrepentimiento"), S("cdArrepentimiento"))
        L:Slider("  Tamaño", 20, 70, 1, G("tamIcono"), S("tamIcono"))
        L:Header("Cómo avisa")
        L:Check("Texto grande", G("avisoTexto"), S("avisoTexto"))
        L:Check("Línea en el chat", G("avisoChat"), S("avisoChat"))
        L:Check("Sonido", G("avisoSonido"), S("avisoSonido"))
        L:Choice("  Sonido", U.KITS, G("avisoKit"), function(v) db.avisoKit = v; U.Sonar(v) end)
    end,
}
