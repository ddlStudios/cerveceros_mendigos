-- Mejora (CervecerosMendigos Clases, chamán): solo se enciende si tu rol de chamán es mejora.
--   * Ataque de tormenta: enfriamiento y las cargas que deja en el objetivo.
--   * Torbellino (Flurry): cargas y cuánto lo mantienes activo en cada pelea.
--   * Aviso si peleas sin Arma Viento furioso (si la conoces).
local ADDON, ns = ...
local Hub = ns.Hub
local U = ns.CU
local C = ns.Chaman

local TORMENTA = 17364
local TORBELLINO = { 16257, 16277, 16278, 16279, 16280 }
local VIENTO = { 8232, 8235, 10486, 16362 }

local DEFAULTS = {
    escala = 1, opacidad = 1, bloquear = false, tamIcono = 36,
    tormenta = true, cargasTormenta = true,
    torbellino = true, uptime = true,
    avisoViento = false,
    avisoTexto = true, avisoChat = false, avisoSonido = true, avisoKit = "RAID_WARNING",
    pos = {},
}

local mod, db, marco
local mover = false
local enPelea, tPelea, tActivo, ultimoTick = false, 0, 0, nil
local vientoAvisado = false

local function Activo() return mod and mod:IsEnabled() and C.EsChaman() and C.Rol() == "mejora" end

local function Pintar()
    if not Activo() then if marco then marco:Hide() end return end
    marco = marco or U.Panel(mod, "CMMejora", "mejora", function() return mover end)
    local lineas, iconos = {}, {}
    local combate = U.EnCombate()
    if db.tormenta and U.Conoce(TORMENTA) then
        iconos[#iconos + 1] = { icono = U.Icono(TORMENTA), queda = U.Enfriamiento(TORMENTA) or 0 }
        if db.cargasTormenta and U.HayEnemigo() then
            local nombre = U.Nombre(TORMENTA, "Ataque de tormenta")
            local fin, _, cargas = U.Aura("target", nombre, "HARMFUL|PLAYER")
            if fin and fin ~= math.huge then
                lineas[#lineas + 1] = ("%s en el objetivo: %d cargas · %s"):format(nombre, cargas or 0, U.Tiempo(math.max(0, fin - GetTime())))
            end
        end
    end
    if db.torbellino and U.ConoceAlguno(TORBELLINO) then
        local nombre = U.Nombre(TORBELLINO[1], "Torbellino")
        local fin, _, cargas = U.Aura("player", nombre, "HELPFUL")
        if fin then lineas[#lineas + 1] = ("|cffffd100%s: %d cargas|r"):format(nombre, cargas or 0) end
        -- Tiempo activo en la pelea.
        local ahora = GetTime()
        if combate then
            if not enPelea then enPelea, tPelea, tActivo = true, 0, 0 end
            if ultimoTick then
                local dt = ahora - ultimoTick
                tPelea = tPelea + dt
                if fin then tActivo = tActivo + dt end
            end
            ultimoTick = ahora
        else
            enPelea, ultimoTick = false, nil
        end
        if db.uptime and tPelea > 0 then
            lineas[#lineas + 1] = ("%s activo: %d%%%s"):format(nombre, tActivo / tPelea * 100, enPelea and "" or " (última pelea)")
        end
    end
    if db.avisoViento and combate and U.ConoceAlguno(VIENTO) then
        local okt, tiene = pcall(GetWeaponEnchantInfo)
        if okt and not tiene and not vientoAvisado then
            vientoAvisado = true
            U.Avisar(mod, "Peleando sin imbuir el arma", true)
        end
    elseif not combate then
        vientoAvisado = false
    end
    U.PintarPanel(mod, marco, lineas, iconos, mover, 0, -260)
end

local acum = 0
mod = Hub:Register{
    key = "mejora", dir = "Mejora", name = "Mejora", clase = "SHAMAN",
    desc = "Chamán de mejora (solo con ese rol): Ataque de tormenta con su enfriamiento y las cargas en el objetivo, "
        .. "Torbellino con sus cargas y cuánto lo mantienes activo, y aviso si peleas con el arma sin imbuir.",
    defaults = DEFAULTS,
    slash = { "cmmejora" },
    Init = function(m)
        db = m.db
        m:Event("PLAYER_TARGET_CHANGED", Pintar)
        m:OnUpdate(function(_, e) acum = acum + e; if acum >= 0.1 then acum = 0; Pintar() end end)
    end,
    Enable = function(m) db = m.db; Pintar() end,
    Disable = function() if marco then marco:Hide() end end,
    OnReset = function() if marco then marco.colocado = false end end,
    OnSlash = function(m, msg) if (msg or ""):lower() == "mover" then mover = not mover; Pintar() else Hub:Open("mejora") end end,
    BuildConfig = function(m, L)
        db = m.db
        local function G(k) return function() return db[k] end end
        local function S(k) return function(v) db[k] = v; Pintar() end end
        L:Text("Solo funciona si tu rol de chamán (pestaña Chamán) es mejora. Ahora: |cffffd100" .. C.Rol() .. "|r. "
            .. "El arma imbuida (tiempo y cargas) está en la pestaña Chamán.", true)
        L:Button("Mover", 90, function() mover = not mover; Pintar() end)
        L:Button("Volver a su sitio", 140, function() db.pos.mejora = nil; if marco then marco.colocado = false end; Pintar() end, true)
        L:Check("Bloquear la posición", G("bloquear"), S("bloquear"))
        L:Slider("Escala", 0.5, 2, 0.05, G("escala"), S("escala"), "%.2f")
        L:Slider("Opacidad", 0.2, 1, 0.05, G("opacidad"), S("opacidad"), "%.2f")
        L:Slider("Tamaño de los iconos", 20, 70, 1, G("tamIcono"), S("tamIcono"))
        L:Header("Qué enseña")
        L:Check(U.Nombre(TORMENTA, "Ataque de tormenta") .. ": enfriamiento", G("tormenta"), S("tormenta"))
        L:Check("  Cargas que deja en el objetivo", G("cargasTormenta"), S("cargasTormenta"))
        L:Check(U.Nombre(TORBELLINO[1], "Torbellino") .. ": cargas", G("torbellino"), S("torbellino"))
        L:Check("  Cuánto lo mantienes activo en cada pelea (%)", G("uptime"), S("uptime"))
        L:Check("Aviso si peleas con el arma sin imbuir", G("avisoViento"), S("avisoViento"))
        L:Header("Cómo avisa")
        L:Check("Texto grande", G("avisoTexto"), S("avisoTexto"))
        L:Check("Línea en el chat", G("avisoChat"), S("avisoChat"))
        L:Check("Sonido", G("avisoSonido"), S("avisoSonido"))
        L:Choice("  Sonido", U.KITS, G("avisoKit"), function(v) db.avisoKit = v; U.Sonar(v) end)
    end,
}
