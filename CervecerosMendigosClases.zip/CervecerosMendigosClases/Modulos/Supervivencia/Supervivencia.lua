-- Supervivencia (CervecerosMendigos Clases, cazador): solo se enciende si tu rol de cazador es supervivencia.
--   * Picadura de dracoleón y Disuasión en grande, con aviso cuando vuelven a estar listas.
--   * Contraataque: aviso cuando lo puedes usar (después de parar un golpe).
local ADDON, ns = ...
local Hub = ns.Hub
local U = ns.CU
local H = ns.Cazador

local DRACOLEON = { 19386, 24132, 24133 }
local DISUASION = 19263
local CONTRA = { 19306, 20909, 20910 }

local DEFAULTS = {
    escala = 1, opacidad = 1, bloquear = false, tamIcono = 36,
    dracoleon = true, disuasion = true, avisoListo = true, contraataque = true, contraSonido = true,
    avisoTexto = true, avisoChat = false, avisoSonido = true, avisoKit = "RAID_WARNING",
    pos = {},
}

local mod, db, marco
local mover = false
local listos, contraUsable = {}, false

local function Activo() return mod and mod:IsEnabled() and H.EsCazador() and H.Rol() == "supervivencia" end

-- ¿Se puede usar ahora? (Contraataque solo se puede tras parar un golpe.)
local function Usable(id)
    if C_Spell and C_Spell.IsSpellUsable then
        local ok, v = pcall(C_Spell.IsSpellUsable, id)
        if ok and not U.issecret(v) then return v and true or false end
    end
    if IsUsableSpell then
        local ok, v = pcall(IsUsableSpell, id)
        if ok and not U.issecret(v) then return v and true or false end
    end
end

local function Pintar()
    if not Activo() then if marco then marco:Hide() end return end
    marco = marco or U.Panel(mod, "CMSupervivencia", "supervivencia", function() return mover end)
    local lineas, iconos = {}, {}
    for _, x in ipairs({ { db.dracoleon, DRACOLEON, "dracoleon" }, { db.disuasion, { DISUASION }, "disuasion" } }) do
        local id = x[1] and U.Mejor(x[2])
        if id then
            local q = U.Enfriamiento(id)
            if q then
                if q == 0 and listos[x[3]] == false and db.avisoListo then U.Avisar(mod, U.Nombre(id) .. " lista", true, 0.4, 1, 0.4) end
                listos[x[3]] = q == 0
            end
            iconos[#iconos + 1] = { icono = U.Icono(id), queda = q or 0 }
        end
    end
    local contra = db.contraataque and U.Mejor(CONTRA)
    if contra then
        local usable = Usable(contra) and (U.Enfriamiento(contra) or 0) == 0
        if usable then
            lineas[#lineas + 1] = "|cff66ff66¡" .. U.Nombre(contra, "Contraataque") .. "!|r"
            if not contraUsable then
                U.Aviso("¡" .. U.Nombre(contra, "Contraataque") .. "!", 0.4, 1, 0.4)
                if db.contraSonido then U.Sonar(db.avisoKit) end
            end
        end
        contraUsable = usable or false
    end
    U.PintarPanel(mod, marco, lineas, iconos, mover, 0, -260)
end

local acum = 0
mod = Hub:Register{
    key = "supervivencia", dir = "Supervivencia", name = "Supervivencia", clase = "HUNTER",
    desc = "Cazador de supervivencia (solo con ese rol): Picadura de dracoleón y Disuasión en grande con aviso cuando "
        .. "están listas, y aviso de Contraataque cuando lo puedes usar.",
    defaults = DEFAULTS,
    slash = { "cmsupervivencia" },
    Init = function(m)
        db = m.db
        m:OnUpdate(function(_, e) acum = acum + e; if acum >= 0.1 then acum = 0; Pintar() end end)
    end,
    Enable = function(m) db = m.db; Pintar() end,
    Disable = function() if marco then marco:Hide() end end,
    OnReset = function() if marco then marco.colocado = false end end,
    OnSlash = function(m, msg) if (msg or ""):lower() == "mover" then mover = not mover; Pintar() else Hub:Open("supervivencia") end end,
    BuildConfig = function(m, L)
        db = m.db
        local function G(k) return function() return db[k] end end
        local function S(k) return function(v) db[k] = v; Pintar() end end
        L:Text("Solo funciona si tu rol de cazador (pestaña Cazador) es supervivencia. Ahora: |cffffd100" .. H.Rol() .. "|r.", true)
        L:Button("Mover", 90, function() mover = not mover; Pintar() end)
        L:Button("Volver a su sitio", 140, function() db.pos.supervivencia = nil; if marco then marco.colocado = false end; Pintar() end, true)
        L:Check("Bloquear la posición", G("bloquear"), S("bloquear"))
        L:Slider("Escala", 0.5, 2, 0.05, G("escala"), S("escala"), "%.2f")
        L:Slider("Opacidad", 0.2, 1, 0.05, G("opacidad"), S("opacidad"), "%.2f")
        L:Slider("Tamaño de los iconos", 20, 70, 1, G("tamIcono"), S("tamIcono"))
        L:Header("Qué enseña")
        L:Check(U.Nombre(DRACOLEON[1], "Picadura de dracoleón"), G("dracoleon"), S("dracoleon"))
        L:Check(U.Nombre(DISUASION, "Disuasión"), G("disuasion"), S("disuasion"))
        L:Check("  Aviso cuando vuelven a estar listas", G("avisoListo"), S("avisoListo"))
        L:Check("Aviso de " .. U.Nombre(CONTRA[1], "Contraataque") .. " cuando lo puedes usar", G("contraataque"), S("contraataque"))
        L:Check("  Con sonido", G("contraSonido"), S("contraSonido"))
        L:Header("Cómo avisa")
        L:Check("Texto grande", G("avisoTexto"), S("avisoTexto"))
        L:Check("Línea en el chat", G("avisoChat"), S("avisoChat"))
        L:Check("Sonido", G("avisoSonido"), S("avisoSonido"))
        L:Choice("  Sonido", U.KITS, G("avisoKit"), function(v) db.avisoKit = v; U.Sonar(v) end)
    end,
}
