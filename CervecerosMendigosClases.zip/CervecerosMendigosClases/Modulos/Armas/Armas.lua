-- Armas (CervecerosMendigos Clases, guerrero): solo con rol armas.
--   Golpe mortal y Golpes de barrido en grande, Desgarrar en el objetivo y aviso de Abrumar.
local ADDON, ns = ...
local U = ns.CU

U.Modulo{
    key = "armas", dir = "Armas", name = "Armas", clase = "WARRIOR", slash = { "cmarmas" }, rolDe = "guerrero", rol = "armas",
    desc = "Guerrero de armas (solo con ese rol): Golpe mortal y Golpes de barrido en grande, tu Desgarrar y el Golpe "
        .. "mortal en el objetivo, y aviso de Abrumar.",
    objetivo = { { "mortal", { 12294, 21551, 21552, 21553 }, "Golpe mortal" }, { "desgarrar", { 772, 6546, 6547, 6548, 11572, 11573, 11574 }, "Desgarrar" } },
    usables = { { "abrumar", { 7384, 7887, 11584, 11585 }, "Abrumar" } },
    cds = { { "mortal", { 12294, 21551, 21552, 21553 }, "Golpe mortal", avisoListo = false }, { "barrido", { 12292 }, "Golpes de barrido" } },
}
