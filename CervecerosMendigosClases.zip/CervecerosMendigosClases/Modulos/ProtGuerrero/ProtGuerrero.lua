-- Protección (CervecerosMendigos Clases, guerrero): solo con rol protección.
--   Bloquear con escudo (cuánto lo mantienes), Embate con escudo, Último recurso y Muro de escudo en grande,
--   aviso de Revancha, cargas de Hender armadura (aviso si faltan) y Provocar.
local ADDON, ns = ...
local U = ns.CU

U.Modulo{
    key = "protguerrero", dir = "ProtGuerrero", name = "Protección", clase = "WARRIOR", slash = { "cmprotguerrero" },
    rolDe = "guerrero", rol = "proteccion",
    desc = "Guerrero de protección (solo con ese rol): Bloquear con escudo, Embate con escudo, Último recurso, Muro de "
        .. "escudo, Provocar y Grito desafiante en grande, aviso de Revancha y las cargas de Hender armadura.",
    objetivo = { { "hender", { 7386, 7405, 8380, 11596, 11597 }, "Hender armadura", propio = false, cargas = 5, falta = true } },
    usables = { { "revancha", { 6572, 6574, 7379, 11600, 11601, 25288 }, "Revancha" } },
    uptime = { { "bloquear", { 2565 }, "Bloquear con escudo" } },
    cds = { { "bloquear", { 2565 }, "Bloquear con escudo", avisoListo = false }, { "embate", { 23922, 23923, 23924, 23925 }, "Embate con escudo", avisoListo = false },
            { "ultimo", { 12975 }, "Último recurso" }, { "muro", { 871 }, "Muro de escudo" }, { "provocar", { 355 }, "Provocar", avisoListo = false },
            { "desafiante", { 1161 }, "Grito desafiante" } },
}
