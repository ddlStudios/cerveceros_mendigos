-- Mago (CervecerosMendigos Clases): lo de cualquier mago (montado con el motor de ComunClases).
--   Rol (arcano, fuego, escarcha), aviso si vas sin armadura, Intelecto arcano al grupo (a quien usa maná),
--   agua, comida y gema de maná con botón para conjurarlas, polvo arcano y runas, tu Polimorfia en el
--   objetivo, maná con la regla de los 5 segundos y enfriamientos.
local ADDON, ns = ...
local U = ns.CU

U.Modulo{
    key = "mago", dir = "Mago", name = "Mago", clase = "MAGE", slash = { "cmmago" },
    desc = "Para cualquier mago: elige tu rol, aviso si vas sin armadura, a quién le falta Intelecto arcano, agua, "
        .. "comida y gema de maná con botón para conjurarlas, polvo arcano y runas, tu Polimorfia en el objetivo, "
        .. "maná con la regla de los 5 segundos y tus enfriamientos.",
    roles = { { "arcano", "Arcano" }, { "fuego", "Fuego" }, { "escarcha", "Escarcha" } },
    pistas = { { "arcano", { 12042 } }, { "fuego", { 11129 } }, { "escarcha", { 11426, 13031, 13032, 13033 } },
               { "arcano", { 12043 } }, { "fuego", { 11113, 13018, 13019, 13020, 13021 } }, { "escarcha", { 12472 } } },
    propios = { { "armadura", { { 168, 7300, 7301 }, { 7302, 7320, 10219, 10220 }, { 6117, 22782, 22783 } }, "armadura (Escarcha, Hielo o Mago)" } },
    beneficios = { { "intelecto", { 1459, 1460, 1461, 10156, 10157 }, "Intelecto arcano", grupo = { 23028 }, soloMana = true } },
    materiales = {
        { "agua", { 5350, 2288, 2136, 3772, 8077, 8078, 8079 }, "Agua conjurada", 20, crear = { 5504, 5505, 5506, 6127, 10138, 10139, 10140 } },
        { "comida", { 5349, 1113, 1114, 1487, 8075, 8076, 22895 }, "Comida conjurada", 10, crear = { 587, 597, 990, 6129, 10144, 10145, 28612 } },
        { "gema", { 5514, 5513, 8007, 8008 }, "Gema de maná", 1, crear = { 759, 3552, 10053, 10054 } },
        { "polvo", { 17020 }, nil, 10, si = { 23028 } },
        { "runaTele", { 17031 }, nil, 3, si = { 3561, 3562, 3563, 3565, 3566, 3567 } },
        { "runaPortal", { 17032 }, nil, 3, si = { 10059, 11416, 11417, 11418, 11419, 11420 } },
        { "pluma", { 17056 }, nil, 5, si = { 130 } },
    },
    objetivo = { { "polimorfia", { 118, 12824, 12825, 12826, 28270, 28271, 28272 }, "Polimorfia" } },
    cds = { { "contrahechizo", { 2139 }, "Contrahechizo" }, { "traslacion", { 1953 }, "Traslación", avisoListo = false },
            { "nova", { 122, 865, 6131, 10230 }, "Nova de Escarcha", avisoListo = false }, { "bloque", { 11958 }, "Bloque de hielo" },
            { "evocacion", { 12051 }, "Evocación" } },
    mana = true,
}
