-- Restauración (CervecerosMendigos Clases, chamán): solo se enciende si tu rol de chamán es restauración.
--   * Lista del grupo con la vida de cada uno, lo que le puedes quitar (veneno, enfermedad) y las cargas de
--     Senda de sanación. Clic izquierdo / derecho / Mayús+clic lanza el hechizo que elijas sobre esa persona.
--   * Maná con la regla de los 5 segundos y aviso de maná bajo.
--   * Rapidez de la Naturaleza y Tótem de marea de maná en grande, con aviso cuando vuelven a estar listos.
local ADDON, ns = ...
local Hub = ns.Hub
local U = ns.CU
local C = ns.Chaman
local Num, Str = U.Num, U.Str

local OLA = { 331, 332, 547, 913, 939, 959, 8005, 10395, 10396, 25357 }
local OLA_MENOR = { 8004, 8008, 8010, 10466, 10467, 10468 }
local CADENA = { 1064, 10622, 10623 }
local CURAR_VENENO = { 526 }
local CURAR_ENFERMEDAD = { 2870 }
local SENDA = 29203
local RAPIDEZ = 16188
local MAREA = { 16190, 17354, 17359 }
local CLICS = { { "menor", "Ola de sanación inferior", OLA_MENOR }, { "ola", "Ola de sanación", OLA }, { "cadena", "Sanación en cadena", CADENA },
                { "veneno", "Curar veneno", CURAR_VENENO }, { "enfermedad", "Curar enfermedad", CURAR_ENFERMEDAD }, { "nada", "Nada" } }
local CLIC = {}
for _, c in ipairs(CLICS) do CLIC[c[1]] = c end
local TIPOS = { Poison = { "Veneno", { 0.2, 0.9, 0.2 } }, Disease = { "Enfermedad", { 0.8, 0.6, 0.2 } } }

local DEFAULTS = {
    escala = 1, opacidad = 1, bloquear = false, fondo = true,
    lista = true, banda = false, maxFilas = 10, anchoFila = 180, altoFila = 22, colorClase = true,
    clicIzq = "menor", clicDer = "cadena", clicMayus = "ola",
    verQuitar = true, quitarVeneno = true, quitarEnfermedad = true, avisoQuitar = false, verSenda = true,
    mana = true, cincoSegundos = true, anchoMana = 180, colorMana = { 0.2, 0.4, 1 },
    avisoMana = true, porcentajeMana = 25,
    verRapidez = true, verMarea = true, tamIcono = 36, avisoListo = true,
    avisoTexto = true, avisoChat = false, avisoSonido = true, avisoKit = "RAID_WARNING",
    pos = {},
}

local mod, db, marco
local mover = false
local ultimoGasto, manaAvisado = 0, false
local listos = {}
local quitarAvisado = {}

local function Activo() return mod and mod:IsEnabled() and C.EsChaman() and C.Rol() == "restauracion" end

-- Qué se le puede quitar a una unidad (tipos de perjuicio que el paladín limpia).
local function Quitables(u)
    if not (C_UnitAuras and C_UnitAuras.GetAuraDataByIndex) then return {} end
    local tipos = {}
    for i = 1, 40 do
        local ok, a = pcall(C_UnitAuras.GetAuraDataByIndex, u, i, "HARMFUL")
        if not ok or type(a) ~= "table" then break end
        local t = Str(a.dispelName)
        if t and TIPOS[t] and ((t == "Poison" and db.quitarVeneno) or (t == "Disease" and db.quitarEnfermedad)) then
            tipos[t] = true
        end
    end
    return tipos
end

local function Hechizo(clave)
    local c = CLIC[clave]
    if not c or clave == "nada" then return nil end
    local id = U.Mejor(c[3])
    return id and U.Nombre(id) or nil
end

local function Unidades()
    local okr, banda = pcall(IsInRaid)
    if db.banda and okr and banda and not U.issecret(banda) then
        local u = {}
        for i = 1, db.maxFilas do u[#u + 1] = "raid" .. i end
        return u
    end
    return { "player", "party1", "party2", "party3", "party4" }
end

local function PrepararFilas()
    if not marco or U.EnCombate() then return end
    marco.filas = marco.filas or {}
    local unidades = Unidades()
    for i = 1, math.max(#unidades, #marco.filas) do
        local u, b = unidades[i], marco.filas[i]
        if u and not b then
            b = CreateFrame("Button", "CMRestauracionFila" .. i, marco, "SecureUnitButtonTemplate")
            b:RegisterForClicks("AnyUp", "AnyDown")
            b.vida = b:CreateTexture(nil, "BACKGROUND"); b.vida:SetPoint("TOPLEFT"); b.vida:SetPoint("BOTTOMLEFT")
            b.fondo = b:CreateTexture(nil, "BACKGROUND", nil, -1); b.fondo:SetAllPoints(); b.fondo:SetColorTexture(0, 0, 0, 0.55)
            b.nombre = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); b.nombre:SetPoint("LEFT", 4, 0)
            b.quitar = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); b.quitar:SetPoint("RIGHT", -4, 0)
            b.luz = b:CreateTexture(nil, "HIGHLIGHT"); b.luz:SetAllPoints(); b.luz:SetColorTexture(1, 1, 1, 0.12)
            marco.filas[i] = b
        end
        if b then
            if u then
                b.unidad = u
                b:SetAttribute("unit", u)
                for boton, clave in pairs({ [1] = db.clicIzq, [2] = db.clicDer }) do
                    local n = Hechizo(clave)
                    b:SetAttribute("type" .. boton, n and "spell" or nil)
                    b:SetAttribute("spell" .. boton, n)
                end
                local nm = Hechizo(db.clicMayus)
                b:SetAttribute("shift-type1", nm and "spell" or nil)
                b:SetAttribute("shift-spell1", nm)
                b:SetSize(db.anchoFila, db.altoFila)
                b:ClearAllPoints(); b:SetPoint("TOPLEFT", marco, "TOPLEFT", 6, -6 - (i - 1) * (db.altoFila + 2))
            else
                b.unidad = nil
                b:Hide()
            end
        end
    end
end

local function Crear()
    if marco then return end
    marco = mod:Frame("Frame", "CMRestauracion", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    marco:SetSize(200, 60)
    U.Movil(mod, marco, "restauracion", function() return db.bloquear and not mover end)
    if marco.SetBackdrop then
        marco:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                            edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    end
    marco.mana = CreateFrame("StatusBar", nil, marco)
    marco.mana:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    marco.mana.fondo = marco.mana:CreateTexture(nil, "BACKGROUND"); marco.mana.fondo:SetAllPoints(); marco.mana.fondo:SetColorTexture(0, 0, 0, 0.6)
    marco.mana.texto = marco.mana:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); marco.mana.texto:SetPoint("CENTER")
    marco.cinco = marco:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    marco.cds = CreateFrame("Frame", nil, marco)
    PrepararFilas()
end

local function Pintar()
    local combate = U.EnCombate()
    if not Activo() then
        if marco and not combate then marco:Hide() end
        return
    end
    if not marco and combate then return end
    Crear()
    marco:SetScale(db.escala); marco:SetAlpha(db.opacidad)
    if marco.SetBackdropColor then
        marco:SetBackdropColor(0, 0, 0, db.fondo and 0.6 or 0)
        marco:SetBackdropBorderColor(1, 1, 1, db.fondo and 0.5 or 0)
    end
    if not combate then PrepararFilas() end
    local y = -6
    for _, b in ipairs(marco.filas) do
        local u = b.unidad
        local ok, existe = pcall(UnitExists, u or "none")
        existe = ok and existe and not U.issecret(existe)
        if db.lista and u and existe then
            local okn, nombre = pcall(UnitName, u)
            nombre = okn and Str(nombre) or "?"
            b.nombre:SetText(nombre)
            local okh, h = pcall(UnitHealth, u)
            local okm, hm = pcall(UnitHealthMax, u)
            local fr = okh and okm and Num(h) and Num(hm) and hm > 0 and h / hm
            b.vida:SetWidth(math.max(1, db.anchoFila * (fr or 1)))
            local r, g, bl = 0.3, 0.8, 0.3
            if db.colorClase then
                local okc, _, c = pcall(UnitClass, u)
                local cc = okc and RAID_CLASS_COLORS and RAID_CLASS_COLORS[c]
                if cc then r, g, bl = cc.r, cc.g, cc.b end
            end
            b.vida:SetColorTexture(r, g, bl, fr and 0.55 or 0.25)
            local partes = {}
            if db.verQuitar then
                local tipos = Quitables(u)
                for t, def in pairs(TIPOS) do
                    if tipos[t] then
                        local c = def[2]
                        partes[#partes + 1] = ("|cff%02x%02x%02x%s|r"):format(c[1] * 255, c[2] * 255, c[3] * 255, def[1])
                    end
                end
                if #partes > 0 and db.avisoQuitar and not quitarAvisado[u] then
                    quitarAvisado[u] = true
                    U.Avisar(mod, ("Puedes curar a %s (%s)"):format(nombre, table.concat(partes, ", ")), true, 0.4, 0.7, 1)
                elseif #partes == 0 then
                    quitarAvisado[u] = nil
                end
            end
            if db.verSenda then
                local fin, _, cargas = U.Aura(u, U.Nombre(SENDA, "Senda de sanación"), "HELPFUL")
                if fin and cargas and cargas > 0 then partes[#partes + 1] = ("|cff66ff66x%d|r"):format(cargas) end
            end
            b.quitar:SetText(table.concat(partes, " "))
            if not combate then b:Show() end
            y = y - db.altoFila - 2
        elseif not combate then
            b:Hide()
        end
    end
    local mana, maxMana = U.Mana()
    if db.mana then
        local b = marco.mana
        b:SetSize(db.anchoMana, 12)
        b:ClearAllPoints(); b:SetPoint("TOPLEFT", marco, "TOPLEFT", 6, y - 2)
        local okm, mx = pcall(UnitPowerMax, "player", 0)
        local okv, v = pcall(UnitPower, "player", 0)
        if okm then pcall(b.SetMinMaxValues, b, 0, mx) end
        if okv then pcall(b.SetValue, b, v) end
        local c = db.colorMana
        b:SetStatusBarColor(c[1], c[2], c[3])
        b.texto:SetText(mana and maxMana and maxMana > 0 and ("%d%%"):format(mana / maxMana * 100) or "")
        b:Show()
        y = y - 16
        if db.cincoSegundos then
            local resto = 5 - (GetTime() - ultimoGasto)
            marco.cinco:ClearAllPoints(); marco.cinco:SetPoint("TOPLEFT", marco, "TOPLEFT", 8, y)
            marco.cinco:SetText(resto > 0 and ("|cffffaa33Regla de 5 s: %.1f|r"):format(resto) or "|cff66ff66Regenerando maná|r")
            marco.cinco:Show()
            y = y - 14
        else
            marco.cinco:Hide()
        end
    else
        marco.mana:Hide(); marco.cinco:Hide()
    end
    if db.avisoMana and mana and maxMana and maxMana > 0 then
        local pc = mana / maxMana * 100
        if pc < db.porcentajeMana and not manaAvisado then
            manaAvisado = true
            U.Avisar(mod, ("Maná bajo (%d%%)"):format(pc), true, 0.4, 0.6, 1)
        elseif pc > db.porcentajeMana + 10 then
            manaAvisado = false
        end
    end
    -- Rapidez de la Naturaleza y Tótem de marea de maná.
    local lista = {}
    local function Add(ver, ids, clave)
        local id = ver and U.Mejor(ids)
        if not id then return end
        local q = U.Enfriamiento(id)
        if q then
            if q == 0 and listos[clave] == false and db.avisoListo then U.Avisar(mod, U.Nombre(id) .. " listo", true, 0.4, 1, 0.4) end
            listos[clave] = q == 0
        end
        lista[#lista + 1] = { icono = U.Icono(id), queda = q or 0 }
    end
    Add(db.verRapidez, { RAPIDEZ }, "rapidez")
    Add(db.verMarea, MAREA, "marea")
    if #lista > 0 then
        marco.cds:ClearAllPoints(); marco.cds:SetPoint("TOPLEFT", marco, "TOPLEFT", 6, y - 2)
        marco.cds:SetSize(#lista * (db.tamIcono + 6), db.tamIcono)
        U.Iconos(marco.cds, lista, db.tamIcono)
        marco.cds:Show()
        y = y - db.tamIcono - 8
    else
        marco.cds:Hide()
    end
    if combate then return end
    if y >= -8 and not mover then marco:Hide(); return end
    marco:SetSize(math.max(db.anchoFila, db.anchoMana) + 12, -y + 4)
    if not marco.colocado then U.Colocar(mod, marco, "restauracion", -300, 0); marco.colocado = true end
    marco:EnableMouse(mover or not db.bloquear)
    marco:Show()
end

local acum = 0
local OPC = {}
for _, c in ipairs(CLICS) do OPC[#OPC + 1] = { c[1], c[2] } end
mod = Hub:Register{
    key = "restauracion", dir = "Restauracion", name = "Restauración", clase = "SHAMAN",
    desc = "Chamán de restauración (solo con ese rol): lista del grupo con su vida, lo que les puedes curar (veneno, "
        .. "enfermedad) y las cargas de Senda de sanación (clic para lanzar), maná con la regla de los 5 segundos y "
        .. "Rapidez de la Naturaleza y Tótem de marea de maná en grande.",
    defaults = DEFAULTS,
    slash = { "cmrestauracion" },
    Init = function(m)
        db = m.db
        m:Event("UNIT_SPELLCAST_SUCCEEDED", function(_, _, unidad, _, hechizo)
            if unidad == "player" and Num(hechizo) then
                local c = U.Coste(hechizo)
                if c and c > 0 then ultimoGasto = GetTime() end
            end
        end)
        m:Event("GROUP_ROSTER_UPDATE", function() PrepararFilas(); Pintar() end)
        m:Event("PLAYER_REGEN_ENABLED", function() PrepararFilas(); Pintar() end)
        m:OnUpdate(function(_, e)
            acum = acum + e
            if acum >= 0.15 then acum = 0; Pintar() end
        end)
    end,
    Enable = function(m) db = m.db; Pintar() end,
    Disable = function() if marco and not U.EnCombate() then marco:Hide() end end,
    OnReset = function() if marco then marco.colocado = false end end,
    OnSlash = function(m, msg) if (msg or ""):lower() == "mover" then mover = not mover; Pintar() else Hub:Open("restauracion") end end,
    BuildConfig = function(m, L)
        db = m.db
        local function G(k) return function() return db[k] end end
        local function S(k) return function(v) db[k] = v; PrepararFilas(); Pintar() end end
        local function Col(k) return function() local c = db[k]; return c[1], c[2], c[3] end end
        local function SetCol(k) return function(r, g, b) db[k] = { r, g, b }; Pintar() end end
        L:Text("Solo funciona si tu rol de chamán (pestaña Chamán) es restauración. Ahora: |cffffd100" .. C.Rol() .. "|r. "
            .. "Los cambios de los clics se aplican fuera de combate.", true)
        L:Button("Mover", 90, function() mover = not mover; Pintar() end)
        L:Button("Volver a su sitio", 140, function() db.pos.restauracion = nil; if marco then marco.colocado = false end; Pintar() end, true)
        L:Check("Bloquear la posición", G("bloquear"), S("bloquear"))
        L:Check("Fondo y borde", G("fondo"), S("fondo"))
        L:Slider("Escala", 0.5, 2, 0.05, G("escala"), S("escala"), "%.2f")
        L:Slider("Opacidad", 0.2, 1, 0.05, G("opacidad"), S("opacidad"), "%.2f")

        L:Header("Lista del grupo")
        L:Check("Mostrar la lista", G("lista"), S("lista"))
        L:Check("  En banda, toda la banda (si no, tu grupo)", G("banda"), S("banda"))
        L:Slider("  Filas como máximo en banda", 5, 40, 1, G("maxFilas"), S("maxFilas"))
        L:Slider("  Ancho de fila", 120, 320, 5, G("anchoFila"), S("anchoFila"))
        L:Slider("  Alto de fila", 14, 40, 1, G("altoFila"), S("altoFila"))
        L:Check("  Vida con el color de la clase", G("colorClase"), S("colorClase"))
        L:Choice("  Clic izquierdo", OPC, G("clicIzq"), S("clicIzq"))
        L:Choice("  Clic derecho", OPC, G("clicDer"), S("clicDer"))
        L:Choice("  Mayús + clic izquierdo", OPC, G("clicMayus"), S("clicMayus"))
        L:Check("Cargas de " .. U.Nombre(SENDA, "Senda de sanación") .. " en cada uno", G("verSenda"), S("verSenda"))
        L:Check("Marcar lo que se puede curar", G("verQuitar"), S("verQuitar"))
        L:Check("  Veneno", G("quitarVeneno"), S("quitarVeneno"))
        L:Check("  Enfermedad", G("quitarEnfermedad"), S("quitarEnfermedad"))
        L:Check("  Aviso cuando hay algo que curar", G("avisoQuitar"), S("avisoQuitar"))

        L:Header("Maná")
        L:Check("Barra de maná", G("mana"), S("mana"))
        L:Slider("  Ancho", 100, 320, 5, G("anchoMana"), S("anchoMana"))
        L:Color("  Color", Col("colorMana"), SetCol("colorMana"))
        L:Check("  Regla de los 5 segundos", G("cincoSegundos"), S("cincoSegundos"))
        L:Check("Aviso de maná bajo", G("avisoMana"), S("avisoMana"))
        L:Slider("  Por debajo de (%)", 5, 60, 5, G("porcentajeMana"), S("porcentajeMana"))

        L:Header("Enfriamientos")
        L:Check(U.Nombre(RAPIDEZ, "Rapidez de la Naturaleza"), G("verRapidez"), S("verRapidez"))
        L:Check(U.Nombre(MAREA[1], "Tótem de marea de maná"), G("verMarea"), S("verMarea"))
        L:Slider("  Tamaño", 20, 70, 1, G("tamIcono"), S("tamIcono"))
        L:Check("  Aviso cuando vuelven a estar listos", G("avisoListo"), S("avisoListo"))

        L:Header("Cómo avisa")
        L:Check("Texto grande", G("avisoTexto"), S("avisoTexto"))
        L:Check("Línea en el chat", G("avisoChat"), S("avisoChat"))
        L:Check("Sonido", G("avisoSonido"), S("avisoSonido"))
        L:Choice("  Sonido", U.KITS, G("avisoKit"), function(v) db.avisoKit = v; U.Sonar(v) end)
    end,
}
