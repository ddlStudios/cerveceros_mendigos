-- Guardián (CervecerosMendigos Clases, druida): solo se enciende si tu rol de druida es guardián (oso).
--   * Barra de ira, lo que les queda a Rugido desmoralizador y Fuego feérico en el objetivo, aviso de
--     Libre lanzamiento y enfriamientos (Regeneración frenética, Rugido desafiante, Carga feral, Enfurecer,
--     Azote, Gruñido).
local ADDON, ns = ...
local Hub = ns.Hub
local D = ns.Druida
local Num, Str = D.Num, D.Str

local LIBRE = 16870                                                 -- Libre lanzamiento (aura de Clarividencia)
local RUGIDO = { 99, 1735, 9490, 9747, 9898 }                       -- Rugido desmoralizador
local FUEGO = { 770, 778, 9749, 9907 }                              -- Fuego feérico
local FUEGO_FERAL = { 16857, 17390, 17391, 17392 }                  -- Fuego feérico (feral)
-- Enfriamientos: { clave, rangos, forma en la que interesa, nombre de repuesto }
local CDS = {
    { "regeneracion", { 22842, 22895, 22896 }, "oso", "Regeneración frenética" },
    { "desafiante", { 5209 }, "oso", "Rugido desafiante" },
    { "carga", { 16979 }, "oso", "Carga feral" },
    { "enfurecer", { 5229 }, "oso", "Enfurecer" },
    { "azote", { 5211, 6798, 8983 }, "oso", "Azote" },
    { "grunido", { 6795 }, "oso", "Gruñido" },
}

local DEFAULTS = {
    escala = 1, opacidad = 1, bloquear = false, soloEnForma = true,
    -- Gato
    libre = true, libreSonido = true, libreIcono = true,
    ira = true, anchoIra = 200, altoIra = 14, colorIra = { 1, 0.2, 0.2 },
    debilitadores = true, verRugido = true, verFuego = true, segundosDebuff = 5, avisoDebuff = true,
    -- Enfriamientos
    enfriamientos = true, tamIcono = 30,
    cds = { regeneracion = true, desafiante = true, carga = true, enfurecer = false, azote = true, grunido = true },
    -- Avisos
    avisoTexto = true, avisoChat = false, avisoSonido = true, avisoKit = "RAID_WARNING",
    pos = {},
}

local mod, db, marco
local mover = false
local libreActivo, cambioAvisado = false, false
local avisadoDebuff = {}

local function Activo() return mod and mod:IsEnabled() and D.EsDruida() and D.EsOso() end

local function Crear()
    if marco then return end
    marco = mod:Frame("Frame", "CMGuardian", UIParent)
    marco:SetSize(220, 30)
    D.Movil(mod, marco, "guardian", function() return db.bloquear and not mover end)
    marco.ira = CreateFrame("StatusBar", nil, marco)
    marco.ira:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    marco.ira.fondo = marco.ira:CreateTexture(nil, "BACKGROUND"); marco.ira.fondo:SetAllPoints(); marco.ira.fondo:SetColorTexture(0, 0, 0, 0.6)
    marco.ira.texto = marco.ira:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); marco.ira.texto:SetPoint("CENTER")
    marco.texto = marco:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    marco.texto:SetJustifyH("LEFT")
    marco.libre = marco:CreateTexture(nil, "OVERLAY")
    marco.libre:SetSize(36, 36)
    marco.cds = CreateFrame("Frame", nil, marco)
end

-- Debilitador en el objetivo (de cualquier druida/guerrero): segundos que le quedan, false si no está, nil si no se sabe.
local function QuedaDebuff(ids)
    local fin = D.Aura("target", D.Nombre(ids[1]), "HARMFUL")
    if fin == nil then return nil end
    if not fin then return false end
    if fin == math.huge then return 999 end
    return math.max(0, fin - GetTime())
end

local function Pintar()
    if not Activo() then if marco then marco:Hide() end return end
    local forma = D.Forma()
    if db.soloEnForma and forma ~= "oso" and not mover then if marco then marco:Hide() end return end
    Crear()
    marco:SetScale(db.escala); marco:SetAlpha(db.opacidad)
    marco:EnableMouse(mover or not db.bloquear)
    local y, ancho = 0, 200
    local lineas = {}
    local combate = D.EnCombate()
    -- Oso: ira.
    if forma == "oso" and db.ira then
        local b = marco.ira
        b:SetSize(db.anchoIra, db.altoIra)
        b:ClearAllPoints(); b:SetPoint("TOPLEFT", marco, "TOPLEFT", 0, y)
        local okm, mx = pcall(UnitPowerMax, "player", 1)
        local okv, v = pcall(UnitPower, "player", 1)
        if okm then pcall(b.SetMinMaxValues, b, 0, mx) end
        if okv then pcall(b.SetValue, b, v); if Num(v) then b.texto:SetText(tostring(v)) else pcall(b.texto.SetFormattedText, b.texto, "%d", v) end end
        local c = db.colorIra
        b:SetStatusBarColor(c[1], c[2], c[3])
        b:Show()
        ancho = math.max(ancho, db.anchoIra)
        y = y - db.altoIra - 4
    else
        marco.ira:Hide()
    end
    -- Oso: debilitadores del objetivo.
    local okt, hay = pcall(UnitCanAttack, "player", "target")
    hay = okt and hay and not D.issecret(hay)
    if forma == "oso" and db.debilitadores and hay then
        local okg, guid = pcall(UnitGUID, "target"); guid = okg and Str(guid) or "?"
        local function Linea(ver, ids, ids2, clave)
            if not ver or not (D.ConoceAlguno(ids) or (ids2 and D.ConoceAlguno(ids2))) then return end
            local q = QuedaDebuff(ids)
            if (q == false or q == nil) and ids2 then q = QuedaDebuff(ids2) end
            local nombre = D.Nombre(ids[1])
            if q == nil then lineas[#lineas + 1] = "|cff999999" .. nombre .. " ?|r"; return end
            local k = guid .. clave
            if q == false or q <= db.segundosDebuff then
                lineas[#lineas + 1] = ("|cffff5555%s %s|r"):format(nombre, q and D.Tiempo(q) or "FALTA")
                if db.avisoDebuff and combate and not avisadoDebuff[k] then
                    avisadoDebuff[k] = true
                    D.Avisar(mod, q and (nombre .. ": quedan " .. math.ceil(q) .. " s") or ("Falta " .. nombre), true, 1, 0.5, 0.2)
                end
            else
                avisadoDebuff[k] = nil
                lineas[#lineas + 1] = ("%s %s"):format(nombre, D.Tiempo(q))
            end
        end
        Linea(db.verRugido, RUGIDO, nil, "r")
        Linea(db.verFuego, FUEGO, FUEGO_FERAL, "f")
    end
    -- Libre lanzamiento.
    if forma == "oso" or mover then
        local fin = D.Aura("player", D.Nombre(LIBRE, "Libre lanzamiento"), "HELPFUL")
        local ahora = fin and true or false
        if ahora and not libreActivo and db.libre then
            D.Aviso("¡" .. D.Nombre(LIBRE, "Libre lanzamiento") .. "!", 0.4, 0.8, 1)
            if db.libreSonido then D.Sonar(db.avisoKit) end
        end
        if fin ~= nil then libreActivo = ahora end
        if db.libreIcono and libreActivo then
            marco.libre:SetTexture(D.Icono(LIBRE))
            marco.libre:ClearAllPoints(); marco.libre:SetPoint("TOPRIGHT", marco, "TOPLEFT", -4, 0)
            marco.libre:Show()
        else
            marco.libre:Hide()
        end
    else
        marco.libre:Hide()
    end
    if #lineas > 0 then
        marco.texto:ClearAllPoints(); marco.texto:SetPoint("TOPLEFT", marco, "TOPLEFT", 0, y)
        marco.texto:SetWidth(ancho + 80)
        marco.texto:SetText(table.concat(lineas, "\n"))
        marco.texto:Show()
        y = y - 16 * #lineas - 2
    else
        marco.texto:Hide()
    end
    -- Enfriamientos de la forma actual.
    if db.enfriamientos then
        local lista = {}
        for _, c in ipairs(CDS) do
            local id = D.Mejor(c[2])
            if id and db.cds[c[1]] and (c[3] == forma or not db.soloEnForma or mover) then
                lista[#lista + 1] = { icono = D.Icono(id), queda = D.Enfriamiento(id) or 0 }
            end
        end
        if #lista > 0 then
            marco.cds:ClearAllPoints(); marco.cds:SetPoint("TOPLEFT", marco, "TOPLEFT", 0, y)
            marco.cds:SetSize(#lista * (db.tamIcono + 6), db.tamIcono)
            D.Iconos(marco.cds, lista, db.tamIcono)
            marco.cds:Show()
            y = y - db.tamIcono - 4
        else
            marco.cds:Hide()
        end
    else
        marco.cds:Hide()
    end
    if y == 0 and not mover then marco:Hide(); return end
    marco:SetSize(ancho, math.max(20, -y))
    if not marco.colocado then D.Colocar(mod, marco, "guardian", 0, -240); marco.colocado = true end
    marco:Show()
end

local acum = 0
mod = Hub:Register{
    key = "guardian", dir = "Guardian", name = "Guardián", clase = "DRUID",
    desc = "Druida guardián, oso (solo con ese rol): barra de ira, lo que les queda a Rugido desmoralizador y Fuego "
        .. "feérico en el objetivo, aviso de Libre lanzamiento y tus enfriamientos de tanque.",
    defaults = DEFAULTS,
    slash = { "cmguardian" },
    Init = function(m)
        db = m.db
        m:Event("PLAYER_TARGET_CHANGED", Pintar)
        m:Event("UPDATE_SHAPESHIFT_FORM", Pintar)
        m:OnUpdate(function(_, e)
            acum = acum + e
            if acum >= 0.1 then acum = 0; Pintar() end
        end)
    end,
    Enable = function(m) db = m.db; Pintar() end,
    Disable = function() if marco then marco:Hide() end end,
    OnReset = function() if marco then marco.colocado = false end end,
    OnSlash = function(m, msg)
        if (msg or ""):lower() == "mover" then mover = not mover; Pintar() else Hub:Open("guardian") end
    end,
    BuildConfig = function(m, L)
        db = m.db
        local function G(k) return function() return db[k] end end
        local function S(k) return function(v) db[k] = v; Pintar() end end
        L:Text("Solo funciona si tu rol de druida (pestaña Druida) es guardián (oso). Ahora: |cffffd100" .. D.Rol() .. "|r.", true)
        L:Button("Mover", 90, function() mover = not mover; Pintar() end)
        L:Button("Volver a su sitio", 140, function() db.pos.guardian = nil; if marco then marco.colocado = false end; Pintar() end, true)
        L:Check("Solo en forma de oso", G("soloEnForma"), S("soloEnForma"))
        L:Check("Bloquear la posición", G("bloquear"), S("bloquear"))
        L:Slider("Escala", 0.5, 2, 0.05, G("escala"), S("escala"), "%.2f")
        L:Slider("Opacidad", 0.2, 1, 0.05, G("opacidad"), S("opacidad"), "%.2f")

        L:Header("Libre lanzamiento")
        L:Check("Aviso de " .. D.Nombre(LIBRE, "Libre lanzamiento") .. " (gasta tu ataque más caro)", G("libre"), S("libre"))
        L:Check("  Con sonido", G("libreSonido"), S("libreSonido"))
        L:Check("  Icono mientras dura", G("libreIcono"), S("libreIcono"))
        L:Header("Oso")
        L:Check("Barra de ira", G("ira"), S("ira"))
        L:Slider("  Ancho", 100, 400, 5, G("anchoIra"), S("anchoIra"))
        L:Slider("  Alto", 8, 40, 1, G("altoIra"), S("altoIra"))
        L:Color("  Color", function() local c = db.colorIra; return c[1], c[2], c[3] end, function(r, g, b) db.colorIra = { r, g, b }; Pintar() end)
        L:Check("Debilitadores en el objetivo", G("debilitadores"), S("debilitadores"))
        L:Check("  " .. D.Nombre(RUGIDO[1], "Rugido desmoralizador"), G("verRugido"), S("verRugido"))
        L:Check("  " .. D.Nombre(FUEGO[1], "Fuego feérico"), G("verFuego"), S("verFuego"))
        L:Slider("  En rojo y aviso cuando quedan (segundos)", 0, 20, 1, G("segundosDebuff"), S("segundosDebuff"))
        L:Check("  Aviso en combate cuando falta o se acaba", G("avisoDebuff"), S("avisoDebuff"))

        L:Header("Enfriamientos")
        L:Check("Iconos de enfriamientos", G("enfriamientos"), S("enfriamientos"))
        L:Slider("  Tamaño", 20, 60, 1, G("tamIcono"), S("tamIcono"))
        for _, c in ipairs(CDS) do
            L:Check("  " .. D.Nombre(c[2][1], c[4]) ,
                function() return db.cds[c[1]] end, function(v) db.cds[c[1]] = v; Pintar() end)
        end

        L:Header("Cómo avisa")
        L:Check("Texto grande", G("avisoTexto"), S("avisoTexto"))
        L:Check("Línea en el chat", G("avisoChat"), S("avisoChat"))
        L:Check("Sonido", G("avisoSonido"), S("avisoSonido"))
        L:Choice("  Sonido", D.KITS, G("avisoKit"), function(v) db.avisoKit = v; D.Sonar(v) end)
    end,
}
