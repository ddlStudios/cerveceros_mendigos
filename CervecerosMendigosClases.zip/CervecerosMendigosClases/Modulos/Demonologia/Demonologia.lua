-- Demonología (CervecerosMendigos Clases, brujo): solo con rol demonología.
--   Dominación vil y Sacrificio demoníaco en grande, y aviso si vas sin Vínculo de alma.
local ADDON, ns = ...
local U = ns.CU

U.Modulo{
    key = "demonologia", dir = "Demonologia", name = "Demonología", clase = "WARLOCK", slash = { "cmdemonologia" }, rolDe = "brujo", rol = "demonologia",
    desc = "Brujo de demonología (solo con ese rol): Dominación vil y Sacrificio demoníaco en grande, y aviso si vas "
        .. "sin Vínculo de alma.",
    propios = { { "vinculo", { { 19028 } }, "Vínculo de alma" } },
    cds = { { "dominacion", { 18708 }, "Dominación vil" }, { "sacrificio", { 18788 }, "Sacrificio demoníaco", avisoListo = false } },
}
