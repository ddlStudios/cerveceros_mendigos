-- Escarcha (CervecerosMendigos Clases, mago): solo con rol escarcha.
--   Barrera de hielo (cuánto la mantienes), Enfriamiento rápido, Nova de Escarcha y Bloque de hielo en grande;
--   Escalofrío invernal en el objetivo.
local ADDON, ns = ...
local U = ns.CU

U.Modulo{
    key = "escarcha", dir = "Escarcha", name = "Escarcha", clase = "MAGE", slash = { "cmescarcha" }, rolDe = "mago", rol = "escarcha",
    desc = "Mago de escarcha (solo con ese rol): Barrera de hielo, Enfriamiento rápido, Nova de Escarcha y Bloque de "
        .. "hielo en grande, y las cargas de Escalofrío invernal en el objetivo.",
    objetivo = { { "escalofrio", { 12579 }, "Escalofrío invernal", propio = false, cargas = 5, si = { 11180, 28592, 28593, 28594, 28595 } } },
    uptime = { { "barrera", { 11426, 13031, 13032, 13033 }, "Barrera de hielo" } },
    cds = { { "barrera", { 11426, 13031, 13032, 13033 }, "Barrera de hielo" }, { "enfriamiento", { 12472 }, "Enfriamiento rápido" },
            { "nova", { 122, 865, 6131, 10230 }, "Nova de Escarcha", avisoListo = false }, { "bloque", { 11958 }, "Bloque de hielo" } },
}
