-- Energia (CervecerosMendigos Clases, pícaro) para WoW Forever: barra de energía con el tic de regeneración,
-- puntos de combo y lo que duraría cada remate con los puntos que llevas.
--   * El tic se detecta cuando la energía sube de golpe lo que da un tic (20, o 40 con Subidón de
--     adrenalina) y se predice cada 2 s. Si el juego regenera la energía poco a poco, no hay tic que
--     enseñar y la chispa se oculta sola.
--   * En combate el cliente puede ocultar la energía («valores secretos»): la barra se sigue pintando
--     (el juego deja dibujar esos valores), pero el tic y los cálculos se quedan con lo último que se leyó.
local ADDON, ns = ...
local Hub = ns.Hub
local issecret = issecretvalue or function() return false end
local function Num(v) if type(v) ~= "number" or issecret(v) then return nil end return v end

local ENERGIA, COMBO = 3, 4
-- Remates: { clave, nombre del primer rango para leerlo del juego, rangos, duración(puntos, rango) }
local REMATES = {
    { "picadillo", { 5171, 6774 }, function(cp) return 6 + 3 * cp end, "Hacer picadillo" },          -- Hacer picadillo: 9-21 s
    { "desgarrar", { 1943, 8639, 8640, 11273, 11274, 11275 }, function(cp) return 6 + 2 * cp end, "Desgarrar" },  -- Desgarrar: 8-16 s
    { "rinones", { 408, 8643 }, function(cp, r) return cp + (r - 1) end, "Golpe en los riñones" },        -- Golpe en los riñones
    { "exponer", { 8647, 8649, 8650, 11197, 11198 }, function() return 30 end, "Exponer armadura" },  -- Exponer armadura
    -- Druida en forma felina
    { "destripar", { 1079, 9492, 9493, 9752, 9894, 9896 }, function() return 12 end, "Destripar", druida = true },
}

local DEFAULTS = {
    ancho = 200, alto = 16, escala = 1, opacidad = 1, opacidadFuera = 0.35, bloquear = false,
    soloObjetivo = false, ocultarFuera = false, verTexto = true, verTic = true, sonidoTic = false,
    verCombos = true, tamCombo = 14, verRemates = true, mejoraPicadillo = 0,
    remates = { picadillo = true, desgarrar = true, rinones = true, exponer = false, destripar = true },
    druidaGato = true, druidaSoloFeral = true,
    colorEnergia = { 1, 0.9, 0.2 }, colorTic = { 1, 1, 1 }, colorCombo = { 1, 0.3, 0.2 },
    colorLleno = { 1, 0.55, 0.1 }, avisoLleno = false, avisoLlenoSonido = false,
    pos = {},
}

local mod, db, marco
local ultimaEnergia, ultimoTic, continua, cambiosPequenos = nil, nil, false, 0
local ultimoCombo, llenoAvisado = 0, false

local function NombreHechizo(id, repuesto)
    if C_Spell and C_Spell.GetSpellName then local ok, n = pcall(C_Spell.GetSpellName, id); if ok and type(n) == "string" and not issecret(n) then return n end end
    return repuesto or "?"
end
local function Conoce(id)
    if IsPlayerSpell then local ok, v = pcall(IsPlayerSpell, id); if ok and v and not issecret(v) then return true end end
    if IsSpellKnown then local ok, v = pcall(IsSpellKnown, id); if ok and v and not issecret(v) then return true end end
    return false
end
-- Rango más alto que conoces de un remate (0 = ninguno).
local function Rango(ids)
    for i = #ids, 1, -1 do if Conoce(ids[i]) then return i end end
    return 0
end

local function Clase()
    local ok, _, c = pcall(UnitClass, "player")
    return ok and c or nil
end
local function EsPicaro() return Clase() == "ROGUE" end
-- Druida: la barra solo en forma felina (y, si se quiere, solo con rol feral).
local function DruidaGato()
    if Clase() ~= "DRUID" or not db.druidaGato then return false end
    local Dr = ns.Druida
    if not Dr then return false end
    if Dr.Forma() ~= "gato" then return false end
    return not db.druidaSoloFeral or Dr.EsFeral()
end

----------------------------------------------------------------------
-- Energía y tic
----------------------------------------------------------------------
local function AlCambiarEnergia()
    local ok, e = pcall(UnitPower, "player", ENERGIA)
    e = ok and Num(e)
    if not e then return end
    if ultimaEnergia and e > ultimaEnergia then
        local d = e - ultimaEnergia
        if (d >= 18 and d <= 22) or (d >= 38 and d <= 42) then
            ultimoTic = GetTime()
            cambiosPequenos = 0
            continua = false
            if db.sonidoTic and db.verTic then pcall(PlaySound, (SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON) or 856, "SFX") end
        elseif d <= 5 then
            -- Muchas subidas pequeñas seguidas: el juego regenera poco a poco, no hay tic.
            cambiosPequenos = cambiosPequenos + 1
            if cambiosPequenos >= 8 then continua = true end
        end
    end
    ultimaEnergia = e
end

----------------------------------------------------------------------
-- Marco
----------------------------------------------------------------------
local function Crear()
    if marco then return end
    marco = mod:Frame("Frame", "CMRogueEnergia", UIParent)
    marco:SetClampedToScreen(true)
    marco:SetMovable(true)
    marco:RegisterForDrag("LeftButton")
    marco:SetScript("OnDragStart", function(self) if not db.bloquear then self:StartMoving() end end)
    marco:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local l, t = self:GetLeft(), self:GetTop()
        if l and t then db.pos.energia = { l, t } end
    end)
    marco.barra = CreateFrame("StatusBar", nil, marco)
    marco.barra:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    marco.barra.fondo = marco.barra:CreateTexture(nil, "BACKGROUND")
    marco.barra.fondo:SetAllPoints(); marco.barra.fondo:SetColorTexture(0, 0, 0, 0.6)
    marco.texto = marco.barra:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    marco.texto:SetPoint("CENTER")
    marco.chispa = marco.barra:CreateTexture(nil, "OVERLAY")
    marco.chispa:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
    marco.chispa:SetBlendMode("ADD")
    marco.combos = {}
    for i = 1, 5 do
        local t = marco:CreateTexture(nil, "ARTWORK")
        t:SetColorTexture(1, 1, 1, 1)
        t.borde = marco:CreateTexture(nil, "BORDER")
        t.borde:SetColorTexture(0, 0, 0, 0.8)
        marco.combos[i] = t
    end
    marco.remates = marco:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    marco.remates:SetJustifyH("LEFT")
end

local mover = false
local function Visible()
    if not (mod and mod:IsEnabled() and (EsPicaro() or DruidaGato())) then return false end
    if mover then return true end
    local combate = (InCombatLockdown and InCombatLockdown()) or (UnitAffectingCombat and UnitAffectingCombat("player"))
    if db.ocultarFuera and not combate then return false end
    if db.soloObjetivo then
        local ok, hay = pcall(UnitCanAttack, "player", "target")
        if not (ok and hay and not issecret(hay)) and not combate then return false end
    end
    return true
end

local function Pintar()
    if not Visible() then if marco then marco:Hide() end return end
    Crear()
    local combate = (InCombatLockdown and InCombatLockdown()) or (UnitAffectingCombat and UnitAffectingCombat("player"))
    marco:SetScale(db.escala)
    marco:SetAlpha(combate and db.opacidad or db.opacidadFuera)
    marco:EnableMouse(mover or not db.bloquear)
    local b = marco.barra
    b:SetSize(db.ancho, db.alto)
    b:ClearAllPoints(); b:SetPoint("TOPLEFT", marco, "TOPLEFT", 0, 0)
    -- Energía: el juego deja dibujar aunque el valor sea secreto.
    local okm, maxE = pcall(UnitPowerMax, "player", ENERGIA)
    local okv, e = pcall(UnitPower, "player", ENERGIA)
    if okm then pcall(b.SetMinMaxValues, b, 0, maxE) end
    if okv then pcall(b.SetValue, b, e) end
    local eN, maxN = okv and Num(e), okm and Num(maxE)
    local lleno = eN and maxN and eN >= maxN
    local c = (lleno and db.colorLleno) or db.colorEnergia
    b:SetStatusBarColor(c[1], c[2], c[3])
    if db.verTexto then
        if eN then marco.texto:SetText(tostring(eN))
        elseif okv then pcall(marco.texto.SetFormattedText, marco.texto, "%d", e) end
        marco.texto:Show()
    else
        marco.texto:Hide()
    end
    if db.avisoLleno and lleno and combate then
        if not llenoAvisado then
            llenoAvisado = true
            if RaidNotice_AddMessage and RaidWarningFrame then pcall(RaidNotice_AddMessage, RaidWarningFrame, "¡Energía llena!", { r = 1, g = 0.8, b = 0.2 }) end
            if db.avisoLlenoSonido then pcall(PlaySound, 8959, "Master") end
        end
    elseif not lleno then
        llenoAvisado = false
    end
    -- Chispa del tic: avanza de 0 a 2 s desde el último tic visto.
    if db.verTic and ultimoTic and not continua then
        local fase = ((GetTime() - ultimoTic) % 2) / 2
        marco.chispa:SetSize(16, db.alto * 2.2)
        marco.chispa:ClearAllPoints()
        marco.chispa:SetPoint("CENTER", b, "LEFT", fase * db.ancho, 0)
        local ct = db.colorTic
        marco.chispa:SetVertexColor(ct[1], ct[2], ct[3])
        marco.chispa:Show()
    else
        marco.chispa:Hide()
    end
    -- Puntos de combo.
    local y = -db.alto - 3
    local okc, cp = pcall(GetComboPoints, "player", "target")
    cp = okc and Num(cp)
    if cp then ultimoCombo = cp end
    if db.verCombos then
        local t = db.tamCombo
        local hueco = math.max(2, (db.ancho - 5 * t) / 4)
        for i, p in ipairs(marco.combos) do
            p:SetSize(t, t); p:ClearAllPoints(); p:SetPoint("TOPLEFT", marco, "TOPLEFT", (i - 1) * (t + hueco), y)
            p.borde:SetSize(t + 2, t + 2); p.borde:ClearAllPoints(); p.borde:SetPoint("CENTER", p, "CENTER")
            local on = ultimoCombo >= i
            local cc = db.colorCombo
            p:SetVertexColor(cc[1], cc[2], cc[3], on and 1 or 0.18)
            p:Show(); p.borde:Show()
        end
        y = y - t - 3
    else
        for _, p in ipairs(marco.combos) do p:Hide(); p.borde:Hide() end
    end
    -- Remates: lo que duraría cada uno con los puntos actuales.
    if db.verRemates and ultimoCombo > 0 then
        local partes = {}
        local esDruida = Clase() == "DRUID"
        for _, r in ipairs(REMATES) do
            local rango = (r.druida or false) == esDruida and Rango(r[2]) or 0
            if db.remates[r[1]] and rango > 0 then
                local s = r[3](ultimoCombo, rango)
                if r[1] == "picadillo" then s = s * (1 + 0.15 * db.mejoraPicadillo) end
                partes[#partes + 1] = ("%s %ds"):format(NombreHechizo(r[2][1], r[4]), math.floor(s + 0.5))
            end
        end
        if #partes > 0 then
            marco.remates:ClearAllPoints(); marco.remates:SetPoint("TOPLEFT", marco, "TOPLEFT", 0, y)
            marco.remates:SetWidth(db.ancho + 60)
            marco.remates:SetText(table.concat(partes, " · "))
            marco.remates:Show()
            y = y - 14
        else
            marco.remates:Hide()
        end
    else
        marco.remates:Hide()
    end
    marco:SetSize(db.ancho, -y)
    if not marco.colocado then
        marco:ClearAllPoints()
        local p = db.pos.energia
        if p then marco:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", p[1], p[2]) else marco:SetPoint("CENTER", UIParent, "CENTER", 0, -200) end
        marco.colocado = true
    end
    marco:Show()
end

----------------------------------------------------------------------
-- Registro
----------------------------------------------------------------------
local acum = 0
mod = Hub:Register{
    key = "energia", dir = "Energia", name = "Energía", clase = { "ROGUE", "DRUID" },
    desc = "Pícaro y druida en forma felina: barra de energía con el tic de regeneración (cada 2 s), tus puntos de combo y lo que duraría cada remate "
        .. "(Hacer picadillo, Desgarrar, Golpe en los riñones, Exponer armadura; Destripar en el druida) con los puntos que llevas.",
    defaults = DEFAULTS,
    slash = { "cmenergia" },
    Init = function(m)
        db = m.db
        m:Event("UNIT_POWER_FREQUENT", function(_, _, unidad) if unidad == "player" then AlCambiarEnergia() end end)
        m:Event("UNIT_POWER_UPDATE", function(_, _, unidad) if unidad == "player" then AlCambiarEnergia() end end)
        m:Event("PLAYER_TARGET_CHANGED", function() ultimoCombo = 0; Pintar() end)
        m:Event("PLAYER_REGEN_DISABLED", Pintar)
        m:Event("PLAYER_REGEN_ENABLED", Pintar)
        m:OnUpdate(function(_, e)
            acum = acum + e
            if acum >= 0.03 then acum = 0; Pintar() end
        end)
    end,
    Enable = function(m) db = m.db; ultimaEnergia = nil; Pintar() end,
    Disable = function() if marco then marco:Hide() end end,
    OnReset = function() if marco then marco.colocado = false end end,
    OnSlash = function(m, msg)
        msg = (msg or ""):lower()
        if msg == "mover" then mover = not mover; m:Print(mover and "arrastra la barra y vuelve a escribir /cmenergia mover." or "posición guardada.")
        else Hub:Open("energia") end
        Pintar()
    end,
    BuildConfig = function(m, L)
        db = m.db
        local function G(k) return function() return db[k] end end
        local function S(k) return function(v) db[k] = v; Pintar() end end
        local function Col(k) return function() local c = db[k]; return c[1], c[2], c[3] end end
        local function SetCol(k) return function(r, g, b) db[k] = { r, g, b }; Pintar() end end
        if Clase() == "DRUID" then
            L:Header("Druida")
            L:Check("Mostrarla en forma felina", G("druidaGato"), S("druidaGato"))
            L:Check("  Solo si tu rol de druida es feral (pestaña Druida)", G("druidaSoloFeral"), S("druidaSoloFeral"))
        end
        L:Button("Mover la barra", 140, function() mover = not mover; Pintar() end)
        L:Button("Volver a su sitio", 140, function() db.pos.energia = nil; if marco then marco.colocado = false end; Pintar() end, true)

        L:Header("Cuándo se ve")
        L:Check("Ocultarla fuera de combate", G("ocultarFuera"), S("ocultarFuera"))
        L:Check("Fuera de combate, solo con un enemigo seleccionado", G("soloObjetivo"), S("soloObjetivo"))
        L:Slider("Opacidad en combate", 0.2, 1, 0.05, G("opacidad"), S("opacidad"), "%.2f")
        L:Slider("Opacidad fuera de combate", 0, 1, 0.05, G("opacidadFuera"), S("opacidadFuera"), "%.2f")

        L:Header("Barra de energía")
        L:Slider("Ancho", 100, 400, 5, G("ancho"), S("ancho"))
        L:Slider("Alto", 8, 40, 1, G("alto"), S("alto"))
        L:Slider("Escala", 0.5, 2, 0.05, G("escala"), S("escala"), "%.2f")
        L:Check("Número de energía", G("verTexto"), S("verTexto"))
        L:Check("Bloquear la posición", G("bloquear"), S("bloquear"))
        L:Color("Color de la energía", Col("colorEnergia"), SetCol("colorEnergia"))
        L:Color("Color con la energía llena", Col("colorLleno"), SetCol("colorLleno"))
        L:Check("Aviso de energía llena en combate (la estás desperdiciando)", G("avisoLleno"), S("avisoLleno"))
        L:Check("  Con sonido", G("avisoLlenoSonido"), S("avisoLlenoSonido"))

        L:Header("Tic de energía")
        L:Text("Una chispa recorre la barra cada 2 s marcando cuándo llega el siguiente tic. Se ajusta sola con cada tic "
            .. "que ve. Si el juego regenera la energía poco a poco, no hay tic y la chispa no sale.", true)
        L:Check("Mostrar el tic", G("verTic"), S("verTic"))
        L:Check("  Sonido suave en cada tic", G("sonidoTic"), S("sonidoTic"))
        L:Color("  Color de la chispa", Col("colorTic"), SetCol("colorTic"))

        L:Header("Puntos de combo y remates")
        L:Check("Puntos de combo", G("verCombos"), S("verCombos"))
        L:Slider("  Tamaño", 6, 30, 1, G("tamCombo"), S("tamCombo"))
        L:Color("  Color", Col("colorCombo"), SetCol("colorCombo"))
        L:Check("Lo que duraría cada remate con tus puntos", G("verRemates"), S("verRemates"))
        local esDruidaCfg = Clase() == "DRUID"
        for _, r in ipairs(REMATES) do
            if (r.druida or false) == esDruidaCfg then
                L:Check("  " .. NombreHechizo(r[2][1], r[4]), function() return db.remates[r[1]] end, function(v) db.remates[r[1]] = v; Pintar() end)
            end
        end
        L:Slider("  Talento Hacer picadillo mejorado (puntos)", 0, 3, 1, G("mejoraPicadillo"), S("mejoraPicadillo"))
    end,
}
