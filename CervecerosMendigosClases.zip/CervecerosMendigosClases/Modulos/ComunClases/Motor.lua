-- Motor de módulos de clase (CervecerosMendigos Clases): cada módulo describe sus piezas y el motor monta
-- el marco, los avisos y la pestaña de configuración (todo configurable, como en el resto).
--
-- U.Modulo{ key, dir, name, clase, desc, slash,
--   roles = { {"armas","Armas"}, ... }, pistas = { {"armas", {ids}}, ... },   -- solo el módulo común de la clase
--   activo = function() return ... end, textoRol = function() return "..." end,  -- rol propio (druida)
--   rolDe = "guerrero", rol = "armas",                                          -- solo los módulos de rol
--   barra = { titulo, { {clave, ids, nombre}, ... } },        -- botones seguros (posturas, armaduras, invocaciones)
--   propios = { {clave, { ids, ids... }, nombre} },            -- debes llevar uno de estos beneficios (armadura...)
--   beneficios = { {clave, ids, nombre, grupo = idsGrupo, soloMana = true, deGrupo = true} },
--   materiales = { {clave, { objetos }, nombre, min, crear = ids} },
--   objetivo = { {clave, ids, nombre, propio = true, cargas = n, si = ids} }, -- tus perjuicios en el objetivo
--   (si = hechizos que tienes que conocer para que interese, cuando el perjuicio lo pone otro hechizo o un talento)
--   cds = { {clave, ids, nombre, anunciar = true, defecto = false} },
--   usables = { {clave, ids, nombre} },                        -- aviso cuando se puede usar (Abrumar, Ejecutar...)
--   procs = { {clave, ids, nombre} },                          -- aviso cuando te salta (Libre lanzamiento...)
--   uptime = { {clave, ids, nombre, unidad} },                 -- % de la pelea con ese beneficio
--   mana = true, extra = function(ctx) ... end, config = function(m, L) ... end }
local ADDON, ns = ...
local Hub = ns.Hub
local U = ns.CU
local Num, Str = U.Num, U.Str

-- Rol del módulo común de una clase (por su key): ajuste a mano o por talentos.
local defs = {}
function U.RolDe(key)
    local m = Hub.byKey[key]
    local def = defs[key]
    local rol = m and m.db and m.db.rol or "auto"
    if rol ~= "auto" then return rol end
    for _, p in ipairs(def and def.pistas or {}) do if U.ConoceAlguno(p[2]) then return p[1] end end
    return "ninguno"
end

function U.Usable(id)
    if C_Spell and C_Spell.IsSpellUsable then
        local ok, v = pcall(C_Spell.IsSpellUsable, id)
        if ok and not U.issecret(v) then return v and true or false end
    end
    if IsUsableSpell then
        local ok, v = pcall(IsUsableSpell, id)
        if ok and not U.issecret(v) then return v and true or false end
    end
end

local function ContarObjetos(lista)
    local n = 0
    for _, id in ipairs(lista) do n = n + U.ContarObjeto(id) end
    return n
end

function U.Modulo(def)
    defs[def.key] = def
    local mod, db, marco
    local mover, pendiente = false, false
    local esComun = def.roles ~= nil
    local protegido = (def.barra or def.beneficios or (def.materiales and def.crearBotones ~= false)) and true or false
    local estado = { aviso = {}, listo = {}, proc = {}, usable = {}, uptime = {}, beneficio = 0 }
    local enviado, ultimoGasto = {}, 0
    local enPelea, ultimoTick = false, nil

    -- Ajustes por defecto: uno por cada pieza (activar/desactivar) y los generales.
    local D = { escala = 1, opacidad = 1, bloquear = false, fondo = true, tamIcono = 30, tamBarra = 28,
                avisoTexto = true, avisoChat = false, avisoSonido = true, avisoKit = "RAID_WARNING", pos = {}, on = {}, min = {},
                avisoListo = true, segundosObjetivo = 3, avisoObjetivo = false, avisoPropio = true,
                beneficiosGrupo = true, banda = false, minutosBeneficio = 1, soloFueraCombate = true, avisoBeneficio = true,
                repetirBeneficio = 5, botonBeneficio = true, avisoMateriales = true, botonCrear = true,
                procSonido = true, usableSonido = true, anunciar = true, canal = "auto", textoAnuncio = "%h en %t",
                porcentajeMana = 25, avisoMana = true, cincoSegundos = true }
    if esComun then D.rol = "auto" end
    for _, sec in ipairs({ "propios", "beneficios", "materiales", "objetivo", "cds", "usables", "procs", "uptime" }) do
        for _, x in ipairs(def[sec] or {}) do D.on[x[1]] = x.defecto ~= false end
    end
    for _, x in ipairs(def.materiales or {}) do D.min[x[1]] = x[4] or 5 end
    if def.barra then D.on.barra = true end
    if def.mana then D.on.mana = true end
    for k, v in pairs(def.defaults or {}) do D[k] = v end

    local function Activo()
        if not (mod and mod:IsEnabled()) then return false end
        local ok, _, c = pcall(UnitClass, "player")
        if not ok or c ~= def.clase then return false end
        if def.activo then return def.activo() and true or false end
        if def.rol then return U.RolDe(def.rolDe) == def.rol end
        return true
    end

    ------------------------------------------------------------------
    -- Botones seguros: barra, beneficio, crear materiales
    ------------------------------------------------------------------
    local function Boton(nombre, plantilla)
        local b = CreateFrame("Button", nombre, marco, plantilla or "SecureActionButtonTemplate")
        b:RegisterForClicks("AnyUp", "AnyDown")
        return b
    end
    local function Preparar()
        if not marco then return end
        if U.EnCombate() then pendiente = true; return end
        pendiente = false
        if def.barra then
            marco.barra = marco.barra or {}
            local n = 0
            for _, x in ipairs(def.barra[2]) do
                local id = U.Mejor(x[2])
                if id then
                    n = n + 1
                    local b = marco.barra[n]
                    if not b then
                        b = Boton("CM" .. def.dir .. "Barra" .. n)
                        b.tex = b:CreateTexture(nil, "ARTWORK"); b.tex:SetAllPoints()
                        b.activa = b:CreateTexture(nil, "OVERLAY"); b.activa:SetAllPoints()
                        b.activa:SetTexture("Interface\\Buttons\\CheckButtonHilight"); b.activa:SetBlendMode("ADD")
                        b:SetScript("OnEnter", function(self) GameTooltip:SetOwner(self, "ANCHOR_TOP"); GameTooltip:SetText(U.Nombre(self.id)); GameTooltip:Show() end)
                        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
                        marco.barra[n] = b
                    end
                    b.id, b.base = id, x[2][1]
                    b:SetAttribute("type", "macro"); b:SetAttribute("macrotext", "/cast " .. U.Nombre(id))
                    b.tex:SetTexture(U.Icono(id))
                end
            end
            for i = n + 1, #marco.barra do marco.barra[i]:Hide() end
            marco.nBarra = n
        end
        if def.beneficios and not marco.beneficio then
            marco.beneficio = Boton("CM" .. def.dir .. "Beneficio", "SecureActionButtonTemplate, UIPanelButtonTemplate")
            marco.beneficio:SetSize(220, 20)
        end
        if def.materiales then
            marco.crear = marco.crear or {}
            for i, x in ipairs(def.materiales) do
                if x.crear then
                    local b = marco.crear[i]
                    if not b then b = Boton("CM" .. def.dir .. "Crear" .. i, "SecureActionButtonTemplate, UIPanelButtonTemplate"); b:SetSize(220, 20); marco.crear[i] = b end
                    local id = U.Mejor(x.crear)
                    b.id = id
                    b:SetAttribute("type", "macro"); b:SetAttribute("macrotext", id and ("/cast " .. U.Nombre(id)) or "")
                    b:SetText(id and (U.Nombre(id) .. "") or "")
                end
            end
        end
    end

    local function Crear()
        if marco then return end
        marco = mod:Frame("Frame", "CM" .. def.dir, UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
        marco:SetSize(220, 40)
        U.Movil(mod, marco, def.key, function() return db.bloquear and not mover end)
        if marco.SetBackdrop then
            marco:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                                edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
        end
        marco.texto = marco:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        marco.texto:SetJustifyH("LEFT")
        marco.cds = CreateFrame("Frame", nil, marco)
        Preparar()
    end

    ------------------------------------------------------------------
    -- Piezas
    ------------------------------------------------------------------
    local function Avisar(clave, texto, sonido, r, g, b)
        U.Avisar(mod, texto, sonido, r, g, b)
    end
    local function Restante(fin) if fin and fin ~= math.huge then return math.max(0, fin - GetTime()) end end

    local function Beneficios(lineas, combate)
        local primero
        if not def.beneficios or (combate and db.soloFueraCombate) then return nil end
        local faltan = {}
        local lim = GetTime() + db.minutosBeneficio * 60
        for _, x in ipairs(def.beneficios) do
            if db.on[x[1]] and U.ConoceAlguno(x.si or x[2]) then
                local unidades = (x.deGrupo ~= false and db.beneficiosGrupo and not x.soloYo) and U.Miembros(db.banda) or { "player" }
                for _, u in ipairs(unidades) do
                    local okv, muerto = pcall(UnitIsDeadOrGhost, u)
                    local valido = not (okv and muerto and not U.issecret(muerto))
                    if valido and x.soloMana and u ~= "player" then
                        local okp, tipo = pcall(UnitPowerType, u)
                        if okp and Num(tipo) and tipo ~= 0 then valido = false end
                    end
                    if valido then
                        local fin = U.Aura(u, U.Nombre(x[2][1]), "HELPFUL")
                        if not fin and x.grupo then fin = U.Aura(u, U.Nombre(x.grupo[1]), "HELPFUL") or fin end
                        if fin ~= nil and ((not fin) or (fin ~= math.huge and fin < lim)) then
                            local okn, nombre = pcall(UnitName, u)
                            nombre = okn and Str(nombre) or u
                            faltan[#faltan + 1] = U.Nombre(x[2][1], x[3]) .. ": " .. nombre
                            primero = primero or { u, x, nombre }
                        end
                    end
                end
            end
        end
        for i = 1, math.min(#faltan, 6) do lineas[#lineas + 1] = "|cffffaa33" .. faltan[i] .. "|r" end
        if #faltan > 6 then lineas[#lineas + 1] = ("y %d más..."):format(#faltan - 6) end
        if #faltan > 0 and db.avisoBeneficio and not combate and GetTime() - estado.beneficio > db.repetirBeneficio * 60 then
            estado.beneficio = GetTime()
            Avisar("beneficio", "Falta " .. faltan[1] .. (#faltan > 1 and (" y %d más"):format(#faltan - 1) or ""), true, 0.6, 1, 0.6)
        end
        return primero
    end

    local function Propios(lineas, combate)
        for _, x in ipairs(def.propios or {}) do
            if db.on[x[1]] then
                local conoce, tiene, dudoso = false, false, false
                for _, ids in ipairs(x[2]) do
                    if U.ConoceAlguno(ids) then
                        conoce = true
                        local fin = U.Aura("player", U.Nombre(ids[1]), "HELPFUL")
                        if fin then tiene = true elseif fin == nil then dudoso = true end
                    end
                end
                if conoce and not tiene and not dudoso then
                    lineas[#lineas + 1] = "|cffff5555Sin " .. x[3] .. "|r"
                    if db.avisoPropio and not estado.aviso[x[1]] then
                        estado.aviso[x[1]] = true
                        Avisar(x[1], "Vas sin " .. x[3], true)
                    end
                elseif tiene then
                    estado.aviso[x[1]] = false
                end
            end
        end
    end

    local function Materiales(lineas)
        for i, x in ipairs(def.materiales or {}) do
            if db.on[x[1]] and (not x.crear or U.ConoceAlguno(x.crear)) and (not x.si or U.ConoceAlguno(x.si)) then
                local n = ContarObjetos(x[2])
                local min = db.min[x[1]] or 0
                lineas[#lineas + 1] = (n < min and "|cffff5555%d|r %s" or "%d %s"):format(n, x[3] or U.NombreObjeto(x[2][1]))
                local k = "mat" .. x[1]
                if n < min and db.avisoMateriales and not estado.aviso[k] then
                    estado.aviso[k] = true
                    Avisar(k, ("Te quedan %d %s"):format(n, x[3] or U.NombreObjeto(x[2][1])), false)
                elseif n >= min then estado.aviso[k] = false end
            end
        end
    end

    local function Objetivo(lineas, combate)
        if not def.objetivo or not U.HayEnemigo() then return end
        local okg, guid = pcall(UnitGUID, "target"); guid = okg and Str(guid) or "?"
        for _, x in ipairs(def.objetivo) do
            if db.on[x[1]] and U.ConoceAlguno(x.si or x[2]) then
                local nombre = U.Nombre(x[2][1], x[3])
                local fin, _, cargas = U.Aura("target", nombre, x.propio == false and "HARMFUL" or "HARMFUL|PLAYER")
                local q = Restante(fin)
                local k = guid .. x[1]
                if fin then
                    local poco = q and q <= db.segundosObjetivo
                    local pocas = x.cargas and cargas and cargas < x.cargas
                    lineas[#lineas + 1] = ("%s%s%s%s|r"):format((poco or pocas) and "|cffff5555" or "|cffffffff", nombre,
                        cargas and cargas > 1 and (" x" .. cargas) or "", q and (" " .. U.Tiempo(q)) or "")
                    if poco and db.avisoObjetivo and combate and not estado.aviso[k] then
                        estado.aviso[k] = true
                        Avisar(k, nombre .. ": quedan " .. math.ceil(q) .. " s", true)
                    elseif q and not poco then estado.aviso[k] = nil end
                elseif fin == false and x.falta and combate then
                    lineas[#lineas + 1] = "|cffff5555Falta " .. nombre .. "|r"
                end
            end
        end
    end

    local function Cds(iconos)
        for _, x in ipairs(def.cds or {}) do
            local id = db.on[x[1]] and U.Mejor(x[2])
            if id then
                local q = U.Enfriamiento(id)
                if q then
                    if q == 0 and estado.listo[x[1]] == false and db.avisoListo and x.avisoListo ~= false then
                        Avisar(x[1], U.Nombre(id, x[3]) .. " listo", true, 0.4, 1, 0.4)
                    end
                    estado.listo[x[1]] = q == 0
                end
                iconos[#iconos + 1] = { icono = U.Icono(id), queda = q or 0 }
            end
        end
    end

    local function Usables(lineas)
        for _, x in ipairs(def.usables or {}) do
            local id = db.on[x[1]] and U.Mejor(x[2])
            if id then
                local usable = U.Usable(id) and (U.Enfriamiento(id) or 0) == 0
                if usable then
                    lineas[#lineas + 1] = "|cff66ff66¡" .. U.Nombre(id, x[3]) .. "!|r"
                    if not estado.usable[x[1]] then
                        U.Aviso("¡" .. U.Nombre(id, x[3]) .. "!", 0.4, 1, 0.4)
                        if db.usableSonido then U.Sonar(db.avisoKit) end
                    end
                end
                estado.usable[x[1]] = usable or false
            end
        end
    end

    local function Procs(lineas, iconos)
        for _, x in ipairs(def.procs or {}) do
            if db.on[x[1]] and U.ConoceAlguno(x.si or x[2]) then
                local nombre = U.Nombre(x[2][1], x[3])
                local fin = U.Aura("player", nombre, "HELPFUL")
                if fin ~= nil then
                    if fin and not estado.proc[x[1]] then
                        U.Aviso("¡" .. nombre .. "!", 0.4, 0.8, 1)
                        if db.procSonido then U.Sonar(db.avisoKit) end
                    end
                    estado.proc[x[1]] = fin and true or false
                end
                if estado.proc[x[1]] then
                    local q = Restante(fin)
                    lineas[#lineas + 1] = "|cff66ccff" .. nombre .. (q and (" " .. U.Tiempo(q)) or "") .. "|r"
                end
            end
        end
    end

    local function Uptime(lineas, combate)
        local ahora = GetTime()
        local dt = (combate and ultimoTick) and (ahora - ultimoTick) or 0
        if combate and not enPelea then for k in pairs(estado.uptime) do estado.uptime[k] = { 0, 0 } end end
        enPelea = combate
        ultimoTick = combate and ahora or nil
        for _, x in ipairs(def.uptime or {}) do
            if db.on[x[1]] and U.ConoceAlguno(x.si or x[2]) then
                local u = estado.uptime[x[1]] or { 0, 0 }
                estado.uptime[x[1]] = u
                local fin = U.Aura(x.unidad or "player", U.Nombre(x[2][1], x[3]), "HELPFUL")
                u[1] = u[1] + dt
                if fin then u[2] = u[2] + dt end
                if u[1] > 0 then
                    lineas[#lineas + 1] = ("%s activo: %d%%%s"):format(U.Nombre(x[2][1], x[3]), u[2] / u[1] * 100, combate and "" or " (última pelea)")
                end
            end
        end
    end

    local function Mana(lineas)
        if not (def.mana and db.on.mana) then return end
        local m, mx = U.Mana()
        if not (m and mx and mx > 0) then return end
        local pc = m / mx * 100
        lineas[#lineas + 1] = ("Maná %d%%"):format(pc)
        if db.cincoSegundos then
            local resto = 5 - (GetTime() - ultimoGasto)
            lineas[#lineas + 1] = resto > 0 and ("|cffffaa33Regla de 5 s: %.1f|r"):format(resto) or "|cff66ff66Regenerando maná|r"
        end
        if db.avisoMana and pc < db.porcentajeMana and not estado.aviso.mana then
            estado.aviso.mana = true
            Avisar("mana", ("Maná bajo (%d%%)"):format(pc), true, 0.4, 0.6, 1)
        elseif pc > db.porcentajeMana + 10 then estado.aviso.mana = false end
    end

    ------------------------------------------------------------------
    -- Pintar
    ------------------------------------------------------------------
    local function Pintar()
        local combate = U.EnCombate()
        if not Activo() then
            if marco and not (protegido and combate) then marco:Hide() end
            return
        end
        if not marco and protegido and combate then return end
        Crear()
        if pendiente and not combate then Preparar() end
        marco:SetScale(db.escala); marco:SetAlpha(db.opacidad)
        if marco.SetBackdropColor then
            marco:SetBackdropColor(0, 0, 0, db.fondo and 0.7 or 0)
            marco:SetBackdropBorderColor(1, 1, 1, db.fondo and 0.5 or 0)
        end
        local y, ancho = -6, 200
        local lineas, iconos = {}, {}
        -- Barra de botones.
        if def.barra and db.on.barra and marco.nBarra and marco.nBarra > 0 then
            local t = db.tamBarra
            for i = 1, marco.nBarra do
                local b = marco.barra[i]
                if not combate then b:SetSize(t, t); b:ClearAllPoints(); b:SetPoint("TOPLEFT", marco, "TOPLEFT", 6 + (i - 1) * (t + 4), y); b:Show() end
                local fin = U.Aura("player", U.Nombre(b.base), "HELPFUL")
                local activa = fin and true or false
                if def.barra.activa then activa = def.barra.activa(b.id, i) end
                b.activa:SetShown(activa)
            end
            ancho = math.max(ancho, 12 + marco.nBarra * (t + 4))
            y = y - t - 6
        elseif marco.barra and not combate then
            for _, b in ipairs(marco.barra) do b:Hide() end
        end
        Propios(lineas, combate)
        Procs(lineas, iconos)
        Usables(lineas)
        Objetivo(lineas, combate)
        Uptime(lineas, combate)
        Mana(lineas)
        Materiales(lineas)
        if def.extra then pcall(def.extra, { mod = mod, db = db, lineas = lineas, iconos = iconos, combate = combate }) end
        local primero = Beneficios(lineas, combate)
        Cds(iconos)
        if #iconos > 0 then
            marco.cds:ClearAllPoints(); marco.cds:SetPoint("TOPLEFT", marco, "TOPLEFT", 6, y)
            marco.cds:SetSize(#iconos * (db.tamIcono + 6), db.tamIcono)
            U.Iconos(marco.cds, iconos, db.tamIcono)
            marco.cds:Show()
            ancho = math.max(ancho, #iconos * (db.tamIcono + 6))
            y = y - db.tamIcono - 16
        else
            marco.cds:Hide()
        end
        if #lineas > 0 then
            marco.texto:ClearAllPoints(); marco.texto:SetPoint("TOPLEFT", marco, "TOPLEFT", 8, y)
            marco.texto:SetWidth(ancho + 40)
            marco.texto:SetText(table.concat(lineas, "\n"))
            marco.texto:Show()
            y = y - 13 * #lineas - 4
        else
            marco.texto:Hide()
        end
        if combate and protegido then return end
        -- Botones de abajo (fuera de combate).
        if marco.beneficio then
            if db.botonBeneficio and primero then
                local x = primero[2]
                local ids = (x.grupo and U.ConoceAlguno(x.grupo) and db.beneficiosGrupo and primero[1] ~= "player") and x.grupo or x[2]
                marco.beneficio:SetAttribute("type", "macro")
                marco.beneficio:SetAttribute("macrotext", ("/cast [@%s] %s"):format(primero[1], U.Nombre(U.Mejor(ids) or ids[1])))
                marco.beneficio:SetText(U.Nombre(x[2][1], x[3]) .. " » " .. primero[3])
                marco.beneficio:ClearAllPoints(); marco.beneficio:SetPoint("TOPLEFT", marco, "TOPLEFT", 8, y)
                marco.beneficio:Show()
                y = y - 24
            else
                marco.beneficio:Hide()
            end
        end
        if marco.crear then
            for i, x in ipairs(def.materiales) do
                local b = marco.crear[i]
                if b then
                    local mostrar = db.botonCrear and db.on[x[1]] and b.id and ContarObjetos(x[2]) < (db.min[x[1]] or 0)
                    if mostrar then
                        b:ClearAllPoints(); b:SetPoint("TOPLEFT", marco, "TOPLEFT", 8, y); b:Show()
                        y = y - 24
                    else
                        b:Hide()
                    end
                end
            end
        end
        if y >= -8 and not mover then marco:Hide(); return end
        marco:SetSize(ancho + 50, -y + 4)
        if not marco.colocado then U.Colocar(mod, marco, def.key, 0, def.rol and -260 or 200); marco.colocado = true end
        marco:EnableMouse(mover or not db.bloquear)
        marco:Show()
    end

    local function Canal()
        if db.canal ~= "auto" then return db.canal end
        local okr, banda = pcall(IsInRaid)
        if okr and banda and not U.issecret(banda) then return "RAID" end
        local okg, grupo = pcall(IsInGroup)
        if okg and grupo and not U.issecret(grupo) then return "PARTY" end
    end

    ------------------------------------------------------------------
    -- Registro
    ------------------------------------------------------------------
    local acum = 0
    local function Etiqueta(x) return x[3] or U.Nombre(x[2][1]) end
    mod = Hub:Register{
        key = def.key, dir = def.dir, name = def.name, clase = def.clase, desc = def.desc,
        defaults = D, slash = def.slash,
        Init = function(m)
            db = m.db
            m:Event("UNIT_SPELLCAST_SENT", function(_, _, unidad, objetivo, _, hechizo)
                if unidad == "player" and Num(hechizo) then enviado[hechizo] = Str(objetivo) end
            end)
            m:Event("UNIT_SPELLCAST_SUCCEEDED", function(_, _, unidad, _, hechizo)
                if unidad ~= "player" then return end
                hechizo = Num(hechizo)
                if not hechizo then return end
                local c = U.Coste(hechizo)
                if c and c > 0 then ultimoGasto = GetTime() end
                for _, x in ipairs(def.cds or {}) do
                    if x.anunciar and db.anunciar and db.on[x[1]] then
                        for _, id in ipairs(x[2]) do
                            if id == hechizo and enviado[hechizo] then
                                local canal = Canal()
                                if canal then pcall(SendChatMessage, (db.textoAnuncio:gsub("%%h", U.Nombre(id, x[3])):gsub("%%t", enviado[hechizo])), canal) end
                            end
                        end
                    end
                end
                enviado[hechizo] = nil
            end)
            m:Event("SPELLS_CHANGED", function() Preparar() end)
            m:Event("UPDATE_SHAPESHIFT_FORMS", function() Preparar() end)
            m:Event("PLAYER_REGEN_ENABLED", function() Preparar(); Pintar() end)
            m:Event("GROUP_ROSTER_UPDATE", Pintar)
            m:Event("BAG_UPDATE_DELAYED", Pintar)
            m:Event("PLAYER_TARGET_CHANGED", Pintar)
            if def.eventos then def.eventos(m, Pintar) end
            m:OnUpdate(function(_, e) acum = acum + e; if acum >= 0.15 then acum = 0; Pintar() end end)
        end,
        Enable = function(m) db = m.db; Pintar() end,
        Disable = function() if marco and not (protegido and U.EnCombate()) then marco:Hide() end end,
        OnReset = function() if marco then marco.colocado = false end end,
        OnSlash = function(m, msg)
            msg = (msg or ""):lower()
            if msg == "mover" then mover = not mover; Pintar()
            elseif msg == "rol" and esComun then m:Print("rol: " .. U.RolDe(def.key) .. " (ajuste: " .. db.rol .. ")")
            else Hub:Open(def.key) end
        end,
        BuildConfig = function(m, L)
            db = m.db
            local function G(k) return function() return db[k] end end
            local function S(k) return function(v) db[k] = v; Preparar(); Pintar() end end
            local function On(k) return function() return db.on[k] end end
            local function SetOn(k) return function(v) db.on[k] = v; Pintar() end end
            local okc, _, clase = pcall(UnitClass, "player")
            if not (okc and clase == def.clase) then L:Text("|cffff7755Este personaje no es de esta clase.|r", true) end
            if esComun then
                L:Header("Rol")
                local pistas = {}
                for _, p in ipairs(def.pistas or {}) do pistas[#pistas + 1] = U.Nombre(p[2][1]) .. " = " .. p[1] end
                L:Text("Los módulos de cada rol solo se encienden con el suyo. En automático se mira qué talentos conoces ("
                    .. table.concat(pistas, "; ") .. ").", true)
                local roles = { { "auto", "Automático (por talentos)" } }
                for _, r in ipairs(def.roles) do roles[#roles + 1] = r end
                L:Choice("Rol", roles, G("rol"), function(v) db.rol = v; Pintar(); m:Print("rol: " .. U.RolDe(def.key)) end)
                L:Button("¿Qué rol tengo ahora?", 180, function() m:Print("rol: " .. U.RolDe(def.key) .. " (ajuste: " .. db.rol .. ")") end)
            elseif def.textoRol then
                L:Text(def.textoRol(), true)
            elseif def.rol then
                L:Text(("Solo funciona si tu rol es «%s» (en la pestaña común de la clase). Ahora: |cffffd100%s|r."):format(def.rol, U.RolDe(def.rolDe)), true)
            end
            L:Header("Marco")
            L:Button("Mover", 90, function() mover = not mover; Pintar() end)
            L:Button("Volver a su sitio", 140, function() db.pos[def.key] = nil; if marco then marco.colocado = false end; Pintar() end, true)
            L:Check("Bloquear la posición", G("bloquear"), S("bloquear"))
            L:Check("Fondo y borde", G("fondo"), S("fondo"))
            L:Slider("Escala", 0.5, 2, 0.05, G("escala"), S("escala"), "%.2f")
            L:Slider("Opacidad", 0.2, 1, 0.05, G("opacidad"), S("opacidad"), "%.2f")
            L:Slider("Tamaño de los iconos", 18, 70, 1, G("tamIcono"), S("tamIcono"))
            if def.barra then
                L:Header(def.barra[1])
                L:Check("Barra de botones (clic para cambiar)", On("barra"), SetOn("barra"))
                L:Slider("  Tamaño", 18, 50, 1, G("tamBarra"), S("tamBarra"))
            end
            if def.propios then
                L:Header("Lo que debes llevar puesto")
                for _, x in ipairs(def.propios) do L:Check("Aviso si vas sin " .. x[3], On(x[1]), SetOn(x[1])) end
                L:Check("  Con aviso (texto/sonido)", G("avisoPropio"), S("avisoPropio"))
            end
            if def.beneficios then
                L:Header("Beneficios")
                for _, x in ipairs(def.beneficios) do L:Check(Etiqueta(x), On(x[1]), SetOn(x[1])) end
                L:Check("  Al grupo (si no, solo a ti)", G("beneficiosGrupo"), S("beneficiosGrupo"))
                L:Check("  También a toda la banda", G("banda"), S("banda"))
                L:Slider("  Avisar cuando le queden menos de (minutos)", 0, 15, 1, G("minutosBeneficio"), S("minutosBeneficio"))
                L:Check("  Solo fuera de combate", G("soloFueraCombate"), S("soloFueraCombate"))
                L:Check("  Aviso (texto/sonido)", G("avisoBeneficio"), S("avisoBeneficio"))
                L:Slider("  Repetir el aviso cada (minutos)", 1, 30, 1, G("repetirBeneficio"), S("repetirBeneficio"))
                L:Check("  Botón para ponérselo al primero que le falte", G("botonBeneficio"), S("botonBeneficio"))
            end
            if def.materiales then
                L:Header("Materiales y objetos")
                for _, x in ipairs(def.materiales) do
                    L:Check(x[3] or U.NombreObjeto(x[2][1]), On(x[1]), SetOn(x[1]))
                    L:Slider("  En rojo y aviso por debajo de", 0, 60, 1, function() return db.min[x[1]] end, function(v) db.min[x[1]] = v; Pintar() end)
                end
                L:Check("Aviso cuando bajan de ahí", G("avisoMateriales"), S("avisoMateriales"))
                L:Check("Botón para crearlos cuando te faltan (si se pueden crear)", G("botonCrear"), S("botonCrear"))
            end
            if def.objetivo then
                L:Header("En el objetivo")
                for _, x in ipairs(def.objetivo) do L:Check(Etiqueta(x), On(x[1]), SetOn(x[1])) end
                L:Slider("  En rojo cuando quedan (segundos)", 0, 15, 1, G("segundosObjetivo"), S("segundosObjetivo"))
                L:Check("  Aviso en combate cuando se van a acabar", G("avisoObjetivo"), S("avisoObjetivo"))
            end
            if def.procs or def.usables then
                L:Header("Avisos al momento")
                for _, x in ipairs(def.procs or {}) do L:Check("Cuando te salta " .. Etiqueta(x), On(x[1]), SetOn(x[1])) end
                if def.procs then L:Check("  Con sonido", G("procSonido"), S("procSonido")) end
                for _, x in ipairs(def.usables or {}) do L:Check("Cuando puedes usar " .. Etiqueta(x), On(x[1]), SetOn(x[1])) end
                if def.usables then L:Check("  Con sonido", G("usableSonido"), S("usableSonido")) end
            end
            if def.uptime then
                L:Header("Cuánto lo mantienes")
                for _, x in ipairs(def.uptime) do L:Check(Etiqueta(x) .. ": % de la pelea", On(x[1]), SetOn(x[1])) end
            end
            if def.mana then
                L:Header("Maná")
                L:Check("Maná", On("mana"), SetOn("mana"))
                L:Check("  Regla de los 5 segundos", G("cincoSegundos"), S("cincoSegundos"))
                L:Check("  Aviso de maná bajo", G("avisoMana"), S("avisoMana"))
                L:Slider("    Por debajo de (%)", 5, 60, 5, G("porcentajeMana"), S("porcentajeMana"))
            end
            if def.cds then
                L:Header("Enfriamientos")
                local anuncia = false
                for _, x in ipairs(def.cds) do L:Check(Etiqueta(x), On(x[1]), SetOn(x[1])); anuncia = anuncia or x.anunciar end
                L:Check("  Aviso cuando vuelven a estar listos", G("avisoListo"), S("avisoListo"))
                if anuncia then
                    L:Check("Anunciar a quién se lo lanzas (los que tienen objetivo)", G("anunciar"), S("anunciar"))
                    L:Choice("  Canal", { { "auto", "Banda o grupo (según estés)" }, { "PARTY", "Grupo" }, { "RAID", "Banda" }, { "SAY", "Decir" }, { "YELL", "Gritar" } },
                        G("canal"), S("canal"))
                    L:Edit("  Texto (%h = hechizo, %t = objetivo)", G("textoAnuncio"), function(v) if type(v) == "string" then db.textoAnuncio = v:gsub("|", "") end end, "text", 220)
                end
            end
            if def.config then def.config(m, L) end
            L:Header("Cómo avisa")
            L:Check("Texto grande", G("avisoTexto"), S("avisoTexto"))
            L:Check("Línea en el chat", G("avisoChat"), S("avisoChat"))
            L:Check("Sonido", G("avisoSonido"), S("avisoSonido"))
            L:Choice("  Sonido", U.KITS, G("avisoKit"), function(v) db.avisoKit = v; U.Sonar(v) end)
        end,
    }
    return mod
end
