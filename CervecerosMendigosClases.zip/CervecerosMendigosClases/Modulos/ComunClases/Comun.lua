-- Ayudas comunes de los módulos de clase de CervecerosMendigos Clases (druida, paladín...).
-- Lo que se lee del juego pasa por Num/Str: en combate el cliente puede devolver valores «secretos».
-- ns.CU = utilidades de todas las clases; ns.Druida es la misma tabla (con lo propio del druida: Rol, Forma).
local ADDON, ns = ...
local D = {}
ns.CU = D
ns.Druida = D

local issecret = issecretvalue or function() return false end
D.issecret = issecret
function D.Num(v) if type(v) ~= "number" or issecret(v) then return nil end return v end
function D.Str(v) if type(v) ~= "string" or issecret(v) then return nil end return v end
local Num, Str = D.Num, D.Str

function D.EsDruida()
    local ok, _, c = pcall(UnitClass, "player")
    return ok and c == "DRUID"
end

function D.Nombre(id, repuesto)
    if C_Spell and C_Spell.GetSpellName then local ok, n = pcall(C_Spell.GetSpellName, id); if ok and Str(n) then return n end end
    if GetSpellInfo then local ok, n = pcall(GetSpellInfo, id); if ok and Str(n) then return n end end
    return repuesto or ("hechizo " .. id)
end
function D.Icono(id)
    if C_Spell and C_Spell.GetSpellTexture then local ok, t = pcall(C_Spell.GetSpellTexture, id); if ok and t then return t end end
    if C_Spell and C_Spell.GetSpellInfo then local ok, i = pcall(C_Spell.GetSpellInfo, id); if ok and type(i) == "table" and i.iconID then return i.iconID end end
    return "Interface\\Icons\\INV_Misc_QuestionMark"
end
function D.Conoce(id)
    if IsPlayerSpell then local ok, v = pcall(IsPlayerSpell, id); if ok and v and not issecret(v) then return true end end
    if IsSpellKnown then local ok, v = pcall(IsSpellKnown, id); if ok and v and not issecret(v) then return true end end
    return false
end
-- Rango más alto que conoces de una lista de rangos (id), o nil.
function D.Mejor(ids)
    for i = #ids, 1, -1 do if D.Conoce(ids[i]) then return ids[i], i end end
end
function D.ConoceAlguno(ids) return D.Mejor(ids) ~= nil end

function D.NombreObjeto(id)
    if C_Item and C_Item.GetItemNameByID then local ok, n = pcall(C_Item.GetItemNameByID, id); if ok and Str(n) then return n end end
    if GetItemInfo then local ok, n = pcall(GetItemInfo, id); if ok and Str(n) then return n end end
    if C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, id) end
    return "objeto " .. id
end
function D.ContarObjeto(id)
    if C_Item and C_Item.GetItemCount then local ok, n = pcall(C_Item.GetItemCount, id); if ok and Num(n) then return n end end
    if GetItemCount then local ok, n = pcall(GetItemCount, id); if ok and Num(n) then return n end end
    return 0
end

-- Maná (en forma también se puede leer el de maná con el tipo 0).
function D.Mana()
    local ok, m = pcall(UnitPower, "player", 0)
    local ok2, mx = pcall(UnitPowerMax, "player", 0)
    return ok and Num(m), ok2 and Num(mx)
end
-- Coste en maná de un hechizo (o nil).
function D.Coste(id)
    if C_Spell and C_Spell.GetSpellPowerCost then
        local ok, c = pcall(C_Spell.GetSpellPowerCost, id)
        if ok and type(c) == "table" then
            for _, x in ipairs(c) do if Num(x.type) == 0 and Num(x.cost) then return x.cost end end
        end
    end
    if GetSpellPowerCost then
        local ok, c = pcall(GetSpellPowerCost, id)
        if ok and type(c) == "table" then
            for _, x in ipairs(c) do if Num(x.type) == 0 and Num(x.cost) then return x.cost end end
        end
    end
end

-- Forma actual: "oso", "gato", "viaje", "acuatica", "lechucico" o nil (humanoide).
D.FORMAS = {
    { "oso", { 5487, 9634 }, "Forma de oso" }, { "gato", { 768 }, "Forma felina" },
    { "acuatica", { 1066 }, "Forma acuática" }, { "viaje", { 783 }, "Forma de viaje" },
    { "lechucico", { 24858 }, "Forma de lechúcico lunar" },
}
local FORMA_DE = {}
for _, f in ipairs(D.FORMAS) do for _, id in ipairs(f[2]) do FORMA_DE[id] = f[1] end end
D.FORMA_DE = FORMA_DE
function D.Forma()
    if not (GetNumShapeshiftForms and GetShapeshiftFormInfo) then return nil end
    local ok, n = pcall(GetNumShapeshiftForms)
    n = ok and Num(n) or 0
    for i = 1, n do
        local r = { pcall(GetShapeshiftFormInfo, i) }
        if r[1] and r[3] and not issecret(r[3]) then return FORMA_DE[Num(r[5])] or "otra", i end
    end
    return nil
end

-- Aura por nombre en una unidad: devuelve fin (GetTime), duración; false si se ha podido mirar y no está;
-- nil si no se puede saber (auras ocultas en combate).
function D.Aura(unidad, nombre, filtro)
    if not (C_UnitAuras and C_UnitAuras.GetAuraDataByIndex) or not nombre then return nil end
    local dudoso = false
    for i = 1, 40 do
        local ok, a = pcall(C_UnitAuras.GetAuraDataByIndex, unidad, i, filtro or "HELPFUL")
        if not ok then return nil end
        if a == nil then if dudoso then return nil end return false end
        if type(a) ~= "table" then return nil end
        local n = Str(a.name)
        if not n then dudoso = true
        elseif n == nombre then
            local fin = Num(a.expirationTime)
            if fin and fin > 0 then return fin, Num(a.duration), Num(a.applications) end
            return math.huge, 0
        end
    end
    return false
end

-- Lo que le queda a un enfriamiento (s); nil si no se puede leer.
function D.Enfriamiento(id)
    if C_Spell and C_Spell.GetSpellCooldown then
        local ok, c = pcall(C_Spell.GetSpellCooldown, id)
        if ok and type(c) == "table" then
            local s, d = Num(c.startTime), Num(c.duration)
            if s and d then
                if d <= 1.6 then return 0 end   -- el enfriamiento global no cuenta
                return math.max(0, s + d - GetTime())
            end
        end
    end
    if GetSpellCooldown then
        local ok, s, d = pcall(GetSpellCooldown, id)
        if ok and Num(s) and Num(d) then
            if d <= 1.6 then return 0 end
            return math.max(0, s + d - GetTime())
        end
    end
end

-- Rol del druida según el ajuste del módulo Druida: "feral", "sanador", "ambos" o "ninguno".
D.TALENTO_FERAL = { 16979, 17007 }        -- Carga feral, Líder de la manada
D.TALENTO_SANADOR = { 17116, 18562 }      -- Rapidez de la Naturaleza, Alivio presto
function D.Rol()
    local m = ns.Hub and ns.Hub.byKey and ns.Hub.byKey.druida
    local rol = m and m.db and m.db.rol or "auto"
    if rol ~= "auto" then return rol end
    local f, s = D.ConoceAlguno(D.TALENTO_FERAL), D.ConoceAlguno(D.TALENTO_SANADOR)
    local forma = D.Forma()
    if forma == "gato" or forma == "oso" then f = true end
    if f and s then return "ambos" elseif f then return "feral" elseif s then return "sanador" end
    return "ninguno"
end
function D.EsFeral() local r = D.Rol(); return r == "feral" or r == "ambos" end
function D.EsSanador() local r = D.Rol(); return r == "sanador" or r == "ambos" end

-- Avisos y sonidos.
D.KITS = { { "RAID_WARNING", "Aviso de banda" }, { "ALARM_CLOCK_WARNING_3", "Alarma" }, { "IG_PVP_UPDATE", "Aviso JcJ" },
           { "READY_CHECK", "Comprobación de listos" }, { "IG_QUEST_LIST_COMPLETE", "Misión completada" } }
local NUM_KIT = { RAID_WARNING = 8959, ALARM_CLOCK_WARNING_3 = 12889, IG_PVP_UPDATE = 8174, READY_CHECK = 8960, IG_QUEST_LIST_COMPLETE = 878 }
function D.Sonar(kit)
    local id = (SOUNDKIT and SOUNDKIT[kit]) or NUM_KIT[kit]
    if id then pcall(PlaySound, id, "Master") end
end
function D.Aviso(texto, r, g, b)
    if RaidNotice_AddMessage and RaidWarningFrame then
        pcall(RaidNotice_AddMessage, RaidWarningFrame, texto, { r = r or 1, g = g or 0.8, b = b or 0.2 })
    elseif UIErrorsFrame and UIErrorsFrame.AddMessage then
        UIErrorsFrame:AddMessage(texto, r or 1, g or 0.8, b or 0.2)
    end
end
-- Aviso completo según los ajustes del módulo (prefijo de las claves: texto, chat, sonido, kit).
function D.Avisar(mod, texto, sonido, r, g, b)
    local db = mod.db
    if db.avisoTexto then D.Aviso(texto, r, g, b) end
    if db.avisoChat then mod:Print(texto) end
    if db.avisoSonido and sonido ~= false then D.Sonar(db.avisoKit) end
end

-- Marco móvil con posición en db.pos[clave].
function D.Movil(mod, f, clave, bloqueado)
    f:SetClampedToScreen(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(self) if not bloqueado() then self:StartMoving() end end)
    f:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local l, t = self:GetLeft(), self:GetTop()
        if l and t then mod.db.pos[clave] = { l, t } end
    end)
end
function D.Colocar(mod, f, clave, x, y)
    local p = mod.db.pos[clave]
    f:ClearAllPoints()
    if p then f:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", p[1], p[2]) else f:SetPoint("CENTER", UIParent, "CENTER", x, y) end
end
function D.Tiempo(s)
    if not s then return "" end
    if s >= 60 then return ("%d:%02d"):format(math.floor(s / 60), math.floor(s % 60)) end
    if s >= 10 then return ("%d"):format(math.floor(s)) end
    return ("%.1f"):format(s)
end
function D.EnCombate()
    local ok, v = pcall(InCombatLockdown)
    if ok and v and not issecret(v) then return true end
    local ok2, v2 = pcall(UnitAffectingCombat, "player")
    return ok2 and v2 and not issecret(v2) and true or false
end

-- Miembros del grupo: "player", "party1".. o "raid1".. (según incluirBanda).
function D.Miembros(incluirBanda)
    local out = { "player" }
    local okr, banda = pcall(IsInRaid)
    if okr and banda and not issecret(banda) and incluirBanda then
        out = {}
        for i = 1, 40 do
            local ok, e = pcall(UnitExists, "raid" .. i)
            if ok and e and not issecret(e) then out[#out + 1] = "raid" .. i end
        end
        return out
    end
    for i = 1, 4 do
        local ok, e = pcall(UnitExists, "party" .. i)
        if ok and e and not issecret(e) then out[#out + 1] = "party" .. i end
    end
    return out
end

-- Fila de iconos con enfriamiento (cooldowns grandes): crea/actualiza iconos en un marco.
function D.Iconos(padre, lista, tam, prefijo)
    padre.iconos = padre.iconos or {}
    for i, x in ipairs(lista) do
        local b = padre.iconos[i]
        if not b then
            b = CreateFrame("Frame", nil, padre)
            b.tex = b:CreateTexture(nil, "ARTWORK"); b.tex:SetAllPoints()
            b.texto = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
            b.texto:SetPoint("CENTER")
            b.nombre = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            b.nombre:SetPoint("TOP", b, "BOTTOM", 0, -1)
            padre.iconos[i] = b
        end
        b:SetSize(tam, tam)
        b:ClearAllPoints(); b:SetPoint("TOPLEFT", padre, "TOPLEFT", (i - 1) * (tam + 6), prefijo or 0)
        b.tex:SetTexture(x.icono)
        b.tex:SetDesaturated(x.queda and x.queda > 0 or false)
        b.texto:SetText(x.queda and x.queda > 0 and D.Tiempo(x.queda) or "")
        b.nombre:SetText(x.etiqueta or "")
        b:Show()
    end
    for i = #lista + 1, #padre.iconos do padre.iconos[i]:Hide() end
end

-- Panel sencillo (líneas de texto + iconos de enfriamiento) para los módulos de rol.
function D.Panel(m, nombre, clave, mover)
    local f = m:Frame("Frame", nombre, UIParent)
    f:SetSize(220, 30)
    D.Movil(m, f, clave, function() return m.db.bloquear and not mover() end)
    f.texto = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    f.texto:SetJustifyH("LEFT")
    f.cds = CreateFrame("Frame", nil, f)
    f.clave = clave
    return f
end
function D.PintarPanel(m, f, lineas, iconos, mover, x, y0)
    local db = m.db
    f:SetScale(db.escala); f:SetAlpha(db.opacidad)
    f:EnableMouse(mover or not db.bloquear)
    local y = 0
    if #iconos > 0 then
        f.cds:ClearAllPoints(); f.cds:SetPoint("TOPLEFT", f, "TOPLEFT", 0, 0)
        f.cds:SetSize(#iconos * (db.tamIcono + 6), db.tamIcono)
        D.Iconos(f.cds, iconos, db.tamIcono)
        f.cds:Show()
        y = y - db.tamIcono - 16
    else
        f.cds:Hide()
    end
    if #lineas > 0 then
        f.texto:ClearAllPoints(); f.texto:SetPoint("TOPLEFT", f, "TOPLEFT", 0, y)
        f.texto:SetWidth(260)
        f.texto:SetText(table.concat(lineas, "\n"))
        f.texto:Show()
        y = y - 16 * #lineas
    else
        f.texto:Hide()
    end
    if y == 0 and not mover then f:Hide(); return end
    f:SetSize(260, math.max(20, -y))
    if not f.colocado then D.Colocar(m, f, f.clave, x, y0); f.colocado = true end
    f:Show()
end
-- Lo que le queda a un perjuicio en el objetivo (de cualquiera): segundos, false si no está, nil si no se sabe.
function D.EnObjetivo(ids)
    local fin = D.Aura("target", D.Nombre(ids[1]), "HARMFUL")
    if fin == nil then return nil end
    if not fin then return false end
    if fin == math.huge then return 999 end
    return math.max(0, fin - GetTime())
end
function D.HayEnemigo()
    local ok, v = pcall(UnitCanAttack, "player", "target")
    return ok and v and not D.issecret(v) or false
end

