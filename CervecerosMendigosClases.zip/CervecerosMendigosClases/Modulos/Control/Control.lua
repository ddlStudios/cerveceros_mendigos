-- Control (CervecerosMendigos Clases, pícaro) para WoW Forever: cuánto les queda a tus controles y los
-- rendimientos decrecientes (RD) de cada objetivo.
--   * Al lanzar Aporrear, Gubia, Ceguera, Golpe bajo o Golpe en los riñones se apunta el objetivo.
--   * La duración sale del aura del objetivo si el juego deja leerla; si no (valores secretos en
--     combate, o ya no lo tienes seleccionado), se calcula con la duración del hechizo y el RD.
--   * Sin registro de combate en Forever: solo se ven tus propios controles.
local ADDON, ns = ...
local Hub = ns.Hub
local issecret = issecretvalue or function() return false end
local function Num(v) if type(v) ~= "number" or issecret(v) then return nil end return v end
local function Str(v) if type(v) ~= "string" or issecret(v) then return nil end return v end

-- Categorías de rendimientos decrecientes (las de clásico para tus controles de pícaro).
local CATS = {
    { "aturdir", "Aturdimientos" }, { "rinones", "Golpe en los riñones" },
    { "incap", "Aporrear / Gubia" }, { "ceguera", "Ceguera" },
}
local NOMBRE_CAT = {}
for _, c in ipairs(CATS) do NOMBRE_CAT[c[1]] = c[2] end
-- [hechizo] = { categoría, duración base (s) } ; riñones: duración según puntos de combo.
local CC = {
    [6770] = { "incap", 25 }, [2070] = { "incap", 35 }, [11297] = { "incap", 45 },          -- Aporrear
    [1776] = { "incap", 4 }, [1777] = { "incap", 4 }, [8629] = { "incap", 4 },             -- Gubia
    [11285] = { "incap", 4 }, [11286] = { "incap", 4 },
    [2094] = { "ceguera", 10 },                                                            -- Ceguera
    [1833] = { "aturdir", 4 },                                                             -- Golpe bajo
    [408] = { "rinones", 0, rango = 1 }, [8643] = { "rinones", 0, rango = 2 },             -- Golpe en los riñones
}
local FACTOR = { 1, 0.5, 0.25, 0 }

local DEFAULTS = {
    barras = true, maxBarras = 4, ancho = 220, alto = 18, escala = 1, opacidad = 1, bloquear = false,
    colorBarra = { 0.85, 0.65, 0.15 }, colorPoco = { 1, 0.25, 0.2 }, verNombre = true, verRD = true,
    soloJugadoresRD = true, segundosRD = 18,
    avisoPoco = true, segundosPoco = 3, avisoPocoSonido = true, avisoKit = "RAID_WARNING",
    avisoRoto = true, avisoRotoSonido = false, avisoInmune = true,
    usarAura = true, mejoraGubia = 0,
    cats = { aturdir = true, rinones = true, incap = true, ceguera = true },
    pos = {},
}

local mod, db
local activos = {}      -- [guid] = { hechizo, cat, fin, dur, nombre, avisado, unidad }
local rd = {}           -- [guid] = { [cat] = { n, reset } }
local ultimosCombos = 0
local marco

local function NombreHechizo(id)
    if C_Spell and C_Spell.GetSpellName then local ok, n = pcall(C_Spell.GetSpellName, id); if ok and Str(n) then return n end end
    return "hechizo " .. id
end
local function IconoHechizo(id)
    if C_Spell and C_Spell.GetSpellTexture then local ok, t = pcall(C_Spell.GetSpellTexture, id); if ok and t then return t end end
    if C_Spell and C_Spell.GetSpellInfo then local ok, i = pcall(C_Spell.GetSpellInfo, id); if ok and type(i) == "table" then return i.iconID end end
    return "Interface\\Icons\\INV_Misc_QuestionMark"
end
local KIT = { RAID_WARNING = 8959, ALARM_CLOCK_WARNING_3 = 12889, IG_PVP_UPDATE = 8174, READY_CHECK = 8960 }
local KITS = { { "RAID_WARNING", "Aviso de banda" }, { "ALARM_CLOCK_WARNING_3", "Alarma" }, { "IG_PVP_UPDATE", "Aviso JcJ" }, { "READY_CHECK", "Comprobación" } }
local function Sonar(k) local id = (SOUNDKIT and SOUNDKIT[k]) or KIT[k]; if id then pcall(PlaySound, id, "Master") end end
local function Aviso(t, r, g, b)
    if RaidNotice_AddMessage and RaidWarningFrame then pcall(RaidNotice_AddMessage, RaidWarningFrame, t, { r = r, g = g, b = b })
    elseif UIErrorsFrame then UIErrorsFrame:AddMessage(t, r, g, b) end
end

----------------------------------------------------------------------
-- Rendimientos decrecientes
----------------------------------------------------------------------
-- Siguiente factor de duración para esa categoría en ese objetivo (1, 0.5, 0.25 o 0 = inmune).
local function FactorRD(guid, cat)
    local x = rd[guid] and rd[guid][cat]
    if not x or GetTime() >= x.reset then return 1, 0 end
    return FACTOR[math.min(x.n + 1, 4)], x.n
end
local function AplicarRD(guid, cat, fin)
    rd[guid] = rd[guid] or {}
    local x = rd[guid][cat]
    if not x or GetTime() >= x.reset then x = { n = 0 } end
    x.n = math.min(x.n + 1, 3)
    x.reset = fin + db.segundosRD
    rd[guid][cat] = x
end

----------------------------------------------------------------------
-- Aura del objetivo (si se puede leer)
----------------------------------------------------------------------
local function LeerAura(unidad, hechizo)
    if not (db.usarAura and C_UnitAuras and C_UnitAuras.GetAuraDataByIndex) then return nil end
    local dudoso = false
    for i = 1, 40 do
        local ok, a = pcall(C_UnitAuras.GetAuraDataByIndex, unidad, i, "HARMFUL|PLAYER")
        if not ok then return nil end              -- no se puede mirar
        if a == nil then                           -- fin de la lista
            if dudoso then return nil end          -- alguna aura oculta: no se sabe
            return false                           -- no está
        end
        if type(a) ~= "table" then return nil end
        local id = Num(a.spellId)
        if not id then dudoso = true end
        if id == hechizo then
            local fin = Num(a.expirationTime)
            if fin and fin > 0 then return fin, Num(a.duration) end
            return nil
        end
    end
    return false   -- se ha podido mirar y no está
end

----------------------------------------------------------------------
-- Al lanzar un control
----------------------------------------------------------------------
local function AlLanzar(unidad, hechizo)
    if unidad ~= "player" then return end
    hechizo = Num(hechizo)
    local def = hechizo and CC[hechizo]
    if not def or not db.cats[def[1]] then return end
    local okg, guid = pcall(UnitGUID, "target")
    guid = okg and Str(guid)
    if not guid then return end
    local okn, nombre = pcall(UnitName, "target")
    local okj, jugador = pcall(UnitIsPlayer, "target")
    jugador = okj and jugador and not issecret(jugador)
    local base = def[2]
    if def.rango then base = math.max(1, ultimosCombos) + (def.rango - 1) end
    if def[1] == "incap" and base == 4 then base = base + 0.5 * db.mejoraGubia end
    local factor, n = 1, 0
    if jugador or not db.soloJugadoresRD then factor, n = FactorRD(guid, def[1]) end
    local ahora = GetTime()
    if factor == 0 then
        if db.avisoInmune then Aviso("¡Inmune a " .. NOMBRE_CAT[def[1]] .. "!", 1, 0.3, 0.3) end
        return
    end
    local fin = ahora + base * factor
    activos[guid] = { hechizo = hechizo, cat = def[1], fin = fin, dur = base * factor, nombre = okn and Str(nombre) or "?",
                      jugador = jugador }
    if jugador or not db.soloJugadoresRD then AplicarRD(guid, def[1], fin) end
end

-- Corrige con el aura si el objetivo es el mismo; si el aura ya no está, se ha roto.
local function Revisar()
    local okg, guidObj = pcall(UnitGUID, "target")
    guidObj = okg and Str(guidObj)
    local ahora = GetTime()
    for guid, a in pairs(activos) do
        if guid == guidObj then
            local fin, dur = LeerAura("target", a.hechizo)
            if fin then
                a.fin, a.dur = fin, dur or a.dur
            elseif fin == false and ahora < a.fin - 0.5 and ahora - (a.fin - a.dur) > 0.4 then
                if db.avisoRoto then
                    Aviso(("¡%s roto! %s"):format(NombreHechizo(a.hechizo), a.nombre), 1, 0.4, 0.1)
                    if db.avisoRotoSonido then Sonar(db.avisoKit) end
                end
                if rd[guid] and rd[guid][a.cat] then rd[guid][a.cat].reset = ahora + db.segundosRD end
                activos[guid] = nil
            end
        end
        if activos[guid] then
            local queda = a.fin - ahora
            if queda <= 0 then
                activos[guid] = nil
            elseif db.avisoPoco and not a.avisado and queda <= db.segundosPoco and a.dur > db.segundosPoco + 1 then
                a.avisado = true
                Aviso(("%s: quedan %d s (%s)"):format(NombreHechizo(a.hechizo), math.ceil(queda), a.nombre), 1, 0.82, 0)
                if db.avisoPocoSonido then Sonar(db.avisoKit) end
            end
        end
    end
end

----------------------------------------------------------------------
-- Barras
----------------------------------------------------------------------
local function Crear()
    if marco then return end
    marco = mod:Frame("Frame", "CMRogueControl", UIParent)
    marco:SetSize(db.ancho, 20)
    marco:SetClampedToScreen(true)
    marco:SetMovable(true)
    marco:RegisterForDrag("LeftButton")
    marco:SetScript("OnDragStart", function(self) if not db.bloquear then self:StartMoving() end end)
    marco:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local l, t = self:GetLeft(), self:GetTop()
        if l and t then db.pos.control = { l, t } end
    end)
    marco.barras = {}
    for i = 1, 8 do
        local b = CreateFrame("StatusBar", nil, marco)
        b:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
        b.fondo = b:CreateTexture(nil, "BACKGROUND"); b.fondo:SetAllPoints(); b.fondo:SetColorTexture(0, 0, 0, 0.55)
        b.icono = b:CreateTexture(nil, "ARTWORK")
        b.texto = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); b.texto:SetPoint("LEFT", 4, 0); b.texto:SetJustifyH("LEFT")
        b.tiempo = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); b.tiempo:SetPoint("RIGHT", -4, 0)
        marco.barras[i] = b
    end
    marco.rd = marco:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    marco.rd:SetJustifyH("LEFT")
    marco.titulo = marco:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    marco.titulo:SetPoint("BOTTOMLEFT", marco, "TOPLEFT", 0, 2)
    marco.titulo:SetText("Control (arrastra para mover)")
end

local mover = false
local function Pintar()
    if not (mod and mod:IsEnabled() and db.barras) then if marco then marco:Hide() end return end
    Crear()
    marco:SetScale(db.escala); marco:SetAlpha(db.opacidad)
    marco:EnableMouse(mover or not db.bloquear)
    marco.titulo:SetShown(mover)
    local lista = {}
    for guid, a in pairs(activos) do lista[#lista + 1] = { guid, a } end
    table.sort(lista, function(x, y) return x[2].fin < y[2].fin end)
    local ahora, y = GetTime(), 0
    local n = 0
    for i, b in ipairs(marco.barras) do
        local x = (i <= db.maxBarras) and lista[i]
        if x then
            local a = x[2]
            n = n + 1
            local queda = math.max(0, a.fin - ahora)
            b:SetSize(db.ancho - db.alto - 2, db.alto)
            b:ClearAllPoints(); b:SetPoint("TOPLEFT", marco, "TOPLEFT", db.alto + 2, y)
            b.icono:SetSize(db.alto, db.alto); b.icono:ClearAllPoints(); b.icono:SetPoint("RIGHT", b, "LEFT", -2, 0)
            b.icono:SetTexture(IconoHechizo(a.hechizo))
            b:SetMinMaxValues(0, math.max(0.1, a.dur)); b:SetValue(queda)
            local c = queda <= db.segundosPoco and db.colorPoco or db.colorBarra
            b:SetStatusBarColor(c[1], c[2], c[3])
            b.texto:SetText(db.verNombre and a.nombre or NombreHechizo(a.hechizo))
            b.tiempo:SetText(("%.1f"):format(queda))
            b:Show()
            y = y - db.alto - 3
        else
            b:Hide()
        end
    end
    -- Rendimientos decrecientes del objetivo actual.
    local txt
    if db.verRD then
        local okg, guid = pcall(UnitGUID, "target")
        guid = okg and Str(guid)
        local partes = {}
        if guid and rd[guid] then
            for _, c in ipairs(CATS) do
                local x = rd[guid][c[1]]
                if x and ahora < x.reset and db.cats[c[1]] then
                    local f = FACTOR[math.min(x.n + 1, 4)]
                    local etiqueta = f == 0 and "|cffff4040inmune|r" or (f == 0.5 and "|cffffcc33½|r" or "|cffff8833¼|r")
                    partes[#partes + 1] = ("%s %s %ds"):format(c[2], etiqueta, math.ceil(x.reset - ahora))
                end
            end
        end
        if #partes > 0 then txt = "RD: " .. table.concat(partes, " · ") end
    end
    if txt or mover then
        marco.rd:ClearAllPoints(); marco.rd:SetPoint("TOPLEFT", marco, "TOPLEFT", 0, y - 2)
        marco.rd:SetWidth(db.ancho)
        marco.rd:SetText(txt or "RD del objetivo")
        marco.rd:Show()
        y = y - 16
    else
        marco.rd:Hide()
    end
    if n == 0 and not txt and not mover then marco:Hide(); return end
    marco:SetSize(db.ancho, math.max(20, -y))
    if not marco.colocado then
        marco:ClearAllPoints()
        local p = db.pos.control
        if p then marco:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", p[1], p[2]) else marco:SetPoint("CENTER", UIParent, "CENTER", 0, -120) end
        marco.colocado = true
    end
    marco:Show()
end

----------------------------------------------------------------------
-- Registro
----------------------------------------------------------------------
local acum = 0
mod = Hub:Register{
    key = "control", dir = "Control", name = "Control", clase = "ROGUE",
    desc = "Cuánto les queda a tus controles (Aporrear, Gubia, Ceguera, Golpe bajo, Golpe en los riñones), aviso cuando "
        .. "van a acabar o se rompen, y los rendimientos decrecientes de cada objetivo (entero, mitad, cuarto, inmune).",
    defaults = DEFAULTS,
    slash = { "cmcontrol" },
    Init = function(m)
        db = m.db
        m:Event("UNIT_SPELLCAST_SUCCEEDED", function(_, _, unidad, _, hechizo) AlLanzar(unidad, hechizo) end)
        m:Event("UNIT_POWER_UPDATE", function(_, _, unidad)
            if unidad ~= "player" then return end
            local ok, c = pcall(GetComboPoints, "player", "target")
            c = ok and Num(c)
            if c and c > 0 then ultimosCombos = c end
        end)
        m:Event("PLAYER_TARGET_CHANGED", function() ultimosCombos = 0; Pintar() end)
        m:OnUpdate(function(_, e)
            acum = acum + e
            if acum >= 0.1 then acum = 0; Revisar(); Pintar() end
        end)
    end,
    Enable = function(m) db = m.db; Pintar() end,
    Disable = function() if marco then marco:Hide() end; wipe(activos) end,
    OnReset = function() if marco then marco.colocado = false end end,
    OnSlash = function(m, msg)
        msg = (msg or ""):lower()
        if msg == "mover" then mover = not mover; m:Print(mover and "arrastra el marco y vuelve a escribir /cmcontrol mover." or "posición guardada.")
        elseif msg == "borrar" then wipe(activos); wipe(rd); m:Print("controles y rendimientos decrecientes borrados.")
        else Hub:Open("control") end
        Pintar()
    end,
    BuildConfig = function(m, L)
        db = m.db
        local function G(k) return function() return db[k] end end
        local function S(k) return function(v) db[k] = v; Pintar() end end
        local function Col(k) return function() local c = db[k]; return c[1], c[2], c[3] end end
        local function SetCol(k) return function(r, g, b) db[k] = { r, g, b }; Pintar() end end
        L:Text("Solo ve tus propios controles: Forever no da el registro de combate. Si el juego oculta las auras en "
            .. "combate, la duración se calcula con la del hechizo y los rendimientos decrecientes.", true)
        L:Button("Mover el marco", 140, function() mover = not mover; Pintar() end)
        L:Button("Volver a su sitio", 140, function() db.pos.control = nil; if marco then marco.colocado = false end; Pintar() end, true)
        L:Button("Borrar RD", 100, function() wipe(rd); Pintar() end, true)

        L:Header("Qué controles")
        for _, c in ipairs(CATS) do
            L:Check(c[2], function() return db.cats[c[1]] end, function(v) db.cats[c[1]] = v; Pintar() end)
        end
        L:Slider("Talento Gubia mejorada (puntos)", 0, 3, 1, G("mejoraGubia"), S("mejoraGubia"))
        L:Check("Leer la duración real del aura cuando se pueda", G("usarAura"), S("usarAura"))

        L:Header("Barras")
        L:Check("Mostrar las barras", G("barras"), S("barras"))
        L:Check("  Nombre del objetivo (si no, el del hechizo)", G("verNombre"), S("verNombre"))
        L:Slider("  Barras como máximo", 1, 8, 1, G("maxBarras"), S("maxBarras"))
        L:Slider("  Ancho", 120, 400, 5, G("ancho"), S("ancho"))
        L:Slider("  Alto", 12, 36, 1, G("alto"), S("alto"))
        L:Slider("  Escala", 0.5, 2, 0.05, G("escala"), S("escala"), "%.2f")
        L:Slider("  Opacidad", 0.2, 1, 0.05, G("opacidad"), S("opacidad"), "%.2f")
        L:Check("  Bloquear la posición", G("bloquear"), S("bloquear"))
        L:Color("  Color de la barra", Col("colorBarra"), SetCol("colorBarra"))
        L:Color("  Color cuando queda poco", Col("colorPoco"), SetCol("colorPoco"))

        L:Header("Rendimientos decrecientes")
        L:Check("Mostrar los del objetivo actual", G("verRD"), S("verRD"))
        L:Check("  Solo contra jugadores (a los PNJ casi nunca les afecta)", G("soloJugadoresRD"), S("soloJugadoresRD"))
        L:Slider("  Se reinician a los (segundos tras acabar)", 10, 25, 1, G("segundosRD"), S("segundosRD"))
        L:Check("Aviso si el objetivo ya es inmune", G("avisoInmune"), S("avisoInmune"))

        L:Header("Avisos")
        L:Check("Cuando a un control le queda poco", G("avisoPoco"), S("avisoPoco"))
        L:Slider("  Segundos", 1, 10, 1, G("segundosPoco"), S("segundosPoco"))
        L:Check("  Con sonido", G("avisoPocoSonido"), S("avisoPocoSonido"))
        L:Check("Cuando se rompe antes de tiempo (con el objetivo seleccionado)", G("avisoRoto"), S("avisoRoto"))
        L:Check("  Con sonido", G("avisoRotoSonido"), S("avisoRotoSonido"))
        L:Choice("Sonido", KITS, G("avisoKit"), function(v) db.avisoKit = v; Sonar(v) end)
    end,
}
