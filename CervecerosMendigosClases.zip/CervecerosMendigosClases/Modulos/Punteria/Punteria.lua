-- Puntería (CervecerosMendigos Clases, cazador): solo se enciende si tu rol de cazador es puntería.
--   * Fuego rápido y Disparo apuntado en grande, con aviso cuando Fuego rápido vuelve a estar listo.
--   * Aviso si vas sin Aura de disparo certero.
local ADDON, ns = ...
local Hub = ns.Hub
local U = ns.CU
local H = ns.Cazador

local FUEGO = 3045
local APUNTADO = { 19434, 20900, 20901, 20902, 20903, 20904 }
local AURA = { 19506, 20905, 20906 }

local DEFAULTS = {
    escala = 1, opacidad = 1, bloquear = false, tamIcono = 36,
    fuego = true, apuntado = true, avisoListo = true, aura = true, avisoAura = true,
    avisoTexto = true, avisoChat = false, avisoSonido = true, avisoKit = "RAID_WARNING",
    pos = {},
}

local mod, db, marco
local mover = false
local fuegoListo, auraAvisada = nil, false

local function Activo() return mod and mod:IsEnabled() and H.EsCazador() and H.Rol() == "punteria" end

local function Pintar()
    if not Activo() then if marco then marco:Hide() end return end
    marco = marco or U.Panel(mod, "CMPunteria", "punteria", function() return mover end)
    local lineas, iconos = {}, {}
    if db.fuego and U.Conoce(FUEGO) then
        local q = U.Enfriamiento(FUEGO)
        if q then
            if q == 0 and fuegoListo == false and db.avisoListo then U.Avisar(mod, U.Nombre(FUEGO, "Fuego rápido") .. " listo", true, 0.4, 1, 0.4) end
            fuegoListo = q == 0
        end
        iconos[#iconos + 1] = { icono = U.Icono(FUEGO), queda = q or 0 }
    end
    if db.apuntado then
        local id = U.Mejor(APUNTADO)
        if id then iconos[#iconos + 1] = { icono = U.Icono(id), queda = U.Enfriamiento(id) or 0 } end
    end
    if db.aura and U.ConoceAlguno(AURA) then
        local nombre = U.Nombre(AURA[1], "Aura de disparo certero")
        local fin = U.Aura("player", nombre, "HELPFUL")
        if fin == false then
            lineas[#lineas + 1] = "|cffff5555Sin " .. nombre .. "|r"
            if db.avisoAura and not auraAvisada then auraAvisada = true; U.Avisar(mod, "Vas sin " .. nombre, true) end
        elseif fin then
            auraAvisada = false
        end
    end
    U.PintarPanel(mod, marco, lineas, iconos, mover, 0, -260)
end

local acum = 0
mod = Hub:Register{
    key = "punteria", dir = "Punteria", name = "Puntería", clase = "HUNTER",
    desc = "Cazador de puntería (solo con ese rol): Fuego rápido y Disparo apuntado en grande con aviso cuando Fuego "
        .. "rápido está listo, y aviso si vas sin Aura de disparo certero.",
    defaults = DEFAULTS,
    slash = { "cmpunteria" },
    Init = function(m)
        db = m.db
        m:OnUpdate(function(_, e) acum = acum + e; if acum >= 0.15 then acum = 0; Pintar() end end)
    end,
    Enable = function(m) db = m.db; Pintar() end,
    Disable = function() if marco then marco:Hide() end end,
    OnReset = function() if marco then marco.colocado = false end end,
    OnSlash = function(m, msg) if (msg or ""):lower() == "mover" then mover = not mover; Pintar() else Hub:Open("punteria") end end,
    BuildConfig = function(m, L)
        db = m.db
        local function G(k) return function() return db[k] end end
        local function S(k) return function(v) db[k] = v; Pintar() end end
        L:Text("Solo funciona si tu rol de cazador (pestaña Cazador) es puntería. Ahora: |cffffd100" .. H.Rol() .. "|r. "
            .. "La barra del disparo automático está en la pestaña Cazador.", true)
        L:Button("Mover", 90, function() mover = not mover; Pintar() end)
        L:Button("Volver a su sitio", 140, function() db.pos.punteria = nil; if marco then marco.colocado = false end; Pintar() end, true)
        L:Check("Bloquear la posición", G("bloquear"), S("bloquear"))
        L:Slider("Escala", 0.5, 2, 0.05, G("escala"), S("escala"), "%.2f")
        L:Slider("Opacidad", 0.2, 1, 0.05, G("opacidad"), S("opacidad"), "%.2f")
        L:Slider("Tamaño de los iconos", 20, 70, 1, G("tamIcono"), S("tamIcono"))
        L:Header("Qué enseña")
        L:Check(U.Nombre(FUEGO, "Fuego rápido"), G("fuego"), S("fuego"))
        L:Check("  Aviso cuando vuelve a estar listo", G("avisoListo"), S("avisoListo"))
        L:Check(U.Nombre(APUNTADO[1], "Disparo apuntado"), G("apuntado"), S("apuntado"))
        L:Check(U.Nombre(AURA[1], "Aura de disparo certero") .. ": mostrar si no la llevas", G("aura"), S("aura"))
        L:Check("  Aviso", G("avisoAura"), S("avisoAura"))
        L:Header("Cómo avisa")
        L:Check("Texto grande", G("avisoTexto"), S("avisoTexto"))
        L:Check("Línea en el chat", G("avisoChat"), S("avisoChat"))
        L:Check("Sonido", G("avisoSonido"), S("avisoSonido"))
        L:Choice("  Sonido", U.KITS, G("avisoKit"), function(v) db.avisoKit = v; U.Sonar(v) end)
    end,
}
