-- Bestias (CervecerosMendigos Clases, cazador): solo se enciende si tu rol de cazador es bestias.
--   * Cólera de las bestias e Intimidación en grande, con aviso cuando vuelven a estar listas.
--   * Frenesí de la mascota: si lo tiene ahora y cuánto lo mantiene en cada pelea.
local ADDON, ns = ...
local Hub = ns.Hub
local U = ns.CU
local H = ns.Cazador

local COLERA, INTIMIDACION = 19574, 19577
local FRENESI = 19615

local DEFAULTS = {
    escala = 1, opacidad = 1, bloquear = false, tamIcono = 36,
    colera = true, intimidacion = true, avisoListo = true, frenesi = true, uptime = true,
    avisoTexto = true, avisoChat = false, avisoSonido = true, avisoKit = "RAID_WARNING",
    pos = {},
}

local mod, db, marco
local mover = false
local listos = {}
local enPelea, tPelea, tActivo, ultimo = false, 0, 0, nil

local function Activo() return mod and mod:IsEnabled() and H.EsCazador() and H.Rol() == "bestias" end

local function Pintar()
    if not Activo() then if marco then marco:Hide() end return end
    marco = marco or U.Panel(mod, "CMBestias", "bestias", function() return mover end)
    local lineas, iconos = {}, {}
    for _, x in ipairs({ { db.colera, COLERA, "colera" }, { db.intimidacion, INTIMIDACION, "intimidacion" } }) do
        if x[1] and U.Conoce(x[2]) then
            local q = U.Enfriamiento(x[2])
            if q then
                if q == 0 and listos[x[3]] == false and db.avisoListo then U.Avisar(mod, U.Nombre(x[2]) .. " lista", true, 0.4, 1, 0.4) end
                listos[x[3]] = q == 0
            end
            iconos[#iconos + 1] = { icono = U.Icono(x[2]), queda = q or 0 }
        end
    end
    if db.frenesi and U.Conoce(FRENESI) then
        local nombre = U.Nombre(FRENESI, "Frenesí")
        local fin = U.Aura("pet", nombre, "HELPFUL")
        if fin then lineas[#lineas + 1] = "|cffffd100Mascota con " .. nombre .. "|r" end
        local ahora = GetTime()
        if U.EnCombate() then
            if not enPelea then enPelea, tPelea, tActivo = true, 0, 0 end
            if ultimo then local dt = ahora - ultimo; tPelea = tPelea + dt; if fin then tActivo = tActivo + dt end end
            ultimo = ahora
        else
            enPelea, ultimo = false, nil
        end
        if db.uptime and tPelea > 0 then
            lineas[#lineas + 1] = ("%s activo: %d%%%s"):format(nombre, tActivo / tPelea * 100, enPelea and "" or " (última pelea)")
        end
    end
    U.PintarPanel(mod, marco, lineas, iconos, mover, 0, -260)
end

local acum = 0
mod = Hub:Register{
    key = "bestias", dir = "Bestias", name = "Bestias", clase = "HUNTER",
    desc = "Cazador de bestias (solo con ese rol): Cólera de las bestias e Intimidación en grande con aviso cuando "
        .. "están listas, y el Frenesí de tu mascota (si lo tiene y cuánto lo mantiene).",
    defaults = DEFAULTS,
    slash = { "cmbestias" },
    Init = function(m)
        db = m.db
        m:OnUpdate(function(_, e) acum = acum + e; if acum >= 0.15 then acum = 0; Pintar() end end)
    end,
    Enable = function(m) db = m.db; Pintar() end,
    Disable = function() if marco then marco:Hide() end end,
    OnReset = function() if marco then marco.colocado = false end end,
    OnSlash = function(m, msg) if (msg or ""):lower() == "mover" then mover = not mover; Pintar() else Hub:Open("bestias") end end,
    BuildConfig = function(m, L)
        db = m.db
        local function G(k) return function() return db[k] end end
        local function S(k) return function(v) db[k] = v; Pintar() end end
        L:Text("Solo funciona si tu rol de cazador (pestaña Cazador) es bestias. Ahora: |cffffd100" .. H.Rol() .. "|r.", true)
        L:Button("Mover", 90, function() mover = not mover; Pintar() end)
        L:Button("Volver a su sitio", 140, function() db.pos.bestias = nil; if marco then marco.colocado = false end; Pintar() end, true)
        L:Check("Bloquear la posición", G("bloquear"), S("bloquear"))
        L:Slider("Escala", 0.5, 2, 0.05, G("escala"), S("escala"), "%.2f")
        L:Slider("Opacidad", 0.2, 1, 0.05, G("opacidad"), S("opacidad"), "%.2f")
        L:Slider("Tamaño de los iconos", 20, 70, 1, G("tamIcono"), S("tamIcono"))
        L:Header("Qué enseña")
        L:Check(U.Nombre(COLERA, "Cólera de las bestias"), G("colera"), S("colera"))
        L:Check(U.Nombre(INTIMIDACION, "Intimidación"), G("intimidacion"), S("intimidacion"))
        L:Check("  Aviso cuando vuelven a estar listas", G("avisoListo"), S("avisoListo"))
        L:Check(U.Nombre(FRENESI, "Frenesí") .. " de la mascota", G("frenesi"), S("frenesi"))
        L:Check("  Cuánto lo mantiene en cada pelea (%)", G("uptime"), S("uptime"))
        L:Header("Cómo avisa")
        L:Check("Texto grande", G("avisoTexto"), S("avisoTexto"))
        L:Check("Línea en el chat", G("avisoChat"), S("avisoChat"))
        L:Check("Sonido", G("avisoSonido"), S("avisoSonido"))
        L:Choice("  Sonido", U.KITS, G("avisoKit"), function(v) db.avisoKit = v; U.Sonar(v) end)
    end,
}
