-- Cazador (CervecerosMendigos Clases): lo de cualquier cazador.
--   * Rol: automático (por talentos), bestias, puntería o supervivencia. Lo usan Bestias, Puntería y Supervivencia.
--   * Mascota: felicidad y lealtad con avisos, botón Alimentar (comida que le gusta, de tus bolsas), aviso si muere
--     o si peleas sin ella, y Aliviar mascota.
--   * Munición: lo que te queda, aviso y reponer en el vendedor.
--   * Disparo automático: barra con el tiempo hasta el siguiente disparo.
--   * Aspectos: barra para cambiarlos y avisos (Guepardo/Manada en combate, sin aspecto).
--   * Marca del cazador y picaduras en el objetivo; aviso de Disparo tranquilizante.
--   * Trampas y Fingir muerte (enfriamientos, aviso si falla); Trampa congelante en el objetivo; rastreo.
local ADDON, ns = ...
local Hub = ns.Hub
local U = ns.CU
local Num, Str = U.Num, U.Str
local H = {}
ns.Cazador = H
local COMIDA = ns.CazadorComida or {}

local TIPO_COMIDA = { carne = 1, pescado = 2, queso = 3, pan = 4, hongo = 5, hongos = 5, fruta = 6, ["carne cruda"] = 7,
    ["pescado crudo"] = 8, meat = 1, fish = 2, cheese = 3, bread = 4, fungus = 5, fruit = 6, ["raw meat"] = 7, ["raw fish"] = 8 }
local ALIMENTAR, ALIVIAR = 6991, { 136, 3111, 3661, 3662, 13542, 13543, 13544 }
local LLAMAR, REVIVIR = 883, 982
local DISPARO_AUTO, APUNTADO = 75, { 19434, 20900, 20901, 20902, 20903, 20904 }
H.ASPECTOS = {
    { "halcon", { 13165, 14318, 14319, 14320, 14321, 14322, 25296 } }, { "mono", { 13163 } },
    { "guepardo", { 5118 } }, { "manada", { 13159 } }, { "bestia", { 13161 } }, { "salvaje", { 20043, 20190 } },
}
local MARCA = { 1130, 14323, 14324, 14325 }
local PICADURAS = { { 1978, 13549, 13550, 13551, 13552, 13553, 13554, 13555, 25295 }, { 3034, 14279, 14280 }, { 3043, 14275, 14276, 14277 } }
local TRANQUILIZANTE = 19801
local TRAMPAS = { { 1499, 14310, 14311 }, { 13795, 14302, 14303, 14304, 14305 }, { 13809 }, { 13813, 14316, 14317 } }
local FINGIR = 5384

local DEFAULTS = {
    rol = "auto",
    escala = 1, opacidad = 1, bloquear = false, fondo = true,
    -- Mascota
    mascota = true, avisoTriste = true, avisoNormal = false, avisoLealtad = true, avisoMuerta = true, avisoSinMascota = true,
    botonAlimentar = true, noUsar = "", verAliviar = true,
    -- Munición
    municion = true, minMunicion = 200, avisoMunicion = true, reponer = true, objetivoMunicion = 1000, reponerSolo = false, reservaOro = 0,
    -- Disparo automático
    disparo = true, anchoDisparo = 200, altoDisparo = 12, zonaRoja = 0.5, colorDisparo = { 0.9, 0.8, 0.3 }, colorZona = { 1, 0.2, 0.2 },
    -- Aspectos
    aspectos = true, tamAspecto = 26, avisoGuepardo = true, avisoSinAspecto = false,
    -- Objetivo
    picaduras = true, segundosPicadura = 3, avisoPicadura = false, tranquilizante = true,
    patronesFuria = "Frenesí;Enfurecer;Furia;Frenzy;Enrage",
    -- Trampas, Fingir muerte, rastreo
    trampas = true, fingir = true, avisoFingir = true, congelante = true, avisoRastreo = false, tamIcono = 28,
    -- Avisos
    avisoTexto = true, avisoChat = false, avisoSonido = true, avisoKit = "RAID_WARNING",
    pos = {},
}

local mod, db, marco, barra
local mover, pendiente = false, false
local avisos = { feliz = 3, lealtad = false, muerta = false, sinMascota = false, municion = false, guepardo = false, aspecto = false, rastreo = false }
local auto, ultimoDisparo, velocidad = false, nil, 2.8
local avisadoPic, avisadoFuria = {}, {}
local fingirLanzado

----------------------------------------------------------------------
-- Rol
----------------------------------------------------------------------
local PISTAS = {
    { "bestias", { 19574 } }, { "punteria", { 19506, 20905, 20906 } }, { "supervivencia", { 19386, 24132, 24133 } },
    { "bestias", { 19577 } }, { "punteria", APUNTADO }, { "supervivencia", { 19306, 20909, 20910, 19263 } },
}
function H.Rol()
    local d = db or (Hub.byKey.cazador and Hub.byKey.cazador.db)
    local rol = d and d.rol or "auto"
    if rol ~= "auto" then return rol end
    for _, p in ipairs(PISTAS) do if U.ConoceAlguno(p[2]) then return p[1] end end
    return "ninguno"
end
function H.EsCazador()
    local ok, _, c = pcall(UnitClass, "player")
    return ok and c == "HUNTER"
end

----------------------------------------------------------------------
-- Mascota
----------------------------------------------------------------------
local function HayMascota()
    local ok, e = pcall(UnitExists, "pet")
    return ok and e and not U.issecret(e) or false
end
local function MascotaMuerta()
    local ok, m = pcall(UnitIsDead, "pet")
    return ok and m and not U.issecret(m) or false
end
-- Tipos de comida que come la mascota: { [tipo] = true }.
local function Dieta()
    local t = {}
    if not GetPetFoodTypes then return t end
    local r = { pcall(GetPetFoodTypes) }
    if not r[1] then return t end
    for i = 2, #r do
        local n = Str(r[i])
        if n then
            n = n:lower()
            local id = TIPO_COMIDA[n] or TIPO_COMIDA[n:gsub("s$", "")]
            if id then t[id] = true end
        end
    end
    return t
end
-- Primera comida de las bolsas que le gusta (y no está en «no usar»): bolsa, hueco, id.
function H.Comida()
    local dieta = Dieta()
    if not next(dieta) or not (C_Container and C_Container.GetContainerNumSlots) then return nil end
    local veto = {}
    for x in (db.noUsar or ""):gmatch("[^;,\n]+") do veto[(x:gsub("^%s+", ""):gsub("%s+$", "")):lower()] = true end
    for bolsa = 0, (NUM_BAG_SLOTS or 4) do
        local ok, n = pcall(C_Container.GetContainerNumSlots, bolsa)
        for hueco = 1, ok and Num(n) or 0 do
            local ok2, info = pcall(C_Container.GetContainerItemInfo, bolsa, hueco)
            local id = ok2 and info and Num(info.itemID)
            if id and COMIDA[id] and dieta[COMIDA[id]] then
                local nombre = U.NombreObjeto(id):lower()
                if not veto[nombre] and not veto[tostring(id)] then return bolsa, hueco, id end
            end
        end
    end
end
local FELICIDAD = { "|cffff5555Triste|r", "|cffffd100Normal|r", "|cff66ff66Contenta|r" }

----------------------------------------------------------------------
-- Munición y vendedor
----------------------------------------------------------------------
function H.Municion()
    local ok, id = pcall(GetInventoryItemID, "player", 0)
    local okc, n = pcall(GetInventoryItemCount, "player", 0)
    return ok and Num(id), okc and Num(n) or 0
end
local botonVendedor
local function ReponerMunicion(silencio)
    local id, tengo = H.Municion()
    if not (id and GetMerchantNumItems and BuyMerchantItem) then return end
    local ok, n = pcall(GetMerchantNumItems)
    local falta = db.objetivoMunicion - tengo
    if falta <= 0 then if not silencio then mod:Print("ya llevas suficiente munición.") end return end
    for i = 1, ok and Num(n) or 0 do
        local oki, vid = pcall(GetMerchantItemID, i)
        if oki and Num(vid) == id then
            local precio, monton = 0, 1
            if GetMerchantItemInfo then local r = { pcall(GetMerchantItemInfo, i) }; if r[1] then precio, monton = Num(r[4]) or 0, Num(r[5]) or 1 end end
            local maxPila = 200
            if GetMerchantItemMaxStack then local okm, m = pcall(GetMerchantItemMaxStack, i); maxPila = okm and Num(m) or 200 end
            local dinero = Num(GetMoney and GetMoney()) or 0
            local unidad = precio / math.max(1, monton)
            local comprado = 0
            while falta > 0 do
                local q = math.min(falta, math.max(1, maxPila))
                if unidad * q > dinero - db.reservaOro * 10000 then break end
                pcall(BuyMerchantItem, i, q)
                dinero, falta, comprado = dinero - unidad * q, falta - q, comprado + q
            end
            if not silencio then mod:Print(comprado > 0 and ("compradas %d de %s."):format(comprado, U.NombreObjeto(id)) or "no te llega el dinero.") end
            return
        end
    end
    if not silencio then mod:Print("este vendedor no tiene tu munición.") end
end
local function AlAbrirVendedor()
    if not (mod and mod:IsEnabled() and H.EsCazador() and db.municion and db.reponer) then return end
    local id = H.Municion()
    local vende = false
    local ok, n = pcall(GetMerchantNumItems)
    for i = 1, ok and Num(n) or 0 do local oki, vid = pcall(GetMerchantItemID, i); if oki and id and Num(vid) == id then vende = true end end
    if not vende then if botonVendedor then botonVendedor:Hide() end return end
    if db.reponerSolo then ReponerMunicion(false) end
    if MerchantFrame then
        if not botonVendedor then
            botonVendedor = CreateFrame("Button", "CMCazadorReponer", MerchantFrame, "UIPanelButtonTemplate")
            botonVendedor:SetSize(130, 22)
            botonVendedor:SetPoint("TOPRIGHT", MerchantFrame, "TOPRIGHT", -40, -30)
            botonVendedor:SetText("Reponer munición")
            botonVendedor:SetScript("OnClick", function() if mod:IsEnabled() then ReponerMunicion(false) end end)
            mod:Track(botonVendedor)
        end
        botonVendedor:Show()
    end
end

----------------------------------------------------------------------
-- Disparo automático
----------------------------------------------------------------------
local function LeerVelocidad()
    local ok, v = pcall(UnitRangedDamage, "player")
    v = ok and Num(v)
    if v and v > 0.5 then velocidad = v end
end
local function CrearBarra()
    if barra then return end
    barra = mod:Frame("StatusBar", "CMCazadorDisparo", UIParent)
    barra:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    barra:SetMinMaxValues(0, 1)
    barra.fondo = barra:CreateTexture(nil, "BACKGROUND"); barra.fondo:SetAllPoints(); barra.fondo:SetColorTexture(0, 0, 0, 0.6)
    barra.zona = barra:CreateTexture(nil, "ARTWORK", nil, 1)
    barra.texto = barra:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); barra.texto:SetPoint("CENTER")
    U.Movil(mod, barra, "disparo", function() return db.bloquear and not mover end)
end
local function PintarBarra()
    if not (db.disparo and (auto or mover)) then if barra then barra:Hide() end return end
    CrearBarra()
    barra:SetSize(db.anchoDisparo, db.altoDisparo)
    barra:SetScale(db.escala)
    local c, z = db.colorDisparo, db.colorZona
    barra:SetStatusBarColor(c[1], c[2], c[3])
    local zona = math.min(1, db.zonaRoja / velocidad)
    barra.zona:ClearAllPoints(); barra.zona:SetPoint("TOPRIGHT"); barra.zona:SetPoint("BOTTOMRIGHT")
    barra.zona:SetWidth(math.max(1, db.anchoDisparo * zona)); barra.zona:SetColorTexture(z[1], z[2], z[3], 0.45)
    local prog, queda = 1, 0
    if ultimoDisparo then
        local t = GetTime() - ultimoDisparo
        prog = math.min(1, t / velocidad)
        queda = math.max(0, velocidad - t)
    end
    barra:SetValue(prog)
    barra.texto:SetText(("%.1f"):format(queda))
    barra:EnableMouse(mover or not db.bloquear)
    if not barra.colocado then U.Colocar(mod, barra, "disparo", 0, -180); barra.colocado = true end
    barra:Show()
end

----------------------------------------------------------------------
-- Botones seguros: aspectos y alimentar
----------------------------------------------------------------------
local function AspectoActivo()
    local dudoso = false
    for _, a in ipairs(H.ASPECTOS) do
        local fin = U.Aura("player", U.Nombre(a[2][1]), "HELPFUL")
        if fin then return a[1] end
        if fin == nil then dudoso = true end
    end
    if dudoso then return nil end
    return false
end
local function PrepararBotones()
    if not marco then return end
    if U.EnCombate() then pendiente = true; return end
    pendiente = false
    marco.aspectos = marco.aspectos or {}
    local n = 0
    for _, a in ipairs(H.ASPECTOS) do
        local id = U.Mejor(a[2])
        if id then
            n = n + 1
            local b = marco.aspectos[n]
            if not b then
                b = CreateFrame("Button", "CMCazadorAspecto" .. n, marco, "SecureActionButtonTemplate")
                b:RegisterForClicks("AnyUp", "AnyDown")
                b.tex = b:CreateTexture(nil, "ARTWORK"); b.tex:SetAllPoints()
                b.activa = b:CreateTexture(nil, "OVERLAY"); b.activa:SetAllPoints()
                b.activa:SetTexture("Interface\\Buttons\\CheckButtonHilight"); b.activa:SetBlendMode("ADD")
                b:SetScript("OnEnter", function(self) GameTooltip:SetOwner(self, "ANCHOR_TOP"); GameTooltip:SetText(U.Nombre(self.id)); GameTooltip:Show() end)
                b:SetScript("OnLeave", function() GameTooltip:Hide() end)
                marco.aspectos[n] = b
            end
            b.id, b.clave = id, a[1]
            b:SetAttribute("type", "macro")
            b:SetAttribute("macrotext", "/cast " .. U.Nombre(id))
            b.tex:SetTexture(U.Icono(id))
        end
    end
    for i = n + 1, #marco.aspectos do marco.aspectos[i]:Hide() end
    marco.nAspectos = n
    -- Alimentar / llamar / revivir mascota.
    if not marco.alimentar then
        marco.alimentar = CreateFrame("Button", "CMCazadorAlimentar", marco, "SecureActionButtonTemplate, UIPanelButtonTemplate")
        marco.alimentar:RegisterForClicks("AnyUp", "AnyDown")
        marco.alimentar:SetSize(200, 20)
    end
    local b = marco.alimentar
    if not HayMascota() then
        b:SetAttribute("type", "macro"); b:SetAttribute("macrotext", "/cast " .. U.Nombre(LLAMAR, "Llamar a mascota"))
        b:SetText(U.Nombre(LLAMAR, "Llamar a mascota")); b.modo = "llamar"
    elseif MascotaMuerta() then
        b:SetAttribute("type", "macro"); b:SetAttribute("macrotext", "/cast " .. U.Nombre(REVIVIR, "Revivir mascota"))
        b:SetText(U.Nombre(REVIVIR, "Revivir mascota")); b.modo = "revivir"
    else
        local bolsa, hueco, id = H.Comida()
        if bolsa then
            b:SetAttribute("type", "macro")
            b:SetAttribute("macrotext", ("/cast %s\n/use %d %d"):format(U.Nombre(ALIMENTAR, "Alimentar a la mascota"), bolsa, hueco))
            b:SetText("Alimentar: " .. U.NombreObjeto(id)); b.modo = "alimentar"
        else
            b:SetAttribute("macrotext", ""); b:SetText("Sin comida que le guste"); b.modo = "nada"
        end
    end
end
H.PrepararBotones = function() PrepararBotones() end

----------------------------------------------------------------------
-- Marco
----------------------------------------------------------------------
local function Crear()
    if marco then return end
    marco = mod:Frame("Frame", "CMCazador", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    marco:SetSize(220, 40)
    U.Movil(mod, marco, "cazador", function() return db.bloquear and not mover end)
    if marco.SetBackdrop then
        marco:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                            edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    end
    marco.texto = marco:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    marco.texto:SetJustifyH("LEFT")
    marco.cds = CreateFrame("Frame", nil, marco)
    PrepararBotones()
end

local function Rastreo()
    if not (C_Minimap and C_Minimap.GetNumTrackingTypes and C_Minimap.GetTrackingInfo) then return nil end
    local ok, n = pcall(C_Minimap.GetNumTrackingTypes)
    for i = 1, ok and Num(n) or 0 do
        local r = { pcall(C_Minimap.GetTrackingInfo, i) }
        if r[1] then
            local activo = type(r[2]) == "table" and r[2].active or r[4]
            if activo and not U.issecret(activo) then return true end
        end
    end
    return false
end

local function Pintar()
    local combate = U.EnCombate()
    PintarBarra()
    if not (mod and mod:IsEnabled() and H.EsCazador()) then
        if marco and not combate then marco:Hide() end
        if barra then barra:Hide() end
        return
    end
    if not marco and combate then return end
    Crear()
    if pendiente and not combate then PrepararBotones() end
    marco:SetScale(db.escala); marco:SetAlpha(db.opacidad)
    if marco.SetBackdropColor then
        marco:SetBackdropColor(0, 0, 0, db.fondo and 0.7 or 0)
        marco:SetBackdropBorderColor(1, 1, 1, db.fondo and 0.5 or 0)
    end
    local y, ancho = -6, 200
    local lineas, iconos = {}, {}
    -- Aspectos.
    local activo = AspectoActivo()
    if db.aspectos and marco.nAspectos and marco.nAspectos > 0 then
        local t = db.tamAspecto
        for i = 1, marco.nAspectos do
            local b = marco.aspectos[i]
            if not combate then b:SetSize(t, t); b:ClearAllPoints(); b:SetPoint("TOPLEFT", marco, "TOPLEFT", 6 + (i - 1) * (t + 4), y); b:Show() end
            b.activa:SetShown(activo == b.clave)
        end
        ancho = math.max(ancho, 12 + marco.nAspectos * (t + 4))
        y = y - t - 6
    elseif marco.aspectos and not combate then
        for _, b in ipairs(marco.aspectos) do b:Hide() end
    end
    if combate and db.avisoGuepardo and (activo == "guepardo" or activo == "manada") then
        if not avisos.guepardo then avisos.guepardo = true; U.Avisar(mod, "¡Peleando con " .. U.Nombre(activo == "guepardo" and 5118 or 13159) .. "!", true, 1, 0.3, 0.3) end
    elseif not combate then avisos.guepardo = false end
    if db.avisoSinAspecto and activo == false then
        lineas[#lineas + 1] = "|cffff5555Sin aspecto|r"
        if combate and not avisos.aspecto then avisos.aspecto = true; U.Avisar(mod, "Vas sin aspecto", true) end
    elseif activo then avisos.aspecto = false end
    -- Mascota.
    if db.mascota then
        if HayMascota() then
            if MascotaMuerta() then
                lineas[#lineas + 1] = "|cffff5555Mascota muerta|r"
                if db.avisoMuerta and not avisos.muerta then avisos.muerta = true; U.Avisar(mod, "Tu mascota ha muerto", true) end
            else
                avisos.muerta, avisos.sinMascota = false, false
                local r = { pcall(GetPetHappiness) }
                local feliz, lealtad = r[1] and Num(r[2]), r[1] and Num(r[4])
                local okh, h = pcall(UnitHealth, "pet"); local okm, hm = pcall(UnitHealthMax, "pet")
                local vida = okh and okm and Num(h) and Num(hm) and hm > 0 and ("%d%%"):format(h / hm * 100) or ""
                lineas[#lineas + 1] = ("Mascota %s %s%s"):format(vida, feliz and FELICIDAD[feliz] or "",
                    lealtad and lealtad < 0 and " |cffff5555(pierde lealtad)|r" or "")
                if feliz and feliz < avisos.feliz then
                    if (feliz == 1 and db.avisoTriste) or (feliz == 2 and db.avisoNormal) then
                        U.Avisar(mod, "Tu mascota está " .. (feliz == 1 and "triste" or "normal") .. ": dale de comer", true)
                    end
                end
                if feliz then avisos.feliz = feliz end
                if lealtad and lealtad < 0 and db.avisoLealtad and not avisos.lealtad then
                    avisos.lealtad = true; U.Avisar(mod, "Tu mascota está perdiendo lealtad", true)
                elseif lealtad and lealtad >= 0 then avisos.lealtad = false end
                if db.verAliviar then
                    local fin = U.Aura("pet", U.Nombre(ALIVIAR[1], "Aliviar mascota"), "HELPFUL")
                    if fin and fin ~= math.huge then lineas[#lineas + 1] = ("%s %s"):format(U.Nombre(ALIVIAR[1], "Aliviar mascota"), U.Tiempo(math.max(0, fin - GetTime()))) end
                end
            end
        else
            lineas[#lineas + 1] = "|cff999999Sin mascota|r"
            if combate and db.avisoSinMascota and not avisos.sinMascota then avisos.sinMascota = true; U.Avisar(mod, "Peleando sin mascota", true) end
        end
    end
    -- Munición.
    if db.municion then
        local id, n = H.Municion()
        if id then
            lineas[#lineas + 1] = (n < db.minMunicion and "|cffff5555%d|r %s" or "%d %s"):format(n, U.NombreObjeto(id))
            if n < db.minMunicion and db.avisoMunicion and not avisos.municion then avisos.municion = true; U.Avisar(mod, ("Te quedan %d de munición"):format(n), true)
            elseif n >= db.minMunicion then avisos.municion = false end
        else
            lineas[#lineas + 1] = "|cffff5555Sin munición equipada|r"
        end
    end
    -- Objetivo: marca, picaduras, furia, trampa congelante.
    if U.HayEnemigo() then
        local okg, guid = pcall(UnitGUID, "target"); guid = okg and Str(guid) or "?"
        if db.picaduras then
            for _, ids in ipairs({ MARCA, PICADURAS[1], PICADURAS[2], PICADURAS[3] }) do
                if U.ConoceAlguno(ids) then
                    local nombre = U.Nombre(ids[1])
                    local fin = U.Aura("target", nombre, "HARMFUL|PLAYER")
                    if fin and fin ~= math.huge then
                        local q = math.max(0, fin - GetTime())
                        lineas[#lineas + 1] = (q <= db.segundosPicadura and "|cffff5555%s %s|r" or "%s %s"):format(nombre, U.Tiempo(q))
                        local k = guid .. ids[1]
                        if q <= db.segundosPicadura and db.avisoPicadura and combate and not avisadoPic[k] then
                            avisadoPic[k] = true; U.Avisar(mod, nombre .. ": quedan " .. math.ceil(q) .. " s", true)
                        elseif q > db.segundosPicadura then avisadoPic[k] = nil end
                    end
                end
            end
        end
        if db.congelante then
            local fin = U.Aura("target", U.Nombre(TRAMPAS[1][1], "Trampa congelante"), "HARMFUL")
            if fin and fin ~= math.huge then lineas[#lineas + 1] = ("|cff66ccff%s %s|r"):format(U.Nombre(TRAMPAS[1][1], "Trampa congelante"), U.Tiempo(math.max(0, fin - GetTime()))) end
        end
        if db.tranquilizante and U.Conoce(TRANQUILIZANTE) and C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
            local patrones = {}
            for p in db.patronesFuria:gmatch("[^;]+") do patrones[#patrones + 1] = p:lower() end
            for i = 1, 40 do
                local ok, a = pcall(C_UnitAuras.GetAuraDataByIndex, "target", i, "HELPFUL")
                if not ok or type(a) ~= "table" then break end
                local n, tipo = Str(a.name), Str(a.dispelName)
                local furia = tipo == ""
                if n and not furia then for _, p in ipairs(patrones) do if n:lower():find(p, 1, true) then furia = true end end end
                if furia and n then
                    lineas[#lineas + 1] = "|cffff5555¡" .. U.Nombre(TRANQUILIZANTE, "Disparo tranquilizante") .. "! (" .. n .. ")|r"
                    local k = guid .. n
                    if not avisadoFuria[k] then avisadoFuria[k] = true; U.Avisar(mod, "¡" .. U.Nombre(TRANQUILIZANTE, "Disparo tranquilizante") .. "! " .. n, true, 1, 0.3, 0.3) end
                    break
                end
            end
        end
    end
    -- Trampas y Fingir muerte.
    if db.trampas then
        local id = U.Mejor(TRAMPAS[1]) or U.Mejor(TRAMPAS[2]) or U.Mejor(TRAMPAS[3]) or U.Mejor(TRAMPAS[4])
        if id then iconos[#iconos + 1] = { icono = U.Icono(id), queda = U.Enfriamiento(id) or 0 } end
    end
    if db.fingir and U.Conoce(FINGIR) then iconos[#iconos + 1] = { icono = U.Icono(FINGIR), queda = U.Enfriamiento(FINGIR) or 0 } end
    if fingirLanzado and GetTime() - fingirLanzado > 0.4 then
        local fin = U.Aura("player", U.Nombre(FINGIR, "Fingir muerte"), "HELPFUL")
        if fin == false and db.avisoFingir then U.Avisar(mod, "¡" .. U.Nombre(FINGIR, "Fingir muerte") .. " ha fallado!", true, 1, 0.2, 0.2) end
        fingirLanzado = nil
    end
    -- Rastreo.
    if db.avisoRastreo and not combate then
        local r = Rastreo()
        if r == false then
            lineas[#lineas + 1] = "|cff999999Sin rastreo|r"
            if not avisos.rastreo then avisos.rastreo = true; U.Avisar(mod, "Vas sin rastreo", false) end
        elseif r then avisos.rastreo = false end
    end
    if #iconos > 0 then
        marco.cds:ClearAllPoints(); marco.cds:SetPoint("TOPLEFT", marco, "TOPLEFT", 6, y)
        marco.cds:SetSize(#iconos * (db.tamIcono + 6), db.tamIcono)
        U.Iconos(marco.cds, iconos, db.tamIcono)
        marco.cds:Show()
        y = y - db.tamIcono - 6
    else
        marco.cds:Hide()
    end
    if #lineas > 0 then
        marco.texto:ClearAllPoints(); marco.texto:SetPoint("TOPLEFT", marco, "TOPLEFT", 8, y)
        marco.texto:SetWidth(ancho + 40)
        marco.texto:SetText(table.concat(lineas, "\n"))
        marco.texto:Show()
        y = y - 13 * #lineas - 4
    else
        marco.texto:Hide()
    end
    if combate then return end
    if db.mascota and db.botonAlimentar then
        -- Solo se rehace el botón si cambia lo que toca (llamar / revivir / alimentar).
        local modo = (not HayMascota() and "llamar") or (MascotaMuerta() and "revivir") or "comer"
        local actual = marco.alimentar.modo
        if (modo == "comer" and actual ~= "alimentar" and actual ~= "nada") or (modo ~= "comer" and actual ~= modo) then PrepararBotones() end
        marco.alimentar:ClearAllPoints(); marco.alimentar:SetPoint("TOPLEFT", marco, "TOPLEFT", 8, y)
        marco.alimentar:Show()
        y = y - 24
    elseif marco.alimentar then
        marco.alimentar:Hide()
    end
    if y >= -8 and not mover then marco:Hide(); return end
    marco:SetSize(ancho + 50, -y + 4)
    if not marco.colocado then U.Colocar(mod, marco, "cazador", 0, 200); marco.colocado = true end
    marco:EnableMouse(mover or not db.bloquear)
    marco:Show()
end
H.Pintar = function() Pintar() end

----------------------------------------------------------------------
-- Registro
----------------------------------------------------------------------
local ROLES = { { "auto", "Automático (por talentos)" }, { "bestias", "Bestias" }, { "punteria", "Puntería" }, { "supervivencia", "Supervivencia" } }
local acum = 0
mod = Hub:Register{
    key = "cazador", dir = "Cazador", name = "Cazador", clase = "HUNTER",
    desc = "Para cualquier cazador: elige tu rol, la felicidad y lealtad de tu mascota con botón para alimentarla, tu "
        .. "munición (aviso y reponer en el vendedor), barra del disparo automático, aspectos con avisos, tus "
        .. "picaduras y marca en el objetivo, Disparo tranquilizante, trampas y Fingir muerte.",
    defaults = DEFAULTS,
    slash = { "cmcazador" },
    Init = function(m)
        db = m.db
        m:Event("START_AUTOREPEAT_SPELL", function() auto = true; LeerVelocidad() end)
        m:Event("STOP_AUTOREPEAT_SPELL", function() auto = false end)
        m:Event("UNIT_SPELLCAST_SUCCEEDED", function(_, _, unidad, _, hechizo)
            if unidad ~= "player" then return end
            hechizo = Num(hechizo)
            if hechizo == DISPARO_AUTO then ultimoDisparo = GetTime(); LeerVelocidad() end
            for _, id in ipairs(APUNTADO) do if hechizo == id then ultimoDisparo = GetTime() end end
            if hechizo == FINGIR then fingirLanzado = GetTime() end
        end)
        m:Event("UNIT_PET", function(_, _, u) if u == "player" then PrepararBotones(); Pintar() end end)
        m:Event("UNIT_HAPPINESS", Pintar)
        m:Event("BAG_UPDATE_DELAYED", function() PrepararBotones(); Pintar() end)
        m:Event("SPELLS_CHANGED", function() PrepararBotones() end)
        m:Event("MERCHANT_SHOW", AlAbrirVendedor)
        m:Event("MERCHANT_CLOSED", function() if botonVendedor then botonVendedor:Hide() end end)
        m:Event("PLAYER_REGEN_ENABLED", function() avisos.sinMascota, avisos.aspecto = false, false; PrepararBotones(); Pintar() end)
        m:Event("PLAYER_REGEN_DISABLED", Pintar)
        m:Event("UNIT_INVENTORY_CHANGED", function(_, _, u) if u == "player" then LeerVelocidad() end end)
        m:OnUpdate(function(_, e)
            acum = acum + e
            PintarBarra()
            if acum >= 0.2 then acum = 0; Pintar() end
        end)
    end,
    Enable = function(m) db = m.db; LeerVelocidad(); Pintar() end,
    Disable = function()
        if marco and not U.EnCombate() then marco:Hide() end
        if barra then barra:Hide() end
    end,
    OnReset = function() if marco then marco.colocado = false end; if barra then barra.colocado = false end end,
    OnSlash = function(m, msg)
        msg = (msg or ""):lower()
        if msg == "mover" then mover = not mover; Pintar()
        elseif msg == "rol" then m:Print("rol: " .. H.Rol() .. " (ajuste: " .. db.rol .. ")")
        elseif msg == "reponer" then ReponerMunicion(false)
        else Hub:Open("cazador") end
    end,
    BuildConfig = function(m, L)
        db = m.db
        local function G(k) return function() return db[k] end end
        local function S(k) return function(v) db[k] = v; Pintar() end end
        local function Col(k) return function() local c = db[k]; return c[1], c[2], c[3] end end
        local function SetCol(k) return function(r, g, b) db[k] = { r, g, b }; Pintar() end end
        if not H.EsCazador() then L:Text("|cffff7755Este personaje no es cazador.|r", true) end

        L:Header("Rol")
        L:Text("Los módulos Bestias, Puntería y Supervivencia solo se encienden con su rol. En automático se mira qué "
            .. "talentos conoces (Cólera de las bestias / Intimidación = bestias; Aura de disparo certero / Disparo "
            .. "apuntado = puntería; Picadura de dracoleón / Contraataque / Disuasión = supervivencia).", true)
        L:Choice("Rol", ROLES, G("rol"), function(v) db.rol = v; Pintar(); m:Print("rol: " .. H.Rol()) end)
        L:Button("¿Qué rol tengo ahora?", 180, function() m:Print("rol: " .. H.Rol() .. " (ajuste: " .. db.rol .. ")") end)

        L:Header("Marco")
        L:Button("Mover (marco y barra de disparo)", 240, function() mover = not mover; Pintar() end)
        L:Button("Volver a su sitio", 140, function() db.pos.cazador, db.pos.disparo = nil, nil
            if marco then marco.colocado = false end; if barra then barra.colocado = false end; Pintar() end, true)
        L:Check("Bloquear la posición", G("bloquear"), S("bloquear"))
        L:Check("Fondo y borde", G("fondo"), S("fondo"))
        L:Slider("Escala", 0.5, 2, 0.05, G("escala"), S("escala"), "%.2f")
        L:Slider("Opacidad", 0.2, 1, 0.05, G("opacidad"), S("opacidad"), "%.2f")
        L:Slider("Tamaño de los iconos", 18, 50, 1, G("tamIcono"), S("tamIcono"))

        L:Header("Mascota")
        L:Check("Vida, felicidad y lealtad de la mascota", G("mascota"), S("mascota"))
        L:Check("  Aviso cuando se pone triste", G("avisoTriste"), S("avisoTriste"))
        L:Check("  Aviso cuando baja a normal", G("avisoNormal"), S("avisoNormal"))
        L:Check("  Aviso cuando pierde lealtad", G("avisoLealtad"), S("avisoLealtad"))
        L:Check("  Aviso si muere", G("avisoMuerta"), S("avisoMuerta"))
        L:Check("  Aviso si peleas sin mascota", G("avisoSinMascota"), S("avisoSinMascota"))
        L:Check("  Lo que le queda a " .. U.Nombre(ALIVIAR[1], "Aliviar mascota"), G("verAliviar"), S("verAliviar"))
        L:Check("Botón Alimentar (o Llamar / Revivir si hace falta)", G("botonAlimentar"), S("botonAlimentar"))
        L:Text("Solo usa comida que le gusta a tu mascota. Comidas que no quieres gastar (nombres o números, separados por ;):", true)
        L:Edit("  No usar", G("noUsar"), function(v) if type(v) == "string" then db.noUsar = v:gsub("|", ""); PrepararBotones() end end, "text", 250)

        L:Header("Munición")
        L:Check("Lo que te queda", G("municion"), S("municion"))
        L:Slider("  En rojo y aviso por debajo de", 0, 2000, 50, G("minMunicion"), S("minMunicion"))
        L:Check("  Aviso", G("avisoMunicion"), S("avisoMunicion"))
        L:Check("Botón «Reponer munición» en el vendedor", G("reponer"), S("reponer"))
        L:Slider("  Llevar hasta", 200, 4000, 100, G("objetivoMunicion"), S("objetivoMunicion"))
        L:Check("  Reponer solo al abrir el vendedor", G("reponerSolo"), S("reponerSolo"))
        L:Slider("  No gastar si me quedaría con menos de (oro)", 0, 100, 1, G("reservaOro"), S("reservaOro"))

        L:Header("Disparo automático")
        L:Check("Barra hasta el siguiente disparo", G("disparo"), S("disparo"))
        L:Slider("  Ancho", 100, 400, 5, G("anchoDisparo"), S("anchoDisparo"))
        L:Slider("  Alto", 6, 30, 1, G("altoDisparo"), S("altoDisparo"))
        L:Slider("  Zona roja al final (segundos: no te muevas)", 0, 1, 0.1, G("zonaRoja"), S("zonaRoja"), "%.1f")
        L:Color("  Color", Col("colorDisparo"), SetCol("colorDisparo"))
        L:Color("  Color de la zona roja", Col("colorZona"), SetCol("colorZona"))

        L:Header("Aspectos")
        L:Check("Barra de aspectos (clic para cambiar)", G("aspectos"), S("aspectos"))
        L:Slider("  Tamaño", 18, 50, 1, G("tamAspecto"), S("tamAspecto"))
        L:Check("Aviso si peleas con Guepardo o Manada", G("avisoGuepardo"), S("avisoGuepardo"))
        L:Check("Aviso si vas sin aspecto", G("avisoSinAspecto"), S("avisoSinAspecto"))

        L:Header("Objetivo")
        L:Check("Tu Marca del cazador y tus picaduras en el objetivo", G("picaduras"), S("picaduras"))
        L:Slider("  En rojo cuando quedan (segundos)", 0, 10, 1, G("segundosPicadura"), S("segundosPicadura"))
        L:Check("  Aviso en combate cuando se van a acabar", G("avisoPicadura"), S("avisoPicadura"))
        L:Check("Aviso de " .. U.Nombre(TRANQUILIZANTE, "Disparo tranquilizante") .. " cuando el objetivo se enfurece", G("tranquilizante"), S("tranquilizante"))
        L:Edit("  Nombres de furia (separados por ;)", G("patronesFuria"), function(v) if type(v) == "string" then db.patronesFuria = v:gsub("|", "") end end, "text", 250)
        L:Check("Trampa congelante en el objetivo", G("congelante"), S("congelante"))

        L:Header("Trampas, Fingir muerte y rastreo")
        L:Check("Enfriamiento de las trampas", G("trampas"), S("trampas"))
        L:Check("Enfriamiento de " .. U.Nombre(FINGIR, "Fingir muerte"), G("fingir"), S("fingir"))
        L:Check("  Aviso si falla", G("avisoFingir"), S("avisoFingir"))
        L:Check("Aviso si vas sin rastreo (fuera de combate)", G("avisoRastreo"), S("avisoRastreo"))

        L:Header("Cómo avisa")
        L:Check("Texto grande", G("avisoTexto"), S("avisoTexto"))
        L:Check("Línea en el chat", G("avisoChat"), S("avisoChat"))
        L:Check("Sonido", G("avisoSonido"), S("avisoSonido"))
        L:Choice("  Sonido", U.KITS, G("avisoKit"), function(v) db.avisoKit = v; U.Sonar(v) end)
    end,
}
