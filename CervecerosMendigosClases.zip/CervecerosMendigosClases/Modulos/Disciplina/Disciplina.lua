-- Disciplina (CervecerosMendigos Clases, sacerdote): solo con rol disciplina.
--   Infusión de poder (con anuncio a quién se la das) y Enfoque interno en grande, y quién del grupo tiene
--   Alma debilitada (no le puedes poner otro escudo).
local ADDON, ns = ...
local U = ns.CU

local DEBILITADA = 6788

U.Modulo{
    key = "disciplina", dir = "Disciplina", name = "Disciplina", clase = "PRIEST", slash = { "cmdisciplina" }, rolDe = "sacerdote", rol = "disciplina",
    desc = "Sacerdote de disciplina (solo con ese rol): Infusión de poder (con anuncio) y Enfoque interno en grande, y "
        .. "quién del grupo tiene Alma debilitada.",
    procs = { { "enfoque", { 14751 }, "Enfoque interno" } },
    cds = { { "infusion", { 10060 }, "Infusión de poder", anunciar = true }, { "enfoque", { 14751 }, "Enfoque interno" } },
    defaults = { debilitada = true },
    extra = function(c)
        if not c.db.debilitada then return end
        local nombre = U.Nombre(DEBILITADA, "Alma debilitada")
        for _, u in ipairs(U.Miembros(false)) do
            local fin = U.Aura(u, nombre, "HARMFUL")
            if fin and fin ~= math.huge then
                local okn, n = pcall(UnitName, u)
                c.lineas[#c.lineas + 1] = ("|cff999999%s: %s %s|r"):format(nombre, okn and U.Str(n) or u, U.Tiempo(math.max(0, fin - GetTime())))
            end
        end
    end,
    config = function(m, L)
        L:Header("Alma debilitada")
        L:Check("Quién del grupo la tiene (y cuánto le queda)", function() return m.db.debilitada end, function(v) m.db.debilitada = v end)
    end,
}
