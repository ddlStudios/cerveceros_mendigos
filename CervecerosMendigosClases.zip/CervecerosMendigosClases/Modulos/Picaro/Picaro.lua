-- Picaro (CervecerosMendigos Clases): lo de cualquier pícaro (montado con el motor de ComunClases).
--   Rol (asesinato, combate, sutileza), tu Exponer armadura en el objetivo y enfriamientos.
--   Los venenos, robos y cajas están en Mangadoor; los controles en Control; la energía y los combos en Energía.
local ADDON, ns = ...
local U = ns.CU

U.Modulo{
    key = "picaro", dir = "Picaro", name = "Pícaro", clase = "ROGUE", slash = { "cmpicaro" },
    desc = "Para cualquier pícaro: elige tu rol (asesinato, combate o sutileza), tu Exponer armadura en el objetivo y "
        .. "tus enfriamientos (Patada, Esprintar, Evasión, Esfumarse, Ceguera...).",
    roles = { { "asesinato", "Asesinato" }, { "combate", "Combate" }, { "sutileza", "Sutileza" } },
    pistas = { { "combate", { 13750 } }, { "sutileza", { 16511, 17347, 17348 } }, { "asesinato", { 14177 } },
               { "combate", { 13877 } }, { "sutileza", { 14183, 14185, 14278 } },
               { "asesinato", { 14186, 14190, 14193, 14194, 14195 } }, { "combate", { 14251 } } },
    objetivo = { { "exponer", { 8647, 8649, 8650, 11197, 11198 }, "Exponer armadura" } },
    cds = {
        { "patada", { 1766, 1767, 1768, 1769 }, "Patada" }, { "esprintar", { 2983, 8696, 11305 }, "Esprintar" },
        { "evasion", { 5277, 26669 }, "Evasión" }, { "esfumarse", { 1856, 1857 }, "Esfumarse" },
        { "ceguera", { 2094 }, "Ceguera" }, { "gubia", { 1776, 1777, 8629, 11285, 11286 }, "Gubia", defecto = false },
        { "rinones", { 408, 8643 }, "Golpe en los riñones", defecto = false }, { "distraer", { 1725 }, "Distraer", defecto = false },
    },
}
