-- Sombras (CervecerosMendigos Clases, sacerdote): solo con rol sombras.
--   Aviso si vas sin Forma de las Sombras; tus Palabra de las Sombras: dolor y Abrazo vampírico en el objetivo,
--   cargas de Tejido de las Sombras; Explosión mental y Silencio en grande.
local ADDON, ns = ...
local U = ns.CU

U.Modulo{
    key = "sombras", dir = "Sombras", name = "Sombras", clase = "PRIEST", slash = { "cmsombras" }, rolDe = "sacerdote", rol = "sombras",
    desc = "Sacerdote de sombras (solo con ese rol): aviso si vas sin Forma de las Sombras, tus Palabra de las Sombras: "
        .. "dolor y Abrazo vampírico en el objetivo, las cargas de Tejido de las Sombras, y Explosión mental y Silencio.",
    propios = { { "forma", { { 15473 } }, "Forma de las Sombras" } },
    objetivo = {
        { "dolor", { 589, 594, 970, 992, 2767, 10892, 10893, 10894 }, "Palabra de las Sombras: dolor", falta = true },
        { "abrazo", { 15286 }, "Abrazo vampírico", falta = true },
        { "tejido", { 15258 }, "Tejido de las Sombras", propio = false, cargas = 5, si = { 15257, 15331, 15332, 15333, 15334 } },
    },
    cds = { { "explosion", { 8092, 8102, 8103, 8104, 8105, 8106, 10945, 10946, 10947 }, "Explosión mental", avisoListo = false },
            { "silencio", { 15487 }, "Silencio" } },
}
