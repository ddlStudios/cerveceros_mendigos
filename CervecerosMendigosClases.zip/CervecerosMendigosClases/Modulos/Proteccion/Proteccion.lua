-- Protección (CervecerosMendigos Clases, paladín): solo se enciende si tu rol de paladín es protección.
--   * Furia recta: aviso si tanqueas sin ella.
--   * Escudo sagrado: lo que le queda y sus cargas, aviso si se te cae en combate.
--   * Enfriamientos: Escudo sagrado, Consagración y Sentencia.
--   * Sentencia de sabiduría / de luz en el objetivo: lo que le queda.
local ADDON, ns = ...
local Hub = ns.Hub
local U = ns.CU
local P = ns.Paladin

local FURIA = 25780
local ESCUDO = { 20925, 20927, 20928 }
local CONSAGRACION = { 26573, 20116, 20922, 20923, 20924 }
local SENTENCIA = { 20271 }
local S_SABIDURIA = { 20186, 20354, 20355 }
local S_LUZ = { 20185, 20344, 20345, 20346 }

local DEFAULTS = {
    escala = 1, opacidad = 1, bloquear = false, tamIcono = 32,
    furia = true, avisoFuria = true,
    escudo = true, avisoEscudo = true,
    cdEscudo = true, cdConsagracion = true, cdSentencia = true,
    sentencias = true, avisoSentencia = false, segundosSentencia = 4,
    avisoTexto = true, avisoChat = false, avisoSonido = true, avisoKit = "RAID_WARNING",
    pos = {},
}

local mod, db, marco
local mover = false
local avisado = { furia = false, escudo = false }
local avisadoSent = {}

local function Activo() return mod and mod:IsEnabled() and P.EsPaladin() and P.Rol() == "proteccion" end

local function Pintar()
    if not Activo() then if marco then marco:Hide() end return end
    marco = marco or P.Panel(mod, "CMProteccion", "proteccion", function() return mover end)
    local combate = U.EnCombate()
    local lineas, iconos = {}, {}
    -- Furia recta.
    if db.furia and U.Conoce(FURIA) then
        local fin = U.Aura("player", U.Nombre(FURIA, "Furia recta"), "HELPFUL")
        if fin == false then
            lineas[#lineas + 1] = "|cffff5555Sin " .. U.Nombre(FURIA, "Furia recta") .. "|r"
            if db.avisoFuria and combate and not avisado.furia then
                avisado.furia = true
                U.Avisar(mod, "¡Tanqueando sin " .. U.Nombre(FURIA, "Furia recta") .. "!", true, 1, 0.3, 0.3)
            end
        elseif fin then
            avisado.furia = false
        end
    end
    -- Escudo sagrado.
    if db.escudo and U.ConoceAlguno(ESCUDO) then
        local fin, _, cargas = U.Aura("player", U.Nombre(ESCUDO[1], "Escudo sagrado"), "HELPFUL")
        local nombre = U.Nombre(ESCUDO[1], "Escudo sagrado")
        if fin and fin ~= math.huge then
            lineas[#lineas + 1] = ("%s %s%s"):format(nombre, U.Tiempo(math.max(0, fin - GetTime())), cargas and cargas > 0 and (" · " .. cargas .. " cargas") or "")
            avisado.escudo = false
        elseif fin == false and combate then
            local q = U.Enfriamiento(U.Mejor(ESCUDO))
            if q == 0 then
                lineas[#lineas + 1] = "|cffffaa33" .. nombre .. ": ¡ponlo!|r"
                if db.avisoEscudo and not avisado.escudo then avisado.escudo = true; U.Avisar(mod, nombre .. " caído", true, 1, 0.6, 0.2) end
            end
        end
    end
    -- Sentencias en el objetivo.
    if db.sentencias and P.HayEnemigo() then
        local okg, guid = pcall(UnitGUID, "target")
        guid = okg and U.Str(guid) or "?"
        for _, x in ipairs({ { S_SABIDURIA, "s" }, { S_LUZ, "l" } }) do
            local q = P.EnObjetivo(x[1])
            if q and q ~= false then
                local nombre = U.Nombre(x[1][1])
                lineas[#lineas + 1] = (q <= db.segundosSentencia and "|cffff5555%s %s|r" or "%s %s"):format(nombre, U.Tiempo(q))
                local k = guid .. x[2]
                if q <= db.segundosSentencia and db.avisoSentencia and combate and not avisadoSent[k] then
                    avisadoSent[k] = true
                    U.Avisar(mod, nombre .. ": quedan " .. math.ceil(q) .. " s", true)
                elseif q > db.segundosSentencia then
                    avisadoSent[k] = nil
                end
            end
        end
    end
    -- Enfriamientos.
    for _, x in ipairs({ { db.cdEscudo, ESCUDO }, { db.cdConsagracion, CONSAGRACION }, { db.cdSentencia, SENTENCIA } }) do
        local id = x[1] and U.Mejor(x[2])
        if id then iconos[#iconos + 1] = { icono = U.Icono(id), queda = U.Enfriamiento(id) or 0 } end
    end
    P.PintarPanel(mod, marco, lineas, iconos, mover, 0, -260)
end

local acum = 0
mod = Hub:Register{
    key = "proteccion", dir = "Proteccion", name = "Protección", clase = "PALADIN",
    desc = "Paladín de protección (solo con ese rol): aviso si tanqueas sin Furia recta, Escudo sagrado con sus cargas "
        .. "y aviso si se cae, enfriamientos de Escudo sagrado, Consagración y Sentencia, y tus sentencias en el objetivo.",
    defaults = DEFAULTS,
    slash = { "cmproteccion" },
    Init = function(m)
        db = m.db
        m:Event("PLAYER_TARGET_CHANGED", Pintar)
        m:Event("PLAYER_REGEN_ENABLED", function() avisado.furia, avisado.escudo = false, false; Pintar() end)
        m:OnUpdate(function(_, e) acum = acum + e; if acum >= 0.15 then acum = 0; Pintar() end end)
    end,
    Enable = function(m) db = m.db; Pintar() end,
    Disable = function() if marco then marco:Hide() end end,
    OnReset = function() if marco then marco.colocado = false end end,
    OnSlash = function(m, msg) if (msg or ""):lower() == "mover" then mover = not mover; Pintar() else Hub:Open("proteccion") end end,
    BuildConfig = function(m, L)
        db = m.db
        local function G(k) return function() return db[k] end end
        local function S(k) return function(v) db[k] = v; Pintar() end end
        L:Text("Solo funciona si tu rol de paladín (pestaña Paladín) es protección. Ahora: |cffffd100" .. P.Rol() .. "|r.", true)
        L:Button("Mover", 90, function() mover = not mover; Pintar() end)
        L:Button("Volver a su sitio", 140, function() db.pos.proteccion = nil; if marco then marco.colocado = false end; Pintar() end, true)
        L:Check("Bloquear la posición", G("bloquear"), S("bloquear"))
        L:Slider("Escala", 0.5, 2, 0.05, G("escala"), S("escala"), "%.2f")
        L:Slider("Opacidad", 0.2, 1, 0.05, G("opacidad"), S("opacidad"), "%.2f")

        L:Header(U.Nombre(FURIA, "Furia recta"))
        L:Check("Mostrar si no la llevas", G("furia"), S("furia"))
        L:Check("  Aviso si entras en combate sin ella", G("avisoFuria"), S("avisoFuria"))
        L:Header(U.Nombre(ESCUDO[1], "Escudo sagrado"))
        L:Check("Tiempo y cargas", G("escudo"), S("escudo"))
        L:Check("  Aviso si se cae en combate y lo tienes listo", G("avisoEscudo"), S("avisoEscudo"))
        L:Header("Sentencias en el objetivo")
        L:Check("Sentencia de sabiduría / de luz: lo que le queda", G("sentencias"), S("sentencias"))
        L:Slider("  En rojo cuando quedan (segundos)", 0, 15, 1, G("segundosSentencia"), S("segundosSentencia"))
        L:Check("  Aviso en combate cuando se va a acabar", G("avisoSentencia"), S("avisoSentencia"))
        L:Header("Enfriamientos")
        L:Check("  " .. U.Nombre(ESCUDO[1], "Escudo sagrado"), G("cdEscudo"), S("cdEscudo"))
        L:Check("  " .. U.Nombre(CONSAGRACION[1], "Consagración"), G("cdConsagracion"), S("cdConsagracion"))
        L:Check("  " .. U.Nombre(SENTENCIA[1], "Sentencia"), G("cdSentencia"), S("cdSentencia"))
        L:Slider("  Tamaño", 20, 60, 1, G("tamIcono"), S("tamIcono"))
        L:Header("Cómo avisa")
        L:Check("Texto grande", G("avisoTexto"), S("avisoTexto"))
        L:Check("Línea en el chat", G("avisoChat"), S("avisoChat"))
        L:Check("Sonido", G("avisoSonido"), S("avisoSonido"))
        L:Choice("  Sonido", U.KITS, G("avisoKit"), function(v) db.avisoKit = v; U.Sonar(v) end)
    end,
}
