-- Configuracion del addon grande CervecerosMendigosGeneral (todo lo demas).
local ADDON, ns = ...
ns.HubConfig = {
    title = "CervecerosMendigosGeneral",
    subtitle = "Guía de leveo, profesiones, economia y comodidad",
    slashes = { "cmgeneral", "cervecerosmendigos" },
    svName = "CervecerosMendigosGeneralHubDB",
    logo = "Interface\\AddOns\\" .. ADDON .. "\\logo.tga",
    minimapIcon = "Interface\\AddOns\\" .. ADDON .. "\\badge.tga",
    angleBase = 190, angleStep = 12,
    intro = "El resto de herramientas: ayuda para levear y explorar, profesiones, subasta, banco y lista de la compra, marcas de mapa para el grupo, avisos de equipo y bolsas, contador de objetos, colores de enfriamiento, mapa de recolección (Farmeadoor), ajustes gráficos y filtros de pantalla (Customizadoor) pantalla de subida de nivel (Subidoor), comparador de equipo (Mejoradoor) y viajes (vuelos, piedra de hogar y portales). Las ayudas de cada clase están en el addon CervecerosMendigosClases. Cada pestana de la izquierda es un modulo con su propia configuracion; puedes activarlo o desactivarlo sin tocar los demas, y todos los ajustes se pueden cambiar para adaptarlos a tu forma de jugar.",
}
