-- Mejoradoor · datos: perfiles de pesos por clase, pistas de talentos para el rol automatico,
-- armas y armaduras que puede llevar cada clase. Todo lo que es ajuste del usuario se cambia en la
-- pestana (los pesos de aqui son solo los valores de partida).
local ADDON, ns = ...
local P = {}
ns.MejoradoorPesos = P

-- Estadisticas que se puntuan (clave interna, nombre en la pestana y en el detalle del tooltip).
-- crit/hit/spcrit/sphit/esquivar/parar/bloqueo van en % (como en los objetos de Forever: "+1 %").
P.STATS = {
    { "fue", "Fuerza" }, { "agi", "Agilidad" }, { "agu", "Aguante" }, { "int", "Intelecto" }, { "esp", "Espíritu" },
    { "armadura", "Armadura" }, { "pa", "Poder de ataque" }, { "pad", "Poder de ataque a distancia" },
    { "crit", "Golpe crítico (%)" }, { "hit", "Golpe (acierto, %)" },
    { "sp", "Daño y sanación de hechizos" }, { "spdano", "Daño de hechizos" }, { "sana", "Sanación" },
    { "spcrit", "Crítico con hechizos (%)" }, { "sphit", "Acierto con hechizos (%)" }, { "mp5", "Maná cada 5 s" },
    { "defensa", "Defensa" }, { "esquivar", "Esquivar (%)" }, { "parar", "Parar (%)" }, { "bloqueo", "Bloqueo (%)" },
    { "valorbloqueo", "Valor de bloqueo" }, { "dps", "DPS del arma cuerpo a cuerpo" }, { "dpsd", "DPS del arma a distancia" },
    { "resist", "Resistencias (todas)" },
}
P.NOMBRE = {}
for _, s in ipairs(P.STATS) do P.NOMBRE[s[1]] = s[2] end

-- Claves de C_Item.GetItemStats -> clave interna.
P.CLAVES = {
    ITEM_MOD_STRENGTH_SHORT = "fue", ITEM_MOD_AGILITY_SHORT = "agi", ITEM_MOD_STAMINA_SHORT = "agu",
    ITEM_MOD_INTELLECT_SHORT = "int", ITEM_MOD_SPIRIT_SHORT = "esp", RESISTANCE0_NAME = "armadura",
    ITEM_MOD_ATTACK_POWER_SHORT = "pa", ITEM_MOD_RANGED_ATTACK_POWER_SHORT = "pad",
    ITEM_MOD_CRIT_RATING_SHORT = "crit", ITEM_MOD_CRIT_MELEE_RATING_SHORT = "crit", ITEM_MOD_CRIT_RANGED_RATING_SHORT = "crit",
    ITEM_MOD_HIT_RATING_SHORT = "hit", ITEM_MOD_HIT_MELEE_RATING_SHORT = "hit", ITEM_MOD_HIT_RANGED_RATING_SHORT = "hit",
    ITEM_MOD_SPELL_POWER_SHORT = "sp", ITEM_MOD_SPELL_DAMAGE_DONE_SHORT = "spdano", ITEM_MOD_SPELL_HEALING_DONE_SHORT = "sana",
    ITEM_MOD_CRIT_SPELL_RATING_SHORT = "spcrit", ITEM_MOD_SPELL_CRIT_RATING_SHORT = "spcrit",
    ITEM_MOD_HIT_SPELL_RATING_SHORT = "sphit", ITEM_MOD_SPELL_HIT_RATING_SHORT = "sphit",
    ITEM_MOD_POWER_REGEN0_SHORT = "mp5", ITEM_MOD_MANA_REGENERATION_SHORT = "mp5",
    ITEM_MOD_DEFENSE_SKILL_RATING_SHORT = "defensa", ITEM_MOD_DODGE_RATING_SHORT = "esquivar",
    ITEM_MOD_PARRY_RATING_SHORT = "parar", ITEM_MOD_BLOCK_RATING_SHORT = "bloqueo", ITEM_MOD_BLOCK_VALUE_SHORT = "valorbloqueo",
    ITEM_MOD_DAMAGE_PER_SECOND_SHORT = "dps",
    RESISTANCE1_NAME = "resist", RESISTANCE2_NAME = "resist", RESISTANCE3_NAME = "resist",
    RESISTANCE4_NAME = "resist", RESISTANCE5_NAME = "resist", RESISTANCE6_NAME = "resist",
}

-- Efectos «Equipar:» que no siempre vienen en GetItemStats: se leen del texto del tooltip
-- (solo si GetItemStats no trae ya esa estadistica). Orden importante: lo mas concreto primero.
-- El texto se pasa a minusculas y sin tildes antes de buscar (en Lua una «í» son dos bytes).
P.TEXTO = {
    { "spcrit", { "critico con hechizos.-(%d+)", "critical strike with spells.-(%d+)" } },
    { "sphit",  { "con hechizos.-(%d+)%s*%%.-$", "hit with spells.-(%d+)" } },
    { "crit",   { "golpe critico.-(%d+)%s*%%", "critical strike.-(%d+)%%" } },
    { "hit",    { "alcanzar.-(%d+)%s*%%", "golpear.-(%d+)%s*%%", "acertar.-(%d+)%s*%%", "chance to hit.-(%d+)%%" } },
    { "sp",     { "dano y la sanacion.-(%d+)", "damage and healing.-(%d+)" } },
    { "sana",   { "sanacion.-(%d+)", "healing done.-(%d+)" } },
    { "spdano", { "dano infligido por los hechizos.-(%d+)", "damage done by.-spells.-(%d+)" } },
    { "pad",    { "(%d+).-poder de ataque a distancia", "(%d+) ranged attack power" } },
    { "pa",     { "(%d+).-poder de ataque", "(%d+) attack power" } },
    { "mp5",    { "(%d+).-mana cada 5", "(%d+) mana per 5" } },
    { "defensa", { "defensa.-(%d+)", "defense.-(%d+)" } },
    { "esquivar", { "esquivar.-(%d+)%s*%%", "dodge.-(%d+)%%" } },
    { "parar",  { "parar.-(%d+)%s*%%", "parry.-(%d+)%%" } },
    { "valorbloqueo", { "valor de bloqueo.-(%d+)", "block value.-(%d+)" } },
    { "bloqueo", { "bloquear.-(%d+)%s*%%", "block.-(%d+)%%" } },
}

-- Perfiles por clase: { clave, "Nombre", pesos }. El primero es el de partida si no se detecta nada.
local LANZADOR_DANO = { int = 0.45, esp = 0.15, agu = 0.35, sp = 1, spdano = 1, spcrit = 10, sphit = 12, mp5 = 0.9, armadura = 0.002, dpsd = 0.6 }
local function Copia(t, extra)
    local r = {}
    for k, v in pairs(t) do r[k] = v end
    for k, v in pairs(extra or {}) do r[k] = v end
    return r
end
local SANADOR = { int = 0.6, esp = 0.35, agu = 0.25, sp = 1, sana = 1, spcrit = 7, mp5 = 2.2, armadura = 0.002 }

P.PERFILES = {
    WARRIOR = {
        { "dps", "Daño (Armas / Furia)", { fue = 1, agi = 0.7, agu = 0.35, pa = 0.5, crit = 14, hit = 15, armadura = 0.01, dps = 5, dpsd = 0.3, defensa = 0.1 } },
        { "tanque", "Tanque (Protección)", { agu = 1, armadura = 0.06, defensa = 1.2, esquivar = 12, parar = 10, bloqueo = 6, valorbloqueo = 0.3, fue = 0.5, agi = 0.6, hit = 6, pa = 0.1, dps = 1 } },
    },
    PALADIN = {
        { "dps", "Daño (Reprensión)", { fue = 1, agi = 0.6, agu = 0.35, int = 0.3, pa = 0.45, crit = 12, hit = 12, sp = 0.3, dps = 5, armadura = 0.005 } },
        { "sanador", "Sanador (Sagrado)", Copia(SANADOR, { esp = 0.1 }) },
        { "tanque", "Tanque (Protección)", { agu = 1, defensa = 1.2, armadura = 0.05, sp = 0.6, int = 0.4, bloqueo = 5, valorbloqueo = 0.3, esquivar = 10, parar = 8, fue = 0.3, dps = 1 } },
    },
    HUNTER = {
        { "dps", "Daño (todas)", { agi = 1, pa = 0.2, pad = 0.45, crit = 14, hit = 14, int = 0.4, agu = 0.35, mp5 = 1, esp = 0.05, armadura = 0.005, dps = 0.5, dpsd = 5 } },
    },
    ROGUE = {
        { "dps", "Daño (todas)", { agi = 1, fue = 0.55, pa = 0.5, crit = 12, hit = 14, agu = 0.35, armadura = 0.005, dps = 5, dpsd = 0.3 } },
    },
    PRIEST = {
        { "sanador", "Sanador (Disciplina / Sagrado)", Copia(SANADOR, { esp = 0.6, int = 0.65 }) },
        { "sombras", "Daño (Sombras)", Copia(LANZADOR_DANO, { esp = 0.3, agu = 0.4, spcrit = 6 }) },
    },
    SHAMAN = {
        { "mejora", "Daño cuerpo a cuerpo (Mejora)", { fue = 1, agi = 0.6, agu = 0.35, int = 0.3, pa = 0.45, crit = 12, hit = 13, sp = 0.2, dps = 5, armadura = 0.005 } },
        { "elemental", "Daño de hechizos (Elemental)", Copia(LANZADOR_DANO, { spcrit = 10 }) },
        { "sanador", "Sanador (Restauración)", Copia(SANADOR, { mp5 = 2.5, esp = 0.15 }) },
    },
    MAGE = {
        { "dps", "Daño (todas)", Copia(LANZADOR_DANO, { esp = 0.2, agu = 0.3 }) },
    },
    WARLOCK = {
        { "dps", "Daño (todas)", Copia(LANZADOR_DANO, { agu = 0.5, int = 0.4 }) },
    },
    DRUID = {
        { "gato", "Gato (Feral)", { agi = 1, fue = 1, pa = 0.5, crit = 12, hit = 13, agu = 0.35, armadura = 0.005 } },
        { "oso", "Oso (Guardián)", { agu = 1, armadura = 0.1, agi = 0.6, defensa = 0.8, esquivar = 12, fue = 0.4, hit = 5, pa = 0.1 } },
        { "equilibrio", "Equilibrio", Copia(LANZADOR_DANO, { spcrit = 9 }) },
        { "sanador", "Sanador (Restauración)", Copia(SANADOR, { esp = 0.5 }) },
    },
}

-- Rol automatico: como en el addon de Clases, el primer talento conocido decide el perfil.
P.PISTAS = {
    WARRIOR = { { "dps", { 12294, 21551, 21552, 21553 } }, { "dps", { 23881, 23892, 23893, 23894 } },
                { "tanque", { 23922, 23923, 23924, 23925 } }, { "dps", { 12292, 12328 } }, { "tanque", { 12975, 12809 } } },
    PALADIN = { { "sanador", { 20473, 20929, 20930 } }, { "tanque", { 20925, 20927, 20928 } }, { "dps", { 20066 } },
                { "sanador", { 20216 } }, { "tanque", { 20911, 20912, 20913, 20914 } }, { "dps", { 20375 } } },
    PRIEST  = { { "sanador", { 10060 } }, { "sanador", { 724, 27870, 27871 } }, { "sombras", { 15473 } },
                { "sanador", { 14751, 15237 } }, { "sombras", { 15286, 15487 } } },
    SHAMAN  = { { "mejora", { 17364 } }, { "sanador", { 16190, 17354, 17359 } }, { "elemental", { 16166 } },
                { "sanador", { 16188 } }, { "mejora", { 16268 } }, { "elemental", { 16164 } } },
    DRUID   = { { "gato", { 16979, 17007 } }, { "sanador", { 17116, 18562 } }, { "equilibrio", { 24858, 16880, 5570 } } },
}
-- Druida: la forma manda (oso -> oso, gato -> gato, lechucico -> equilibrio). GetShapeshiftFormID.
P.FORMA_DRUIDA = { [1] = "gato", [5] = "oso", [8] = "oso", [31] = "equilibrio" }

-- Armas (subclase de la clase 2) que puede llevar cada clase.
-- 0 hacha 1M, 1 hacha 2M, 2 arco, 3 arma de fuego, 4 maza 1M, 5 maza 2M, 6 arma de asta, 7 espada 1M,
-- 8 espada 2M, 10 baston, 13 puno, 14 miscelanea, 15 daga, 16 arrojadiza, 18 ballesta, 19 varita, 20 cana de pescar.
local function Set(t) local r = {} for _, v in ipairs(t) do r[v] = true end r[14] = true r[20] = true return r end
P.ARMAS = {
    WARRIOR = Set{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 13, 15, 16, 18 },
    PALADIN = Set{ 0, 1, 4, 5, 6, 7, 8 },
    HUNTER  = Set{ 0, 1, 2, 3, 6, 7, 8, 10, 13, 15, 16, 18 },
    ROGUE   = Set{ 2, 3, 4, 7, 13, 15, 16, 18 },
    PRIEST  = Set{ 4, 10, 15, 19 },
    SHAMAN  = Set{ 0, 1, 4, 5, 10, 13, 15 },
    MAGE    = Set{ 7, 10, 15, 19 },
    WARLOCK = Set{ 7, 10, 15, 19 },
    DRUID   = Set{ 4, 5, 10, 13, 15 },
}
-- Armaduras (subclase de la clase 4): 1 tela, 2 cuero, 3 malla, 4 placas, 6 escudo, 7 tratado, 8 idolo, 9 totem.
-- { subclase = nivel minimo }. El 0 (miscelanea: anillos, abalorios, capas...) vale para todos.
P.ARMADURAS = {
    WARRIOR = { [1] = 1, [2] = 1, [3] = 1, [4] = 40, [6] = 1 },
    PALADIN = { [1] = 1, [2] = 1, [3] = 1, [4] = 40, [6] = 1, [7] = 1 },
    HUNTER  = { [1] = 1, [2] = 1, [3] = 40 },
    ROGUE   = { [1] = 1, [2] = 1 },
    PRIEST  = { [1] = 1 },
    SHAMAN  = { [1] = 1, [2] = 1, [3] = 40, [6] = 1, [9] = 1 },
    MAGE    = { [1] = 1 },
    WARLOCK = { [1] = 1 },
    DRUID   = { [1] = 1, [2] = 1, [8] = 1 },
}
-- Tipo principal de armadura (para la opcion «solo tu tipo principal»): { subclase antes de 40, desde 40 }.
P.PRINCIPAL = { WARRIOR = { 3, 4 }, PALADIN = { 3, 4 }, HUNTER = { 2, 3 }, ROGUE = { 2, 2 }, PRIEST = { 1, 1 },
                SHAMAN = { 2, 3 }, MAGE = { 1, 1 }, WARLOCK = { 1, 1 }, DRUID = { 2, 2 } }
-- Ambidiestro: picaro siempre; guerrero y cazador cuando aprenden Ambidiestro (674).
P.AMBIDIESTRO = { ROGUE = true, WARRIOR = 674, HUNTER = 674 }

-- Ranuras donde va cada tipo de objeto.
P.RANURAS = {
    INVTYPE_HEAD = { 1 }, INVTYPE_NECK = { 2 }, INVTYPE_SHOULDER = { 3 }, INVTYPE_BODY = { 4 },
    INVTYPE_CHEST = { 5 }, INVTYPE_ROBE = { 5 }, INVTYPE_WAIST = { 6 }, INVTYPE_LEGS = { 7 }, INVTYPE_FEET = { 8 },
    INVTYPE_WRIST = { 9 }, INVTYPE_HAND = { 10 }, INVTYPE_FINGER = { 11, 12 }, INVTYPE_TRINKET = { 13, 14 },
    INVTYPE_CLOAK = { 15 }, INVTYPE_WEAPON = { 16, 17 }, INVTYPE_SHIELD = { 17 }, INVTYPE_2HWEAPON = { 16 },
    INVTYPE_WEAPONMAINHAND = { 16 }, INVTYPE_WEAPONOFFHAND = { 17 }, INVTYPE_HOLDABLE = { 17 },
    INVTYPE_RANGED = { 18 }, INVTYPE_RANGEDRIGHT = { 18 }, INVTYPE_THROWN = { 18 }, INVTYPE_RELIC = { 18 },
}
P.NOMBRE_RANURA = { [1] = "cabeza", [2] = "cuello", [3] = "hombros", [4] = "camisa", [5] = "pecho", [6] = "cintura",
    [7] = "piernas", [8] = "pies", [9] = "muñecas", [10] = "manos", [11] = "anillo 1", [12] = "anillo 2",
    [13] = "abalorio 1", [14] = "abalorio 2", [15] = "espalda", [16] = "mano derecha", [17] = "mano izquierda", [18] = "distancia" }
