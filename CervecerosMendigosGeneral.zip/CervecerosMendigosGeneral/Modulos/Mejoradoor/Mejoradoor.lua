-- Mejoradoor (CervecerosMendigosGeneral) para WoW Forever (Interface 16001).
-- Comparador de equipo: en el tooltip de cada objeto dice si es una mejora para tu clase y tu rol y cuanto
-- («+4,2 % para Daño»), marca la mejor recompensa de las misiones, avisa en las tiradas de botin y cuando
-- te llega a las bolsas algo mejor que lo que llevas. Los pesos de cada estadistica se cambian en la pestana.
-- Comandos: /mejoradoor (/cmmejora) [bolsas | perfil | pesos].

local ADDON, ns = ...
local Hub = ns.Hub
local P = ns.MejoradoorPesos

local DEFAULTS = {
    tooltip = true,          -- linea en el tooltip de los objetos
    soloMayus = false,       -- solo con Mayus pulsada
    verPerfil = true,        -- poner el nombre del perfil en la linea
    verPuntos = false,       -- ensenar la puntuacion (nueva / la tuya)
    verDetalle = true,       -- lineas con lo que ganas y pierdes
    detalleMax = 4,          -- cuantas estadisticas en el detalle
    verPuesto = false,       -- linea «lo llevas puesto» en lo que ya llevas
    verNoUsable = true,      -- linea «no puedes llevarlo»
    soloPrincipal = false,   -- tratar como no usable lo que no es tu tipo principal de armadura
    umbral = 1,              -- % minimo para llamarlo mejora (por debajo es «igual»)
    dosRanuras = "peor",     -- anillos, abalorios, armas a una mano: comparar con la peor o la mejor de las dos
    leerTexto = true,        -- leer los efectos «Equipar:» del texto si GetItemStats no los trae
    colorMejor = { 0.2, 1, 0.3 },
    colorPeor = { 1, 0.35, 0.3 },
    colorIgual = { 0.75, 0.75, 0.75 },
    -- Recompensas de mision
    mision = true,           -- marcar la mejor recompensa
    misionDetalle = true,    -- tambien al aceptar (no solo al entregar)
    misionVenta = true,      -- si ninguna es mejora, marcar la que mas vale vendida
    misionChat = true,       -- decirlo en el chat
    -- Botin
    tiradas = true,          -- avisar en las tiradas de botin del grupo
    bolsas = true,           -- avisar cuando te llega a las bolsas una mejora
    avisoChat = true,
    avisoSonido = true,
    sonido = "IG_QUEST_LIST_COMPLETE",
    -- Rol y pesos (perfil["CLASE"] = "auto" o la clave de un perfil; pesos["CLASE|perfil"][stat] = numero)
    perfil = {},
    pesos = {},
}

local mod
local issecret = issecretvalue or function() return false end
local cache = {}             -- link -> datos leidos del objeto
local avisados = {}          -- link -> true (no repetir el aviso de bolsas en la sesion)
local vistos                 -- links que habia en las bolsas (para saber que es nuevo)
local overlays = {}

local function Num(v) if type(v) == "number" and not issecret(v) then return v end end
local function Str(v) if type(v) == "string" and not issecret(v) and v ~= "" then return v end end

local KITS = { { "IG_QUEST_LIST_COMPLETE", "Misión completada" }, { "READY_CHECK", "Comprobación de listos" },
               { "RAID_WARNING", "Aviso de banda" }, { "IG_PVP_UPDATE", "Aviso JcJ" }, { "ALARM_CLOCK_WARNING_3", "Alarma" } }
local NUM_KIT = { RAID_WARNING = 8959, ALARM_CLOCK_WARNING_3 = 12889, IG_PVP_UPDATE = 8174, READY_CHECK = 8960, IG_QUEST_LIST_COMPLETE = 878 }
local function Sonar()
    if not mod.db.avisoSonido then return end
    local id = (SOUNDKIT and SOUNDKIT[mod.db.sonido]) or NUM_KIT[mod.db.sonido]
    if id then pcall(PlaySound, id, "Master") end
end

local function Coma(x, dec) return (string.format("%." .. (dec or 1) .. "f", x):gsub("%.", ",")) end
local function Hex(c) return string.format("|cff%02x%02x%02x", math.floor(c[1] * 255), math.floor(c[2] * 255), math.floor(c[3] * 255)) end

----------------------------------------------------------------------
-- Clase y perfil
----------------------------------------------------------------------
local function Clase() return Hub.ClaseJugador() end

local function Conoce(id)
    if IsPlayerSpell then local ok, v = pcall(IsPlayerSpell, id); if ok and v == true then return true end end
    if IsSpellKnown then local ok, v = pcall(IsSpellKnown, id); if ok and v == true then return true end end
    return false
end

local function Perfiles(clase) return P.PERFILES[clase or Clase()] or {} end
local function NombrePerfil(clase, key)
    for _, p in ipairs(Perfiles(clase)) do if p[1] == key then return p[2] end end
    return key
end

local function PerfilAuto(clase)
    local lista = Perfiles(clase)
    if #lista == 0 then return nil end
    if clase == "DRUID" and GetShapeshiftFormID then
        local ok, f = pcall(GetShapeshiftFormID)
        f = ok and Num(f)
        if f and P.FORMA_DRUIDA[f] then return P.FORMA_DRUIDA[f] end
    end
    for _, pista in ipairs(P.PISTAS[clase] or {}) do
        for _, id in ipairs(pista[2]) do if Conoce(id) then return pista[1] end end
    end
    return lista[1][1]
end

-- Perfil que se usa ahora (el elegido en la pestana o el automatico) y si es automatico.
local function PerfilActual(clase)
    clase = clase or Clase()
    local elegido = mod.db.perfil[clase or "?"] or "auto"
    if elegido ~= "auto" then
        for _, p in ipairs(Perfiles(clase)) do if p[1] == elegido then return elegido, false end end
    end
    return PerfilAuto(clase), true
end

local function PesosBase(clase, perfil)
    for _, p in ipairs(Perfiles(clase)) do if p[1] == perfil then return p[3] end end
    return {}
end
local function Peso(clase, perfil, stat)
    local u = mod.db.pesos[(clase or "?") .. "|" .. (perfil or "?")]
    if u and u[stat] ~= nil then return u[stat] end
    return PesosBase(clase, perfil)[stat] or 0
end
local function SetPeso(clase, perfil, stat, v)
    local k = clase .. "|" .. perfil
    mod.db.pesos[k] = mod.db.pesos[k] or {}
    mod.db.pesos[k][stat] = v
end

----------------------------------------------------------------------
-- Lectura de objetos
----------------------------------------------------------------------
local RANGO = { INVTYPE_RANGED = true, INVTYPE_RANGEDRIGHT = true, INVTYPE_THROWN = true }

local function IdDe(link)
    local id = Str(link) and link:match("item:(%d+)")
    return id and tonumber(id)
end

local function InfoObjeto(link)
    local fn = (C_Item and C_Item.GetItemInfo) or GetItemInfo
    if not fn then return nil end
    local r = { pcall(fn, link) }
    if not r[1] or not Str(r[2]) then
        if C_Item and C_Item.RequestLoadItemDataByID and IdDe(link) then pcall(C_Item.RequestLoadItemDataByID, IdDe(link)) end
        return nil
    end
    return { nombre = r[2], link = r[3] or link, calidad = Num(r[4]), nivelMin = Num(r[6]) or 0, equipLoc = Str(r[10]),
             venta = Num(r[12]) or 0, clase = Num(r[13]), subclase = Num(r[14]) }
end

local function StatsJuego(link)
    local fn = (C_Item and C_Item.GetItemStats) or GetItemStats
    if not fn then return {} end
    local ok, t = pcall(fn, link)
    if not ok or type(t) ~= "table" then return {} end
    return t
end

local function LineasTooltip(link)
    if not (C_TooltipInfo and C_TooltipInfo.GetHyperlink) then return {} end
    local ok, data = pcall(C_TooltipInfo.GetHyperlink, link)
    local res = {}
    if ok and type(data) == "table" and type(data.lines) == "table" then
        for _, l in ipairs(data.lines) do
            local t = Str(l.leftText)
            if t then res[#res + 1] = t end
        end
    end
    return res
end

-- Lee las estadisticas de un efecto «Equipar:» (sin tildes ni mayusculas que importen).
local TILDES = { ["á"] = "a", ["é"] = "e", ["í"] = "i", ["ó"] = "o", ["ú"] = "u", ["ü"] = "u", ["ñ"] = "n",
                 ["Á"] = "a", ["É"] = "e", ["Í"] = "i", ["Ó"] = "o", ["Ú"] = "u", ["Ñ"] = "n" }
local function SinTildes(s)
    s = s:lower()
    for k, v in pairs(TILDES) do s = s:gsub(k, v) end
    return s
end

local function LeerEquipar(texto, stats, ya)
    local t = SinTildes(texto)
    if not (t:find("^equipar") or t:find("^equip:")) then return end
    for _, def in ipairs(P.TEXTO) do
        for _, pat in ipairs(def[2]) do
            local v = t:match(pat)
            if v then
                if not ya[def[1]] then stats[def[1]] = (stats[def[1]] or 0) + tonumber(v) end
                return
            end
        end
    end
end

local function Leer(link)
    if not Str(link) then return nil end
    local c = cache[link]
    if c then return c end
    local info = InfoObjeto(link)
    if not info then return nil end
    local stats, ya = {}, {}
    for k, v in pairs(StatsJuego(link)) do
        local key = P.CLAVES[k]
        v = Num(v)
        if key and v then stats[key] = (stats[key] or 0) + v; ya[key] = true end
    end
    if RANGO[info.equipLoc or ""] and stats.dps then stats.dpsd, stats.dps = stats.dps, nil; ya.dpsd = true end
    if mod.db.leerTexto then
        for _, l in ipairs(LineasTooltip(link)) do LeerEquipar(l, stats, ya) end
    end
    info.stats = stats
    cache[link] = info
    return info
end

local function Puntos(info, clase, perfil)
    if not info then return 0 end
    local s = 0
    for k, v in pairs(info.stats) do s = s + v * Peso(clase, perfil, k) end
    return s
end

local function NivelJugador() local ok, n = pcall(UnitLevel, "player"); return ok and Num(n) or 1 end

local NOMBRE_ARMADURA = { [1] = "tela", [2] = "cuero", [3] = "malla", [4] = "placas", [6] = "escudos", [7] = "tratados", [8] = "ídolos", [9] = "tótems" }
-- true / false, motivo
local function Puede(info, clase)
    if not info or not clase then return true end
    if info.clase == 2 then
        local ok = P.ARMAS[clase] and P.ARMAS[clase][info.subclase or -1]
        if not ok then return false, "tu clase no usa esta arma" end
    elseif info.clase == 4 and info.subclase and info.subclase ~= 0 and info.equipLoc ~= "INVTYPE_CLOAK" then
        local nivel = P.ARMADURAS[clase] and P.ARMADURAS[clase][info.subclase]
        local nombre = NOMBRE_ARMADURA[info.subclase] or "esta armadura"
        if not nivel then return false, "tu clase no lleva " .. nombre end
        if NivelJugador() < nivel then return false, nombre .. " a partir del nivel " .. nivel end
        if mod.db.soloPrincipal and info.subclase <= 4 then
            local pr = P.PRINCIPAL[clase]
            local tipo = pr and (NivelJugador() >= 40 and pr[2] or pr[1])
            if tipo and info.subclase ~= tipo then return false, "no es tu tipo principal (" .. (NOMBRE_ARMADURA[tipo] or "?") .. ")" end
        end
    end
    return true
end

local function Ambidiestro(clase)
    local a = P.AMBIDIESTRO[clase]
    if a == true then return true end
    if type(a) == "number" then return Conoce(a) end
    return false
end

local function Equipado(slot)
    local ok, link = pcall(GetInventoryItemLink, "player", slot)
    return ok and Str(link) or nil
end

local function EsDosManos(link)
    local i = link and Leer(link)
    return i and i.equipLoc == "INVTYPE_2HWEAPON"
end

-- Suma de estadisticas de varios objetos (para el detalle cuando un arma de dos manos sustituye a dos).
local function Suma(lista)
    local s = {}
    for _, i in ipairs(lista) do for k, v in pairs(i.stats) do s[k] = (s[k] or 0) + v end end
    return s
end

-- Compara un objeto con lo que llevas. Devuelve una tabla o nil si no es equipable o aun no se ha cargado.
local function Comparar(link, clase, perfil)
    local info = Leer(link)
    if not info or not info.equipLoc then return nil end
    local ranuras = P.RANURAS[info.equipLoc]
    if not ranuras then return nil end
    clase = clase or Clase()
    if not perfil then perfil = PerfilActual(clase) end
    local r = { info = info, perfil = perfil, clase = clase }
    r.usable, r.motivo = Puede(info, clase)
    if info.nivelMin > NivelJugador() then r.nivel = info.nivelMin end
    r.nuevo = Puntos(info, clase, perfil)

    local candidatos = {}
    if info.equipLoc == "INVTYPE_2HWEAPON" then
        local mh, oh = Equipado(16), Equipado(17)
        if mh == link then r.puesto = true; return r end
        local piezas = {}
        if mh and Leer(mh) then piezas[#piezas + 1] = Leer(mh) end
        if oh and Leer(oh) and not EsDosManos(mh) then piezas[#piezas + 1] = Leer(oh) end
        local viejo = 0
        for _, p in ipairs(piezas) do viejo = viejo + Puntos(p, clase, perfil) end
        candidatos[1] = { slot = 16, link = mh, viejo = viejo, stats = Suma(piezas), vacio = #piezas == 0,
                          nota = (#piezas == 2) and "frente a tus dos armas" or nil }
    else
        local lista = ranuras
        if info.equipLoc == "INVTYPE_WEAPON" and not Ambidiestro(clase) then lista = { 16 } end
        local mh = Equipado(16)
        for _, slot in ipairs(lista) do
            local eq = Equipado(slot)
            if slot == 17 and EsDosManos(mh) then
                -- Llevas un arma de dos manos: lo de la mano izquierda no se compara solo.
                if #lista == 1 then r.nota = "llevas un arma de dos manos"; r.sinComparar = true; return r end
            elseif slot == 16 and EsDosManos(eq) and info.equipLoc ~= "INVTYPE_2HWEAPON" then
                local i = Leer(eq)
                candidatos[#candidatos + 1] = { slot = 16, link = eq, viejo = Puntos(i, clase, perfil), stats = i and i.stats or {},
                                                nota = "frente a tu arma de dos manos" }
            else
                local i = eq and Leer(eq)
                if eq and not i then return nil end   -- lo que llevas aun no se ha cargado
                candidatos[#candidatos + 1] = { slot = slot, link = eq, viejo = i and Puntos(i, clase, perfil) or 0,
                                                stats = i and i.stats or {}, vacio = not eq }
                if eq == link then r.puesto = true end
            end
        end
    end
    if r.puesto then return r end
    if #candidatos == 0 then return nil end
    -- Con dos ranuras: la peor (la que mas mejora) o la mejor (comparacion prudente).
    local elegido = candidatos[1]
    for i = 2, #candidatos do
        local c = candidatos[i]
        if c.vacio and not elegido.vacio then elegido = c
        elseif not elegido.vacio and not c.vacio then
            if mod.db.dosRanuras == "peor" and c.viejo < elegido.viejo then elegido = c end
            if mod.db.dosRanuras == "mejor" and c.viejo > elegido.viejo then elegido = c end
        end
    end
    r.slot, r.contra, r.viejo, r.vacio = elegido.slot, elegido.link, elegido.viejo, elegido.vacio
    r.nota = r.nota or elegido.nota
    r.diff = r.nuevo - r.viejo
    if not r.vacio and r.viejo > 0.001 then r.pct = r.diff / r.viejo * 100 end
    -- Detalle: lo que cambia de cada estadistica, ordenado por lo que pesa.
    local det, claves = {}, {}
    for k in pairs(info.stats) do claves[k] = true end
    for k in pairs(elegido.stats or {}) do claves[k] = true end
    for k in pairs(claves) do
        local d = (info.stats[k] or 0) - ((elegido.stats or {})[k] or 0)
        if math.abs(d) > 0.001 then det[#det + 1] = { k = k, d = d, w = math.abs(d * Peso(clase, perfil, k)) } end
    end
    table.sort(det, function(a, b) if a.w ~= b.w then return a.w > b.w end return a.k < b.k end)
    r.detalle = det
    return r
end

-- "mejor" | "peor" | "igual" | "vacio" | nil (no se compara)
local function Veredicto(r)
    if not r or r.puesto or r.sinComparar or not r.usable then return nil end
    if r.vacio then return r.nuevo > 0 and "vacio" or "igual" end
    if r.pct then
        if r.pct >= mod.db.umbral then return "mejor" end
        if r.pct <= -mod.db.umbral then return "peor" end
        return "igual"
    end
    if r.diff > 0.001 then return "mejor" elseif r.diff < -0.001 then return "peor" end
    return "igual"
end
local function EsMejora(r) local v = Veredicto(r); return v == "mejor" or v == "vacio" end

local function TextoPct(r)
    if r.vacio then return "ranura vacía" end
    if r.pct then return (r.pct >= 0 and "+" or "") .. Coma(r.pct) .. " %" end
    return (r.diff >= 0 and "+" or "") .. Coma(r.diff) .. " puntos"
end

----------------------------------------------------------------------
-- Tooltip
----------------------------------------------------------------------
local function LineasDe(r)
    local db = mod.db
    local lineas = {}
    local pref = "Mejoradoor" .. (db.verPerfil and (" (" .. NombrePerfil(r.clase, r.perfil) .. ")") or "") .. ": "
    if r.puesto then
        if db.verPuesto then lineas[1] = { pref .. "lo llevas puesto", db.colorIgual } end
        return lineas
    end
    if not r.usable then
        if db.verNoUsable then lineas[1] = { pref .. "no puedes llevarlo (" .. (r.motivo or "?") .. ")", db.colorPeor } end
        return lineas
    end
    if r.sinComparar then lineas[1] = { pref .. (r.nota or "no se puede comparar"), db.colorIgual }; return lineas end
    local v = Veredicto(r)
    local color = (v == "mejor" or v == "vacio") and db.colorMejor or (v == "peor" and db.colorPeor or db.colorIgual)
    local palabra = (v == "mejor" and "mejora") or (v == "vacio" and "mejora") or (v == "peor" and "peor") or "igual"
    local txt = pref .. TextoPct(r) .. " · " .. palabra
    if r.nivel then txt = txt .. " (a nivel " .. r.nivel .. ")" end
    lineas[1] = { txt, color }
    if r.nota then lineas[#lineas + 1] = { "   " .. r.nota, db.colorIgual } end
    if db.verPuntos then
        lineas[#lineas + 1] = { "   puntos: " .. Coma(r.nuevo) .. " frente a " .. Coma(r.viejo or 0), db.colorIgual }
    end
    if db.verDetalle and r.detalle and #r.detalle > 0 then
        local partes = {}
        for i = 1, math.min(db.detalleMax, #r.detalle) do
            local d = r.detalle[i]
            local c = d.d > 0 and db.colorMejor or db.colorPeor
            local n = math.abs(d.d) >= 10 and tostring(math.floor(d.d + (d.d > 0 and 0.5 or -0.5))) or Coma(d.d)
            partes[#partes + 1] = Hex(c) .. (d.d > 0 and "+" or "") .. n .. " " .. (P.NOMBRE[d.k] or d.k) .. "|r"
        end
        lineas[#lineas + 1] = { "   " .. table.concat(partes, ", "), db.colorIgual }
    end
    return lineas
end

local function OnTooltipItem(tt, data)
    if not (mod and mod.enabled and mod.db and mod.db.tooltip) then return end
    if tt.IsForbidden and tt:IsForbidden() then return end
    local nombre = tt.GetName and tt:GetName()
    if type(nombre) == "string" and nombre:find("ShoppingTooltip") then return end
    if mod.db.soloMayus and not (IsShiftKeyDown and IsShiftKeyDown()) then return end
    local link
    if tt.GetItem then local ok, _, l = pcall(tt.GetItem, tt); if ok then link = Str(l) end end
    if not link and data and Str(data.hyperlink) then link = data.hyperlink end
    if not link then return end
    local ok, r = pcall(Comparar, link)
    if not ok or not r then return end
    for _, l in ipairs(LineasDe(r)) do tt:AddLine(l[1], l[2][1], l[2][2], l[2][3], true) end
end

----------------------------------------------------------------------
-- Recompensas de mision
----------------------------------------------------------------------
local function BotonRecompensa(i)
    local frame = QuestInfoRewardsFrame
    if frame and frame.RewardButtons then
        for _, b in ipairs(frame.RewardButtons) do
            if b.type == "choice" and b.GetID and b:GetID() == i and (not b.IsShown or b:IsShown()) then return b end
        end
    end
    return _G["QuestInfoRewardsFrameQuestInfoItem" .. i] or _G["QuestInfoItem" .. i]
end

local function QuitarMarcas() for _, t in pairs(overlays) do t:Hide() end end

local function Marcar(boton, tipo)
    if not boton then return end
    local t = overlays[boton]
    if not t then
        t = boton:CreateTexture(nil, "OVERLAY", nil, 7)
        t:SetSize(22, 22)
        local ancla = boton.Icon or boton.icon or _G[(boton.GetName and boton:GetName() or "") .. "IconTexture"] or boton
        t:SetPoint("TOPLEFT", ancla, "TOPLEFT", -6, 6)
        overlays[boton] = t
    end
    t:SetTexture(tipo == "venta" and "Interface\\MoneyFrame\\UI-GoldIcon" or "Interface\\RaidFrame\\ReadyCheck-Ready")
    t:Show()
end

local function MarcarRecompensas()
    QuitarMarcas()
    if not (mod.enabled and mod.db.mision) then return end
    local n = GetNumQuestChoices and Num(GetNumQuestChoices()) or 0
    if n < 1 then return end
    local mejor, mejorI, venta, ventaI, pendiente = nil, nil, -1, nil, false
    for i = 1, n do
        local link = GetQuestItemLink and Str(GetQuestItemLink("choice", i))
        local r = link and Comparar(link)
        local info = link and Leer(link)
        if link and not info then pendiente = true end
        if r and EsMejora(r) then
            local val = r.vacio and (1e6 + r.nuevo) or (r.pct or r.diff)
            if not mejor or val > mejor then mejor, mejorI = val, i end
        end
        if info and (info.venta or 0) > venta then venta, ventaI = info.venta, i end
    end
    if pendiente then
        -- Algun objeto aun no estaba en la cache del juego: se reintenta una vez.
        if not mod._reintento then mod._reintento = true; C_Timer.After(0.6, MarcarRecompensas) end
    end
    mod._reintento = nil
    if mejorI then
        Marcar(BotonRecompensa(mejorI), "mejora")
        if mod.db.misionChat then
            local link = GetQuestItemLink("choice", mejorI)
            local r = Comparar(link)
            mod:Print("la mejor recompensa para ti es " .. link .. " (" .. TextoPct(r) .. ").")
        end
    elseif mod.db.misionVenta and ventaI and venta > 0 then
        Marcar(BotonRecompensa(ventaI), "venta")
        if mod.db.misionChat then
            mod:Print("ninguna recompensa es mejora; la que más vale vendida es " .. GetQuestItemLink("choice", ventaI) .. ".")
        end
    end
end

----------------------------------------------------------------------
-- Botin: tiradas y bolsas
----------------------------------------------------------------------
local function Avisar(texto)
    if mod.db.avisoChat then mod:Print(texto) end
    Sonar()
end

local function LinksBolsas()
    local res = {}
    if not (C_Container and C_Container.GetContainerNumSlots) then return res end
    local ultima = NUM_BAG_SLOTS or 4
    for bag = 0, ultima do
        local ok, n = pcall(C_Container.GetContainerNumSlots, bag)
        for slot = 1, (ok and Num(n) or 0) do
            local ok2, link = pcall(C_Container.GetContainerItemLink, bag, slot)
            if ok2 and Str(link) then res[#res + 1] = link end
        end
    end
    return res
end

local function MejorasEnBolsas()
    local res = {}
    for _, link in ipairs(LinksBolsas()) do
        local r = Comparar(link)
        if r and EsMejora(r) and not r.nivel then res[#res + 1] = r end
    end
    return res
end

local function RevisarBolsas()
    if not (mod.enabled and mod.db.bolsas) then return end
    local ahora = {}
    for _, link in ipairs(LinksBolsas()) do ahora[link] = true end
    if not vistos then vistos = ahora; return end   -- primera lectura: lo que ya tenias no se avisa
    for link in pairs(ahora) do
        if not vistos[link] and not avisados[link] then
            local r = Comparar(link)
            if r and EsMejora(r) then
                avisados[link] = true
                Avisar("te ha llegado una mejora: " .. link .. " (" .. TextoPct(r) .. ", " .. (P.NOMBRE_RANURA[r.slot] or "?") .. ")"
                    .. (r.nivel and (", a nivel " .. r.nivel) or "") .. ".")
            end
        end
    end
    vistos = ahora
end

----------------------------------------------------------------------
-- Comandos
----------------------------------------------------------------------
local function ListarBolsas()
    local l = MejorasEnBolsas()
    if #l == 0 then mod:Print("no tienes mejoras en las bolsas para " .. NombrePerfil(nil, PerfilActual()) .. "."); return end
    mod:Print("mejoras en tus bolsas (" .. NombrePerfil(nil, PerfilActual()) .. "):")
    for _, r in ipairs(l) do mod:Print("  " .. r.info.link .. " " .. TextoPct(r) .. " (" .. (P.NOMBRE_RANURA[r.slot] or "?") .. ")") end
end

local function OnSlash(m, msg)
    msg = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    if msg == "bolsas" then ListarBolsas()
    elseif msg == "perfil" then
        local p, auto = PerfilActual()
        m:Print("perfil: " .. NombrePerfil(nil, p) .. (auto and " (automático)" or " (elegido a mano)"))
    elseif msg == "pesos" then
        local c, p = Clase(), PerfilActual()
        local partes = {}
        for _, s in ipairs(P.STATS) do
            local w = Peso(c, p, s[1])
            if w ~= 0 then partes[#partes + 1] = s[2] .. " " .. Coma(w, 2) end
        end
        m:Print(NombrePerfil(c, p) .. ": " .. table.concat(partes, "; "))
    else
        Hub:Open("mejoradoor")
        if msg ~= "" then m:Print("/mejoradoor bolsas | perfil | pesos") end
    end
end

----------------------------------------------------------------------
-- Pestana
----------------------------------------------------------------------
local function BuildConfig(m, L)
    local db = m.db
    local clase = Clase()
    L:Header("Comparador de equipo")
    L:Text("En el tooltip de cada objeto dice si es una mejora para tu clase y tu rol, y cuánto. La puntuación es la suma de cada estadística por su peso; los pesos de cada perfil se cambian abajo.", true)
    L:Check("Línea en el tooltip de los objetos", function() return db.tooltip end, function(v) db.tooltip = v end)
    L:Check("Solo con Mayús pulsada", function() return db.soloMayus end, function(v) db.soloMayus = v end)
    L:Check("Poner el nombre del perfil", function() return db.verPerfil end, function(v) db.verPerfil = v end)
    L:Check("Enseñar la puntuación (la nueva y la tuya)", function() return db.verPuntos end, function(v) db.verPuntos = v end)
    L:Check("Detalle: lo que ganas y lo que pierdes", function() return db.verDetalle end, function(v) db.verDetalle = v end)
    L:Slider("Estadísticas en el detalle", 1, 8, 1, function() return db.detalleMax end, function(v) db.detalleMax = v end)
    L:Check("Decir «lo llevas puesto» en tu equipo", function() return db.verPuesto end, function(v) db.verPuesto = v end)
    L:Check("Decir «no puedes llevarlo» (arma o armadura de otra clase)", function() return db.verNoUsable end, function(v) db.verNoUsable = v end)
    L:Check("Solo tu tipo principal de armadura (p. ej. placas para guerrero desde el 40)", function() return db.soloPrincipal end, function(v) db.soloPrincipal = v; wipe(cache) end)
    L:Slider("Diferencia mínima para llamarlo mejora (%)", 0, 10, 0.5, function() return db.umbral end, function(v) db.umbral = v end, "%.1f")
    L:Choice("Anillos, abalorios y armas a una mano", { { "peor", "Contra la peor de las dos" }, { "mejor", "Contra la mejor de las dos" } },
        function() return db.dosRanuras end, function(v) db.dosRanuras = v end)
    L:Check("Leer los efectos «Equipar:» del texto del objeto", function() return db.leerTexto end, function(v) db.leerTexto = v; wipe(cache) end)
    L:Color("Color de mejora", function() return unpack(db.colorMejor) end, function(r, g, b) db.colorMejor = { r, g, b } end)
    L:Color("Color de peor", function() return unpack(db.colorPeor) end, function(r, g, b) db.colorPeor = { r, g, b } end)
    L:Color("Color de igual y notas", function() return unpack(db.colorIgual) end, function(r, g, b) db.colorIgual = { r, g, b } end)

    L:Header("Tu rol")
    if not clase or #Perfiles(clase) == 0 then
        L:Text("Aún no se sabe tu clase: entra con un personaje y vuelve a abrir la pestaña.", true)
    else
        local detectado = L:Text("", true)
        detectado.Refresh = function(s)
            local p, auto = PerfilActual(clase)
            s:SetText("Ahora se usa: |cffffd100" .. NombrePerfil(clase, p) .. "|r" .. (auto and " (automático, por tus talentos" .. (clase == "DRUID" and " y tu forma" or "") .. ")" or " (elegido a mano)"))
        end
        L:Add(detectado, 0)
        local ops = { { "auto", "Automático" } }
        for _, p in ipairs(Perfiles(clase)) do ops[#ops + 1] = { p[1], p[2] } end
        L:Choice("Perfil de " .. ((LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[clase]) or clase),
            ops, function() return db.perfil[clase] or "auto" end, function(v) db.perfil[clase] = v; L:Refresh() end)

        L:Header("Pesos")
        L:Text("Cuánto vale cada punto de estadística en el perfil que elijas aquí (los % de crítico, acierto, esquivar... cuentan por cada 1 %). 0 = no cuenta.", true)
        local editando = { perfil = Perfiles(clase)[1][1] }
        local opsP = {}
        for _, p in ipairs(Perfiles(clase)) do opsP[#opsP + 1] = { p[1], p[2] } end
        L:Choice("Perfil que editas", opsP, function() return editando.perfil end, function(v) editando.perfil = v; L:Refresh() end)
        for _, s in ipairs(P.STATS) do
            local stat = s[1]
            L:Edit(s[2], function() return Peso(clase, editando.perfil, stat) end,
                function(v) SetPeso(clase, editando.perfil, stat, v) end, "number", 70)
        end
        L:Button("Restaurar los pesos de este perfil", 240, function()
            db.pesos[clase .. "|" .. editando.perfil] = nil
            L:Refresh()
            m:Print("pesos de " .. NombrePerfil(clase, editando.perfil) .. " restaurados.")
        end)
    end

    L:Header("Recompensas de misión")
    L:Check("Marcar la mejor recompensa (marca verde sobre el icono)", function() return db.mision end, function(v) db.mision = v; if not v then QuitarMarcas() end end)
    L:Check("También al aceptar la misión (no solo al entregarla)", function() return db.misionDetalle end, function(v) db.misionDetalle = v end)
    L:Check("Si ninguna es mejora, marcar la que más vale vendida (moneda)", function() return db.misionVenta end, function(v) db.misionVenta = v end)
    L:Check("Decirlo en el chat", function() return db.misionChat end, function(v) db.misionChat = v end)

    L:Header("Botín")
    L:Check("Avisar en las tiradas de botín si el objeto es mejora", function() return db.tiradas end, function(v) db.tiradas = v end)
    L:Check("Avisar cuando te llega a las bolsas una mejora", function() return db.bolsas end, function(v) db.bolsas = v; vistos = nil end)
    L:Check("Avisos en el chat", function() return db.avisoChat end, function(v) db.avisoChat = v end)
    L:Check("Sonido en los avisos", function() return db.avisoSonido end, function(v) db.avisoSonido = v end)
    L:Choice("Sonido", KITS, function() return db.sonido end, function(v) db.sonido = v; local s = db.avisoSonido; db.avisoSonido = true; Sonar(); db.avisoSonido = s end)
    L:Button("Ver las mejoras que llevas en las bolsas", 280, ListarBolsas)
    L:Text("Comandos: /mejoradoor bolsas, /mejoradoor perfil, /mejoradoor pesos.", true)
end

mod = Hub:Register{
    key = "mejoradoor", dir = "Mejoradoor", name = "Mejoradoor",
    desc = "Comparador de equipo: te dice en cada objeto si es una mejora para tu clase y tu rol, marca la mejor recompensa de misión y avisa del botín que te conviene.",
    defaults = DEFAULTS,
    slash = { "mejoradoor", "cmmejora" },
    OnSlash = OnSlash,
    BuildConfig = BuildConfig,
    rightHint = "mejoras en tus bolsas",
    OnRightClick = function() ListarBolsas() end,
    OnReset = function() wipe(cache); QuitarMarcas() end,
    Init = function(m)
        if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType
           and Enum.TooltipDataType.Item then
            pcall(TooltipDataProcessor.AddTooltipPostCall, Enum.TooltipDataType.Item, OnTooltipItem)
        elseif GameTooltip and GameTooltip.HookScript then
            pcall(GameTooltip.HookScript, GameTooltip, "OnTooltipSetItem", function(tt) OnTooltipItem(tt) end)
        end
        m:Event("QUEST_COMPLETE", function() C_Timer.After(0.2, MarcarRecompensas) end)
        m:Event("QUEST_DETAIL", function() if m.db.misionDetalle then C_Timer.After(0.2, MarcarRecompensas) else QuitarMarcas() end end)
        m:Event("QUEST_FINISHED", function() QuitarMarcas() end)
        m:Event("START_LOOT_ROLL", function(_, _, rollID)
            if not m.db.tiradas or not GetLootRollItemLink then return end
            local ok, link = pcall(GetLootRollItemLink, rollID)
            link = ok and Str(link)
            local r = link and Comparar(link)
            if r and EsMejora(r) then
                Avisar("tirada: " .. link .. " es una mejora para ti (" .. TextoPct(r) .. (r.nivel and (", a nivel " .. r.nivel) or "") .. ").")
            end
        end)
        m:Event("BAG_UPDATE_DELAYED", function() RevisarBolsas() end)
        m:Event("PLAYER_LEVEL_UP", function() wipe(cache) end)
    end,
    Enable = function(m)
        vistos = nil
        C_Timer.After(3, function() if m.enabled then RevisarBolsas() end end)
    end,
    Disable = function() QuitarMarcas(); vistos = nil end,
}

-- Para las pruebas y para otros modulos.
ns.Mejoradoor = { Leer = Leer, Comparar = Comparar, Veredicto = Veredicto, PerfilActual = PerfilActual, Puede = Puede,
                  Peso = Peso, SetPeso = SetPeso, Lineas = LineasDe, MarcarRecompensas = MarcarRecompensas,
                  LimpiarCache = function() wipe(cache) end, OnTooltipItem = OnTooltipItem, overlays = overlays }
