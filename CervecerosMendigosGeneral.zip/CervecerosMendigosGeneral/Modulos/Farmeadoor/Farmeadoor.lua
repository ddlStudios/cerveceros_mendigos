-- Farmeadoor (CervecerosMendigos General) para WoW Forever (Interface 16001).
-- Menas, plantas y bancos de peces en el mapa del mundo y en el minimapa, desde el primer momento:
--   * datos precargados (Datos.lua): QuestieDB (equipo de Questie, GPLv3) y CMaNGOS classic-db (GPL-3.0)
--   * aprende lo que recoges y no estaba en el mapa (y lo comparte con la hermandad / el grupo)
--   * actualizar: pedir sus puntos aprendidos a la hermandad, exportar / importar un texto
-- Licencia: GPL-3.0 (ver LICENSE.txt del addon).

local ADDON, ns = ...
local Hub = ns.Hub
local D = ns.FarmDatos or { tipos = {}, objetos = {}, puntos = {}, version = "?" }
local issecret = issecretvalue or function() return false end
local atan2 = math.atan2 or function(y, x) return math.atan(y, x) end

local PREFIX, PROTO = "CMFarm", "1"
local SKILL_ID = { herb = 182, ore = 186, fish = 356 }
local CAT_NAME = { herb = "Plantas", ore = "Menas", fish = "Pesca" }
local CAT_ICON = { herb = "Interface\\Icons\\INV_Misc_Herb_07", ore = "Interface\\Icons\\INV_Ore_Copper_01",
                   fish = "Interface\\Icons\\INV_Misc_Fish_02" }
local FISH_ES = {
    fishschool = "Banco de peces", tastyfish = "Banco de pez sabroso", blackmouth = "Banco de boquinegro aceitoso",
    firefin = "Banco de pargo aletafuego", sagefish = "Banco de salvia", greatersagefish = "Banco de salvia superior",
    deviate = "Banco de pez desviado", stonescale = "Enjambre de anguila escamapiedra", oilspill = "Mancha de aceite",
    elemental = "Agua elemental", wreckage = "Restos flotantes", debris = "Escombros flotantes",
}
-- hechizos de recoleccion (para reconocer menas/plantas que no estan en los datos)
local GATHER_SPELLS = { [2575] = "ore", [2576] = "ore", [3564] = "ore", [10248] = "ore",
                        [2366] = "herb", [2368] = "herb", [3570] = "herb", [11993] = "herb" }
local BOBBER = 35591   -- corcho de pesca: pescar en agua abierta no es un banco

local DEFAULTS = {
    show = { herb = true, ore = true, fish = true },   -- categorias
    hidden = {},             -- tipos ocultos: hidden[clave] = true
    onlySkill = false,       -- ocultar lo que tu habilidad aun no puede recoger
    dimHigh = true,          -- ...o mostrarlo atenuado
    noProfHide = false,      -- ocultar categorias de profesiones que no tienes
    map = { on = true, size = 12, alpha = 90, max = 2500 },
    mini = { on = true, size = 12, alpha = 100, max = 60, edge = false },
    tooltip = true,          -- tooltip al pasar el raton por un punto del mapa
    learn = true,            -- apuntar lo que recojo y no esta en el mapa
    learnChat = true,        -- avisar en el chat al aprender un punto nuevo
    radius = 12,             -- yardas: mas cerca que esto de un punto conocido = el mismo punto
    showLearned = true,      -- mostrar los puntos aprendidos (mios y compartidos)
    shareGuild = true, shareGroup = false,   -- enviar los puntos nuevos
    receive = true,          -- recibir puntos de otros
    answer = true,           -- contestar cuando la hermandad pide puntos
    senderLimit = 40,        -- puntos por minuto aceptados de cada emisor
}

local mod, DB
local learnedCache = {}      -- [mapID] = { {x, y, key, by, t}, ... } decodificado
local baseCache = {}         -- [mapID] = { {x, y, key}, ... } decodificado de Datos.lua
local skills = {}            -- cat -> rango
local hasProf = {}

local function Print(msg) if mod then mod:Print(msg) end end
local function Clean(v) if issecret(v) then return nil end return v end

----------------------------------------------------------------------
-- Datos
----------------------------------------------------------------------
local function Decode(s, out, key, extra)
    for i = 1, #s - 7, 8 do
        local x, y = tonumber(s:sub(i, i + 3)), tonumber(s:sub(i + 4, i + 7))
        if x and y then out[#out + 1] = { x = x / 10000, y = y / 10000, key = key, by = extra and extra.by, t = extra and extra.t } end
    end
end

local function Base(mapID)
    local c = baseCache[mapID]
    if c then return c end
    c = {}
    local m = D.puntos and D.puntos[mapID]
    if m then for key, s in pairs(m) do Decode(s, c, key) end end
    baseCache[mapID] = c
    return c
end

-- DB.learned[mapID][key] = { {x, y, by, t}, ... } (x, y en 0..1)
local function Learned(mapID)
    local c = learnedCache[mapID]
    if c then return c end
    c = {}
    local m = DB and DB.learned and DB.learned[mapID]
    if m then
        for key, list in pairs(m) do
            for _, p in ipairs(list) do c[#c + 1] = { x = p[1], y = p[2], key = key, by = p[3], t = p[4], learned = true } end
        end
    end
    learnedCache[mapID] = c
    return c
end

-- tipo de una clave: datos precargados o tipo nuevo aprendido ("o12345")
local function Type(key)
    local t = D.tipos[key]
    if t then return t end
    local c = DB and DB.custom and DB.custom[key]
    if c then return { cat = c.cat, item = 0, skill = 0, en = c.name, icon = c.icon, custom = true } end
    return { cat = "ore", item = 0, skill = 0, en = key }
end

local itemNames = {}
local function TypeName(key)
    local t = Type(key)
    if t.custom then return t.en end
    if t.cat == "fish" then return FISH_ES[key] or t.en end
    if itemNames[key] then return itemNames[key] end
    if t.item and t.item > 0 and C_Item and C_Item.GetItemNameByID then
        local ok, n = pcall(C_Item.GetItemNameByID, t.item)
        if ok and type(n) == "string" and not issecret(n) then itemNames[key] = n; return n end
        if C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, t.item) end
    end
    return t.en
end

local iconCache = {}
local function TypeIcon(key)
    if iconCache[key] then return iconCache[key] end
    local t = Type(key)
    local icon = t.icon
    if not icon and t.item and t.item > 0 and C_Item and C_Item.GetItemIconByID then
        local ok, i = pcall(C_Item.GetItemIconByID, t.item)
        if ok and i and not issecret(i) then icon = i end
    end
    icon = icon or CAT_ICON[t.cat] or CAT_ICON.ore
    iconCache[key] = icon
    return icon
end

----------------------------------------------------------------------
-- Habilidades (C_SkillInfo en Forever; globales en otros clientes)
----------------------------------------------------------------------
local function ReadSkills()
    wipe(skills); wipe(hasProf)
    local c = C_SkillInfo
    local function pick(n) if type(_G[n]) == "function" then return _G[n] end if type(c) == "table" and type(c[n]) == "function" then return c[n] end end
    local num, info = pick("GetNumSkillLines"), pick("GetSkillLineInfo")
    if not (num and info) then return end
    local ok, n = pcall(num)
    if not ok or type(n) ~= "number" then return end
    for i = 1, n do
        local r = { pcall(info, i) }
        if r[1] then
            local id, rank
            if type(r[2]) == "table" then id, rank = r[2].skillID, r[2].rank or r[2].skillRank
            else rank = r[5] end
            local name = type(r[2]) == "table" and (r[2].name or r[2].skillName) or r[2]
            for cat, sid in pairs(SKILL_ID) do
                local match = (id == sid)
                if not match and type(name) == "string" and not issecret(name) and C_Spell and C_Spell.GetSpellName then
                    local es = ({ herb = 2366, ore = 2575, fish = 7620 })[cat]
                    local okn, sn = pcall(C_Spell.GetSpellName, es)
                    match = okn and sn == name
                end
                if match and type(rank) == "number" and not issecret(rank) then skills[cat] = rank; hasProf[cat] = true end
            end
        end
    end
end

-- devuelve: visible, atenuado
local function Visible(key)
    local t = Type(key)
    if not DB.show[t.cat] or DB.hidden[key] then return false end
    if DB.noProfHide and next(hasProf) and not hasProf[t.cat] then return false end
    local need, have = t.skill or 0, skills[t.cat]
    if have and need > have then
        if DB.onlySkill then return false end
        return true, DB.dimHigh
    end
    return true, false
end

----------------------------------------------------------------------
-- Posicion
----------------------------------------------------------------------
local function XY(pos)
    if not pos then return end
    local x, y
    if pos.GetXY then x, y = pos:GetXY() else x, y = pos.x, pos.y end
    if type(x) ~= "number" or type(y) ~= "number" or issecret(x) or issecret(y) then return end
    return x, y
end

local function PlayerPos()
    if not (C_Map and C_Map.GetBestMapForUnit and C_Map.GetPlayerMapPosition) then return end
    local ok, mid = pcall(C_Map.GetBestMapForUnit, "player")
    if not ok or not mid or issecret(mid) then return end
    local ok2, pos = pcall(C_Map.GetPlayerMapPosition, mid, "player")
    if not ok2 then return end
    local x, y = XY(pos)
    if not x or x <= 0 then return end
    local w, h = 0, 0
    if C_Map.GetMapWorldSize then
        local ok3, a, b = pcall(C_Map.GetMapWorldSize, mid)
        if ok3 then w, h = a or 0, b or 0 end
    end
    return mid, x, y, w, h
end

local function Yards(ax, ay, bx, by, w, h)
    if not w or w <= 0 then w, h = 1000, 667 end
    local dx, dy = (ax - bx) * w, (ay - by) * h
    return math.sqrt(dx * dx + dy * dy)
end

----------------------------------------------------------------------
-- Aprender y compartir
----------------------------------------------------------------------
local queue, lastSend = {}, 0
local function Channels()
    local c = {}
    if DB.shareGuild and IsInGuild and IsInGuild() then c[#c + 1] = "GUILD" end
    if DB.shareGroup and IsInGroup and IsInGroup() then
        local inst = LE_PARTY_CATEGORY_INSTANCE
        c[#c + 1] = (inst and IsInGroup(inst) and "INSTANCE_CHAT") or ((IsInRaid and IsInRaid()) and "RAID") or "PARTY"
    end
    return c
end
local function Send(msg, chans)
    for _, ch in ipairs(chans or Channels()) do
        if #queue < 400 then queue[#queue + 1] = { msg = msg, chan = ch, t = GetTime() } end
    end
end
local function Flush()
    if not queue[1] then return end
    local now = GetTime()
    if now - lastSend < 0.3 then return end
    if InCombatLockdown and InCombatLockdown() then return end
    local q = table.remove(queue, 1)
    if now - q.t > 300 then return end
    lastSend = now
    local ok, res = pcall(C_ChatInfo.SendAddonMessage, PREFIX, q.msg, q.chan)
    if not ok or (res ~= nil and res ~= 0 and res ~= true) then table.insert(queue, 1, q) end
end

local function Pack(v) return string.format("%04d", math.max(0, math.min(9999, math.floor(v * 10000 + 0.5)))) end

local function SafeLabel(s)
    if type(s) ~= "string" or issecret(s) then return nil end
    s = s:gsub("[%c|]", ""):sub(1, 40)
    return s ~= "" and s or nil
end

-- Mete un punto aprendido si no hay ya uno (precargado o aprendido) del mismo tipo cerca.
-- Devuelve true si es nuevo.
local function AddLearned(mapID, key, x, y, by, w, h)
    if not (mapID and key and x and y) or x <= 0 or y <= 0 or x >= 1 or y >= 1 then return false end
    if not w then
        if C_Map and C_Map.GetMapWorldSize then
            local ok, a, b = pcall(C_Map.GetMapWorldSize, mapID)
            if ok then w, h = a, b end
        end
    end
    local r = DB.radius or 12
    for _, p in ipairs(Base(mapID)) do
        if p.key == key and Yards(p.x, p.y, x, y, w, h) < r then return false end
    end
    for _, p in ipairs(Learned(mapID)) do
        if p.key == key and Yards(p.x, p.y, x, y, w, h) < r then return false end
    end
    DB.learned[mapID] = DB.learned[mapID] or {}
    DB.learned[mapID][key] = DB.learned[mapID][key] or {}
    local list = DB.learned[mapID][key]
    if #list >= 400 then return false end
    local e = { math.floor(x * 10000 + 0.5) / 10000, math.floor(y * 10000 + 0.5) / 10000, by, time() }
    list[#list + 1] = e
    local c = learnedCache[mapID]
    if c then c[#c + 1] = { x = e[1], y = e[2], key = key, by = by, t = e[4], learned = true } end
    return true
end

local RefreshAll   -- se define abajo

local function ShareNode(mapID, key, x, y)
    local c = DB.custom[key]
    if c then
        Send(table.concat({ PROTO, "C", mapID, key, c.cat, Pack(x), Pack(y), c.name or "" }, "|"))
    else
        Send(table.concat({ PROTO, "N", mapID, key, Pack(x), Pack(y) }, "|"))
    end
end

-- Despues de recoger: LOOT_OPENED / LOOT_READY.
local lastGather = { cat = nil, t = 0 }
local lootSeen = {}
local function OnLoot()
    if not (DB and DB.learn) then return end
    if not GetLootSourceInfo then return end
    local ok, guid = pcall(GetLootSourceInfo, 1)
    if not ok or type(guid) ~= "string" or issecret(guid) then return end
    if lootSeen[guid] and GetTime() - lootSeen[guid] < 60 then return end
    local kind, oid = guid:match("^(%a+)%-%d+%-%d+%-%d+%-%d+%-(%d+)%-")
    if kind ~= "GameObject" then return end
    oid = tonumber(oid)
    if not oid or oid == BOBBER then return end
    local key = D.objetos[oid]
    local isFish = IsFishingLoot and IsFishingLoot()
    if not key then
        local cat = isFish and "fish" or ((GetTime() - lastGather.t < 8) and lastGather.cat)
        if not cat then return end
        key = "o" .. oid
        if not DB.custom[key] then
            local name, icon
            if GetLootSlotInfo then
                local okl, tex, item = pcall(GetLootSlotInfo, 1)
                if okl then icon = Clean(tex); name = SafeLabel(item) end
            end
            DB.custom[key] = { cat = cat, name = name or ((cat == "fish" and "Banco de peces" or CAT_NAME[cat]) .. " " .. oid), icon = icon }
        end
    end
    lootSeen[guid] = GetTime()
    local mapID, x, y, w, h = PlayerPos()
    if not mapID then return end
    if AddLearned(mapID, key, x, y, Hub.MyName(), w, h) then
        if DB.learnChat then Print("punto nuevo aprendido: |cffffd100" .. TypeName(key) .. "|r (" .. string.format("%.1f, %.1f", x * 100, y * 100) .. ").") end
        ShareNode(mapID, key, x, y)
        RefreshAll()
    end
end

-- Recepcion
local rate = {}
local function RateOK(sender)
    local now = GetTime()
    local r = rate[sender]
    if not r or now - r.t0 > 60 then r = { t0 = now, n = 0 }; rate[sender] = r end
    r.n = r.n + 1
    return r.n <= (DB.senderLimit or 40)
end

local answered = {}
local function Answer(sender, chan)
    if not DB.answer then return end
    local now = GetTime()
    if answered[sender] and now - answered[sender] < 120 then return end
    answered[sender] = now
    local n = 0
    for mapID, keys in pairs(DB.learned) do
        for key, list in pairs(keys) do
            local buf = {}
            local function Out()
                if #buf > 0 then
                    local c = DB.custom[key]
                    Send(table.concat({ PROTO, "L", mapID, key, c and c.cat or "", c and (c.name or "") or "", table.concat(buf) }, "|"), { chan })
                    buf = {}
                end
            end
            for _, p in ipairs(list) do
                buf[#buf + 1] = Pack(p[1]) .. Pack(p[2])
                n = n + 1
                if #buf >= 20 then Out() end
                if n >= 2000 then break end
            end
            Out()
        end
    end
end

local function ValidKey(key, cat, name)
    if type(key) ~= "string" or #key > 24 then return false end
    if D.tipos[key] then return true end
    if key:match("^o%d+$") and (cat == "herb" or cat == "ore" or cat == "fish") then
        if not DB.custom[key] then DB.custom[key] = { cat = cat, name = SafeLabel(name) or (CAT_NAME[cat] .. " " .. key:sub(2)) } end
        return true
    end
    return false
end

local function OnAddonMessage(prefix, text, chan, sender)
    if issecret(prefix) or prefix ~= PREFIX then return end
    if not (DB and DB.receive) or issecret(text) or issecret(sender) or type(text) ~= "string" or #text > 255 then return end
    sender = Hub.ShortName(sender)
    if not sender or Hub.IsMe(sender) then return end
    local p = {}
    for part in string.gmatch(text .. "|", "([^|]*)|") do p[#p + 1] = part end
    if p[1] ~= PROTO then return end
    local cmd = p[2]
    if cmd == "Q" then Answer(sender, (chan == "GUILD" or chan == "PARTY" or chan == "RAID") and chan or "GUILD"); return end
    local mapID = tonumber(p[3])
    if not mapID or mapID < 1 or mapID > 100000 then return end
    local added = 0
    if cmd == "N" and #p == 6 and ValidKey(p[4]) then
        if RateOK(sender) and AddLearned(mapID, p[4], (tonumber(p[5]) or 0) / 10000, (tonumber(p[6]) or 0) / 10000, sender) then added = 1 end
    elseif cmd == "C" and #p == 8 and ValidKey(p[4], p[5], p[8]) then
        if RateOK(sender) and AddLearned(mapID, p[4], (tonumber(p[6]) or 0) / 10000, (tonumber(p[7]) or 0) / 10000, sender) then added = 1 end
    elseif cmd == "L" and #p == 7 and ValidKey(p[4], p[5], p[6]) then
        local s = p[7]
        if #s % 8 ~= 0 or s:find("%D") then return end
        for i = 1, #s - 7, 8 do
            if not RateOK(sender) then break end
            if AddLearned(mapID, p[4], tonumber(s:sub(i, i + 3)) / 10000, tonumber(s:sub(i + 4, i + 7)) / 10000, sender) then added = added + 1 end
        end
    end
    if added > 0 then
        mod.received = (mod.received or 0) + added
        RefreshAll()
    end
end

local function RequestGuild()
    if not (IsInGuild and IsInGuild()) then Print("no tienes hermandad."); return end
    Send(PROTO .. "|Q", { "GUILD" })
    mod.received = 0
    Print("pidiendo a la hermandad sus puntos aprendidos (los que tengan el addon y la opcion de contestar)...")
    if C_Timer and C_Timer.After then
        C_Timer.After(30, function() Print((mod.received or 0) .. " puntos nuevos recibidos de la hermandad.") end)
    end
end

----------------------------------------------------------------------
-- Exportar / importar (texto para copiar y pegar)
----------------------------------------------------------------------
local function Export()
    local parts, n = { "FARM1" }, 0
    for mapID, keys in pairs(DB.learned) do
        for key, list in pairs(keys) do
            local buf = {}
            for _, p in ipairs(list) do buf[#buf + 1] = Pack(p[1]) .. Pack(p[2]); n = n + 1 end
            local c = DB.custom[key]
            parts[#parts + 1] = table.concat({ mapID, key, c and c.cat or "", c and (c.name or ""):gsub("[;:]", "") or "", table.concat(buf) }, ":")
        end
    end
    return table.concat(parts, ";"), n
end

local function Import(text)
    if type(text) ~= "string" or issecret(text) then return 0 end
    text = text:gsub("%s", "")
    if text:sub(1, 6) ~= "FARM1;" then return nil end
    local added = 0
    for chunk in string.gmatch(text:sub(7), "[^;]+") do
        local mapID, key, cat, name, pts = chunk:match("^(%d+):([%w]+):(%a*):([^:]*):(%d*)$")
        mapID = tonumber(mapID)
        if mapID and ValidKey(key, cat, name) and #pts % 8 == 0 then
            for i = 1, #pts - 7, 8 do
                if AddLearned(mapID, key, tonumber(pts:sub(i, i + 3)) / 10000, tonumber(pts:sub(i + 4, i + 7)) / 10000, "importado") then
                    added = added + 1
                end
            end
        end
    end
    RefreshAll()
    return added
end

local textWin
local function TextWindow(title, text, onAccept)
    if not textWin then
        textWin = Hub.UI.MakeWindow("CMFarmeadoorTexto", "Farmeadoor", 520, 300)
        local sf = CreateFrame("ScrollFrame", nil, textWin, "UIPanelScrollFrameTemplate")
        sf:SetPoint("TOPLEFT", 16, -36); sf:SetPoint("BOTTOMRIGHT", -34, 44)
        local eb = CreateFrame("EditBox", nil, sf)
        eb:SetMultiLine(true); eb:SetAutoFocus(false); eb:SetFontObject("ChatFontNormal"); eb:SetWidth(460)
        eb:SetScript("OnEscapePressed", function() textWin:Hide() end)
        sf:SetScrollChild(eb)
        textWin.eb = eb
        textWin.ok = Hub.UI.NewButton and Hub.UI.NewButton(textWin, "Importar", 120, "BOTTOMRIGHT", -16, 12, function()
            if textWin.onAccept then textWin.onAccept(textWin.eb:GetText()) end
        end) or nil
        if not textWin.ok then
            local b = CreateFrame("Button", nil, textWin, "UIPanelButtonTemplate")
            b:SetSize(120, 22); b:SetPoint("BOTTOMRIGHT", -16, 12); b:SetText("Importar")
            b:SetScript("OnClick", function() if textWin.onAccept then textWin.onAccept(textWin.eb:GetText()) end end)
            textWin.ok = b
        end
        textWin.info = textWin:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        textWin.info:SetPoint("BOTTOMLEFT", 16, 18); textWin.info:SetWidth(360); textWin.info:SetJustifyH("LEFT")
    end
    textWin.info:SetText(title)
    textWin.onAccept = onAccept
    textWin.eb:SetText(text or "")
    if onAccept then textWin.ok:Show() else textWin.ok:Hide() end
    textWin:Show()
    textWin.eb:SetFocus()
    if text and text ~= "" then textWin.eb:HighlightText() end
end

local function OpenExport()
    local s, n = Export()
    if n == 0 then Print("todavia no has aprendido ningun punto (ni recibido de otros)."); return end
    TextWindow(n .. " puntos aprendidos. Ctrl+C para copiar y pasaselo a quien quieras.", s)
end
local function OpenImport()
    TextWindow("Pega aqui (Ctrl+V) el texto que te han pasado y pulsa Importar.", "", function(txt)
        local n = Import(txt)
        if n == nil then Print("ese texto no es de Farmeadoor.") else Print(n .. " puntos nuevos importados.") end
        textWin:Hide()
    end)
end

----------------------------------------------------------------------
-- Puntos de un mapa (precargados + aprendidos)
----------------------------------------------------------------------
local function Points(mapID, fn)
    for _, p in ipairs(Base(mapID)) do fn(p) end
    if DB.showLearned then for _, p in ipairs(Learned(mapID)) do fn(p) end end
end

local function ShowTip(owner, p)
    if not DB.tooltip then return end
    local t = Type(p.key)
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    GameTooltip:AddLine(TypeName(p.key), 1, 0.82, 0)
    local need, have = t.skill or 0, skills[t.cat]
    local line = CAT_NAME[t.cat] or ""
    if need > 0 then line = line .. " · habilidad " .. need end
    GameTooltip:AddLine(line, (have and need > have) and 1 or 0.8, (have and need > have) and 0.3 or 0.8, (have and need > have) and 0.3 or 0.8)
    GameTooltip:AddLine(string.format("%.1f, %.1f", p.x * 100, p.y * 100), 0.6, 0.6, 0.6)
    if p.learned then
        GameTooltip:AddLine("Aprendido" .. (p.by and (" por " .. p.by) or "") .. (p.t and (" el " .. date("%d/%m/%y", p.t)) or ""), 0.5, 1, 0.5)
    end
    GameTooltip:Show()
end

----------------------------------------------------------------------
-- Mapa del mundo
----------------------------------------------------------------------
local worldPins, worldUsed = {}, 0
local function WorldPin(i)
    local p = worldPins[i]
    if p then return p end
    local canvas = WorldMapFrame:GetCanvas()
    p = CreateFrame("Frame", nil, canvas)
    mod:Track(p)
    p:SetFrameStrata("HIGH")
    p.tex = p:CreateTexture(nil, "OVERLAY")
    p.tex:SetAllPoints(p)
    p:SetScript("OnEnter", function(self) if self.pt then ShowTip(self, self.pt) end end)
    p:SetScript("OnLeave", function() GameTooltip:Hide() end)
    worldPins[i] = p
    return p
end

local function UpdateWorld()
    for i = 1, worldUsed do worldPins[i]:Hide(); worldPins[i].pt = nil end
    worldUsed = 0
    if not (DB and mod.enabled and DB.map.on and WorldMapFrame and WorldMapFrame.IsVisible and WorldMapFrame:IsVisible()) then return end
    local mid = WorldMapFrame.GetMapID and WorldMapFrame:GetMapID()
    if not mid then return end
    local canvas = WorldMapFrame:GetCanvas()
    local w, h = canvas:GetWidth(), canvas:GetHeight()
    local size, alpha, maxn = DB.map.size or 12, (DB.map.alpha or 90) / 100, DB.map.max or 2500
    local n = 0
    Points(mid, function(pt)
        if n >= maxn then return end
        local vis, dim = Visible(pt.key)
        if not vis then return end
        n = n + 1
        local p = WorldPin(n)
        p.pt = pt
        p:SetSize(size, size)
        p.tex:SetTexture(TypeIcon(pt.key))
        p.tex:SetDesaturated(dim and true or false)
        p:SetAlpha(dim and alpha * 0.45 or alpha)
        p:EnableMouse(DB.tooltip and true or false)
        p:ClearAllPoints()
        p:SetPoint("CENTER", canvas, "TOPLEFT", pt.x * w, -pt.y * h)
        p:Show()
    end)
    worldUsed = n
end

----------------------------------------------------------------------
-- Minimapa
----------------------------------------------------------------------
local miniPins, miniUsed = {}, 0
local function MiniPin(i)
    local p = miniPins[i]
    if p then return p end
    p = CreateFrame("Frame", nil, Minimap)
    mod:Track(p)
    p:SetFrameStrata("MEDIUM"); p:SetFrameLevel(8)
    p.tex = p:CreateTexture(nil, "OVERLAY")
    p.tex:SetAllPoints(p)
    p:SetScript("OnEnter", function(self) if self.pt then ShowTip(self, self.pt) end end)
    p:SetScript("OnLeave", function() GameTooltip:Hide() end)
    miniPins[i] = p
    return p
end

local function Facing()
    local f = GetPlayerFacing and GetPlayerFacing()
    if type(f) ~= "number" or issecret(f) then return 0 end
    return f
end

local function UpdateMini()
    for i = 1, miniUsed do miniPins[i]:Hide() end
    miniUsed = 0
    if not (DB and mod.enabled and DB.mini.on and Minimap and Minimap:IsVisible()) then return end
    local mid, px, py, w, h = PlayerPos()
    if not mid or not w or w <= 0 then return end
    local radius = (C_Minimap and C_Minimap.GetViewRadius and C_Minimap.GetViewRadius()) or 150
    if type(radius) ~= "number" or issecret(radius) or radius <= 0 then radius = 150 end
    local half = Minimap:GetWidth() / 2
    local scale = half / radius
    local rotated = GetCVar and GetCVar("rotateMinimap") == "1"
    local f = rotated and Facing() or 0
    local c, s = math.cos(f), math.sin(f)
    local size, alpha, maxn = DB.mini.size or 12, (DB.mini.alpha or 100) / 100, DB.mini.max or 60
    local lim = radius * (DB.mini.edge and 1.6 or 1)
    local n = 0
    Points(mid, function(pt)
        if n >= maxn then return end
        local east, north = (pt.x - px) * w, -(pt.y - py) * h
        if math.abs(east) > lim or math.abs(north) > lim then return end
        local d = math.sqrt(east * east + north * north)
        if d > lim then return end
        local vis, dim = Visible(pt.key)
        if not vis then return end
        local sx, sy = east, north
        if rotated then sx, sy = east * c + north * s, -east * s + north * c end
        local ox, oy = sx * scale, sy * scale
        local r = math.sqrt(ox * ox + oy * oy)
        if r > half - 4 then
            if not DB.mini.edge then return end
            ox, oy = ox / r * (half - 4), oy / r * (half - 4)
        end
        n = n + 1
        local p = MiniPin(n)
        p.pt = pt
        p:SetSize(size, size)
        p.tex:SetTexture(TypeIcon(pt.key))
        p.tex:SetDesaturated(dim and true or false)
        p:SetAlpha(((dim and 0.45) or 1) * alpha * ((r > half - 4) and 0.6 or 1))
        p:EnableMouse(DB.tooltip and true or false)
        p:ClearAllPoints()
        p:SetPoint("CENTER", Minimap, "CENTER", ox, oy)
        p:Show()
    end)
    miniUsed = n
end

RefreshAll = function()
    UpdateWorld()
    UpdateMini()
end

local function HideAll()
    for i = 1, worldUsed do worldPins[i]:Hide() end
    for i = 1, miniUsed do miniPins[i]:Hide() end
    worldUsed, miniUsed = 0, 0
end

----------------------------------------------------------------------
-- Configuracion
----------------------------------------------------------------------
local function Count()
    local base, learned = 0, 0
    for _, m in pairs(D.puntos or {}) do for _, s in pairs(m) do base = base + #s / 8 end end
    for _, m in pairs(DB.learned or {}) do for _, l in pairs(m) do learned = learned + #l end end
    return base, learned
end

local function SortedTypes(cat)
    local out = {}
    for key, t in pairs(D.tipos) do if t.cat == cat then out[#out + 1] = key end end
    for key, c in pairs(DB.custom or {}) do if c.cat == cat then out[#out + 1] = key end end
    table.sort(out, function(a, b)
        local ta, tb = Type(a), Type(b)
        if (ta.skill or 0) ~= (tb.skill or 0) then return (ta.skill or 0) < (tb.skill or 0) end
        return TypeName(a) < TypeName(b)
    end)
    return out
end

local function BuildConfig(m, L)
    local base, learned = Count()
    L:Header("Farmeadoor")
    L:Text(string.format("Menas, plantas y bancos de peces de Forever en el mapa y el minimapa: %d puntos precargados (datos del %s) y %d aprendidos por ti y tu hermandad.", base, D.version or "?", learned), true)
    L:Text("Fuentes: " .. (D.fuentes or "?") .. ". Addon con licencia GPL-3.0.", true)

    L:Header("Que mostrar")
    L:Check("Plantas", function() return DB.show.herb end, function(v) DB.show.herb = v; RefreshAll() end)
    L:Check("Menas", function() return DB.show.ore end, function(v) DB.show.ore = v; RefreshAll() end)
    L:Check("Bancos de peces", function() return DB.show.fish end, function(v) DB.show.fish = v; RefreshAll() end)
    L:Check("Ocultar lo que tu habilidad aun no puede recoger", function() return DB.onlySkill end, function(v) DB.onlySkill = v; RefreshAll() end)
    L:Check("   ...si no se oculta, mostrarlo atenuado y en gris", function() return DB.dimHigh end, function(v) DB.dimHigh = v; RefreshAll() end)
    L:Check("Ocultar categorias de profesiones que no tienes", function() return DB.noProfHide end, function(v) DB.noProfHide = v; RefreshAll() end)
    L:Check("Mostrar los puntos aprendidos (tuyos y compartidos)", function() return DB.showLearned end, function(v) DB.showLearned = v; RefreshAll() end)
    L:Check("Tooltip al pasar el raton por un punto", function() return DB.tooltip end, function(v) DB.tooltip = v; RefreshAll() end)

    L:Header("Mapa del mundo")
    L:Check("Mostrar en el mapa del mundo", function() return DB.map.on end, function(v) DB.map.on = v; RefreshAll() end)
    L:Slider("Tamaño de los iconos", 6, 32, 1, function() return DB.map.size end, function(v) DB.map.size = v; RefreshAll() end)
    L:Slider("Opacidad (%)", 20, 100, 5, function() return DB.map.alpha end, function(v) DB.map.alpha = v; RefreshAll() end)
    L:Slider("Iconos maximos por mapa", 200, 4000, 100, function() return DB.map.max end, function(v) DB.map.max = v; RefreshAll() end)

    L:Header("Minimapa")
    L:Check("Mostrar en el minimapa", function() return DB.mini.on end, function(v) DB.mini.on = v; RefreshAll() end)
    L:Check("   Mostrar en el borde los que estan un poco mas lejos", function() return DB.mini.edge end, function(v) DB.mini.edge = v; RefreshAll() end)
    L:Slider("Tamaño de los iconos", 6, 24, 1, function() return DB.mini.size end, function(v) DB.mini.size = v; RefreshAll() end)
    L:Slider("Opacidad (%)", 20, 100, 5, function() return DB.mini.alpha end, function(v) DB.mini.alpha = v; RefreshAll() end)
    L:Slider("Iconos maximos a la vez", 10, 150, 5, function() return DB.mini.max end, function(v) DB.mini.max = v; RefreshAll() end)

    L:Header("Aprender lo que recoges")
    L:Check("Apuntar las menas, plantas y bancos que recojo y no estan en el mapa", function() return DB.learn end, function(v) DB.learn = v end)
    L:Check("   Avisar en el chat al aprender un punto", function() return DB.learnChat end, function(v) DB.learnChat = v end)
    L:Slider("Es el mismo punto si esta a menos de (yardas)", 4, 40, 1, function() return DB.radius end, function(v) DB.radius = v end)

    L:Header("Compartir y actualizar")
    L:Check("Enviar mis puntos nuevos a la hermandad", function() return DB.shareGuild end, function(v) DB.shareGuild = v end)
    L:Check("Enviar mis puntos nuevos al grupo / banda", function() return DB.shareGroup end, function(v) DB.shareGroup = v end)
    L:Check("Recibir puntos de otros", function() return DB.receive end, function(v) DB.receive = v end)
    L:Check("Contestar cuando la hermandad pide puntos", function() return DB.answer end, function(v) DB.answer = v end)
    L:Slider("Puntos por minuto aceptados de cada jugador", 10, 400, 10, function() return DB.senderLimit end, function(v) DB.senderLimit = v end)
    L:Button("Pedir puntos a la hermandad", 210, function() RequestGuild() end)
    L:Button("Exportar", 100, function() OpenExport() end, true)
    L:Button("Importar", 100, function() OpenImport() end, true)
    L:Text("Los datos precargados se actualizan con cada version del addon (el script _suite/herramientas/farmeadoor_datos.py los vuelve a bajar de QuestieDB y CMaNGOS). Lo aprendido no se borra al actualizar ni al restaurar los ajustes.", true)
    L:Button("Borrar lo aprendido", 170, function()
        if not mod.confirmClear or GetTime() - mod.confirmClear > 5 then
            mod.confirmClear = GetTime(); Print("pulsa otra vez en 5 s para borrar todos los puntos aprendidos."); return
        end
        DB.learned, DB.custom = {}, {}
        wipe(learnedCache)
        Print("puntos aprendidos borrados.")
        RefreshAll()
    end)

    for _, cat in ipairs({ "herb", "ore", "fish" }) do
        L:Header(CAT_NAME[cat] .. ": cuales mostrar")
        -- Marcar / quitar todas de golpe (y solo las de tu habilidad actual).
        local function Todas(fn)
            return function()
                for _, key in ipairs(SortedTypes(cat)) do DB.hidden[key] = (not fn(Type(key))) or nil end
                RefreshAll(); L:Refresh()
            end
        end
        L:Button("Marcar todas", 120, Todas(function() return true end))
        L:Button("Quitar todas", 120, Todas(function() return false end), true)
        L:Button("Solo las de mi nivel", 160, Todas(function(t)
            local have = skills[cat]
            return not have or (t.skill or 0) <= have
        end), true)
        for _, key in ipairs(SortedTypes(cat)) do
            local t = Type(key)
            L:Check(TypeName(key) .. (((t.skill or 0) > 0) and ("  |cff999999(" .. t.skill .. ")|r") or "") .. (t.custom and "  |cff55ff55(aprendido)|r" or ""),
                function() return not DB.hidden[key] end, function(v) DB.hidden[key] = (not v) or nil; RefreshAll() end)
        end
    end
end

----------------------------------------------------------------------
-- Comandos
----------------------------------------------------------------------
local function OnSlash(m, msg)
    local cmd = (msg or ""):lower():match("^(%S*)")
    if cmd == "" or cmd == "config" then Hub:Open("farmeadoor")
    elseif cmd == "exportar" then OpenExport()
    elseif cmd == "importar" then OpenImport()
    elseif cmd == "pedir" or cmd == "actualizar" then RequestGuild()
    elseif cmd == "mapa" then DB.map.on = not DB.map.on; Print("mapa: " .. (DB.map.on and "SI" or "NO")); RefreshAll()
    elseif cmd == "minimapa" then DB.mini.on = not DB.mini.on; Print("minimapa: " .. (DB.mini.on and "SI" or "NO")); RefreshAll()
    elseif cmd == "diag" then
        local base, learned = Count()
        local mid = PlayerPos()
        Print(string.format("datos %s: %d precargados, %d aprendidos; este mapa (%s): %d precargados, %d aprendidos; habilidades: plantas %s, menas %s, pesca %s",
            D.version or "?", base, learned, tostring(mid), mid and #Base(mid) or 0, mid and #Learned(mid) or 0,
            tostring(skills.herb or "-"), tostring(skills.ore or "-"), tostring(skills.fish or "-")))
    else
        Print("comandos: /farmeadoor (opciones) · exportar · importar · pedir (a la hermandad) · mapa · minimapa · diag")
    end
end

----------------------------------------------------------------------
-- Registro
----------------------------------------------------------------------
local hooked = false
mod = Hub:Register{
    key = "farmeadoor", dir = "Farmeadoor", name = "Farmeadoor",
    desc = "Menas, plantas y bancos de peces de Forever en el mapa y el minimapa desde el primer momento (datos de QuestieDB y CMaNGOS). Aprende lo que recoges y no estaba, lo comparte con la hermandad y se puede exportar e importar. Filtros por tipo y por tu habilidad.",
    defaults = DEFAULTS,
    slash = { "farmeadoor", "farm" },
    BuildConfig = BuildConfig,
    OnSlash = OnSlash,
    Init = function(m)
        DB = m.db
        DB.learned = DB.learned or {}
        DB.custom = DB.custom or {}
        if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then pcall(C_ChatInfo.RegisterAddonMessagePrefix, PREFIX) end
        m:Event("PLAYER_ENTERING_WORLD", function() ReadSkills(); RefreshAll() end)
        m:Event("SKILL_LINES_CHANGED", function() ReadSkills(); RefreshAll() end)
        m:Event("LOOT_READY", function() OnLoot() end)
        m:Event("LOOT_OPENED", function() OnLoot() end)
        m:Event("UNIT_SPELLCAST_SUCCEEDED", function(_, _, unit, _, spellID)
            if unit == "player" and not issecret(spellID) and GATHER_SPELLS[spellID] then
                lastGather.cat, lastGather.t = GATHER_SPELLS[spellID], GetTime()
            end
        end)
        m:Event("UNIT_SPELLCAST_SENT", function(_, _, unit, _, _, spellID)
            if unit == "player" and not issecret(spellID) and GATHER_SPELLS[spellID] then
                lastGather.cat, lastGather.t = GATHER_SPELLS[spellID], GetTime()
            end
        end)
        m:Event("CHAT_MSG_ADDON", function(_, _, prefix, text, chan, sender) OnAddonMessage(prefix, text, chan, sender) end)
        m:Event("GET_ITEM_INFO_RECEIVED", function() wipe(iconCache) end)
        if WorldMapFrame and not hooked then
            hooked = true
            WorldMapFrame:HookScript("OnShow", function() if mod.enabled then UpdateWorld() end end)
            if WorldMapFrame.OnMapChanged then
                hooksecurefunc(WorldMapFrame, "OnMapChanged", function() if mod.enabled then UpdateWorld() end end)
            end
        end
        local acc, facc = 0, 0
        m:OnUpdate(function(_, e)
            acc, facc = acc + e, facc + e
            if facc >= 0.3 then facc = 0; Flush() end
            if acc >= 0.25 then acc = 0; UpdateMini() end
        end)
    end,
    Enable = function(m) DB = m.db; ReadSkills(); RefreshAll() end,
    Disable = function(m) HideAll(); queue = {} end,
    OnReset = function(m)
        DB = m.db
        DB.learned = DB.learned or {}
        DB.custom = DB.custom or {}
        wipe(learnedCache)
        if m.enabled then RefreshAll() end
    end,
}

-- para las pruebas
ns.Farm = { AddLearned = AddLearned, Export = Export, Import = Import, OnLoot = OnLoot, Base = Base, Learned = Learned,
            Visible = Visible, TypeName = TypeName, ReadSkills = ReadSkills, skills = skills, OnAddonMessage = OnAddonMessage,
            Refresh = function() RefreshAll() end, Counts = function() return worldUsed, miniUsed end }
