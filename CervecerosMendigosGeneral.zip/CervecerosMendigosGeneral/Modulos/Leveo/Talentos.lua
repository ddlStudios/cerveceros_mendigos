-- CervecerosMendigos · Leveo: talentos para subir de nivel (codigo propio, GPL-3.0).
-- Orden de puntos por clase y rama: tabla de Brudda FastXP (DatosBrudda/BruddaTalents.lua, de las guias de
-- subida de Icy Veins para WoW Forever). Cada build: t = {arbol, fila, columna, rangos, nodo, hechizo, nombre}
-- y seq = indice en t de cada punto, desde el nivel 10.
-- Pone los puntos con el sistema nuevo (C_Traits) o el clasico (LearnTalent), uno a uno y fuera de combate.
local ADDON, ns = ...
local LV = ns.LV or {}
ns.LV = LV
local TL = {}
LV.Talents = TL

local function S() return LV.S end
local function O() return S().talentos or {} end

function TL.Builds()
    local list = (ns.BruddaTalentBuilds or {})[LV.ClassTok()] or {}
    table.sort(list, function(a, b) return (a.tree or 0) < (b.tree or 0) end)
    return list
end

local function SpellName(id)
    if C_Spell and C_Spell.GetSpellName then return C_Spell.GetSpellName(id) end
    if GetSpellInfo then return (GetSpellInfo(id)) end
end

----------------------------------------------------------------------
-- Sistemas de talentos
----------------------------------------------------------------------
local Traits = {}
local function Cfg()
    if C_ClassTalents and C_ClassTalents.GetActiveConfigID then
        local ok, id = pcall(C_ClassTalents.GetActiveConfigID)
        if ok and id then return id end
    end
end
local function Node(p)
    local cfg = Cfg()
    if not (cfg and C_Traits and C_Traits.GetNodeInfo) then return end
    local ok, info = pcall(C_Traits.GetNodeInfo, cfg, p[5])
    if ok and type(info) == "table" and (tonumber(info.ID) or 0) ~= 0 then return info, cfg end
end
function Traits.ok(b) return C_Traits and C_Traits.PurchaseRank and b and Node(b.t[1]) and true or false end
function Traits.rank(p)
    local info = Node(p)
    if not info then return 0 end
    return tonumber(info.currentRank or info.ranksPurchased) or 0
end
function Traits.learn(p)
    local info, cfg = Node(p)
    if not info then return false end
    local ok, res = pcall(C_Traits.PurchaseRank, cfg, p[5])
    if ok and res then Traits.dirty = true end
    return ok and res
end
function Traits.commit()
    if not Traits.dirty then return end
    Traits.dirty = nil
    local cfg = Cfg()
    if cfg and C_Traits.CommitConfig then pcall(C_Traits.CommitConfig, cfg) end
end

local Classic = {}
local idxCache = {}
local function ClassicIndex(p)
    local k = p[1] .. ":" .. p[2] .. ":" .. p[3]
    if idxCache[k] then return idxCache[k] end
    if not (GetNumTalents and GetTalentInfo) then return end
    for i = 1, (GetNumTalents(p[1]) or 0) do
        local _, _, tier, col = GetTalentInfo(p[1], i)
        if tier == p[2] and col == p[3] then idxCache[k] = i; return i end
    end
end
function Classic.ok(b) return LearnTalent and b and ClassicIndex(b.t[1]) and true or false end
function Classic.rank(p)
    local i = ClassicIndex(p)
    if not i then return 0 end
    local _, _, _, _, rank = GetTalentInfo(p[1], i)
    return tonumber(rank) or 0
end
function Classic.learn(p)
    local i = ClassicIndex(p)
    if not i then return false end
    LearnTalent(p[1], i)
    return true
end
function Classic.commit() end

local function Backend(b)
    if Classic.ok(b) then return Classic end
    if Traits.ok(b) then return Traits end
end
TL.Backend = Backend

----------------------------------------------------------------------
-- Rama elegida: la de las opciones, o la que mas puntos tiene, o la primera
----------------------------------------------------------------------
function TL.Current()
    local list = TL.Builds()
    if #list == 0 then return end
    local elegida = O().rama
    if elegida and elegida ~= "auto" then
        for _, b in ipairs(list) do if b.key == elegida then return b end end
    end
    local best, bestPts
    for _, b in ipairs(list) do
        local be = Backend(b)
        local pts = 0
        if be then
            for _, p in ipairs(b.t) do if p[1] == b.tree then pts = pts + be.rank(p) end end
        end
        if pts > (bestPts or 0) then best, bestPts = b, pts end
    end
    return best or list[1]
end

-- Puntos que faltan de la build, en orden: {ti, rank, pos (1 = nivel 10)}
function TL.Plan(b)
    b = b or TL.Current()
    if not b then return {} end
    local be = Backend(b)
    local have, used, missing = {}, {}, {}
    for i, p in ipairs(b.t) do have[i] = be and be.rank(p) or 0 end
    for k, ti in ipairs(b.seq) do
        used[ti] = (used[ti] or 0) + 1
        if used[ti] > have[ti] then missing[#missing + 1] = { ti = ti, rank = used[ti], pos = k } end
    end
    return missing
end

function TL.Free()
    if UnitCharacterPoints then
        local n = UnitCharacterPoints("player")
        if type(n) == "number" then return n end
    end
    if GetUnspentTalentPoints then
        local ok, n = pcall(GetUnspentTalentPoints)
        if ok and type(n) == "number" then return n end
    end
    -- sistema nuevo sin contador: los puntos de tu nivel menos los que la build ya tiene puestos
    local lvl = LV.Level()
    if lvl < 10 then return 0 end
    local b = TL.Current()
    if not b then return 0 end
    local total = lvl - 9
    local missing = TL.Plan(b)
    local puestos = #b.seq - #missing
    return math.max(0, total - puestos)
end

function TL.PointText(b, m)
    local p = b.t[m.ti]
    local name = SpellName(p[6]) or p[7]
    return string.format("%s %d/%d (nivel %d)", name, m.rank, p[4], m.pos + 9)
end

----------------------------------------------------------------------
-- Poner los puntos: uno cada poco, esperando a que el juego responda
----------------------------------------------------------------------
local aplicando
function TL.Apply()
    if aplicando then return end
    if InCombatLockdown and InCombatLockdown() then LV.mod:Print("en combate no se pueden poner talentos."); return end
    local b = TL.Current()
    if not b then LV.mod:Print("no tengo builds de talentos para tu clase."); return end
    local be = Backend(b)
    if not be then LV.mod:Print("no encuentro tus talentos en el juego. Abre la ventana de talentos y vuelve a probar."); return end
    local free = TL.Free()
    local missing = TL.Plan(b)
    local lvl = LV.Level()
    local cola = {}
    for _, m in ipairs(missing) do
        if m.pos + 9 <= lvl and #cola < free then cola[#cola + 1] = m end
    end
    if #cola == 0 then LV.mod:Print("no hay puntos de talento que poner ahora."); return end
    aplicando = { b = b, be = be, cola = cola, i = 1, puestos = 0 }
    local function Paso()
        local a = aplicando
        if not a then return end
        local m = a.cola[a.i]
        if not m or (InCombatLockdown and InCombatLockdown()) then
            a.be.commit()
            aplicando = nil
            LV.mod:Print(string.format("talentos (%s): %d puntos puestos.", a.b.es or a.b.key, a.puestos))
            if TL.frameBtn then TL.RefreshButton() end
            return
        end
        if a.be.learn(a.b.t[m.ti]) then a.puestos = a.puestos + 1 end
        a.i = a.i + 1
        if C_Timer and C_Timer.After then C_Timer.After(0.3, Paso) else Paso() end
    end
    Paso()
end

----------------------------------------------------------------------
-- Boton en la ventana de talentos y aviso al subir
----------------------------------------------------------------------
function TL.RefreshButton()
    local btn = TL.frameBtn
    if not btn then return end
    local b = TL.Current()
    if not (LV.mod and LV.mod:IsEnabled()) or O().boton == false or not b then btn:Hide(); return end
    local free = TL.Free()
    btn:SetText(free > 0 and string.format("Leveo: poner %d (%s)", free, b.es or b.key) or ("Leveo: " .. (b.es or b.key)))
    btn:Show()
end

local hooked = {}
local function HookFrame(f)
    if not f or hooked[f] or not f.HookScript then return end
    hooked[f] = true
    local tab = rawget(f, "TalentsFrame")
    if type(tab) == "table" and tab.HookScript then f = tab; hooked[f] = true end
    local btn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    btn:SetSize(190, 22)
    btn:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -12, 34)
    btn:SetFrameLevel((f:GetFrameLevel() or 1) + 20)
    btn:SetScript("OnClick", function() TL.Apply() end)
    btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        local b = TL.Current()
        GameTooltip:SetText("Talentos de subida (Leveo)", 1, 0.82, 0)
        if b then
            local missing = TL.Plan(b)
            for k = 1, math.min(5, #missing) do GameTooltip:AddLine(TL.PointText(b, missing[k]), 1, 1, 1) end
            if #missing == 0 then GameTooltip:AddLine("Build completa.", 0.6, 1, 0.6) end
        end
        GameTooltip:AddLine("La rama se cambia en la pestaña Leveo.", 0.6, 0.6, 0.6)
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    TL.frameBtn = btn
    f:HookScript("OnShow", function()
        if not (LV.mod and LV.mod:IsEnabled()) then return end
        TL.RefreshButton()
        if O().ofrecer ~= false and TL.Free() > 0 and LV.Level() >= 10 then
            local b = TL.Current()
            if b and O().solo then TL.Apply() end
        end
    end)
    TL.RefreshButton()
end

function TL.Hook()
    for _, n in ipairs({ "PlayerSpellsFrame", "ClassTalentFrame", "PlayerTalentFrame", "TalentFrame" }) do
        local f = rawget(_G, n)
        if f then HookFrame(f) end
    end
end

LV.On("ADDON_LOADED", function(_, name)
    if name == "Blizzard_PlayerSpells" or name == "Blizzard_ClassTalentUI" or name == "Blizzard_TalentUI" then TL.Hook() end
end)
LV.On("PLAYER_LEVEL_UP", function(_, level)
    if O().avisar == false or (level or 0) < 10 then return end
    local b = TL.Current()
    if not b then return end
    for _, m in ipairs(TL.Plan(b)) do
        if m.pos + 9 == level then
            LV.mod:Print("nuevo punto de talento: " .. TL.PointText(b, m) .. ". Ábrelos y pulsa «Leveo: poner».")
            return
        end
    end
end)
