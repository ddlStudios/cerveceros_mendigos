-- CervecerosMendigos · Leveo: acepta y entrega solas las misiones de la ruta (codigo propio, GPL-3.0).
-- Solo las que pide la ruta cargada y te tocan (clase, raza, nivel). Con la tecla de pausa (Shift por
-- defecto) pulsada al hablar con alguien no hace nada.
local ADDON, ns = ...
local LV = ns.LV or {}
ns.LV = LV
local T = LV.T
local Au = {}
LV.Auto = Au

local function S() return LV.S end
local function O() return S().auto or {} end

local function Paused()
    local k = O().pausa or "SHIFT"
    if k == "SHIFT" then return IsShiftKeyDown and IsShiftKeyDown() end
    if k == "CTRL" then return IsControlKeyDown and IsControlKeyDown() end
    if k == "ALT" then return IsAltKeyDown and IsAltKeyDown() end
    return false
end

local function On(kind)
    if not (LV.mod and LV.mod:IsEnabled()) or not T.g then return false end
    if O()[kind] == false then return false end
    return not Paused()
end

-- La ruta pide esta mision para "accept" o "turnin" en un paso que te toca
function Au.Wants(q, verb)
    if not (T.g and q) then return false end
    for _, st in ipairs(T.steps) do
        for _, el in ipairs(st.els) do
            if el.quest == q and el.verb == verb and T.StepShown(st) and T.ElShown(el) then return true, el end
        end
    end
    return false
end

local function WantsTitle(title, verb)
    if not (T.g and title) then return end
    for _, st in ipairs(T.steps) do
        for _, el in ipairs(st.els) do
            if el.verb == verb and el.quest and LV.Q.Title(el.quest) == title and T.StepShown(st) and T.ElShown(el) then
                return el.quest
            end
        end
    end
end

local function QuestID() return GetQuestID and GetQuestID() or nil end

LV.On("QUEST_DETAIL", function()
    if not On("aceptar") then return end
    local q = QuestID()
    if Au.Wants(q, "accept") then
        if QuestGetAutoAccept and QuestGetAutoAccept() then
            if AcknowledgeAutoAcceptQuest then AcknowledgeAutoAcceptQuest() end
        elseif AcceptQuest then
            AcceptQuest()
        end
    end
end)

LV.On("QUEST_PROGRESS", function()
    if not On("entregar") then return end
    local q = QuestID()
    if Au.Wants(q, "turnin") and IsQuestCompletable and IsQuestCompletable() and CompleteQuest then CompleteQuest() end
end)

LV.On("QUEST_COMPLETE", function()
    if not On("entregar") then return end
    local q = QuestID()
    local quiere, el = Au.Wants(q, "turnin")
    if not quiere then return end
    local n = GetNumQuestChoices and GetNumQuestChoices() or 0
    if n == 0 then
        if GetQuestReward then GetQuestReward(nil) end
    elseif n == 1 then
        if O().recompensa ~= false and GetQuestReward then GetQuestReward(1) end
    elseif el and el.reward and el.reward <= n and O().recompensaRuta ~= false then
        if GetQuestReward then GetQuestReward(el.reward) end
    elseif LV.mod then
        LV.mod:Print("elige tu recompensa (" .. n .. " a elegir).")
    end
end)

-- Ventana de dialogo con varias misiones
LV.On("GOSSIP_SHOW", function()
    if not C_GossipInfo then return end
    if On("entregar") then
        for _, q in ipairs(C_GossipInfo.GetActiveQuests and C_GossipInfo.GetActiveQuests() or {}) do
            if q.isComplete and Au.Wants(q.questID, "turnin") then return C_GossipInfo.SelectActiveQuest(q.questID) end
        end
    end
    if On("aceptar") then
        for _, q in ipairs(C_GossipInfo.GetAvailableQuests and C_GossipInfo.GetAvailableQuests() or {}) do
            if Au.Wants(q.questID, "accept") then return C_GossipInfo.SelectAvailableQuest(q.questID) end
        end
    end
end)

-- Saludo de misiones antiguo (sin numeros de mision en algunos PNJ)
LV.On("QUEST_GREETING", function()
    if On("entregar") then
        for i = 1, (GetNumActiveQuests and GetNumActiveQuests() or 0) do
            local title, done = GetActiveTitle(i)
            local q = (GetActiveQuestID and GetActiveQuestID(i)) or WantsTitle(title, "turnin")
            if q and Au.Wants(q, "turnin") and (done or LV.Q.Complete(q)) then return SelectActiveQuest(i) end
        end
    end
    if On("aceptar") then
        for i = 1, (GetNumAvailableQuests and GetNumAvailableQuests() or 0) do
            local title = GetAvailableTitle(i)
            local q = GetAvailableQuestInfo and select(5, GetAvailableQuestInfo(i)) or nil
            if type(q) ~= "number" then q = WantsTitle(title, "accept") end
            if q and Au.Wants(q, "accept") then return SelectAvailableQuest(i) end
        end
    end
end)
