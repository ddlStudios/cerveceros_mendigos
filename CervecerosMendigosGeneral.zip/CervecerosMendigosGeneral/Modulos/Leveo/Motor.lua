-- CervecerosMendigos · Leveo: lector de las rutas de subida (codigo propio, GPL-3.0).
-- Las rutas (Rutas/R_*.lua) usan el formato de RestedXP: cabecera con #name/#group/#next..., y pasos
-- "step" con lineas ".accept 123 >>texto << condicion". Aqui se leen y se dejan como tablas:
--   guia  = {id, name, group, title, min, max, next, defaultfor, steps (al cargarla)}
--   paso  = {i, cond, flags, label, completewith, sticky, optional, loop, requires, els, tests, notes}
--   linea = {tag, verb, cond, text, quest, obj, item, count, map, x, y, wx, wy, inst, radius, ...}
-- Lo que se cumple o no (misiones, nivel, lugar) lo decide Seguir.lua.
local ADDON, ns = ...
local LV = ns.LV or {}
ns.LV = LV

LV.S = LV.S or {}          -- ajustes (mod.db), los pone el registro
local function S() return LV.S end

----------------------------------------------------------------------
-- El personaje
----------------------------------------------------------------------
local function Faction() return (UnitFactionGroup and UnitFactionGroup("player")) or "" end
local function ClassTok() local _, c = UnitClass("player"); return c or "" end
local function RaceTok() local _, r = UnitRace("player"); return r or "" end
local function Level() return UnitLevel("player") or 1 end
LV.Faction, LV.ClassTok, LV.RaceTok, LV.Level = Faction, ClassTok, RaceTok, Level

----------------------------------------------------------------------
-- Condiciones: "Warrior/Shaman" (o), "!Orc !Troll" (y), "Alliance Hunter", "(Orc/Troll) !Hunter"
----------------------------------------------------------------------
local ALIAS = { undead = "scourge", dk = "deathknight", dawrf = "dwarf", shmaan = "shaman", maget = "mage",
                pala = "paladin", frogue = "rogue" }
local SIEMPRE = { forever = true, era = true, classic = true, vanilla = true }
LV.unknownTokens = {}

local function Token(w)
    local n = tonumber(w)
    if n then return Level() >= n end
    local low = w:lower()
    low = ALIAS[low] or low
    if SIEMPRE[low] then return true end
    if low == Faction():lower() or low == ClassTok():lower() or low == RaceTok():lower() then return true end
    if low == "male" or low == "female" then
        local sex = UnitSex and UnitSex("player")
        return (low == "male" and sex == 2) or (low == "female" and sex == 3)
    end
    if GetLocale and w == GetLocale() then return true end
    LV.unknownTokens[low] = (LV.unknownTokens[low] or 0) + 1
    return false
end

local Eval
Eval = function(expr)
    expr = expr:gsub("(!?)(%b())", function(neg, inner)
        local v = Eval(inner:sub(2, -2))
        if neg == "!" then v = not v end
        return v and " CMSI " or " CMNO "
    end)
    for alt in expr:gmatch("[^/]+") do
        local ok, alguna = true, false
        for word in alt:gmatch("!?[%w_']+") do
            alguna = true
            local neg = word:sub(1, 1) == "!"
            if neg then word = word:sub(2) end
            local v
            if word == "CMSI" then v = true elseif word == "CMNO" then v = false else v = Token(word) end
            if v == neg then ok = false; break end
        end
        if ok and alguna then return true end
    end
    return false
end

-- cache por personaje y nivel (las condiciones se miran muchas veces)
local condCache, condLevel = {}, nil
function LV.Cond(str)
    if not str then return true end
    if condLevel ~= Level() then condCache, condLevel = {}, Level() end
    local c = condCache[str]
    if c ~= nil then return c end
    local s = str:gsub("%-%-.*$", "")
    if s:find("^%s*$") then c = true else c = Eval(s) end
    condCache[str] = c
    return c
end
function LV.ClearCondCache() condCache = {} end

-- "texto << condicion" (la condicion va al final de la linea)
local function SplitCond(line)
    local body, cond = line:match("^(.-)%s*<<%s*([^<>]*)$")
    if body then
        cond = cond:gsub("%-%-.*$", "")
        return body, cond
    end
    return line, nil
end
LV.SplitCond = SplitCond

----------------------------------------------------------------------
-- Etiquetas # de la cabecera y de los pasos (modo de juego, fase de Forever, subasta...)
----------------------------------------------------------------------
local function Hardcore()
    if S().modo == "hardcore" then return true end
    if S().modo == "normal" then return false end
    return C_GameRules and C_GameRules.IsHardcoreActive and C_GameRules.IsHardcoreActive() and true or false
end
LV.Hardcore = Hardcore
local function HCServer()
    return C_GameRules and C_GameRules.IsHardcoreActive and C_GameRules.IsHardcoreActive() and true or false
end

local function PhaseOK(arg)
    local fase = tonumber(S().fase) or 5
    for parte in (arg or ""):gmatch("[^,]+") do
        local a, b = parte:match("(%d+)%s*%-%s*(%d+)")
        if a then
            if fase >= tonumber(a) and fase <= tonumber(b) then return true end
        else
            local n = tonumber(parte:match("%d+") or "")
            if n and fase == n then return true end
        end
    end
    return false
end

local function FlagOK(tag, arg)
    if tag == "hardcore" then return Hardcore()
    elseif tag == "softcore" then return not Hardcore()
    elseif tag == "hardcoreserver" then return HCServer()
    elseif tag == "softcoreserver" then return not HCServer()
    elseif tag == "era" or tag == "forever" then return true
    elseif tag == "som" or tag == "wotlk" or tag == "tbc" or tag == "sod" then return false
    elseif tag == "ssf" then return S().ssf == true
    elseif tag == "ah" then return S().ssf ~= true
    elseif tag == "phase" then return PhaseOK(arg)
    elseif tag == "season" then
        for n in (arg or ""):gmatch("%d+") do if tonumber(n) == 0 then return true end end
        return false
    elseif tag == "xprate" then
        local op, v = (arg or ""):match("([<>]?)%s*([%d%.]+)")
        v = tonumber(v)
        if not v then return true end
        if op == "<" then return 1 < v elseif op == ">" then return 1 > v end
        return true
    end
    return true
end
LV.FlagOK = FlagOK

----------------------------------------------------------------------
-- Zonas escritas por nombre (en ingles, como en el formato) -> mapa del juego
----------------------------------------------------------------------
local ZONAS = {
    durotar = 1411, mulgore = 1412, ["the barrens"] = 1413, barrens = 1413, teldrassil = 1438, darkshore = 1439,
    ashenvale = 1440, ["thousand needles"] = 1441, ["stonetalon mountains"] = 1442, stonetalon = 1442,
    desolace = 1443, feralas = 1444, ["dustwallow marsh"] = 1445, tanaris = 1446, azshara = 1447, felwood = 1448,
    ["un'goro crater"] = 1449, moonglade = 1450, silithus = 1451, winterspring = 1452, orgrimmar = 1454,
    ["thunder bluff"] = 1456, darnassus = 1457, ["alterac mountains"] = 1416, ["arathi highlands"] = 1417,
    badlands = 1418, ["blasted lands"] = 1419, ["tirisfal glades"] = 1420, ["silverpine forest"] = 1421,
    ["western plaguelands"] = 1422, ["eastern plaguelands"] = 1423, ["hillsbrad foothills"] = 1424,
    ["the hinterlands"] = 1425, ["dun morogh"] = 1426, ["searing gorge"] = 1427, ["burning steppes"] = 1428,
    ["elwynn forest"] = 1429, ["deadwind pass"] = 1430, duskwood = 1431, ["loch modan"] = 1432,
    ["redridge mountains"] = 1433, ["stranglethorn vale"] = 1434, ["swamp of sorrows"] = 1435, westfall = 1436,
    wetlands = 1437, ["stormwind city"] = 1453, stormwindclassic = 1453, stormwind = 1453, ironforge = 1455,
    undercity = 1458, kalimdor = 1414, ["eastern kingdoms"] = 1415,
}
LV.ZONAS = ZONAS
local function ZoneId(s)
    s = (s or ""):gsub("^%s+", ""):gsub("%s+$", "")
    local n = tonumber(s)
    if n then return n end
    return ZONAS[s:lower()]
end
LV.ZoneId = ZoneId

----------------------------------------------------------------------
-- Catalogo: solo las cabeceras; los pasos se leen al cargar la ruta
----------------------------------------------------------------------
LV.guides, LV.byId = {}, {}

local function HeaderLines(text)
    local t = {}
    for raw in (text .. "\n"):gmatch("(.-)\r?\n") do
        local line = raw:gsub("^%s+", ""):gsub("%s+$", "")
        local first = line:lower():match("^(%a+)")
        if first == "step" then break end
        if line ~= "" and not line:find("^%-%-") then t[#t + 1] = line end
    end
    return t
end

-- La cabecera vista por este personaje (algunas lineas dependen de la faccion o la clase)
local function Header(lines)
    local h = { flags = {} }
    for _, line in ipairs(lines) do
        local body, cond = SplitCond(line)
        if body == "" and cond then
            h.cond = (h.cond and (h.cond .. " ") or "") .. cond
        elseif cond == nil or LV.Cond(cond) then
            local tag, arg = body:match("^#(%S+)%s*(.-)$")
            if tag then
                tag = tag:lower()
                if tag == "name" or tag == "group" or tag == "subgroup" or tag == "next" or tag == "displayname"
                    or tag == "defaultfor" or tag == "version" then
                    h[tag] = arg
                else
                    h.flags[tag] = (arg ~= "" and arg) or true
                end
            end
        end
    end
    return h
end

local function IsDungeonGroup(group)
    local g = (group or ""):lower()
    return g:find("mazmorra") ~= nil
end
LV.IsDungeonGroup = IsDungeonGroup

-- Lee ns.LeveoRutas (una vez, al entrar al juego: hace falta saber la faccion y la clase)
function LV.BuildCatalog()
    LV.guides, LV.byId = {}, {}
    LV.ClearCondCache()
    for _, r in ipairs(ns.LeveoRutas or {}) do
        local text, fac = r[1], r[2]
        if not fac or fac == Faction() then
            local h = Header(HeaderLines(text))
            local fits = h.name and LV.Cond(h.cond)
            if fits then
                for tag, arg in pairs(h.flags) do
                    if not FlagOK(tag, arg) then fits = false; break end
                end
            end
            if fits then
                local group = h.group or "Rutas"
                local id = group .. "\\" .. h.name
                if not LV.byId[id] then
                    local g = { id = id, name = h.name, group = group, subgroup = h.subgroup, next = h.next,
                                defaultfor = h.defaultfor, text = text, flags = h.flags,
                                dungeon = IsDungeonGroup(group) }
                    g.title = (h.displayname and h.displayname ~= "") and h.displayname or h.name
                    local lo, hi = h.name:match("^(%d+)%s*%-%s*(%d+)")
                    g.min, g.max = tonumber(lo), tonumber(hi)
                    if g.max and g.max > 60 then g.max = tonumber(tostring(g.max):sub(1, 2)) end
                    LV.guides[#LV.guides + 1] = g
                    LV.byId[id] = g
                end
            end
        end
    end
    table.sort(LV.guides, function(a, b)
        if a.group ~= b.group then return a.group < b.group end
        if (a.min or 99) ~= (b.min or 99) then return (a.min or 99) < (b.min or 99) end
        return a.name < b.name
    end)
    return LV.guides
end

-- Grupos de rutas que le sirven a este personaje: {nombre, {guias}}
function LV.Groups()
    local order, by = {}, {}
    for _, g in ipairs(LV.guides) do
        if not by[g.group] then by[g.group] = {}; order[#order + 1] = g.group end
        table.insert(by[g.group], g)
    end
    local out = {}
    for _, name in ipairs(order) do out[#out + 1] = { name = name, guides = by[name], dungeon = IsDungeonGroup(name) } end
    return out
end

-- La ruta siguiente de "#next": primero en el mismo grupo, luego por nombre en cualquiera
function LV.NextOf(g)
    if not (g and g.next and g.next ~= "") then return nil end
    for nombre in g.next:gmatch("[^;]+") do
        nombre = nombre:gsub("^%s+", ""):gsub("%s+$", "")
        local grupo, n = nombre:match("^(.-)\\(.+)$")
        if grupo and LV.byId[nombre] then return LV.byId[nombre] end
        n = n or nombre
        local mismo = LV.byId[g.group .. "\\" .. n]
        if mismo then return mismo end
        for _, o in ipairs(LV.guides) do if o.name == n then return o end end
    end
end

----------------------------------------------------------------------
-- Pasos
----------------------------------------------------------------------
local function Split(s)
    local t = {}
    for part in ((s or "") .. ","):gmatch("(.-),") do t[#t + 1] = (part:gsub("^%s+", ""):gsub("%s+$", "")) end
    return t
end
local function Ids(s)
    local t = {}
    for n in (s or ""):gmatch("%-?%d+") do t[#t + 1] = math.abs(tonumber(n)) end
    return t
end
LV.Ids = Ids

-- Etiquetas que se completan con algo que haces en el juego (lo marca Seguir.lua al pasar)
local EVENTO = { vendor = "vendor", trainer = "train", train = "train", fly = "fly", fp = "fp", hs = "hearth",
                 home = "sethome", stable = "stable", bankdeposit = "bank", bankwithdraw = "bank",
                 hastyhearth = "hearth", tame = "tame" }
-- Etiquetas que solo ayudan (nombres de enemigos, objetos a usar...): no frenan el paso
local AYUDA = { target = "target", mob = "mob", unitscan = "unitscan", use = "use", link = 1, line = 1, pin = 1,
                timer = 1, cooldown = 1, disablecheckbox = 1, skipgossip = 1, skipgossipid = 1, group = 1, solo = 1,
                aura = 1, destroy = 1, equip = 1, macro = 1, addquestitem = 1, bronzetube = 1, emote = 1,
                deathskip = 1, gossipoption = 1, enabledungeon = 1, openmap = 1, clicknext = 1, reputation = 1,
                skill = 1, buy = 1, engrave = 1, showwhiledead = 1, gossip = 1, itemstat = 1 }

local function Element(tag, args, text, st, estado)
    local a = Split(args)
    local el
    if tag == "goto" or tag == "waypoint" or tag == "groundgoto" or tag == "flygoto" then
        local spec = a[1] or ""
        local m, inst = spec:match("^(%d+)/(%d+)$")
        local n1, n2 = tonumber(a[2]), tonumber(a[3])
        if not (n1 and n2) then return end
        el = { verb = "wp" }
        if m then
            -- coordenadas del mundo: primero oeste-este (Y), luego norte-sur (X), como UnitPosition al reves
            el.wy, el.wx, el.inst, el.map = n1, n2, tonumber(inst), tonumber(m)
        else
            el.map = ZoneId(spec) or estado.lastZone
            el.x, el.y = n1, n2
            if not el.map then return end
        end
        estado.lastZone = el.map
        local radius, five = tonumber(a[4]), a[5]
        if radius and radius > 0 then
            el.radius = radius
            if (five == nil or five == "") and tag ~= "waypoint" then el.verb = "go" end
        elseif radius == 0 then
            el.noArrow = true
        end
    elseif tag == "accept" or tag == "daily" then
        local q = tonumber(a[1]); if not q then return end
        el = { verb = "accept", quest = math.abs(q) }
    elseif tag == "turnin" or tag == "dailyturnin" then
        local q = tonumber(a[1]); if not q then return end
        el = { verb = "turnin", quest = math.abs(q), reward = tonumber(a[2]) }
    elseif tag == "complete" then
        local q = tonumber(a[1]); if not q then return end
        el = { verb = "complete", quest = math.abs(q), obj = tonumber(a[2]) }
    elseif tag == "collect" then
        local item = tonumber(a[1]); if not item then return end
        el = { verb = "collect", item = item, count = tonumber(a[2]) or 1, quest = tonumber(a[3]), obj = tonumber(a[4]) }
    elseif tag == "xp" then
        local s = (a[1] or ""):gsub(" ", "")
        local op = s:sub(1, 1)
        local lv, extra = s:match("(%d+)([%+%.%-]?%d*)")
        lv = tonumber(lv)
        if not lv then return end
        if a[2] and a[2] ~= "" then
            -- ".xp <N,1": el paso se salta por debajo de ese nivel; ".xp >N,1": por encima
            if op == "<" then st.tests[#st.tests + 1] = { kind = "minlevel", level = lv }
            elseif op == ">" then st.tests[#st.tests + 1] = { kind = "maxlevel", level = lv } end
            return
        end
        el = { verb = "xp", level = lv }
        if extra and extra ~= "" then
            local sign, num = extra:sub(1, 1), tonumber(extra:sub(2))
            if num then
                if sign == "." then el.frac = tonumber("0." .. extra:sub(2))
                elseif sign == "+" then el.plus = num
                elseif sign == "-" then el.minus = num end
            end
        end
    elseif tag == "zone" then
        el = { verb = "zone", zone = ZoneId(a[1]) or a[1] }
    elseif tag == "subzone" then
        el = { verb = "subzone", area = tonumber(a[1]), skip = a[2] ~= nil and a[2] ~= "" }
    elseif tag == "abandon" then
        local q = tonumber(a[1]); if not q then return end
        el = { verb = "abandon", quest = math.abs(q) }
    elseif tag == "money" then
        local op, v = (a[1] or ""):match("([<>]?)%s*([%d%.]+)")
        if not v then return end
        el = { verb = "money", op = op, copper = math.floor(tonumber(v) * 10000 + 0.5) }
    elseif tag == "cast" or tag == "usespell" then
        el = { verb = "cast", spells = Ids(a[1]) }
        if tag == "usespell" then el.verb = "hint" end
    elseif EVENTO[tag] then
        el = { verb = "event", event = EVENTO[tag], arg = a[1] }
    -- condiciones del paso (si no se cumplen, el paso no te toca)
    elseif tag == "isonquest" then st.tests[#st.tests + 1] = { kind = "onquest", ids = Ids(args) }; return
    elseif tag == "isnotonquest" then st.tests[#st.tests + 1] = { kind = "notonquest", ids = Ids(args) }; return
    elseif tag == "isquestturnedin" then st.tests[#st.tests + 1] = { kind = "turnedin", ids = Ids(args) }; return
    elseif tag == "isquestcomplete" then st.tests[#st.tests + 1] = { kind = "complete", ids = Ids(args) }; return
    elseif tag == "isquestnotcomplete" then st.tests[#st.tests + 1] = { kind = "notcomplete", ids = Ids(args) }; return
    elseif tag == "isquestavailable" then st.tests[#st.tests + 1] = { kind = "available", ids = Ids(args) }; return
    elseif tag == "maxlevel" then st.tests[#st.tests + 1] = { kind = "maxlevel", level = tonumber(a[1]) or 99 }; return
    elseif tag == "zoneskip" then
        st.tests[#st.tests + 1] = { kind = "zoneskip", zone = ZoneId(a[1]) or a[1], inverse = a[2] ~= nil and a[2] ~= "" }; return
    elseif tag == "subzoneskip" then
        st.tests[#st.tests + 1] = { kind = "subzoneskip", area = tonumber(a[1]), inverse = a[2] ~= nil and a[2] ~= "" }; return
    elseif tag == "itemcount" then
        local op, n = (a[2] or "1"):match("([<>]?)%s*(%d+)")
        st.tests[#st.tests + 1] = { kind = "itemcount", item = tonumber(a[1]), op = op, n = tonumber(n) or 1 }; return
    elseif tag == "bindlocation" then
        st.tests[#st.tests + 1] = { kind = "bind", area = tonumber(a[1]), inverse = a[2] ~= nil and a[2] ~= "" }; return
    elseif tag == "dungeon" then
        st.dungeon = a[1] or "?"; return
    elseif AYUDA[tag] then
        el = { verb = "hint", hint = tag, arg = args }
        if tag == "target" or tag == "mob" or tag == "unitscan" then el.names = Split(args) end
        if tag == "use" then el.item = tonumber(a[1]) end
    else
        LV.unknownTags = LV.unknownTags or {}
        LV.unknownTags[tag] = (LV.unknownTags[tag] or 0) + 1
        return
    end
    el.tag = tag
    if text and text ~= "" then el.text = text end
    return el
end

local function NewStep(steps, cond)
    local st = { i = #steps + 1, cond = (cond and cond ~= "") and cond or nil, flags = {}, els = {}, tests = {}, notes = {} }
    steps[#steps + 1] = st
    return st
end

local Parse

-- "#include Grupo\Nombre@etiquetaA-etiquetaB": pega los pasos de otra ruta (o un tramo)
local function Include(spec, steps, cond, depth)
    local ref, desde, hasta = spec:match("^(.-)@([^%-]*)%-?(.*)$")
    ref = ref or spec
    ref = ref:gsub("^%s+", ""):gsub("%s+$", "")
    local g = LV.byId[ref]
    if not g then
        local n = ref:match("\\(.+)$") or ref
        for _, o in ipairs(LV.guides) do if o.name == n then g = o; break end end
    end
    if not g or depth > 4 then return end
    local sub = Parse(g.text, depth + 1)
    local dentro = (desde == nil or desde == "")
    for _, st in ipairs(sub) do
        if not dentro and st.label == desde then dentro = true end
        if dentro then
            local copia = NewStep(steps, st.cond)
            for k, v in pairs(st) do if k ~= "i" and k ~= "els" then copia[k] = v end end
            copia.els = {}
            for _, e in ipairs(st.els) do
                local ne = {}
                for k2, v2 in pairs(e) do ne[k2] = v2 end
                ne.step = copia
                copia.els[#copia.els + 1] = ne
            end
            if cond then copia.cond = copia.cond and ("(" .. copia.cond .. ") (" .. cond .. ")") or cond end
        end
        if dentro and hasta and hasta ~= "" and st.label == hasta then break end
    end
end

Parse = function(text, depth)
    depth = depth or 0
    local steps, st = {}, nil
    local estado = {}
    local enCabecera = true
    for raw in (text .. "\n"):gmatch("(.-)\r?\n") do
        local line = raw:gsub("^%s+", ""):gsub("%s+$", "")
        if line ~= "" and not line:find("^%-%-") then
            local low = line:lower()
            if low == "step" or low:find("^step%s") or low:find("^step<<") then
                enCabecera = false
                local _, cond = SplitCond(line)
                st = NewStep(steps, cond)
            elseif not enCabecera and st then
                local body, cond = SplitCond(line)
                local c = line:sub(1, 1)
                if c == "#" then
                    local tag, arg = body:match("^#(%S+)%s*(.-)$")
                    if tag and (cond == nil or LV.Cond(cond)) then
                        tag = tag:lower()
                        if tag == "include" then
                            -- el paso que lleva el #include desaparece si esta vacio: lo sustituyen los incluidos
                            if #st.els == 0 and #st.notes == 0 and steps[#steps] == st then steps[#steps] = nil end
                            Include(arg, steps, st.cond, depth)
                            st = steps[#steps] or st
                        elseif tag == "completewith" then st.completewith = arg
                        elseif tag == "label" then st.label = arg
                        elseif tag == "optional" then st.optional = true
                        elseif tag == "sticky" then st.sticky = true
                        elseif tag == "loop" then st.loop = true
                        elseif tag == "requires" then st.requires = arg
                        elseif tag == "hidewindow" or tag == "map" or tag == "title" then -- nada
                        else st.flags[tag] = (arg ~= "" and arg) or true end
                    end
                elseif c == "." then
                    local tag, rest = body:match("^%.(%S+)%s*(.*)$")
                    if tag then
                        local args, txt = rest:match("^(.-)%s*>>%s*(.*)$")
                        if not args then args, txt = rest, nil end
                        local el = Element(tag:lower(), args, txt, st, estado)
                        if el then
                            el.cond = cond
                            el.pos = #st.els + 1
                            el.step = st
                            st.els[#st.els + 1] = el
                        end
                    end
                elseif body:sub(1, 2) == ">>" then
                    -- texto del paso
                    local t = body:sub(3):gsub("^%s+", "")
                    if t ~= "" then st.notes[#st.notes + 1] = { text = t, cond = cond } end
                elseif c == "+" then
                    local t = body:sub(2):gsub("^%s+", "")
                    st.els[#st.els + 1] = { verb = "note", text = t, cond = cond, pos = #st.els + 1, step = st, tag = "+" }
                elseif c == "*" then
                    local last = st.els[#st.els]
                    local t = body:sub(2):gsub("^%s+", "")
                    if last then last.tip = (last.tip and (last.tip .. "\n") or "") .. t end
                end
            end
        end
    end
    for i, s in ipairs(steps) do s.i = i end
    return steps
end
LV.Parse = Parse

-- Pasos de una ruta (se leen una vez y se guardan)
function LV.Steps(g)
    if not g then return {} end
    if not g.steps then
        local ok, res = pcall(Parse, g.text)
        g.steps = ok and res or {}
        if not ok then g.error = tostring(res) end
        -- etiquetas -> paso
        g.labels = {}
        for _, st in ipairs(g.steps) do if st.label then g.labels[st.label] = st.i end end
    end
    return g.steps
end
