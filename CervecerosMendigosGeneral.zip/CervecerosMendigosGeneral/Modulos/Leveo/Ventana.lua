-- CervecerosMendigos · Leveo: ventana de la ruta (paso actual, pegados y lo que sigue) y selector de rutas.
-- Codigo propio, GPL-3.0.
local ADDON, ns = ...
local LV = ns.LV or {}
ns.LV = LV
local T = LV.T
local W = {}
LV.Win = W

local function S() return LV.S end
local function O() return S().ventana or {} end

----------------------------------------------------------------------
-- Texto de cada linea
----------------------------------------------------------------------
local EVENTOS = { vendor = "Vende la basura y repara", train = "Entrena con tu instructor", fly = "Vuela",
                  fp = "Aprende la ruta de vuelo", hearth = "Usa la piedra de hogar", sethome = "Fija tu hogar aquí",
                  stable = "Deja la mascota en el establo", bank = "Pasa por el banco", tame = "Doma una mascota" }

local function ItemName(id)
    local n = C_Item and C_Item.GetItemNameByID and C_Item.GetItemNameByID(id)
    if not n and GetItemInfo then n = GetItemInfo(id) end
    return n or ("objeto " .. tostring(id))
end

local function Progress(el)
    if not (el.quest and LV.Q.On(el.quest)) then return "" end
    local objs = LV.Q.Objectives(el.quest)
    local list = el.obj and { objs[el.obj] } or objs
    local parts = {}
    for _, o in ipairs(list) do
        if o and o.numRequired and o.numRequired > 0 and not o.finished then
            parts[#parts + 1] = (o.numFulfilled or 0) .. "/" .. o.numRequired
        end
    end
    if #parts == 0 then return "" end
    return " |cffaaaaaa(" .. table.concat(parts, ", ") .. ")|r"
end

function W.ElText(el)
    local v = el.verb
    local t = el.text
    if v == "accept" then t = t or ("Acepta |cffffd100" .. LV.Q.Title(el.quest) .. "|r")
    elseif v == "turnin" then
        t = t or ("Entrega |cffffd100" .. LV.Q.Title(el.quest) .. "|r")
        if el.missing and not LV.Q.Done(el.quest) then t = t .. " |cff888888(no la llevas)|r" end
    elseif v == "complete" then t = (t or ("Completa |cffffd100" .. LV.Q.Title(el.quest) .. "|r")) .. Progress(el)
    elseif v == "collect" then
        t = t or ("Consigue " .. (el.count or 1) .. " x " .. ItemName(el.item))
        local n = LV.ItemCount(el.item)
        if n < (el.count or 1) then t = t .. " |cffaaaaaa(" .. n .. "/" .. (el.count or 1) .. ")|r" end
    elseif v == "xp" then t = t or ("Llega a nivel " .. el.level)
    elseif v == "event" then t = t or EVENTOS[el.event] or el.event
    elseif v == "zone" or v == "subzone" then
        local n = v == "subzone" and C_Map and C_Map.GetAreaInfo and C_Map.GetAreaInfo(el.area)
        t = t or ("Viaja a " .. (n or tostring(el.zone or el.area)))
    elseif v == "abandon" then t = t or ("Abandona |cffffd100" .. LV.Q.Title(el.quest) .. "|r")
    end
    return t
end

-- Las lineas que se ven de un paso: {texto, linea o nil, hecha}
local function StepLines(st)
    local out = {}
    for _, n in ipairs(st.notes) do
        if LV.Cond(n.cond) then out[#out + 1] = { text = n.text } end
    end
    for _, el in ipairs(st.els) do
        if T.ElShown(el) then
            local estado = T.ElState(el)
            local t = W.ElText(el)
            if t and (estado ~= nil or el.text) then
                out[#out + 1] = { text = t, el = el, done = estado == true, check = estado ~= nil }
            end
        end
    end
    if #out == 0 then out[1] = { text = "|cffaaaaaaSigue la flecha|r" } end
    return out
end
W.StepLines = StepLines

local function Short(st)
    for _, el in ipairs(st.els) do
        if T.ElShown(el) and T.ElState(el) ~= nil then return W.ElText(el) end
    end
    for _, n in ipairs(st.notes) do if LV.Cond(n.cond) then return n.text end end
    for _, el in ipairs(st.els) do if el.text and T.ElShown(el) then return el.text end end
    return "..."
end

----------------------------------------------------------------------
-- La ventana
----------------------------------------------------------------------
local win, rows = nil, {}
local PAD = 8

local function Btn(parent, text, w, tip, onClick)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(w, 18)
    b:SetText(text)
    if b.GetFontString and b:GetFontString() then b:GetFontString():SetFontObject("GameFontNormalSmall") end
    b:SetScript("OnClick", onClick)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_TOP"); GameTooltip:SetText(tip, 1, 1, 1, 1, true); GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    return b
end

local function Row(i)
    local r = rows[i]
    if r then return r end
    r = CreateFrame("Button", nil, win.body)
    r.check = r:CreateTexture(nil, "ARTWORK")
    r.check:SetSize(13, 13)
    r.check:SetPoint("TOPLEFT", 0, -1)
    r.text = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    r.text:SetPoint("TOPLEFT", 17, 0)
    r.text:SetJustifyH("LEFT")
    r.text:SetJustifyV("TOP")
    if r.text.SetWordWrap then r.text:SetWordWrap(true) end
    r:SetScript("OnClick", function(self)
        if self.el and self.checkable then T.Toggle(self.el) end
    end)
    r:SetScript("OnEnter", function(self)
        if not (self.el and (self.el.tip or self.el.quest)) then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        if self.el.quest then GameTooltip:AddLine(LV.Q.Title(self.el.quest), 1, 0.82, 0) end
        if self.el.quest and LV.Help and LV.Help.QuestInfo then
            for _, l in ipairs(LV.Help.QuestInfo(self.el.quest)) do GameTooltip:AddLine(l, 0.85, 0.85, 0.85, true) end
        end
        if self.el.tip then GameTooltip:AddLine(self.el.tip, 1, 1, 1, true) end
        if self.checkable then GameTooltip:AddLine("Clic: marcar o desmarcar a mano", 0.6, 0.6, 0.6) end
        GameTooltip:Show()
    end)
    r:SetScript("OnLeave", function() GameTooltip:Hide() end)
    rows[i] = r
    return r
end

local function Skin()
    if not win then return end
    local o = O()
    win:SetScale((o.escala or 100) / 100)
    win.bg:SetColorTexture(0.05, 0.045, 0.04, (o.opacidad or 85) / 100)
    win:SetWidth(o.ancho or 300)
    win:EnableMouse(true)
end
W.Skin = Skin

local function Build()
    if win then return win end
    win = LV.mod:Frame("Frame", "CMLeveoGuia", UIParent)
    win:SetFrameStrata("MEDIUM")
    win:SetSize(300, 120)
    win:SetClampedToScreen(true)
    win:SetMovable(true)
    win:RegisterForDrag("LeftButton")
    win:SetScript("OnDragStart", function(self) if not O().bloqueada then self:StartMoving() end end)
    win:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p, _, rp, x, y = self:GetPoint()
        O().pos = { p, rp, x, y }
    end)
    win.bg = win:CreateTexture(nil, "BACKGROUND")
    win.bg:SetAllPoints()
    local borde = win:CreateTexture(nil, "BORDER")
    borde:SetPoint("TOPLEFT"); borde:SetPoint("TOPRIGHT"); borde:SetHeight(2)
    borde:SetColorTexture(0.55, 0.42, 0.12, 0.9)
    win.title = win:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    win.title:SetPoint("TOPLEFT", PAD, -6)
    win.title:SetJustifyH("LEFT")
    win.sub = win:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    win.sub:SetPoint("TOPLEFT", win.title, "BOTTOMLEFT", 0, -1)
    win.sub:SetJustifyH("LEFT")
    win.bClose = Btn(win, "x", 20, "Ocultar la ventana (vuelve con /leveo guia)", function()
        O().mostrar = false; W.Refresh()
    end)
    win.bClose:SetPoint("TOPRIGHT", -4, -4)
    win.bRutas = Btn(win, "Rutas", 46, "Elegir otra ruta", function() W.TogglePicker() end)
    win.bRutas:SetPoint("RIGHT", win.bClose, "LEFT", -2, 0)
    win.bLost = Btn(win, "?", 20, "Estoy perdido: busca el primer paso que te falta", function()
        if T.g then T.Load(T.g, "lost"); LV.mod:Print("te he puesto en el primer paso que te falta.") end
    end)
    win.bLost:SetPoint("RIGHT", win.bRutas, "LEFT", -2, 0)
    win.bNext = Btn(win, ">", 20, "Saltar este paso", function() T.Go(1) end)
    win.bNext:SetPoint("RIGHT", win.bLost, "LEFT", -2, 0)
    win.bPrev = Btn(win, "<", 20, "Paso anterior (mientras miras atras la ruta no avanza sola)", function() T.Go(-1) end)
    win.bPrev:SetPoint("RIGHT", win.bNext, "LEFT", -2, 0)
    win.title:SetPoint("RIGHT", win.bPrev, "LEFT", -4, 0)
    win.body = CreateFrame("Frame", nil, win)
    win.body:SetPoint("TOPLEFT", PAD, -38)
    win.body:SetPoint("TOPRIGHT", -PAD, -38)
    win.body:SetHeight(10)
    local p = O().pos
    if p then win:SetPoint(p[1], UIParent, p[2], p[3], p[4]) else win:SetPoint("RIGHT", UIParent, "RIGHT", -60, 120) end
    Skin()
    win:Hide()
    return win
end

function W.ResetPos()
    O().pos = nil
    if win then win:ClearAllPoints(); win:SetPoint("RIGHT", UIParent, "RIGHT", -60, 120) end
end

local CHECK_ON = "Interface\\RaidFrame\\ReadyCheck-Ready"
local CHECK_OFF = "Interface\\Buttons\\UI-CheckBox-Up"

function W.Refresh()
    if not (LV.mod and LV.mod:IsEnabled()) then return end
    local o = O()
    local mostrar = o.mostrar ~= false and S().guiaActiva ~= false
    if mostrar and o.combate == false and InCombatLockdown and InCombatLockdown() then mostrar = false end
    if not mostrar then if win then win:Hide() end; return end
    Build()
    Skin()
    local ancho = (o.ancho or 300) - PAD * 2 - 17
    local n, y = 0, 0
    local function Add(text, el, done, checkable, color, small)
        n = n + 1
        local r = Row(n)
        r.el, r.checkable = el, checkable
        r.text:SetWidth(ancho)
        r.text:SetFontObject(small and "GameFontDisableSmall" or "GameFontHighlightSmall")
        r.text:SetText(text)
        if color then r.text:SetTextColor(color[1], color[2], color[3]) else r.text:SetTextColor(1, 1, 1) end
        if checkable then
            r.check:Show()
            r.check:SetTexture(done and CHECK_ON or CHECK_OFF)
            r.check:SetDesaturated(false)
            r.text:SetAlpha(done and 0.55 or 1)
        else
            r.check:Hide()
            r.text:SetAlpha(1)
        end
        local h = math.max(14, (r.text:GetStringHeight() or 12) + 3)
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", win.body, "TOPLEFT", 0, -y)
        r:SetSize(ancho + 17, h)
        r:Show()
        y = y + h
    end
    if not T.g then
        win.title:SetText("Leveo")
        win.sub:SetText("Sin ruta cargada")
        Add("Pulsa |cffffd100Rutas|r para elegir una, o escribe |cffffd100/leveo ruta|r para que la elija sola.")
    elseif T.finished then
        win.title:SetText(T.g.title)
        win.sub:SetText("Ruta terminada")
        local nx = LV.NextOf(T.g)
        Add(nx and ("Sigue con |cffffd100" .. nx.title .. "|r (se carga sola si lo tienes activado).")
            or "Ruta terminada. Elige la siguiente en |cffffd100Rutas|r.")
    else
        local pos, total = T.Count()
        win.title:SetText(T.g.title)
        win.sub:SetText(string.format("Paso %d de %d%s", pos, total, T.browse and "  |cffff9a3c(mirando atrás)|r" or ""))
        local st = T.Current()
        if st then
            for _, l in ipairs(StepLines(st)) do Add(l.text, l.el, l.done, l.check) end
        end
        if o.pegados ~= false then
            local side = T.Side()
            local max = o.maxPegados or 3
            for k, s2 in ipairs(side) do
                if k > max then break end
                for _, l in ipairs(StepLines(s2)) do
                    if l.check or not l.el then Add(l.text, l.el, l.done, l.check, { 0.85, 0.85, 0.7 }, true) end
                end
            end
        end
        local nSig = o.siguientes or 2
        if nSig > 0 then
            local up = T.Upcoming(nSig)
            if #up > 0 then
                Add("Después:", nil, nil, nil, { 0.6, 0.6, 0.6 }, true)
                for _, s2 in ipairs(up) do Add("· " .. Short(s2), nil, nil, nil, { 0.6, 0.6, 0.6 }, true) end
            end
        end
    end
    for i = n + 1, #rows do rows[i]:Hide() end
    win.body:SetHeight(math.max(10, y))
    win:SetHeight(38 + y + PAD)
    win:Show()
end

LV.Listen("update", function() W.Refresh() end)
LV.Listen("guide", function() W.Refresh(); if W.picker and W.picker:IsShown() then W.FillPicker() end end)
LV.On("PLAYER_REGEN_DISABLED", function() if O().combate == false then W.Refresh() end end)
LV.On("PLAYER_REGEN_ENABLED", function() if O().combate == false then W.Refresh() end end)

----------------------------------------------------------------------
-- Selector de rutas
----------------------------------------------------------------------
local pickRows = {}
function W.FillPicker()
    local pk = W.picker
    if not pk then return end
    local child = pk.child
    local y, n = 0, 0
    local function Line(text, onClick, header, current)
        n = n + 1
        local b = pickRows[n]
        if not b then
            b = CreateFrame("Button", nil, child)
            b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            b.text:SetPoint("LEFT", 6, 0)
            b.text:SetJustifyH("LEFT")
            b.hl = b:CreateTexture(nil, "HIGHLIGHT")
            b.hl:SetAllPoints(); b.hl:SetColorTexture(1, 1, 1, 0.08)
            pickRows[n] = b
        end
        b:ClearAllPoints()
        b:SetPoint("TOPLEFT", child, "TOPLEFT", 0, -y)
        b:SetSize(370, header and 20 or 16)
        b.text:SetFontObject(header and "GameFontNormal" or "GameFontHighlightSmall")
        b.text:SetText(text)
        b.text:SetTextColor(header and 1 or (current and 0.3 or 1), header and 0.82 or 1, header and 0 or (current and 0.3 or 1))
        b:SetScript("OnClick", onClick)
        b:Show()
        y = y + (header and 22 or 16)
    end
    local lvl = LV.Level()
    for _, grp in ipairs(LV.Groups()) do
        if not grp.dungeon or S().verMazmorras ~= false then
            Line(grp.name, function() end, true)
            for _, g in ipairs(grp.guides) do
                local marca = (g.min and g.max and lvl >= g.min and lvl <= g.max) and " |cff5cf05c(tu nivel)|r" or ""
                local actual = T.g and T.g.id == g.id
                Line((actual and "> " or "   ") .. g.title .. marca, function()
                    T.Load(g, "lost")
                    O().mostrar = true
                    W.Refresh()
                    LV.mod:Print("ruta cargada: " .. g.title)
                end, false, actual)
            end
        end
    end
    for i = n + 1, #pickRows do pickRows[i]:Hide() end
    child:SetHeight(math.max(10, y))
end

function W.TogglePicker()
    if not W.picker then
        local pk = ns.Hub.UI.MakeWindow("CMLeveoRutas", "Rutas de leveo", 420, 500)
        LV.mod:Track(pk)
        local sf, child = ns.Hub.UI.MakeScroll(pk, 380, 400)
        sf:SetPoint("TOPLEFT", 14, -34)
        pk.child = child
        local auto = CreateFrame("Button", nil, pk, "UIPanelButtonTemplate")
        auto:SetSize(180, 22)
        auto:SetPoint("BOTTOMLEFT", 14, 12)
        auto:SetText("Elegir la de mi nivel")
        auto:SetScript("OnClick", function()
            local g = LV.Suggest()
            if g then T.Load(g, "lost"); O().mostrar = true; W.Refresh(); LV.mod:Print("ruta cargada: " .. g.title)
            else LV.mod:Print("no encontré una ruta para tu nivel.") end
        end)
        local quitar = CreateFrame("Button", nil, pk, "UIPanelButtonTemplate")
        quitar:SetSize(120, 22)
        quitar:SetPoint("LEFT", auto, "RIGHT", 8, 0)
        quitar:SetText("Quitar la ruta")
        quitar:SetScript("OnClick", function() T.Unload(); LV.Arrow.Refresh() end)
        W.picker = pk
    end
    if W.picker:IsShown() then W.picker:Hide() else W.FillPicker(); W.picker:Show() end
end

----------------------------------------------------------------------
-- Ruta para tu nivel: la de tu raza/clase si la hay, en el grupo normal (o el de mazmorras si lo eliges)
----------------------------------------------------------------------
function LV.Suggest()
    local lvl = LV.Level()
    local best, bestScore
    for _, g in ipairs(LV.guides) do
        if g.min and g.max and not g.group:find("Misiones de Mazmorras") then
            local score
            if lvl >= g.min and lvl < math.max(g.max, g.min + 1) then score = 100
            elseif lvl == g.max then score = 60
            elseif lvl < g.min then score = 40 - (g.min - lvl) * 5
            else score = -1 end
            if score > 0 then
                if g.defaultfor and not g.defaultfor:lower():find("^none") and LV.Cond(g.defaultfor) then score = score + 30 end
                local quiereMaz = S().mazmorras == true
                if g.dungeon == quiereMaz then score = score + 20 end
                if g.group:find("^Guía Forever") or g.group:find("^Forever Guía") then score = score + 10 end
                if g.group:find("Mago") and LV.ClassTok() ~= "MAGE" then score = score - 200 end
                if g.group:find("ADV") then score = score - 15 end
                if not bestScore or score > bestScore then best, bestScore = g, score end
            end
        end
    end
    return best
end
