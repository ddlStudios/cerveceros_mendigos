-- CervecerosMendigos · Leveo: sigue la ruta cargada (codigo propio, GPL-3.0).
-- Decide que lineas de cada paso ya hiciste, cual es el paso actual, que pasos "pegados" se ven a la
-- vez y cuales vienen despues. Guarda por personaje: ruta, paso, lo marcado a mano y los lugares visitados.
local ADDON, ns = ...
local LV = ns.LV or {}
ns.LV = LV
local T = {}
LV.T = T

local function S() return LV.S end

----------------------------------------------------------------------
-- Eventos: un solo manejador por evento en el Hub; aqui se reparten
----------------------------------------------------------------------
LV.handlers = LV.handlers or {}
function LV.On(ev, fn)
    local l = LV.handlers[ev]
    if not l then l = {}; LV.handlers[ev] = l end
    l[#l + 1] = fn
end
function LV.Fire(ev, ...)
    local l = LV.handlers[ev]
    if not l then return end
    for _, fn in ipairs(l) do
        local ok, err = pcall(fn, ev, ...)
        if not ok and LV.debug then print("|cff33ff99Leveo:|r error en " .. ev .. ": " .. tostring(err)) end
    end
end
-- avisos internos (la ventana y la flecha se enteran de que cambio algo)
LV.listeners = LV.listeners or {}
function LV.Listen(name, fn) LV.listeners[name] = LV.listeners[name] or {}; table.insert(LV.listeners[name], fn) end
function LV.Notify(name, ...)
    for _, fn in ipairs(LV.listeners[name] or {}) do pcall(fn, ...) end
end

----------------------------------------------------------------------
-- Misiones (API nueva de Forever, con la vieja de respaldo)
----------------------------------------------------------------------
local Q = {}
LV.Q = Q
local doneCache = {}
function Q.Reset() doneCache = {} end
function Q.Done(q)
    if not q then return false end
    local v = doneCache[q]
    if v == nil then
        if C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted then v = C_QuestLog.IsQuestFlaggedCompleted(q)
        elseif IsQuestFlaggedCompleted then v = IsQuestFlaggedCompleted(q) end
        v = v and true or false
        doneCache[q] = v
    end
    return v
end
function Q.MarkDone(q) if q then doneCache[q] = true end end
function Q.On(q)
    if not q then return false end
    if C_QuestLog and C_QuestLog.GetLogIndexForQuestID then
        local i = C_QuestLog.GetLogIndexForQuestID(q)
        if i and i > 0 then return true end
    end
    if C_QuestLog and C_QuestLog.IsOnQuest then return C_QuestLog.IsOnQuest(q) and true or false end
    if GetQuestLogIndexByID then local i = GetQuestLogIndexByID(q); return i and i > 0 or false end
    return false
end
function Q.Complete(q)
    if not Q.On(q) then return false end
    if C_QuestLog and C_QuestLog.IsComplete then return C_QuestLog.IsComplete(q) and true or false end
    if C_QuestLog and C_QuestLog.ReadyForTurnIn then return C_QuestLog.ReadyForTurnIn(q) and true or false end
    return false
end
function Q.Objectives(q)
    if C_QuestLog and C_QuestLog.GetQuestObjectives then
        local ok, t = pcall(C_QuestLog.GetQuestObjectives, q)
        if ok and type(t) == "table" then return t end
    end
    return {}
end
function Q.Title(q)
    local t = C_QuestLog and C_QuestLog.GetTitleForQuestID and C_QuestLog.GetTitleForQuestID(q)
    if t and t ~= "" then return t end
    local d = LV.QuestData and LV.QuestData(q)
    return d and d[2] or ("mision " .. tostring(q))
end

-- Datos.lua (CMLQuests) por numero: para saber donde esta el dador si la ruta no lo dice
local qIndex
function LV.QuestData(q)
    if not qIndex then
        qIndex = {}
        for _, d in ipairs(CMLQuests or {}) do qIndex[d[1]] = d end
    end
    return qIndex[q]
end
function LV.QuestGiver(q)
    local d = LV.QuestData(q)
    if not d or not d[8] or d[8] == 0 or not d[9] or d[9] == 0 then return end
    local z = (CMLZones or {})[d[8]]
    local map = z and z[7]
    if not map then return end
    return { map = map, x = d[9], y = d[10], approx = true, name = d[7] }
end

----------------------------------------------------------------------
-- Lugar: donde estas y donde queda cada punto (metros del mundo)
----------------------------------------------------------------------
function LV.PlayerWorld()
    if UnitPosition then
        local a, b, _, inst = UnitPosition("player")
        if a and b then return inst, a, b end
    end
    local map = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
    if not map then return end
    local pos = C_Map.GetPlayerMapPosition and C_Map.GetPlayerMapPosition(map, "player")
    if not pos then return end
    local x, y = pos:GetXY()
    if not x or (x == 0 and y == 0) then return end
    return LV.MapToWorld(map, x * 100, y * 100)
end

function LV.MapToWorld(map, x, y)
    if not (C_Map and C_Map.GetWorldPosFromMapPos and CreateVector2D) then return end
    local ok, cont, pos = pcall(C_Map.GetWorldPosFromMapPos, map, CreateVector2D(x / 100, y / 100))
    if not ok or not pos then return end
    local wx, wy = pos:GetXY()
    return cont, wx, wy
end

-- Punto del mundo de una linea o de un sitio {map,x,y} / {inst,wx,wy}
function LV.SpotWorld(p)
    if p.wx then return p.inst, p.wx, p.wy end
    if p.x and p.map then
        if p._w == nil then
            local c, wx, wy = LV.MapToWorld(p.map, p.x, p.y)
            p._w = c and { c, wx, wy } or false
        end
        if p._w then return p._w[1], p._w[2], p._w[3] end
    end
end

-- metros y angulo (desde el norte, hacia el oeste: como GetPlayerFacing) del jugador al punto
function LV.Distance(p)
    local c2, wx, wy = LV.SpotWorld(p)
    if not c2 then return end
    local c1, px, py = LV.PlayerWorld()
    if not c1 or c1 ~= c2 then return end
    local dx, dy = wx - px, wy - py
    return math.sqrt(dx * dx + dy * dy), math.atan2(dy, dx)
end

-- Estas en ese mapa (o en una zona dentro de el)
function LV.InMap(map)
    if not (C_Map and C_Map.GetBestMapForUnit) then return false end
    local m, guard = C_Map.GetBestMapForUnit("player"), 0
    while m and m > 0 and guard < 8 do
        if m == map then return true end
        local info = C_Map.GetMapInfo and C_Map.GetMapInfo(m)
        m = info and info.parentMapID
        guard = guard + 1
    end
    return false
end
function LV.InArea(area)
    local name = area and C_Map and C_Map.GetAreaInfo and C_Map.GetAreaInfo(area)
    if not name then return false end
    local sub = GetSubZoneText and GetSubZoneText() or ""
    local mini = GetMinimapZoneText and GetMinimapZoneText() or ""
    local zone = GetZoneText and GetZoneText() or ""
    return name == sub or name == mini or name == zone
end
function LV.InZone(z)
    if type(z) == "number" then
        if LV.InMap(z) then return true end
        if C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(z) then return false end
        return LV.InArea(z)
    end
    local zone = (GetZoneText and GetZoneText() or ""):lower()
    return type(z) == "string" and zone == z:lower()
end

----------------------------------------------------------------------
-- Estado guardado de este personaje
----------------------------------------------------------------------
local function CharKey()
    return (UnitName("player") or "?") .. "-" .. (GetRealmName and GetRealmName() or "?")
end
function T.P()
    local s = S()
    s.pj = s.pj or {}
    local k = CharKey()
    local p = s.pj[k]
    if not p then p = { manual = {}, visited = {}, labels = {} }; s.pj[k] = p end
    p.manual = p.manual or {}; p.visited = p.visited or {}; p.labels = p.labels or {}
    return p
end
local P = T.P
local function Key(el) return el.step.i .. ":" .. el.pos end
T.Key = Key

----------------------------------------------------------------------
-- Condiciones de cada paso
----------------------------------------------------------------------
local function AnyQuest(ids, fn)
    for _, q in ipairs(ids or {}) do if fn(q) then return true end end
    return false
end

local function ItemCount(id)
    if C_Item and C_Item.GetItemCount then return C_Item.GetItemCount(id) or 0 end
    if GetItemCount then return GetItemCount(id) or 0 end
    return 0
end
LV.ItemCount = ItemCount

local TEST = {
    onquest = function(t) return AnyQuest(t.ids, Q.On) end,
    notonquest = function(t) return not AnyQuest(t.ids, Q.On) end,
    turnedin = function(t) return AnyQuest(t.ids, Q.Done) end,
    complete = function(t) return AnyQuest(t.ids, Q.Complete) end,
    notcomplete = function(t) return AnyQuest(t.ids, function(q) return Q.On(q) and not Q.Complete(q) end) end,
    available = function(t) return AnyQuest(t.ids, function(q) return not Q.On(q) and not Q.Done(q) end) end,
    maxlevel = function(t) return LV.Level() <= t.level end,
    minlevel = function(t) return LV.Level() >= t.level end,
    zoneskip = function(t)
        local dentro = LV.InZone(t.zone)
        if t.inverse then return dentro end
        return not dentro
    end,
    subzoneskip = function(t)
        local dentro = LV.InArea(t.area)
        if t.inverse then return dentro end
        return not dentro
    end,
    itemcount = function(t)
        if not t.item then return true end
        local n = ItemCount(t.item)
        if t.op == "<" then return n < t.n end
        if t.op == ">" then return n > t.n end
        return n >= t.n
    end,
    bind = function(t)
        local name = t.area and C_Map and C_Map.GetAreaInfo and C_Map.GetAreaInfo(t.area)
        local bind = GetBindLocation and GetBindLocation()
        local alli = name and bind and name == bind
        -- ".bindlocation X": el paso sobra si tu piedra ya esta en X; con ",1" al reves
        if t.inverse then return alli and true or false end
        return not alli
    end,
}

function T.StepShown(st)
    if not LV.Cond(st.cond) then return false end
    for tag, arg in pairs(st.flags) do
        if not LV.FlagOK(tag, arg) then return false end
    end
    if st.dungeon and not S().mazmorras then return false end
    if st.requires and not P().labels[st.requires] then return false end
    for _, t in ipairs(st.tests) do
        local fn = TEST[t.kind]
        if fn and not fn(t) then return false end
    end
    return true
end

function T.ElShown(el) return LV.Cond(el.cond) end

----------------------------------------------------------------------
-- Si una linea ya esta hecha: true = hecha, false = falta, nil = no cuenta (ayuda o lugar de paso)
----------------------------------------------------------------------
local function XPDone(el)
    local lv = LV.Level()
    if lv > el.level then return true end
    if lv < el.level then return false end
    local xp, max = UnitXP("player") or 0, UnitXPMax("player") or 1
    if el.frac then return max > 0 and xp / max >= el.frac end
    if el.plus then return xp >= el.plus end
    if el.minus then return max - xp <= el.minus end
    return true
end

function T.ElState(el)
    if P().manual[Key(el)] then return true end
    local v = el.verb
    if v == "accept" then
        return Q.Done(el.quest) or Q.On(el.quest)
    elseif v == "turnin" then
        if Q.Done(el.quest) then return true end
        if not Q.On(el.quest) then el.missing = true; return true end
        el.missing = nil
        return false
    elseif v == "complete" then
        if Q.Done(el.quest) then return true end
        if not Q.On(el.quest) then el.missing = true; return true end
        el.missing = nil
        if el.obj then
            local o = Q.Objectives(el.quest)[el.obj]
            if o then return o.finished and true or false end
        end
        return Q.Complete(el.quest)
    elseif v == "collect" then
        if el.quest then
            if Q.Done(el.quest) or not Q.On(el.quest) or Q.Complete(el.quest) then return true end
            if el.obj then
                local o = Q.Objectives(el.quest)[el.obj]
                if o and o.finished then return true end
            end
        end
        return ItemCount(el.item) >= (el.count or 1)
    elseif v == "go" then
        return P().visited[Key(el)] and true or false
    elseif v == "xp" then
        return XPDone(el)
    elseif v == "zone" then
        return LV.InZone(el.zone)
    elseif v == "subzone" then
        return LV.InArea(el.area)
    elseif v == "abandon" then
        return not Q.On(el.quest)
    elseif v == "money" then
        local m = GetMoney and GetMoney() or 0
        if el.op == "<" then return m < el.copper end
        return m >= el.copper
    elseif v == "event" or v == "cast" or v == "note" then
        return false
    end
    return nil
end

-- Lugar al que hay que llegar en un paso que solo tiene lugares (sin nada mas que hacer)
local function ArrivalEl(st)
    local last
    for _, el in ipairs(st.els) do
        if (el.verb == "wp" or el.verb == "go") and not el.noArrow and T.ElShown(el) then last = el end
    end
    return last
end

-- lenient: para "Estoy perdido" (lo que el juego no puede comprobar se da por hecho)
function T.StepDone(st, lenient)
    if P().manual["s" .. st.i] then return true end
    local cuenta = false
    for _, el in ipairs(st.els) do
        if T.ElShown(el) then
            local s = T.ElState(el)
            if s ~= nil then
                if lenient and (el.verb == "event" or el.verb == "cast" or el.verb == "note" or el.verb == "go"
                                or el.verb == "zone" or el.verb == "subzone" or el.verb == "money") then
                    s = true
                end
                cuenta = true
                if not s then return false end
            end
        end
    end
    if cuenta then return true end
    if lenient then return true end
    local a = ArrivalEl(st)
    if a then return P().visited[Key(a)] and true or false end
    return false
end

-- Lleva alguna mision de este paso (los opcionales solo frenan si la llevas)
local function HasQuest(st)
    for _, el in ipairs(st.els) do
        if el.quest and (el.verb == "complete" or el.verb == "turnin" or el.verb == "collect") and Q.On(el.quest) then
            return true
        end
    end
    return false
end

function T.Blocks(st)
    if st.completewith or st.sticky then return false end
    if st.optional then return HasQuest(st) end
    return true
end

----------------------------------------------------------------------
-- Cargar una ruta y avanzar
----------------------------------------------------------------------
T.g, T.steps, T.cur = nil, {}, 1

function T.Load(g, at)
    if not g then return end
    local p = P()
    T.g = g
    T.steps = LV.Steps(g)
    if p.guide ~= g.id then
        p.guide = g.id
        p.manual, p.visited = {}, {}
        p.cur = 1
    end
    T.browse = nil
    if at == "lost" then
        p.cur = T.Lost() or 1
    elseif type(at) == "number" then
        p.cur = math.max(1, math.min(at, #T.steps))
    end
    T.cur = p.cur or 1
    T.finished = nil
    T.Update()
    LV.Notify("guide")
end

function T.Unload()
    T.g, T.steps, T.cur, T.finished = nil, {}, 1, nil
    P().guide = nil
    LV.Notify("guide")
end

-- Primer paso que te falta, dando por hecho lo que no se puede comprobar
function T.Lost()
    for i, st in ipairs(T.steps) do
        if T.StepShown(st) and T.Blocks(st) and not T.StepDone(st, true) then return i end
    end
    return #T.steps + 1
end

function T.Update()
    if not T.g then return end
    local p = P()
    local steps = T.steps
    local i = p.cur or 1
    -- mirando pasos de atras a mano: no se avanza solo hasta que vuelvas hacia delante
    if T.browse then LV.Notify("update"); return end
    while i <= #steps do
        local st = steps[i]
        if T.StepShown(st) then
            local done = T.StepDone(st)
            if done and st.label then p.labels[st.label] = true end
            if not done and T.Blocks(st) then break end
        end
        i = i + 1
    end
    -- bucles: si ya pasaste por todos los puntos, se vuelve a empezar la vuelta
    local st = steps[i]
    if st and st.loop then
        local todos, alguno = true, false
        for _, el in ipairs(st.els) do
            if el.radius and T.ElShown(el) then
                alguno = true
                if not p.visited[Key(el)] then todos = false end
            end
        end
        if alguno and todos then
            for _, el in ipairs(st.els) do if el.radius then p.visited[Key(el)] = nil end end
        end
    end
    local cambio = i ~= T.cur
    p.cur, T.cur = i, i
    if i > #steps then
        if not T.finished then
            T.finished = true
            LV.Notify("finished", T.g)
        end
    else
        T.finished = nil
    end
    if cambio then LV.Notify("step", i) end
    LV.Notify("update")
end

function T.Schedule() LV.dirty = true end

function T.Current() if T.g and not T.finished then return T.steps[T.cur] end end

-- Ir a un paso a mano (anterior / siguiente)
function T.Go(delta)
    if not T.g then return end
    local p = P()
    local i = (T.cur or 1) + delta
    -- se saltan los pasos que no te tocan
    while T.steps[i] and not (T.StepShown(T.steps[i]) and T.Blocks(T.steps[i])) do i = i + delta end
    if i < 1 then i = 1 end
    if delta > 0 then
        if T.browse then
            T.browse = nil
        elseif T.steps[T.cur] then
            p.manual["s" .. T.cur] = true
        end
    else
        T.browse = true
        for j = i, (T.cur or i) do p.manual["s" .. j] = nil end
    end
    p.cur, T.cur = i, i
    T.finished = i > #T.steps or nil
    LV.Notify("step", i)
    LV.Notify("update")
end

-- Marcar una linea a mano (clic en su circulo)
function T.Toggle(el)
    local p = P()
    local k = Key(el)
    p.manual[k] = (not p.manual[k]) or nil
    T.Update()
end

-- Pasos que siguen visibles a la vez que el actual ("pegados" y "hasta el siguiente")
local function Target(st)
    local g = T.g
    local cw = st.completewith
    if not cw then return nil end
    if cw:lower() == "next" then
        for k = st.i + 1, #T.steps do
            local o = T.steps[k]
            if T.StepShown(o) and T.Blocks(o) then return k end
        end
        return #T.steps
    end
    return g.labels and g.labels[cw] or nil
end

function T.Side()
    local out = {}
    if not T.g then return out end
    local cur = T.cur or 1
    local desde = math.max(1, cur - 120)
    for j = desde, math.min(cur - 1, #T.steps) do
        local st = T.steps[j]
        if (st.completewith or st.sticky) and T.StepShown(st) and not T.StepDone(st) then
            local ok
            if st.sticky then ok = true else
                local k = Target(st)
                ok = k and cur <= k
            end
            if ok then out[#out + 1] = st end
        end
    end
    -- tambien los "hasta el siguiente" que estan justo en el paso actual o delante y aun no toca saltar
    return out
end

-- Los pasos que vienen despues
function T.Upcoming(n)
    local out = {}
    if not T.g then return out end
    local k = (T.cur or 1) + 1
    while k <= #T.steps and #out < n do
        local st = T.steps[k]
        if T.StepShown(st) and T.Blocks(st) and not T.StepDone(st) then out[#out + 1] = st end
        k = k + 1
    end
    return out
end

-- Numero de pasos que te tocan (para "Paso 12 de 80")
function T.Count()
    if not T.g then return 0, 0 end
    local n, pos = 0, 0
    for i, st in ipairs(T.steps) do
        if T.StepShown(st) and T.Blocks(st) then
            n = n + 1
            if i <= (T.cur or 1) then pos = n end
        end
    end
    return pos, n
end

----------------------------------------------------------------------
-- Lugares de paso: al llegar al radio de un punto se marca visitado
----------------------------------------------------------------------
function T.CheckPlaces()
    if not T.g then return end
    local p = P()
    local list = { T.Current() }
    for _, st in ipairs(T.Side()) do list[#list + 1] = st end
    local cambio = false
    for _, st in ipairs(list) do
        if st then
            local llegar = ArrivalEl(st)
            local soloLugares = true
            for _, el in ipairs(st.els) do
                if T.ElShown(el) and T.ElState(el) ~= nil and el.verb ~= "go" then soloLugares = false; break end
            end
            for _, el in ipairs(st.els) do
                if (el.verb == "go" or el.verb == "wp") and T.ElShown(el) and not p.visited[Key(el)] then
                    local radio = el.radius or ((soloLugares and el == llegar) and (S().llegada or 12)) or nil
                    if radio then
                        local d = LV.Distance(el)
                        if d and d <= radio then p.visited[Key(el)] = true; cambio = true end
                    end
                end
            end
        end
    end
    if cambio then T.Update() end
end

----------------------------------------------------------------------
-- Cosas que el juego no deja comprobar despues: se marcan al hacerlas con el paso a la vista
----------------------------------------------------------------------
function T.MarkEvent(event, test)
    if not T.g then return end
    local list = { T.Current() }
    for _, st in ipairs(T.Side()) do list[#list + 1] = st end
    local p, marcado = P(), false
    for _, st in ipairs(list) do
        if st then
            for _, el in ipairs(st.els) do
                if T.ElShown(el) and el.verb == "event" and el.event == event and (not test or test(el)) then
                    p.manual[Key(el)] = true
                    marcado = true
                end
            end
        end
    end
    if marcado then T.Update() end
    return marcado
end

function T.MarkCast(spell)
    if not T.g then return end
    local list = { T.Current() }
    for _, st in ipairs(T.Side()) do list[#list + 1] = st end
    local p, marcado = P(), false
    for _, st in ipairs(list) do
        if st then
            for _, el in ipairs(st.els) do
                if el.verb == "cast" and T.ElShown(el) then
                    for _, id in ipairs(el.spells or {}) do
                        if id == spell then p.manual[Key(el)] = true; marcado = true end
                    end
                end
            end
        end
    end
    if marcado then T.Update() end
end

local HEARTH = { [8690] = true, [556] = true }   -- piedra de hogar, Regreso astral
LV.On("UNIT_SPELLCAST_SUCCEEDED", function(_, unit, _, spell)
    if unit ~= "player" then return end
    if HEARTH[spell] then T.MarkEvent("hearth") end
    T.MarkCast(spell)
end)
LV.On("MERCHANT_CLOSED", function() T.MarkEvent("vendor") end)
LV.On("TRAINER_CLOSED", function() T.MarkEvent("train") end)
LV.On("HEARTHSTONE_BOUND", function() T.MarkEvent("sethome") end)
LV.On("PET_STABLE_CLOSED", function() T.MarkEvent("stable") end)
LV.On("BANKFRAME_CLOSED", function() T.MarkEvent("bank") end)
LV.On("UI_INFO_MESSAGE", function(_, _, msg)
    if msg and ERR_NEWTAXIPATH and msg == ERR_NEWTAXIPATH then T.MarkEvent("fp") end
end)
LV.On("PLAYER_CONTROL_LOST", function()
    if C_Timer and C_Timer.After then
        C_Timer.After(1, function() if UnitOnTaxi and UnitOnTaxi("player") then T.MarkEvent("fly") end end)
    end
end)

-- lo que cambia el estado de las misiones o del personaje
for _, ev in ipairs({ "QUEST_LOG_UPDATE", "QUEST_ACCEPTED", "QUEST_REMOVED", "PLAYER_LEVEL_UP", "PLAYER_XP_UPDATE",
                      "ZONE_CHANGED", "ZONE_CHANGED_INDOORS", "ZONE_CHANGED_NEW_AREA", "BAG_UPDATE_DELAYED",
                      "PLAYER_MONEY", "UNIT_QUEST_LOG_CHANGED" }) do
    LV.On(ev, function() T.Schedule() end)
end
LV.On("QUEST_TURNED_IN", function(_, q) Q.MarkDone(q); T.Schedule() end)
LV.On("PLAYER_LEVEL_UP", function() LV.ClearCondCache() end)
