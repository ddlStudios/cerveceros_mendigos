-- CervecerosMendigos · Leveo: ayudas del paso actual (codigo propio, GPL-3.0).
--  * botones con el objeto que el paso te pide usar (clic = lo usas)
--  * botones con los PNJ o enemigos del paso (clic = lo seleccionas)
--  * elige sola la opcion de dialogo que indica la ruta, toma el vuelo del paso y confirma el hogar
--  * al pasar el raton por un enemigo u objeto del paso, dice para que es
-- Los botones son seguros del juego: solo cambian fuera de combate. La tecla de pausa frena lo automatico.
local ADDON, ns = ...
local LV = ns.LV or {}
ns.LV = LV
local T = LV.T
local H = {}
LV.Help = H

local function S() return LV.S end
local function O() return S().ayudas or {} end
local function Enabled() return LV.mod and LV.mod:IsEnabled() and S().guiaActiva ~= false and T.g ~= nil end

local function Paused()
    local k = (S().auto or {}).pausa or "SHIFT"
    if k == "SHIFT" then return IsShiftKeyDown and IsShiftKeyDown() end
    if k == "CTRL" then return IsControlKeyDown and IsControlKeyDown() end
    if k == "ALT" then return IsAltKeyDown and IsAltKeyDown() end
    return false
end

local function ActiveSteps()
    local list = {}
    local st = T.Current()
    if st then list[1] = st end
    for _, s in ipairs(T.Side()) do list[#list + 1] = s end
    return list
end
H.ActiveSteps = ActiveSteps

----------------------------------------------------------------------
-- Barra de botones (objetos y objetivos)
----------------------------------------------------------------------
local bar, itemBtns, targetBtns = nil, {}, {}
local pendiente = false

local function BarLook()
    if not bar then return end
    local o = O()
    if InCombatLockdown and InCombatLockdown() then return end
    bar:SetScale((o.escala or 100) / 100)
    bar:EnableMouse(not o.bloqueada)
end

local function Bar()
    if bar then return bar end
    bar = LV.mod:Frame("Frame", "CMLeveoBotones", UIParent)
    bar:SetSize(200, 40)
    bar:SetMovable(true); bar:SetClampedToScreen(true)
    bar:RegisterForDrag("LeftButton")
    bar:SetScript("OnDragStart", function(self) if not O().bloqueada and not InCombatLockdown() then self:StartMoving() end end)
    bar:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p, _, rp, x, y = self:GetPoint()
        O().pos = { p, rp, x, y }
    end)
    local p = O().pos
    if p then bar:SetPoint(p[1], UIParent, p[2], p[3], p[4]) else bar:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, 190) end
    bar.handle = bar:CreateTexture(nil, "BACKGROUND")
    bar.handle:SetAllPoints()
    bar.handle:SetColorTexture(0, 0, 0, 0.25)
    BarLook()
    return bar
end

function H.ResetPos()
    O().pos = nil
    if bar and not InCombatLockdown() then bar:ClearAllPoints(); bar:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, 190) end
end

local function Tip(self)
    GameTooltip:SetOwner(self, "ANCHOR_TOP")
    if self.itemID then
        if GameTooltip.SetItemByID then GameTooltip:SetItemByID(self.itemID) else GameTooltip:SetText(self.label or "") end
        GameTooltip:AddLine("Clic: usar (Leveo)", 0.6, 0.8, 1)
    else
        GameTooltip:SetText(self.label or "", 1, 1, 1)
        GameTooltip:AddLine("Clic: seleccionarlo (Leveo)", 0.6, 0.8, 1)
    end
    GameTooltip:Show()
end

local function ItemButton(i)
    local b = itemBtns[i]
    if b then return b end
    b = CreateFrame("Button", "CMLeveoObjeto" .. i, Bar(), "SecureActionButtonTemplate")
    b:SetSize(36, 36)
    b:RegisterForClicks("AnyUp", "AnyDown")
    b:SetAttribute("type", "item")
    b.icon = b:CreateTexture(nil, "ARTWORK"); b.icon:SetAllPoints()
    b.count = b:CreateFontString(nil, "OVERLAY", "NumberFontNormal"); b.count:SetPoint("BOTTOMRIGHT", -2, 2)
    b.cd = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate"); b.cd:SetAllPoints()
    b:SetScript("OnEnter", Tip)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    itemBtns[i] = b
    return b
end

local function TargetButton(i)
    local b = targetBtns[i]
    if b then return b end
    b = CreateFrame("Button", "CMLeveoObjetivo" .. i, Bar(), "SecureActionButtonTemplate")
    b:SetSize(36, 36)
    b:RegisterForClicks("AnyUp", "AnyDown")
    b:SetAttribute("type", "macro")
    b.icon = b:CreateTexture(nil, "ARTWORK"); b.icon:SetAllPoints()
    b.icon:SetTexture("Interface\\Icons\\Ability_Hunter_SniperShot")
    b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.text:SetPoint("TOP", b, "BOTTOM", 0, -1); b.text:SetWidth(70)
    b:SetScript("OnEnter", Tip)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    targetBtns[i] = b
    return b
end

-- Objetos a usar: los ".use" del paso y los objetos de mision de sus misiones
local function StepItems()
    local items, seen = {}, {}
    for _, st in ipairs(ActiveSteps()) do
        for _, el in ipairs(st.els) do
            if T.ElShown(el) then
                if el.verb == "hint" and el.hint == "use" and el.item and not seen[el.item] then
                    seen[el.item] = true; items[#items + 1] = el.item
                end
                if el.quest and LV.Q.On(el.quest) and GetQuestLogSpecialItemInfo and C_QuestLog and C_QuestLog.GetLogIndexForQuestID then
                    local idx = C_QuestLog.GetLogIndexForQuestID(el.quest)
                    local link = idx and GetQuestLogSpecialItemInfo(idx)
                    local id = link and tonumber(tostring(link):match("item:(%d+)"))
                    if id and not seen[id] then seen[id] = true; items[#items + 1] = id end
                end
            end
        end
    end
    local out = {}
    for _, id in ipairs(items) do if LV.ItemCount(id) > 0 then out[#out + 1] = id end end
    return out
end
H.StepItems = StepItems

-- Nombres de PNJ y enemigos del paso actual (".target", ".mob", ".unitscan")
local function StepNames()
    local names, seen = {}, {}
    for _, st in ipairs(ActiveSteps()) do
        for _, el in ipairs(st.els) do
            if T.ElShown(el) and el.names then
                for _, n in ipairs(el.names) do
                    n = n:gsub("^%s+", ""):gsub("%s+$", "")
                    if n ~= "" and not seen[n] then seen[n] = true; names[#names + 1] = n end
                end
            end
        end
    end
    return names
end
H.StepNames = StepNames

function H.RefreshButtons()
    if not (LV.mod and LV.mod:IsEnabled()) then return end
    if InCombatLockdown and InCombatLockdown() then pendiente = true; return end
    pendiente = false
    local o = O()
    local items = (Enabled() and o.objetos ~= false) and StepItems() or {}
    local names = (Enabled() and o.objetivos ~= false) and StepNames() or {}
    if #items == 0 and #names == 0 then
        for _, b in ipairs(itemBtns) do b:Hide() end
        for _, b in ipairs(targetBtns) do b:Hide() end
        if bar then bar:Hide() end
        return
    end
    Bar()
    BarLook()
    local x = 4
    local maxT = o.maxObjetivos or 3
    for i = 1, math.max(#items, #itemBtns) do
        local id = items[i]
        if id then
            local b = ItemButton(i)
            b.itemID = id
            b:SetAttribute("item", "item:" .. id)
            local icon = (C_Item and C_Item.GetItemIconByID and C_Item.GetItemIconByID(id)) or (GetItemIcon and GetItemIcon(id))
            b.icon:SetTexture(icon or "Interface\\Icons\\INV_Misc_QuestionMark")
            local n = LV.ItemCount(id)
            b.count:SetText(n > 1 and n or "")
            b:ClearAllPoints(); b:SetPoint("LEFT", bar, "LEFT", x, 0)
            b:Show()
            x = x + 40
        elseif itemBtns[i] then
            itemBtns[i]:Hide()
        end
    end
    for i = 1, math.max(#names, #targetBtns) do
        local n = (i <= maxT) and names[i] or nil
        if n then
            local b = TargetButton(i)
            b.label = n
            b:SetAttribute("macrotext", "/targetexact " .. n .. (o.marcar and "\n/tm 8" or ""))
            b.text:SetText(n)
            b:ClearAllPoints(); b:SetPoint("LEFT", bar, "LEFT", x, 4)
            b:Show()
            x = x + 40
        elseif targetBtns[i] then
            targetBtns[i]:Hide()
        end
    end
    bar:SetSize(math.max(44, x), 44)
    bar:Show()
    H.UpdateCooldowns()
end

function H.UpdateCooldowns()
    for _, b in ipairs(itemBtns) do
        if b:IsShown() and b.itemID then
            local s, d
            if C_Container and C_Container.GetItemCooldown then s, d = C_Container.GetItemCooldown(b.itemID)
            elseif GetItemCooldown then s, d = GetItemCooldown(b.itemID) end
            if s and d and d > 0 and b.cd.SetCooldown then b.cd:SetCooldown(s, d) end
        end
    end
end

LV.Listen("update", function() H.RefreshButtons() end)
LV.On("PLAYER_REGEN_ENABLED", function() if pendiente then H.RefreshButtons() end end)
LV.On("BAG_UPDATE_COOLDOWN", function() H.UpdateCooldowns() end)

----------------------------------------------------------------------
-- Dialogos, vuelos y posadero
----------------------------------------------------------------------
local function StepHints(kind)
    local out = {}
    for _, st in ipairs(ActiveSteps()) do
        for _, el in ipairs(st.els) do
            if T.ElShown(el) and ((el.verb == "hint" and el.hint == kind) or (el.verb == "event" and el.event == kind)) then
                out[#out + 1] = el
            end
        end
    end
    return out
end

-- ".skipgossipid 1234" / ".skipgossip 2" / ".skipgossip" (la unica opcion)
LV.On("GOSSIP_SHOW", function()
    if not Enabled() or O().dialogos == false or Paused() then return end
    if not (C_GossipInfo and C_GossipInfo.GetOptions and C_GossipInfo.SelectOption) then return end
    local opts = C_GossipInfo.GetOptions() or {}
    if #opts == 0 then return end
    for _, el in ipairs(StepHints("skipgossipid")) do
        for _, id in ipairs(LV.Ids(el.arg)) do
            for _, o in ipairs(opts) do
                if o.gossipOptionID == id then return C_GossipInfo.SelectOption(id) end
            end
        end
    end
    for _, el in ipairs(StepHints("skipgossip")) do
        local n = tonumber((el.arg or ""):match("%d+"))
        local o = n and opts[n] or (#opts == 1 and opts[1]) or nil
        -- con misiones a la vista no se elige nada: eso lo decide Auto.lua
        local hayMisiones = (C_GossipInfo.GetAvailableQuests and #C_GossipInfo.GetAvailableQuests() > 0)
            or (C_GossipInfo.GetActiveQuests and #C_GossipInfo.GetActiveQuests() > 0)
        if o and o.gossipOptionID and not hayMisiones then return C_GossipInfo.SelectOption(o.gossipOptionID) end
    end
end)

-- En el maestro de vuelo: toma el vuelo del paso (".fly Orgrimmar >>Vuela a Orgrimmar")
local function Plain(s)
    s = (s or ""):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", "")
    return s:lower()
end
function H.FlyNode()
    local els = StepHints("fly")
    if #els == 0 or not NumTaxiNodes then return end
    for _, el in ipairs(els) do
        local quiere = Plain((el.arg or "") .. " " .. (el.text or ""))
        for i = 1, NumTaxiNodes() do
            local name = TaxiNodeName(i) or ""
            local tipo = TaxiNodeGetType and TaxiNodeGetType(i)
            local corto = Plain(name:match("^([^,]+)") or name)
            if tipo == "REACHABLE" and corto ~= "" and quiere:find(corto, 1, true) then return i, name end
        end
    end
end
LV.On("TAXIMAP_OPENED", function()
    if not Enabled() or O().vuelos == false or Paused() then return end
    local i, name = H.FlyNode()
    if i and TakeTaxiNode then
        TakeTaxiNode(i)
        if S().aviso then LV.mod:Print("volando a " .. name .. " (ruta de leveo).") end
    end
end)

-- Posadero: confirma fijar el hogar si el paso lo pide
LV.On("CONFIRM_BINDER", function()
    if not Enabled() or O().hogar == false or Paused() then return end
    if #StepHints("sethome") == 0 then return end
    if ConfirmBinder then ConfirmBinder() end
    if StaticPopup_Hide then StaticPopup_Hide("CONFIRM_BINDER") end
end)

----------------------------------------------------------------------
-- Al pasar el raton: para que mision es ese enemigo u objeto
----------------------------------------------------------------------
local porNombre, porObjeto, firma = {}, {}, nil
local function Rebuild()
    porNombre, porObjeto = {}, {}
    for _, st in ipairs(ActiveSteps()) do
        local por
        for _, el in ipairs(st.els) do
            if el.quest and T.ElShown(el) then por = LV.Q.Title(el.quest); break end
        end
        por = por or ((st.notes[1] and st.notes[1].text) or "este paso")
        for _, el in ipairs(st.els) do
            if T.ElShown(el) then
                if el.names then for _, n in ipairs(el.names) do porNombre[n:lower()] = por end end
                if el.verb == "collect" and el.item then porObjeto[el.item] = por end
                if el.verb == "hint" and el.hint == "use" and el.item then porObjeto[el.item] = por end
            end
        end
        -- objetivos de las misiones del paso ("Jabali jaspeado muerto: 3/8")
        for _, el in ipairs(st.els) do
            if el.quest and el.verb == "complete" and LV.Q.On(el.quest) then
                for _, o in ipairs(LV.Q.Objectives(el.quest)) do
                    local txt = o.text and o.text:match("^(.-)%s*[:%d]") or o.text
                    if txt and txt ~= "" then porNombre[txt:lower()] = LV.Q.Title(el.quest) end
                end
            end
        end
    end
end
LV.Listen("update", function() firma = nil end)

local function Linea(tip, por)
    if not por then return end
    tip:AddLine("|cff33ff99Leveo:|r " .. por, 1, 1, 1, true)
end

local function OnUnit(tip)
    if not Enabled() or O().tooltip == false then return end
    if not firma then Rebuild(); firma = true end
    local _, unit = tip:GetUnit()
    if not unit then return end
    local name = UnitName(unit)
    if not name or (issecretvalue and issecretvalue(name)) then return end
    local low = name:lower()
    local por = porNombre[low]
    if not por then
        for k, v in pairs(porNombre) do
            if k ~= "" and (low:find(k, 1, true) or k:find(low, 1, true)) then por = v; break end
        end
    end
    Linea(tip, por)
end

local function OnItem(tip, data)
    if not Enabled() or O().tooltip == false then return end
    if not firma then Rebuild(); firma = true end
    local id = data and data.id
    if not id and tip.GetItem then
        local _, link = tip:GetItem()
        id = link and tonumber(tostring(link):match("item:(%d+)"))
    end
    Linea(tip, id and porObjeto[id])
end

function H.HookTooltips()
    if H.hooked then return end
    H.hooked = true
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Unit, function(tip) pcall(OnUnit, tip) end)
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tip, data) pcall(OnItem, tip, data) end)
    elseif GameTooltip and GameTooltip.HookScript then
        GameTooltip:HookScript("OnTooltipSetUnit", function(tip) pcall(OnUnit, tip) end)
        GameTooltip:HookScript("OnTooltipSetItem", function(tip) pcall(OnItem, tip) end)
    end
end

----------------------------------------------------------------------
-- Cadena de una mision (para la ventana): previas, siguiente y quien la da
----------------------------------------------------------------------
function H.QuestInfo(q)
    local out = {}
    local C = ns.BruddaQuestChainData
    local c = C and C[q]
    local d = LV.QuestData(q)
    if d then
        if d[3] and d[3] > 0 then out[#out + 1] = "Nivel " .. d[3] .. ((d[4] and d[4] > 0) and (" (se coge a nivel " .. d[4] .. ")") or "") end
        if d[7] and d[7] ~= "" then
            local z = (CMLZones or {})[d[8]]
            out[#out + 1] = "La da: " .. d[7] .. (z and (" (" .. z[2] .. ")") or "")
        end
    end
    if c then
        local function Lista(ids)
            local t = {}
            for _, id in ipairs(ids) do
                t[#t + 1] = (LV.Q.Done(id) and "|cff5cf05c" or "|cffff9a3c") .. LV.Q.Title(id) .. "|r"
            end
            return table.concat(t, ", ")
        end
        if c.g then out[#out + 1] = "Antes necesitas: " .. Lista(c.g) end
        if c.s then out[#out + 1] = "Antes necesitas una de: " .. Lista(c.s) end
        if c.n then out[#out + 1] = "Sigue con: " .. LV.Q.Title(c.n) end
    end
    return out
end
