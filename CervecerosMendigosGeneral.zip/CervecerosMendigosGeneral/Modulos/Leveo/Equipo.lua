-- CervecerosMendigos · Leveo: mejor equipo para tu nivel (codigo propio, GPL-3.0).
-- Datos: guia de equipo de Brudda FastXP (DatosBrudda/BruddaGear.lua) y donde sale cada pieza
-- (DatosBrudda/BruddaItemSrc.lua, de QuestieDB_Forever). Cada ranura: A/H/B = "1-14:id,15-19:id,..."
-- Se ve al pasar el raton por las ranuras de tu personaje, con /leveo equipo y al subir de nivel.
local ADDON, ns = ...
local LV = ns.LV or {}
ns.LV = LV
local EQ = {}
LV.Gear = EQ

local function S() return LV.S end
local function O() return S().equipo or {} end
local function GD() return ns.BruddaGearData or {} end

-- ranura de la guia -> ranuras del personaje
EQ.INV = {
    ["Cabeza"] = { 1 }, ["Cuello"] = { 2 }, ["Hombros"] = { 3 }, ["Espalda"] = { 15 }, ["Pecho"] = { 5 }, ["Muñeca"] = { 9 },
    ["Manos"] = { 10 }, ["Cintura"] = { 6 }, ["Piernas"] = { 7 }, ["Pies"] = { 8 }, ["Anillos"] = { 11, 12 },
    ["Abalorios"] = { 13, 14 }, ["Mano principal / dos manos"] = { 16 }, ["Mano secundaria"] = { 17 }, ["A distancia"] = { 18 },
}
local SLOT_OF = {}
for nombre, l in pairs(EQ.INV) do for _, s in ipairs(l) do SLOT_OF[s] = nombre end end
local FRAMES = { [1] = "CharacterHeadSlot", [2] = "CharacterNeckSlot", [3] = "CharacterShoulderSlot", [15] = "CharacterBackSlot",
                 [5] = "CharacterChestSlot", [9] = "CharacterWristSlot", [10] = "CharacterHandsSlot", [6] = "CharacterWaistSlot",
                 [7] = "CharacterLegsSlot", [8] = "CharacterFeetSlot", [11] = "CharacterFinger0Slot", [12] = "CharacterFinger1Slot",
                 [13] = "CharacterTrinket0Slot", [14] = "CharacterTrinket1Slot", [16] = "CharacterMainHandSlot",
                 [17] = "CharacterSecondaryHandSlot", [18] = "CharacterRangedSlot" }

function EQ.Specs() return GD()[LV.ClassTok()] or {} end

-- Rama: la elegida, la de los talentos de Leveo, o la primera
function EQ.Spec()
    local list = EQ.Specs()
    if #list == 0 then return end
    local elegida = O().rama
    if elegida and elegida ~= "auto" then
        for _, s in ipairs(list) do if s.spec == elegida then return s end end
    end
    local b = LV.Talents and LV.Talents.Current()
    if b then
        for _, s in ipairs(list) do if s.talent == b.key then return s end end
    end
    return list[1]
end

local function Parse(str)
    local out = {}
    for lo, hi, ids in (str or ""):gmatch("(%d+)%-(%d+):([%d/]+)") do
        local t = {}
        for id in ids:gmatch("%d+") do t[#t + 1] = tonumber(id) end
        out[#out + 1] = { tonumber(lo), tonumber(hi), t }
    end
    return out
end
local cache = {}
local function Ranges(spec, slot)
    local k = (spec.spec or "?") .. "|" .. slot
    if cache[k] then return cache[k] end
    local d = spec.slots and spec.slots[slot]
    if not d then cache[k] = {}; return cache[k] end
    local fac = LV.Faction() == "Alliance" and "A" or "H"
    cache[k] = Parse(d[fac] or d.B or "")
    return cache[k]
end

-- La pieza recomendada para ese nivel (y la siguiente mejora)
function EQ.Best(slot, level, spec)
    spec = spec or EQ.Spec()
    if not spec then return end
    level = level or LV.Level()
    local best, nxt
    for _, r in ipairs(Ranges(spec, slot)) do
        if level >= r[1] and level <= r[2] then best = r[3][1]
        elseif r[1] > level and not nxt and r[3][1] ~= best then nxt = { item = r[3][1], level = r[1] } end
    end
    return best, nxt
end

function EQ.ItemName(id)
    local n = C_Item and C_Item.GetItemNameByID and C_Item.GetItemNameByID(id)
    if not n and GetItemInfo then n = GetItemInfo(id) end
    return n or (GD().names and GD().names[id]) or ("objeto " .. tostring(id))
end

local function Npc(id)
    local src = ns.BruddaItemSrc or {}
    return (src.npc and src.npc[id]) or ("PNJ " .. id)
end
local function Area(id)
    local n = C_Map and C_Map.GetAreaInfo and C_Map.GetAreaInfo(id)
    return n or ("zona " .. id)
end

-- Donde se consigue: "mision X", "vendedor Y", "botin de Z"...
function EQ.Source(id)
    local src = ns.BruddaItemSrc or {}
    local s = src.src and src.src[id]
    if not s then return nil end
    local tipo, resto = s:match("^(%a):?(.*)$")
    local ids = {}
    for n in (resto or ""):gmatch("%d+") do ids[#ids + 1] = tonumber(n) end
    if tipo == "q" then
        local q = ids[1]
        local t = q and ((C_QuestLog and C_QuestLog.GetTitleForQuestID and C_QuestLog.GetTitleForQuestID(q))
            or (src.quest and src.quest[q]) or LV.Q.Title(q))
        return "misión " .. tostring(t)
    elseif tipo == "v" then
        local n = {}
        for k = 1, math.min(2, #ids) do n[#n + 1] = Npc(ids[k]) end
        return "vendedor: " .. table.concat(n, ", ")
    elseif tipo == "d" then
        local id1 = ids[1]
        local z = id1 and src.zone and src.zone[id1]
        return "botín de " .. (id1 and Npc(id1) or "?") .. (z and (" (" .. Area(z) .. ")") or "")
    elseif tipo == "z" then return "botín en " .. (ids[1] and Area(ids[1]) or "?")
    elseif tipo == "w" then return "botín del mundo (al azar)"
    elseif tipo == "o" then return "cofre u objeto del suelo"
    elseif tipo == "c" then return "fabricada o en la subasta"
    end
end

local function Has(id)
    if not id then return false end
    for s = 1, 19 do
        local iid = GetInventoryItemID and GetInventoryItemID("player", s)
        if iid == id then return true, "puesta" end
    end
    if LV.ItemCount(id) > 0 then return true, "en las bolsas" end
    return false
end
EQ.Has = Has

-- Lineas para una ranura
function EQ.SlotLines(slot)
    local out = {}
    local best, nxt = EQ.Best(slot)
    if best then
        local tiene, donde = Has(best)
        out[#out + 1] = { "Mejor para tu nivel: |cffffd100" .. EQ.ItemName(best) .. "|r" .. (tiene and (" |cff5cf05c(" .. donde .. ")|r") or ""), 1, 1, 1 }
        local src = not tiene and EQ.Source(best)
        if src then out[#out + 1] = { "  " .. src, 0.75, 0.75, 0.75 } end
        local nota = GD().notes and GD().notes[best]
        if nota then out[#out + 1] = { "  " .. nota, 0.6, 0.6, 0.6 } end
    end
    if nxt then
        out[#out + 1] = { "A nivel " .. nxt.level .. ": " .. EQ.ItemName(nxt.item), 0.7, 0.7, 0.7 }
    end
    return out
end

----------------------------------------------------------------------
-- Raton por las ranuras de tu personaje
----------------------------------------------------------------------
local function OnSlotEnter(self)
    if not (LV.mod and LV.mod:IsEnabled()) or O().tooltip == false then return end
    local id = self.GetID and self:GetID()
    local slot = id and SLOT_OF[id]
    if not slot then return end
    local lines = EQ.SlotLines(slot)
    if #lines == 0 then return end
    local spec = EQ.Spec()
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine("|cff33ff99Leveo|r · " .. (spec and spec.spec or ""), 1, 1, 1)
    for _, l in ipairs(lines) do GameTooltip:AddLine(l[1], l[2], l[3], l[4], true) end
    GameTooltip:Show()
end

function EQ.HookSlots()
    if EQ.hooked then return end
    local alguno = false
    for _, name in pairs(FRAMES) do
        local f = rawget(_G, name)
        if f and f.HookScript then f:HookScript("OnEnter", OnSlotEnter); alguno = true end
    end
    EQ.hooked = alguno
end

----------------------------------------------------------------------
-- Lista completa y aviso al subir
----------------------------------------------------------------------
function EQ.Report(soloFalta)
    local spec = EQ.Spec()
    if not spec then LV.mod:Print("no tengo guía de equipo para tu clase."); return end
    LV.mod:Print("equipo para nivel " .. LV.Level() .. " (" .. spec.spec .. "):")
    local n = 0
    for _, slot in ipairs(GD().slots or {}) do
        local best = EQ.Best(slot)
        if best then
            local tiene = Has(best)
            if not (soloFalta and tiene) then
                n = n + 1
                local src = EQ.Source(best)
                DEFAULT_CHAT_FRAME:AddMessage(string.format("  %s: %s%s%s", slot, EQ.ItemName(best),
                    tiene and " |cff5cf05c(la tienes)|r" or "", (not tiene and src) and (" |cffaaaaaa- " .. src .. "|r") or ""))
            end
        end
    end
    if n == 0 then DEFAULT_CHAT_FRAME:AddMessage("  Tienes todo lo recomendado para tu nivel.") end
end

-- Piezas que empiezan justo en este nivel y no tienes
function EQ.NewAt(level)
    local spec = EQ.Spec()
    if not spec then return {} end
    local out = {}
    for _, slot in ipairs(GD().slots or {}) do
        for _, r in ipairs(Ranges(spec, slot)) do
            if r[1] == level and not Has(r[3][1]) then out[#out + 1] = { slot = slot, item = r[3][1] } end
        end
    end
    return out
end

LV.On("PLAYER_LEVEL_UP", function(_, level)
    if O().avisar == false or not level then return end
    local nuevas = EQ.NewAt(level)
    if #nuevas == 0 then return end
    local t = {}
    for k, v in ipairs(nuevas) do
        if k > 4 then break end
        t[#t + 1] = v.slot .. ": " .. EQ.ItemName(v.item)
    end
    LV.mod:Print("equipo nuevo para nivel " .. level .. ": " .. table.concat(t, "; ") .. (#nuevas > 4 and " ..." or "") .. " (/leveo equipo)")
end)
