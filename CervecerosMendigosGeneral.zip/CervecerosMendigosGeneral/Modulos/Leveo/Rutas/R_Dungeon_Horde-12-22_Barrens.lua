-- GENERADO por _suite/herramientas/leveo_rutas.py: no editar a mano.
-- Ruta de subida de RestedXP (RXPGuides), traducida y adaptada a WoW Forever por Brudda FastXP.
-- Licencia de este archivo: CC BY-NC-SA 4.0 (ver LICENCIA_RUTAS.txt).
local _, ns = ...
local R = ns.LeveoRutas or {}
ns.LeveoRutas = R
R[#R + 1] = {[=[
#forever
<< Horde
#name 12-16 Los Baldíos
#displayname 14-16 Los Baldíos << !Shaman !Hunter !Tauren
#displayname 15-16 Los Baldíos << Paladin
#version 11
#group Forever Guía de Mazmorras (H)
#subgroup Mazmorras 1-22
#next 16-17 Sima Ígnea


step << Tauren Shaman
    .goto 1411/1,-4648.55,271.43
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTakrin|r
    .accept 840 >>Acepta la misión Nuevo recluta de la Horda
    .target Takrin Pathseeker
step << Tauren Shaman
    #completewith next
    .goto 1411/1,-4834.14,418.07,30,0
    .goto 1411/1,-4754.3,796.66,20 >> Entra en la Cueva Viento Seco
step << Tauren Shaman
    #loop
    .goto 1411/1,-4706.71,902.41,0
    .goto 1411/1,-4774.39,780.80,20,0
    .goto 1411/1,-4749.01,822.39,12,0
    .goto 1411/1,-4767.52,825.92,12,0
    .goto 1411/1,-4772.28,848.12,12,0
    .goto 1411/1,-4756.41,863.630,12,0
    .goto 1411/1,-4715.70,861.87,12,0
    .goto 1411/1,-4706.71,902.41,12,0
    >>Mata a los |cffff5a4aCultores|r. Despójalos para obtener una |cff4fc3f7Faltriquera de componentes|r
    .complete 1525,2 --Reagent Pouch (1)
    .mob Burning Blade Cultist
step << Tauren Shaman
    .goto 1413/1,-3687.11,303.14
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKargal|r
    .turnin 840 >>Entrega la misión Nuevo recluta de la Horda
    .accept 842 >>Acepta la misión Servicio militar en El Cruce
    .target Kargal Battlescar
step << Tauren Warrior
    #completewith next
    .goto 1413/1,-2902.79,-276.55,30,0
    .goto 1413/1,-3004.12,-298.17,30,0
    .goto 1413/1,-3110.52,-320.46,30 >>Viaja a la cima de la montaña
step << Tauren Warrior
    .goto 1413/1,-3176.39,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThun'grim|r
    .turnin 1502 >>Entrega la misión Thun'grim Vistafuego
    .accept 1503 >>Acepta la misión Acero fundido
    .target Thun'grim Firegaze
step << Tauren Warrior
    .goto 1413/1,-2955.48,-188.04
    >>Despoja el |cffe07cf5Cofre de hierro robado|r para obtener sus |cff4fc3f7Barras de acero forjado|r
    .complete 1503,1 --Forged Steel Bars (1)
step << Tauren Warrior
    #completewith next
    .goto 1413/1,-2902.79,-276.55,30,0
    .goto 1413/1,-3004.12,-298.17,30,0
    .goto 1413/1,-3110.52,-320.46,30 >>Viaja a la cima de la montaña
step << Tauren Warrior
    .goto 1413/1,-3176.39,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThun'grim|r
    .turnin 1503 >>Entrega la misión Acero fundido
    .target Thun'grim Firegaze
step << !Tauren
    #softcore
    #completewith ThievesPickup
    .goto 1413/1,-2516.71,-590.71
    .deathskip >> Muere y reaparece en el |cff5cf05cÁngel de la Resurrección|r
    .xp >15,1
step << !Tauren
    #softcore
    #completewith ThievesPickup
    .subzone 380 >> Viaja a El Cruce
    .xp <15,1
step << !Tauren
    #hardcore
    #completewith ThievesPickup
    .subzone 380 >> Viaja a El Cruce
step << !Tauren
    #softcore
    .goto 1413/1,-2672.76,-544.77
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTonga|r
    .accept 870 >>Acepta la misión Las Charcas del Olvido
    .target Tonga Runetotem
step << Orc/Troll
    #hardcore
    .goto 1413/1,-2709.24,-403.57
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZargh|r
    .accept 6365 >>Acepta la misión Entrega de carne a Orgrimmar
    .target Zargh
step << !Tauren
    .goto 1413/1,-2670.74,-482.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSergra|r
    .turnin 842 >>Entrega la misión Servicio militar en El Cruce << !Druid
    .accept 844 >>Acepta la misión La amenaza de los zancudos de llanura
    .target Sergra Darkthorn
    .isOnQuest 842
step << !Tauren
    .goto 1413/1,-2670.74,-482.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSergra|r
    .accept 844 >>Acepta la misión La amenaza de los zancudos de llanura
    .target Sergra Darkthorn
step << !Tauren
    #hardcore
    .goto 1413/1,-2672.76,-544.77
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTonga|r
    .accept 870 >>Acepta la misión Las Charcas del Olvido
    .target Tonga Runetotem
step << !Tauren
    .goto 1413/1,-2595.75,-473.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThork|r
    .turnin 98024 >>Entrega la misión Viaje a El Cruce << Skyborne
    .accept 871 >>Acepta la misión Interrupción de los ataques
    .accept 5041 >>Acepta la misión Suministros para El Cruce
    .target Thork
    .maxlevel 15
step << Skyborne
    #optional
    .goto 1413/1,-2595.75,-473.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThork|r
    .turnin 98024 >>Entrega la misión Viaje a El Cruce 
    .target Thork
    .maxlevel 15
step << Orc/Troll
    #hardcore
    .goto 1413/1,-2595.75,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDevrak|r
    >>|cffff9a3c¡NO vueles a Orgrimmar!|r
    .turnin 6365 >>Entrega la misión Entrega de carne a Orgrimmar
    .accept 6384 >>Acepta la misión Un viaje a Orgrimmar
    .target Devrak
step << Undead/Skyborne
    .goto 1413/1,-2595.75,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDevrak|r
    .fp >> Consigue la ruta de vuelo de El Cruce
    .target Devrak
    .isQuestAvailable 1492
step << !Tauren
    .goto 1413/1,-2589.67,-424.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHelbrim|r
    .accept 1492 >>Acepta la misión Maestro de muelles Vertipeluca
    .accept 848 >>Acepta la misión Esporas de hongos
    .turnin 1358 >>Entrega la misión Muestra para Helbrim
    .target Apothecary Helbrim
    .isOnQuest 1358
step << !Tauren
    .goto 1413/1,-2589.67,-424.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHelbrim|r
    .accept 1492 >>Acepta la misión Maestro de muelles Vertipeluca
    .accept 848 >>Acepta la misión Esporas de hongos
    .target Apothecary Helbrim
step << Orc Hunter/Troll Hunter/Skyborne Hunter
    .goto 1413/1,-2556.23,-351.54
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cUthrok|r|cffe07cf5. Compra un|r |T135499:0|t[Arco corvo laminado] |cffe07cf5a este vendedor|r
    .collect 2507,1,871,1 --Collect Laminated Recurve Bow (1)
    .money <0.1751
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<5.7
    .target Uthrok
step << Orc Hunter/Troll Hunter/Skyborne Hunter
    #optional
    #completewith DisruptTheAttacks
    +|cffff9a3cEquipa el|r |T135499:0|t[Arco corvo laminado]
    .use 2507
    .itemcount 2507,1
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<5.7
step << Tauren Hunter
    .goto 1413/1,-2556.23,-351.54
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cUthrok|r|cffe07cf5. Compra una|r |T135613:0|t[Bocarda de cazador] |cffe07cf5a este vendedor|r
    .collect 2511,1,871,1 --Collect Hunter's Boomstick (1)
    .money <0.1324
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<4.9
    .target Uthrok
step << Tauren Hunter
    #optional
    #completewith DisruptTheAttacks
    +|cffff9a3cEquipa la|r |T135613:0|t[Bocarda de cazador]
    .use 2511
    .itemcount 2511,1
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<4.9
step << !Tauren
    #label ThievesPickup
    .goto 1413/1,-2639.32,-436.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGazrog|r
    .accept 869 >>Acepta la misión Raptores ladrones
    .target Gazrog
step << !Tauren
    .goto 1413/1,-2645.40,-406.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Boorand|r
    .home >> Establece tu Piedra de hogar en El Cruce
    .target Innkeeper Boorand Plainswind
    .bindlocation 380
    .isQuestAvailable 1492
step << Orc/Troll
    #softcore
    .goto 1413/1,-2709.24,-403.57
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZargh|r
    .accept 6365 >>Acepta la misión Entrega de carne a Orgrimmar
    .target Zargh
step
    #optional
    #completewith DisruptTheAttacks
    >>Mata a cada |cffff5a4aRaptor|r que veas. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Lashtail
    .mob Sunscale Screecher
step
    #optional
    #completewith DisruptTheAttacks
    >>Mata a los |cffff5a4aZancudos de llanura|r. Despójalos para obtener sus |cff4fc3f7Picos|r
    .complete 844,1 --Plainstrider Beak (7)
    .mob Greater Plainstrider
    .mob Fleeting Plainstrider
step << !Tauren !Undead !Skyborne
    #completewith DemonSeed
    #label DemonMountain
    .goto 1413/1,-2554.2,80.18,40,0
    .goto 1413/1,-2477.19,136.26,40,0
    .goto 1413/1,-2363.7,232.87,40,0
    .goto 1413/1,-2205.62,314.62,100 >> Viaja a la cima de la montaña
    .isOnQuest 924
step << !Tauren !Undead !Skyborne
    #completewith next
    #requires DemonMountain
    .goto 1413/1,-2205.62,314.62,15 >> Entra en Cubil Calígine
    .isOnQuest 924
step << !Tauren !Undead !Skyborne
    #label DemonSeed
    .goto 1413/1,-2238.04,324.08
    >>Haz clic derecho en el |cffe07cf5Altar|r
    >>|cffff9a3cAsegúrate de tener una|r |T134095:0|t[Piedra de energía con imperfecciones] |cffff9a3c(duración de 30 minutos) contigo|r
    .collect 4986,1,924 --Collect Flawed Power Stone
    .complete 924,1 --Destroy the Demon Seed (1)
    .isOnQuest 924
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #sticky
    #label FireTar2
    .goto 1413/1,-2947.38,-92.1,50,0
    .goto 1413/1,-2869.35,-49.54,50,0
    .goto 1413/1,-2805.51,-111.02
    >>Mata a un |cffff5a4aBuscaqua Crines de Acero|r o a un |cffff5a4aTejespina Crines de Acero|r. Despójalos para obtener un |cff4fc3f7Alquitrán|r
    .complete 1525,1 --Fire Tar (1)
    .mob Razormane Water Seeker
    .mob Razormane Thornweaver
step
    #optional
    #completewith next
    >>Mata a los |cffff5a4aBuscaqua|r, a los |cffff5a4aTejespina|r y a los |cffff5a4aCazadores|r
    .complete 871,1 --Razormane Water Seeker (8)
    .mob +Razormane Water Seeker
    .complete 871,2 --Razormane Thornweaver (8)
    .mob +Razormane Thornweaver
    .complete 871,3 --Razormane Hunter (3)
    .mob +Razormane Hunter
    .isOnQuest 871
step
    .goto 1413/1,-3021.35,-231.960
    .use 4926 >> Despoja el |cffe07cf5Barril vacío de Chen|r del suelo y comienza la misión
    >>|cffff9a3cPuedes conseguirlo más tarde si no está allí|r
    .collect 4926,1,819 --Collect Chen's Empty Keg
    .accept 819 >> Acepta la misión El barril vacío de Chen
    .isOnQuest 871
step
    #requires FireTar2 << Shaman
    #label DisruptTheAttacks
    #loop
	.goto 1413/1,-2811.59,-42.780,0
	.goto 1413/1,-2811.59,-42.780,50,0
	.goto 1413/1,-2875.43,-52.24,50,0
	.goto 1413/1,-2931.16,-89.40,50,0
	.goto 1413/1,-3001.08,-117.78,50,0
	.goto 1413/1,-3037.56,-164.390,50,0
	.goto 1413/1,-3034.52,-221.82,50,0
	.goto 1413/1,-2991.96,-239.39,50,0
	.goto 1413/1,-2899.75,-209.66,50,0
	.goto 1413/1,-2854.15,-151.56,50,0
	.goto 1413/1,-2799.43,-92.78,50,0
    >>Mata a los |cffff5a4aBuscaqua|r, a los |cffff5a4aTejespina|r y a los |cffff5a4aCazadores|r
    .complete 871,1 --Razormane Water Seeker (8)
    .mob +Razormane Water Seeker
    .complete 871,2 --Razormane Thornweaver (8)
    .mob +Razormane Thornweaver
    .complete 871,3 --Razormane Hunter (3)
    .mob +Razormane Hunter
    .isOnQuest 871
step
    #completewith next
    >>Mata a cada |cffff5a4aRaptor|r que veas. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Lashtail
    .mob Sunscale Screecher
step
    #loop
    .goto 1413/1,-2819.70,-359.65,0
    .goto 1413/1,-2784.23,-163.04,80,0
    .goto 1413/1,-2771.06,-306.95,80,0
    .goto 1413/1,-2805.51,-386.00,80,0
    .goto 1413/1,-2738.63,-610.310,80,0
    .goto 1413/1,-2576.50,-610.98,80,0
    .goto 1413/1,-2494.42,-485.32,80,0
    .goto 1413/1,-2448.82,-398.84,80,0
    .goto 1413/1,-2537.99,-260.33,80,0
    .goto 1413/1,-2730.52,-273.17,80,0
    .goto 1413/1,-2819.70,-359.65,80,0
    >>Mata a los |cffff5a4aZancudos de llanura|r. Despójalos para obtener sus |cff4fc3f7Picos|r
    .complete 844,1 --Plainstrider Beak (7)
    .mob Greater Plainstrider
    .mob Fleeting Plainstrider
step
    .goto 1413/1,-2670.74,-482.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSergra|r
    .turnin 842 >>Entrega la misión Servicio militar en El Cruce << Tauren Shaman
    .turnin 844 >>Entrega la misión La amenaza de los zancudos de llanura
    .accept 845 >>Acepta la misión La zhebra
    .target Sergra Darkthorn
    .isOnQuest 842 << Tauren Shaman
step << Tauren Shaman
    #optional
    .goto 1413/1,-2670.74,-482.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSergra|r
    .turnin 844 >>Entrega la misión La amenaza de los zancudos de llanura
    .accept 845 >>Acepta la misión La zhebra
    .target Sergra Darkthorn
step
    .goto 1413/1,-2595.75,-473.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThork|r
    .turnin 871 >>Entrega la misión Interrupción de los ataques
    .accept 872 >>Acepta la misión La perturbación termina
    .target Thork
    .isQuestComplete 871
step
    #optional
    .goto 1413/1,-2595.75,-473.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThork|r
    .accept 872 >>Acepta la misión La perturbación termina
    .target Thork
    .isQuestTurnedIn 871
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-2607.91,-475.180
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDarsok|r
    >>|cffff9a3cEstá en la cima de la torre|r
    .accept 867 >>Acepta la misión Arpías saqueadoras
    .target Darsok Swiftdagger
step << Orc/Troll
    #softcore
    .goto 1413/1,-2595.75,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDevrak|r
    >>|cffff9a3c¡NO vueles a Orgrimmar!|r
    .turnin 6365 >>Entrega la misión Entrega de carne a Orgrimmar
    .accept 6384 >>Acepta la misión Un viaje a Orgrimmar
    .target Devrak
step << Orc Hunter/Troll Hunter/Skyborne Hunter
    #optional
    .goto 1413/1,-2556.23,-351.54
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cUthrok|r|cffe07cf5. Compra un|r |T135499:0|t[Arco corvo laminado] |cffe07cf5a este vendedor|r
    .collect 2507,1,871,1 --Collect Laminated Recurve Bow (1)
    .money <0.1751
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<5.7
    .target Uthrok
step << Tauren Hunter
    #optional
    .goto 1413/1,-2556.23,-351.54
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cUthrok|r|cffe07cf5. Compra una|r |T135613:0|t[Bocarda de cazador] |cffe07cf5a este vendedor|r
    .collect 2511,1,871,1 --Collect Hunter's Boomstick (1)
    .money <0.1324
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<4.9
    .target Uthrok
step << Orc Warrior/Troll Warrior/Tauren Warrior/Skyborne Warrior
    #sticky
    #completewith KreenigSnarlsnout
    .goto 1413/1,-2697.08,-461.67,0
    .vendor >>|cffff9a3cRevisa si|r |cff5cf05cLizzarik|r |cffff9a3cestá en El Cruce. Vende pociones y|r |T133476:0|t[|cff5cf05cMaza con pinchos pesada|r] |cffff9a3cque es un objeto de suministro limitado|r
	.unitscan Lizzarik
    .subzoneskip 380,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
step
    .goto 1413/1,-2645.40,-406.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Boorand|r
    .vendor >>Abastécete de comida y agua << !Rogue !Warrior
    .vendor >>Abastécete de comida << Rogue/Warrior
    .target Innkeeper Boorand Plainswind
    .isOnQuest 872,5041,845
step
    .goto 1413/1,-3021.35,-231.96,20,0
    .goto 1413/1,-3029.46,261.25
    .use 4926 >> Despoja el |cffe07cf5Barril vacío de Chen|r del suelo y comienza la misión
    >>|cffff9a3cEspera a la reaparición si no ha aparecido|r
    .collect 4926,1,819 --Collect Chen's Empty Keg
    .accept 819 >> Acepta la misión El barril vacío de Chen
    .isOnQuest 872
step
    #optional
    #completewith KreenigSnarlsnout
    .goto 1413/1,-3127.75,-55.62,50,0
    .goto 1413/1,-3382.10,-54.27,50,0
    >>Mata a las |cffff5a4aGeománticas Crines de Acero|r y a los |cffff5a4aDefensores Crines de Acero|r
    .complete 872,1 --Razormane Geomancer (8)
    .mob +Razormane Geomancer
    .complete 872,2 --Razormane Defender (8)
    .mob +Razormane Defender
    .isOnQuest 872
step
    #optional
    #completewith next
    >>Despoja los |cffe07cf5Cajones de suministro de El Cruce|r
    >>|cffff9a3cTiene múltiples localizaciones de aparición|r
    .complete 5041,1 --Crossroads' Supply Crates (1)
    .isOnQuest 872
step
    #label KreenigSnarlsnout
    .goto 1413/1,-3324.34,-217.09
    >>Mata a |cffff5a4aKreenig Gruñucico|r. Despójalo para obtener su |cff4fc3f7Colmillo|r
    .complete 872,3 --Kreenig Snarlsnout's Tusk (1)
    .mob Kreenig Snarlsnout
    .isOnQuest 872
step
    #optional
    #completewith next
    .goto 1413/1,-3127.75,-55.62,0
    .goto 1413/1,-3382.10,-54.27,0
    >>Mata a las |cffff5a4aGeománticas Crines de Acero|r y a los |cffff5a4aDefensores Crines de Acero|r
    .complete 872,1 --Razormane Geomancer (8)
    .mob +Razormane Geomancer
    .complete 872,2 --Razormane Defender (8)
    .mob +Razormane Defender
    .isOnQuest 872
step
    #loop
    .goto 1413/1,-3292.92,-212.36,30,0
    .goto 1413/1,-3402.36,-48.19,30,0
    .goto 1413/1,-3292.92,-212.36,0
    .goto 1413/1,-3402.36,-48.19,0
    >>Despoja los |cffe07cf5Cajones de suministro de El Cruce|r
    >>|cffff9a3cTiene múltiples localizaciones de aparición|r
    .complete 5041,1 --Crossroads' Supply Crates (1)
    .isOnQuest 872
step
    #loop
	.goto 1413/1,-3345.62,-101.56,0
	.goto 1413/1,-3393.24,-102.24,50,0
	.goto 1413/1,-3419.59,-40.08,50,0
	.goto 1413/1,-3419.59,-0.89,50,0
	.goto 1413/1,-3361.83,-1.57,50,0
	.goto 1413/1,-3317.24,-7.65,50,0
	.goto 1413/1,-3237.19,-27.92,50,0
	.goto 1413/1,-3139.91,-46.16,50,0
	.goto 1413/1,-3126.74,-101.56,50,0
	.goto 1413/1,-3178.42,-107.64,50,0
	.goto 1413/1,-3205.78,-119.13,50,0
	.goto 1413/1,-3218.95,-81.97,50,0
	.goto 1413/1,-3278.74,-75.21,50,0
	.goto 1413/1,-3345.62,-101.56,50,0
    >>Mata a las |cffff5a4aGeománticas Crines de Acero|r y a los |cffff5a4aDefensores Crines de Acero|r
    .complete 872,1 --Razormane Geomancer (8)
    .mob +Razormane Geomancer
    .complete 872,2 --Razormane Defender (8)
    .mob +Razormane Defender
    .isOnQuest 872
step << !Tauren !Undead !Skyborne
    #optional
    #completewith next
    >>Mata a cualquier |cffff5a4aZhebra|r que veas. Despójalas para obtener sus |cff4fc3f7Pezuñas|r
    .complete 845,1 --Zhevra Hooves (4)
    .mob Zhevra Runner
    .isQuestComplete 924
step << !Tauren !Undead !Skyborne
    .goto 1413/1,-3694.2,256.52
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAk'Zeloth|r
    .turnin 924 >>Entrega la misión La Semilla del Demonio
    .target Ak'Zeloth
    .isQuestComplete 924
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #optional
    #completewith ShamanDurotar
    >>Mata a cada |cffff5a4aRaptor|r que veas. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Lashtail
    .mob Sunscale Screecher
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #optional
    #completewith ShamanDurotar
    >>Mata a cualquier |cffff5a4aZhebra|r que veas. Despójalas para obtener sus |cff4fc3f7Pezuñas|r
    .complete 845,1 --Zhevra Hooves (4)
    .mob Zhevra Runner
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #completewith CallofFire3
    #label ShamanDurotar
    .goto 1411/1,-3905.13,-228.41
    .zone Durotar >> Viaja hacia Durotar
    .isOnQuest 1525
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #requires ShamanDurotar
    #completewith next
    .goto 1411/1,-3905.13,-228.41,10,0
    .goto 1411/1,-3899.31,-241.45,8,0
    .goto 1411/1,-3899.31,-241.45,8,0
    .goto 1411/1,-3906.71,-270.71,8,0
    .goto 1411/1,-3910.94,-247.45,8,0
    .goto 1411/1,-3931.56,-240.75,8,0
    .goto 1411/1,-3964.35,-242.51,8,0
    .goto 1411/1,-3974.39,-228.76,8,0
    .goto 1411/1,-4020.92,-219.95,8,0
    .goto 1411/1,-4034.67,-232.64,8,0
    .goto 1411/1,-4033.08,-255.91,10 >> Sigue el camino montaña arriba hacia |cff5cf05cTelf|r
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #label CallofFire3
    #requires ShamanDurotar
    .goto 1411/1,-3999.24,-268.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTelf|r
    .turnin 1525 >>Entrega la misión La llamada del fuego
    .accept 1526 >>Acepta la misión La llamada del fuego
    .target Telf Joolam
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #completewith next
    .goto 1411/1,-3981.27,-256.61
    .cast 8898 >>|cffff9a3cUsa la|r |T134732:0|t[La sapta de fuego]
    .use 6636
step << Orc Shaman/Troll Shaman/Tauren Shaman
    .goto 1411/1,-4022.51,-243.92
    >>Mata a la |cffff5a4aManifestación Menor de Fuego|r. Despójalo para obtener un |cff4fc3f7Ascua resplandeciente|r
    .complete 1526,1 --Glowing Ember (1)
    .mob Minor Manifestation of Fire
step << Orc Shaman/Troll Shaman/Tauren Shaman
    .goto 1411/1,-4022.51,-243.92
    >>Haz clic en el |cffe07cf5Blandón|r del suelo
    .turnin 1526 >>Entrega la misión La llamada del fuego
    .accept 1527 >>Acepta la misión La llamada del fuego
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #optional
    #completewith FireEnd
    >>Mata a cada |cffff5a4aRaptor|r que veas. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Lashtail
    .mob Sunscale Screecher
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #optional
    #completewith next
    >>Mata a cualquier |cffff5a4aZhebra|r que veas. Despójalas para obtener sus |cff4fc3f7Pezuñas|r
    .complete 845,1 --Zhevra Hooves (4)
    .mob Zhevra Runner
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #label FireEnd
    .goto 1413/1,-3037.56,264.63
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKranal|r
    .turnin 1527 >>Entrega la misión La llamada del fuego
    .target Kranal Fiss
step << Orc Shaman/Troll Shaman/Tauren Shaman
    .goto 1413/1,-3029.46,261.25
    .use 4926 >> Despoja el |cffe07cf5Barril vacío de Chen|r del suelo y comienza la misión
    >>|cffff9a3cEspera a la reaparición si no ha aparecido|r
    .collect 4926,1,819 --Collect Chen's Empty Keg
    .accept 819 >> Acepta la misión El barril vacío de Chen
step 
    #completewith RatchetEnter
    >>Mata a los |cffff5a4aRaptores|r. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Screecher
step
    #optional
    #completewith RatchetEnter
    .goto 1413/1,-3851.27,-526.53,100,0
    >>Mata |cffff5a4aGalopadores zhebra|r. Despójalos para obtener sus |cff4fc3f7Pezuñas|r
    .complete 845,1 --Zhevra Hooves (4)
    .mob Zhevra Runner
    .isOnQuest 872
step
    #label RatchetEnter
    .goto 1413/1,-3728.66,-835.29
    .subzone 392 >> Viaja a Trinquete
    .isOnQuest 845
step
    .goto 1413/1,-3767.800,-842.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDesdio|r
    .accept 97253 >>Acepta la misión Partes y piezas
    .target Wrenix the Wretched
step
    .goto 1413/1,-3728.66,-835.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGazlowe|r
    .accept 887 >>Acepta la misión Los filibusteros de los Mares del Sur
    .target Gazlowe
step
    #completewith next
    .goto 1413/1,-3770.20,-898.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBragok|r
    .fp Ratchet >> Consigue la ruta de vuelo de Trinquete
    .target Bragok
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cPetardol|r y el |cff5cf05cCartel de Se busca|r
    .accept 894 >>Acepta la misión El churumbele
    .goto 1413/1,-3759.06,-902.18
    .accept 895 >>Acepta la misión SE BUSCA: Barón Longavera
    .goto 1413/1,-3719.54,-919.07
    .target Sputtervalve
step << Undead Warrior/Skyborne Warrior
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra un|r |T135353:0|t[Espadón] |cffe07cf5a este vendedor|r
    .collect 2024,1,895,1 --Collect Espadon (1)
    .money <0.6397
    .target Ironzar
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
step << Undead Warrior/Skyborne Warrior
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa el|r |T135353:0|t[Espadón] |cffff9a3ccuando alcances el nivel 16|r
    .use 2024
    .itemcount 2024,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
    .xp >16,1
step << Undead Warrior/Skyborne Warrior
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa el|r |T135353:0|t[Espadón]
    .use 2024
    .itemcount 2024,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
    .xp <16,1
step << Troll Warrior
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra un|r |T135147:0|t[Bastón nudoso] |cffe07cf5a este vendedor|r
    .collect 2030,1,850,1 --Collect Gnarled Staff (1)
    .money <0.5544
    .target Ironzar
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.9
step << Troll Warrior
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa el|r |T135147:0|t[Bastón nudoso]
    .use 2030
    .itemcount 2030,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.9
step << Orc Warrior
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra una|r |T132394:0|t[Hacha barbada] |cffe07cf5a este vendedor|r
    .collect 2025,1,850,1 --Collect Bearded Axe (1)
    .money <0.5304
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.8
step << Orc Warrior
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa el|r |T132394:0|t[Hacha barbada]
    .use 2025
    .itemcount 2025,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.8
step << Tauren Warrior
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra un|r |T133046:0|t[Martillo de roca] |cffe07cf5a este vendedor|r
    .collect 2026,1,850,1 --Collect Rock Hammer (1)
    .money <0.6286
    .target Ironzar
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
step << Tauren Warrior
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa el|r |T133046:0|t[Martillo de roca] |cffff9a3ccuando estés en el nivel 16|r
    .use 2026
    .itemcount 2026,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
    .xp >16,1
step << Tauren Warrior
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa el|r |T133046:0|t[Martillo de roca]
    .use 2026
    .itemcount 2026,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
    .xp <16,1
step << Shaman
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra un|r |T135147:0|t[Bastón nudoso] |cffe07cf5a este vendedor|r
    .collect 2030,1,895,1 --Collect Gnarled Staff (1)
    .money <0.5544
    .target Ironzar
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.9
step << Shaman
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa el|r |T135147:0|t[Bastón nudoso]
    .use 2030
    .itemcount 2030,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.9
step << Rogue
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra una|r |T135343:0|t[Cimitarra] |cffe07cf5a este vendedor|r
    .collect 2027,1,895,1 --Collect Scimitar (1)
    .money <0.3815
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.6
    .target Ironzar
step << Rogue
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa la|r |T135343:0|t[Cimitarra]
    .use 2027
    .itemcount 2027,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.6
step << Rogue
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Cómprale una segunda|r |T135343:0|t[Cimitarra] |cffe07cf5para tu mano izquierda|r
    .collect 2027,2,895,1 --Collect Scimitar(1)
    .money <0.3815
    .itemStat 17,QUALITY,<7
    .itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.6
    .target Ironzar
step << skip
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa la segunda|r |T135343:0|t[Cimitarra] |cffff9a3cen tu mano izquierda|r
    .use 2027
    .itemcount 2027,1
    .itemStat 17,QUALITY,<7
    .itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.6
step
    .goto 1413/1,-3687.11,-981.22
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDrohn|r
    .turnin 819 >>Entrega la misión El barril vacío de Chen
    .accept 821 >>Acepta la misión El barril vacío de Chen
    .target Brewmaster Drohn
    .isOnQuest 819
step
    #optional
    .goto 1413/1,-3687.11,-981.22
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDrohn|r
    .accept 821 >>Acepta la misión El barril vacío de Chen
    .target Brewmaster Drohn
    .isQuestTurnedIn 819
step << Mage/Priest/Warlock/Shaman/Druid
    .goto 1413/1,-3664.82,-1050.14
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Wiley|r
    -->>|cffe07cf5Buy|r |T133918:0|t[Longjaw Mud Snappers] |cffe07cf5from him|r
    >>|cffe07cf5Compra|r |T132796:0|t[Zumo de melón] |cffe07cf5a este vendedor|r << Mage/Warlock/Priest/Shaman/Druid
    -->>|T133918:0|t[Longjaw Mud Snappers] |cffff9a3care extremely cheap, buy as many as you want|r
    .vendor >> Vende la Basura
    --.collect 4592,20,895,1 --Longjaw Mud Snapper (20)
    .collect 1205,10,895,1 << Mage/Warlock/Priest/Shaman/Druid --Melon Juice (10)
    .target Innkeeper Wiley
    .isOnQuest 887
    .xp <15,1
step
    #optional
    #completewith BaronLongshore
    .destroy 5088 >> |cffff9a3cElimina el|r |T133735:0|t[Manual de instrucciones de la consola de control] |cffff9a3cde tus bolsas, ya que ya no se necesita|r
step
    #optional
    #completewith BaronLongshore
    >>Mata a los |cffff5a4aSalteadores de los Mares del Sur|r y a los |cffff5a4aCañoneros de los Mares del Sur|r
    .complete 887,1 --Southsea Brigand (12)
    .mob +Southsea Brigand
    .complete 887,2 --Southsea Cannoneer (6)
    .mob +Southsea Cannoneer
step << Orc Rogue/Troll Rogue
    #optional
	#completewith SouthSea
	>>Mata a |cffff5a4aTazan|r. Despójalo para obtener su |cff4fc3f7Cartera|r
    >>|cffff9a3cAparece en el primer campamento y patrulla subiendo la colina|r
	.complete 1963,1 --Tazan's Satchel (1)
    .unitscan Tazan
step
    #label BaronLongshore
    #loop
    .goto 1413/1,-3883.70,-1572.40,0
    .goto 1413/1,-3818.84,-1707.52,0
    .goto 1413/1,-3724.60,-1746.71,0
    .goto 1413/1,-3883.70,-1572.40,50,0
    .goto 1413/1,-3818.84,-1707.52,50,0
    .goto 1413/1,-3724.60,-1746.71,50,0
    >>Mata al |cffff5a4aBarón Longavera|r. Despójalo para obtener su |cff4fc3f7Cabeza|r
    >>|cffff9a3cSe le puede encontrar en uno de los campamentos|r
    .complete 895,1 --Baron Longshore's Head (1)
    .unitscan Baron Longshore
step
    #loop
    .goto 1413/1,-3885.72,-1569.690,0
    .goto 1413/1,-3902.95,-1366.33,50,0
    .goto 1413/1,-3823.91,-1512.94,50,0
    .goto 1413/1,-3885.72,-1569.690,50,0
    >>Mata a los |cffff5a4aSalteadores de los Mares del Sur|r y a los |cffff5a4aCañoneros de los Mares del Sur|r
    .complete 887,1 --Southsea Brigand (12)
    .mob +Southsea Brigand
    .complete 887,2 --Southsea Cannoneer (6)
    .mob +Southsea Cannoneer
step
    #label SouthSea
    #loop
    .goto 1413/1,-3657.700,-1435.500,0
    .goto 1413/1,-3675.100,-1364.100,40,0
    .goto 1413/1,-3598.900,-1378.800,40,0
    .goto 1413/1,-3657.700,-1435.500,40,0
    .goto 1413/1,-3654.900,-1482.400,40,0
    .goto 1413/1,-3680.100,-1593.000,40,0
    .goto 1413/1,-3614.800,-1632.800,40,0
    .goto 1413/1,-3611.500,-1692.500,40,0
    >>Despoja el |cffe07cf5Puñado de piezas complicadas|r del suelo
    .complete 97253,1 --|5/5 Handful of Complicated Parts
    .isOnQuest 97253
step << Orc Rogue/Troll Rogue
    #loop
    .goto 1413/1,-3895.600,-1365.000,0
    .goto 1413/1,-3677.99,-1392.00,50,0
    .goto 1413/1,-3895.600,-1365.000,50,0
    .goto 1413/1,-3826.300,-1487.300,50,0
	>>Mata a |cffff5a4aTazan|r. Despójalo para obtener su |cff4fc3f7Cartera|r
    >>|cffff9a3cAparece en el primer campamento y patrulla subiendo la colina|r
	.complete 1963,1 --Tazan's Satchel (1)
    .unitscan Tazan
step
    .goto 1413/1,-3728.66,-835.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGazlowe|r
    .turnin 887 >>Entrega la misión Los filibusteros de los Mares del Sur
    .turnin 895 >>Entrega la misión SE BUSCA: Barón Longavera
    .accept 890 >>Acepta la misión El envío perdido
    .target Gazlowe
step
    .goto 1413/1,-3767.800,-842.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDesdio|r
    .turnin 97253 >>Entrega la misión Partes y piezas
    .target Wrenix the Wretched
    .isQuestComplete 97253
step
    .goto 1413/1,-3796.55,-985.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVertipeluca|r
    .turnin 1492 >>Entrega la misión Maestro de muelles Vertipeluca
    .turnin 890 >>Entrega la misión El envío perdido
    .accept 892 >>Acepta la misión El envío perdido
    --.accept 896 >>Acepta la misión La fortuna de un minero
    .target Wharfmaster Dizzywig
step
    .goto 1413/1,-3728.66,-835.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGazlowe|r
    .turnin 892 >>Entrega la misión El envío perdido
    .accept 888 >>Acepta la misión Botín robado
    .target Gazlowe
step << Undead Warrior/Skyborne Warrior
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra un|r |T135353:0|t[Espadón] |cffe07cf5a este vendedor|r
    .collect 2024,1,850,1 --Collect Espadon (1)
    .money <0.6397
    .target Ironzar
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
step << Undead Warrior/Skyborne Warrior
    #optional
    #completewith FlyToXroads1
    +|cffff9a3cEquipa el|r |T135353:0|t[Espadón] |cffff9a3ccuando alcances el nivel 16|r
    .use 2024
    .itemcount 2024,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
    .xp >16,1
step << Undead Warrior/Skyborne Warrior
    #optional
    #completewith FlyToXroads1
    +|cffff9a3cEquipa el|r |T135353:0|t[Espadón]
    .use 2024
    .itemcount 2024,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
    .xp <16,1
step << Troll Warrior
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra un|r |T135147:0|t[Bastón nudoso] |cffe07cf5a este vendedor|r
    .collect 2030,1,850,1 --Collect Gnarled Staff (1)
    .money <0.5544
    .target Ironzar
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.9
step << Troll Warrior
    #optional
    #completewith FlyToXroads1
    +|cffff9a3cEquipa el|r |T135147:0|t[Bastón nudoso]
    .use 2030
    .itemcount 2030,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.9
step << Orc Warrior
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra una|r |T132394:0|t[Hacha barbada] |cffe07cf5a este vendedor|r
    .collect 2025,1,850,1 --Collect Bearded Axe (1)
    .money <0.5304
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.8
step << Orc Warrior
    #optional
    #completewith FlyToXroads1
    +|cffff9a3cEquipa el|r |T132394:0|t[Hacha barbada]
    .use 2025
    .itemcount 2025,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.8
step << Tauren Warrior
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra un|r |T133046:0|t[Martillo de roca] |cffe07cf5a este vendedor|r
    .collect 2026,1,850,1 --Collect Rock Hammer (1)
    .money <0.6286
    .target Ironzar
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
step << Tauren Warrior
    #optional
    #completewith FlyToXroads1
    +|cffff9a3cEquipa el|r |T133046:0|t[Martillo de roca] |cffff9a3ccuando estés en el nivel 16|r
    .use 2026
    .itemcount 2026,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
    .xp >16,1
step << Tauren Warrior
    #optional
    #completewith FlyToXroads1
    +|cffff9a3cEquipa el|r |T133046:0|t[Martillo de roca]
    .use 2026
    .itemcount 2026,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
    .xp <16,1
step << Shaman
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra un|r |T135147:0|t[Bastón nudoso] |cffe07cf5a este vendedor|r
    .collect 2030,1,850,1 --Collect Gnarled Staff (1)
    .money <0.5544
    .target Ironzar
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.9
step << Shaman
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa el|r |T135147:0|t[Bastón nudoso]
    .use 2030
    .itemcount 2030,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.9
step << Rogue
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra una|r |T135343:0|t[Cimitarra] |cffe07cf5a este vendedor|r
    .collect 2027,1,850,1 --Collect Scimitar (1)
    .money <0.3815
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.6
    .target Ironzar
step << Rogue
    #optional
    #completewith FlyToXroads1
    +|cffff9a3cEquipa la|r |T135343:0|t[Cimitarra]
    .use 2027
    .itemcount 2027,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.6
step << Rogue
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Cómprale una segunda|r |T135343:0|t[Cimitarra] |cffe07cf5para tu mano izquierda|r
    .collect 2027,2,850,1 --Collect Scimitar (1)
    .money <0.3815
    .itemStat 17,QUALITY,<7
    .itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.6
    .target Ironzar
step << skip
    #optional
    #completewith FlyToXroads1
    +|cffff9a3cEquipa la|r |T135343:0|t[Cimitarra]
    .use 2027
    .itemcount 2027,1
    .itemStat 17,QUALITY,<7
    .itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.6
step << !Tauren
    #label FlyToXroads1
    #completewith XroadsTurnins3
    .goto 1413/1,-3770.20,-898.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBragok|r
    .fly Crossroads >> Vuela a El Cruce
    .target Bragok
    .subzoneskip 380
    .isQuestComplete 845
step
    #optional
    #completewith next
    >>Mata a cada |cffff5a4aRaptor|r que veas. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Lashtail
    .mob Sunscale Screecher
step
    #loop
    .goto 1413/1,-2977.78,-942.71,0
    .goto 1413/1,-2274.52,-870.42,0
    .goto 1413/1,-2977.78,-942.71,80,0
    .goto 1413/1,-2832.87,-990.01,80,0
    .goto 1413/1,-2710.26,-959.6,80,0
    .goto 1413/1,-2392.07,-900.83,80,0
    .goto 1413/1,-2274.52,-870.42,80,0
    >>Termina de matar |cffff5a4aZhebras|r. Despójalas para obtener sus |cff4fc3f7Pezuñas|r
    .complete 845,1 --Zhevra Hooves (4)
    .mob Zhevra Runner
step << Tauren Druid
    #completewith DruidTraining1
    .cast 18960 >>|cffff9a3cLanza|r |T135758:0|t[Teletransporte a: Claro de la Luna]
    .zoneskip Moonglade
step << Tauren Druid
    .goto 1450/1,-2593.82,7866.90
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLoganaar|r
    .train 782 >> Aprende tus hechizos de clase
    .target Loganaar
    .bindlocation 1638,1
    .cooldown item,6948,>0
    .xp <14,1
    .xp >16,1
step << Tauren Druid
    #label DruidTraining1
    .goto 1450/1,-2593.82,7866.90
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLoganaar|r
    .train 8925 >> Aprende tus hechizos de clase
    .target Loganaar
    .bindlocation 1638,1
    .cooldown item,6948,>0
    .xp <16,1
step << Tauren
    #completewith FlyXroads2
    .hs >> Usa tu Piedra de hogar para ir a Cima del Trueno
    .bindlocation 1638,1
    .zoneskip Thunder Bluff
    .cooldown item,6948,>0
    .use 6948
step << Tauren
    .goto 1456/1,40.72,-1238.97--c:Thunder Bluff,45.6,55.9
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAhanu|r
    .turnin 6362 >>Entrega la misión Un viaje a Cima del Trueno
    .accept 6363 >>Acepta la misión Tal, maestro de jinetes del viento
    .target Ahanu
step << Tauren Shaman
    .goto 1456/1,269.92,-980.40
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTigor|r
    .train 2645 >> Aprende tus hechizos de clase
    .target Tigor Skychaser
    .xp <14,1
    .xp >16,1
step << Tauren Shaman
    #optional
    .goto 1456/1,269.92,-980.40
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTigor|r
    .train 8498 >> Aprende tus hechizos de clase
    .target Tigor Skychaser
    .xp <16,1
step << Tauren Hunter/Tauren Warrior
    #completewith HunterTraining1 << Tauren Hunter
    #completewith WarriorTraining1 << Tauren Warrior
    .goto 1456/1,-123.26,-1394.49,60 >> Viaja al Alto de los Cazadores
step << Tauren Hunter
    #label HunterTraining1
    .goto 1456/1,-100.50,-1454.75
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cUrek|r
    .train 13795 >> Aprende tus hechizos de clase
    .target Urek Thunderhorn
    .xp <16,1
step << Tauren Hunter
    .goto 1456/1,-47.69,-1434.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHesuwa|r
    .train 24556 >> Entrena los hechizos de tu mascota
    .target Hesuwa Thunderhorn
step << Tauren Warrior
    .goto 1456/1,-81.09,-1457.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTorm|r
    .train 1160 >>Aprende tus hechizos de clase
    .target Torm Ragetotem
    .xp <14,1
    .xp >16,1
step << Tauren Warrior
    #label WarriorTraining1
    .goto 1456/1,-81.09,-1457.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTorm|r
    .train 285 >>Aprende tus hechizos de clase
    .target Torm Ragetotem
    .xp <16,1
step << Tauren
    .goto 1456/1,26.10,-1196.66--c:Thunder Bluff,47.00,49.82
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTal|r
    .turnin 6363 >>Entrega la misión Tal, maestro de jinetes del viento
    .accept 6364 >>Acepta la misión Regresa con Jahan
    .target Tal
step << Tauren
    #label FlyXroads2
    #completewith HidesTurnIn
    .goto 1456/1,26.1,-1196.66
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTal|r
    .fly Crossroads >>Vuela a El Cruce
    .target Tal
    .zoneskip The Barrens
step << Tauren
    .goto 1413/1,-2645.40,-406.94--c:The Barrens,51.99,29.89
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Boorand|r
    .home >>Establece tu Piedra de hogar en El Cruce
    .target Innkeeper Boorand Plainswind
    .bindlocation 380
    .isQuestAvailable 903,850,867,901
step
    .goto 1413/1,-2595.75,-473.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThork|r
    .turnin 5041 >>Entrega la misión Suministros para El Cruce
    .turnin 872 >>Entrega la misión La perturbación termina
    .target Thork
    .isQuestTurnedIn 871
step
    #label XroadsTurnins3
    .goto 1413/1,-2669.72,-481.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSergra|r
    .turnin 845 >>Entrega la misión La zhebra
    .accept 903 >>Acepta la misión Merodeadores en Los Baldíos
    .target Sergra Darkthorn
step << Tauren
    #label HidesTurnIn
    .goto 1413/1,-2566.36,-350.19--c:The Barrens,51.21,29.05
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJahan|r
    .turnin 6364 >>Entrega la misión Regresa con Jahan
    .target Jahan Hawkwing
    .isOnQuest 6364
step << Troll Hunter/Orc Hunter
    .goto 1413/1,-2612.98,-411.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cBarg|r
    >>|cffe07cf5Compra|r |T132382:0|t[Flechas afiladas] |cffe07cf5a este vendedor|r
    .collect 2515,1200,850,1 << Hunter --Sharp Arrow (1200)
    .target Barg
step << Tauren Hunter
    .goto 1413/1,-2612.98,-411.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cBarg|r
    >>|cffe07cf5Compra|r |T132384:0|t[Perdigones pesados] |cffe07cf5a este vendedor|r
    .collect 2519,1000,850,1 << Hunter --Heavy Shot (1000)
    .target Barg
step << Troll Hunter/Orc Hunter/Skyborne Hunter
    .goto 1413/1,-2556.23,-351.54
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cUthrok|r
    .vendor >> |cffe07cf5Cómprale un|r |T135490:0|t[|cff5cf05cArco largo refinado|r] |cffe07cf5si está disponible y abastécete de flechas|r
    >>|cffff9a3cSi no está disponible, compra un|r |T135490:0|t[Arco reforzado] |cffff9a3cen su lugar|r
    .collect 2515,1200,870,1 << Hunter --Sharp Arrow (1200)
    .target Uthrok
    .isOnQuest 903
step << Tauren Hunter
    .goto 1413/1,-2556.23,-351.54
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cUthrok|r|cffe07cf5. Compra una|r |T135613:0|t[Bocarda de cazador] |cffe07cf5a este vendedor|r
    .collect 2511,1,871,1 --Collect Hunter's Boomstick (1)
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<4.9
    .target Uthrok
step
    #optional
    #completewith RegtharDeathgate1
    >>Mata a los |cffff5a4aZancudos de llanura|r. Despójalos para obtener sus |cff4fc3f7Riñones|r
    .complete 821,2 --Plainstrider Kidney (5)
    .mob Greater Plainstrider
    .mob Fleeting Plainstrider
    .isQuestTurnedIn 819
step
    #optional
    #completewith next
    >>Mata a cada |cffff5a4aRaptor|r que veas. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Lashtail
    .mob Sunscale Screecher
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .accept 850 >>Acepta la misión Los jefes Kolkar
    .accept 855 >>Acepta la misión Los brazales centauro
    .target Regthar Deathgate
step
    #optional
    #label RegtharDeathgate1
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .accept 850 >>Acepta la misión Los jefes Kolkar
    .target Regthar Deathgate
step
    #optional
    #completewith KodobaneTurnin
    >>Mata |cffff5a4aRetadores Kolkar|r y |cffff5a4aAgitadoras Kolkar|r. Despójalos para obtener sus |cff4fc3f7Brazales|r
    >>|cffff9a3cEsta misión no tiene que ser completada ahora|r
    .complete 855,1 --Centaur Bracers (15)
    .mob Kolkar Wrangler
    .mob Kolkar Stormer
    .isOnQuest 855
step
    #optional
    #completewith Barak
    >>Recoge |cff4fc3f7Champiñones cargados|r alrededor de Las Charcas del Olvido
    >>|cffff9a3cEsta misión no tiene que ser completada ahora|r
    .complete 848,1 --Collect Fungal Spores (x4)
step
    .goto 1413/1,-1943.16,89.64
    >>Sumérgete bajo el agua hacia la |cffe07cf5Fisura burbujeante|r
    .complete 870,1 --Explore the waters of the Forgotten Pools
step
    #label Barak
    .goto 1413/1,-1716.18,23.43
    >>Mata a |cffff5a4aBarak Aterrakodos|r. Despójalo para obtener su |cff4fc3f7Cabeza|r
    >>|cffff9a3cTen cuidado ya que los golpes de |cffff5a4aBarak Aterrakodos|r causan MUCHO daño y está protegido por un |cffff5a4aRetador Kolkar|r. Pueden atraparte con una red y dispararte desde la distancia|r
    .complete 850,1 --Kodobane's Head (1)
    .mob Barak Kodobane
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 850 >>Entrega la misión Los jefes Kolkar
    .accept 851 >>Acepta la misión Verog el Derviche
    .turnin 855 >>Entrega la misión Los brazales centauro
    .target Regthar Deathgate
    .isQuestComplete 855
step
    #label KodobaneTurnin
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 850 >>Entrega la misión Los jefes Kolkar
    .accept 851 >>Acepta la misión Verog el Derviche
    .target Regthar Deathgate
step
    #optional
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .accept 851 >>Acepta la misión Verog el Derviche
    .target Regthar Deathgate
    .isQuestTurnedIn 850
step
    #optional
    #completewith HarpyTalons
    >>Mata a cada |cffff5a4aRaptor|r que veas. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Lashtail
    .mob Sunscale Screecher
step
    #loop
    .goto 1413/1,-1594.58,30.19,0
    .goto 1413/1,-1594.58,30.19,50,0
    .goto 1413/1,-1562.15,-29.94,50,0
    .goto 1413/1,-1483.11,66.67,50,0
    .goto 1413/1,-1531.75,180.85,50,0
    .goto 1413/1,-1462.84,214.63,50,0
    >>Mata |cffff5a4aMerodeadores de la sabana|r. Despójalos para obtener sus |cff4fc3f7Garras|r y |cff4fc3f7Colmillos|r
    .complete 903,1 --Prowler Claws (7)
    .complete 821,1 --Savannah Lion Tusk (5)
    .disablecheckbox
    .mob Savannah Prowler
    .isQuestTurnedIn 819
step
    #optional
    #loop
    .goto 1413/1,-1594.58,30.19,0
    .goto 1413/1,-1594.58,30.19,50,0
    .goto 1413/1,-1562.15,-29.94,50,0
    .goto 1413/1,-1483.11,66.67,50,0
    .goto 1413/1,-1531.75,180.85,50,0
    .goto 1413/1,-1462.84,214.63,50,0
    >>Mata |cffff5a4aMerodeadores de la sabana|r. Despójalos para obtener sus |cff4fc3f7Garras|r
    .complete 903,1 --Prowler Claws (7)
    .mob Savannah Prowler
    .isQuestAvailable 819
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #loop
    .goto 1413/1,-1616.87,611.90,0
    .goto 1413/1,-1583.43,322.73,60,0
    .goto 1413/1,-1513.51,380.84,60,0
    .goto 1413/1,-1526.68,477.450,60,0
    .goto 1413/1,-1555.06,545.69,60,0
    .goto 1413/1,-1553.03,615.95,60,0
    .goto 1413/1,-1616.87,611.90,60,0
    >>Mata |cffff5a4aArpías Alabruja|r y |cffff5a4aMalaplumas Alabruja|r. Despójalas para obtener sus |cff4fc3f7Garras|r
    .complete 867,1 --Witchwing Talon (8)
    .mob Witchwing Harpy
    .mob Witchwing Roguefeather
step
    #optional
    #label HarpyTalons
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #completewith Samophlange
    +|cffff9a3cTen cuidado con los|r |cffff5a4aSegadores Solescama|r |cffff9a3cen la zona. Tienen hasta nivel 18 y pueden usar|r |T132152:0|t[Vapulear]
    .xp >17,1
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #optional
    #completewith Samophlange
    >>Mata a los |cffff5a4aZancudos de llanura|r. Despójalos para obtener sus |cff4fc3f7Riñones|r
    .complete 821,2 --Plainstrider Kidney (5)
    .mob Greater Plainstrider
    .mob Fleeting Plainstrider
    .mob Ornery Plainstrider
    .isQuestTurnedIn 819
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-1812.500,790.000
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVrang|r
    .accept 95494 >>Acepta la misión El orgullo herido y la piel del león
    .accept 95507 >>Acepta la misión Las presas de Vrang
    .target Vrang Wildgore
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-1815.48,786.89
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVrang|r
    >>|cff5cf05cVrang|r |cffff9a3cvende|r |T133476:0|t[|cff5cf05cMaza con pinchos pesada|r] |cffff9a3cque es un objeto de suministro limitado|r << Tauren Warrior/Tauren Shaman/Druid
	.vendor	>> Vende la basura y repara
    .target Vrang Wildgore
    .isQuestAvailable 95494,95507
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #completewith next
    >>Despoja las |cffe07cf5Trampas activadas|r del suelo
    .complete 95507,1 --|8/8 Trapped Game
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #loop
    .goto 1413/1,-1848.200,486.900,0
    .goto 1413/1,-1848.200,486.900,50,0
    .goto 1413/1,-1937.500,480.000,50,0
    .goto 1413/1,-1983.100,579.700,50,0
    .goto 1413/1,-1960.600,653.700,50,0
    .goto 1413/1,-1871.600,653.700,50,0
    .goto 1413/1,-1729.700,592.400,50,0
    >>Mata |cffff5a4aPatriarcas de la sabana|r. Despójalos para obtener sus |cff4fc3f7Cueros|r y |cff4fc3f7Colmillos|r
    >>|cffff9a3cSi hay demasiada competencia y no puedes completar esta misión rápidamente, puedes omitir este paso|r
    .complete 95494,1 --|6/6 Savannah Lion Hide
    .complete 821,1 --Savannah Lion Tusk (5)
    .disablecheckbox
    .mob Savannah Patriarch
    .isQuestTurnedIn 819
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #optional
    #loop
    .goto 1413/1,-1848.200,486.900,0
    .goto 1413/1,-1848.200,486.900,50,0
    .goto 1413/1,-1937.500,480.000,50,0
    .goto 1413/1,-1983.100,579.700,50,0
    .goto 1413/1,-1960.600,653.700,50,0
    .goto 1413/1,-1871.600,653.700,50,0
    .goto 1413/1,-1729.700,592.400,50,0
    >>Mata a los |cffff5a4aPatriarcas de la sabana|r. Despójalos para obtener sus |cff4fc3f7Cueros|r
    >>|cffff9a3cSi hay demasiada competencia y no puedes completar esta misión rápidamente, puedes omitir este paso|r
    .complete 95494,1 --|6/6 Savannah Lion Hide
    .mob Savannah Patriarch
    .isQuestAvailable 819
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #loop
    .goto 1413/1,-1960.600,653.700,0
    .goto 1413/1,-1848.200,486.900,50,0
    .goto 1413/1,-1937.500,480.000,50,0
    .goto 1413/1,-1983.100,579.700,50,0
    .goto 1413/1,-1960.600,653.700,50,0
    .goto 1413/1,-1871.600,653.700,50,0
    .goto 1413/1,-1729.700,592.400,50,0
    >>Despoja las |cffe07cf5Trampas activadas|r del suelo
    .complete 95507,1 --|8/8 Trapped Game
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-1812.600,789.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVrang Sangrevaje|r
    .turnin 95494 >>Entrega la misión El orgullo herido y la piel del león
    .turnin 95507 >>Entrega la misión Las presas de Vrang
    .accept 95495 >>Acepta la misión El peletero ermitaño
    .target Vrang Wildgore
    .isQuestComplete 95494
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #completewith next
    .goto 1413/1,-1778.100,684.200,25,0
    .goto 1413/1,-1741.700,721.400,25,0
    .goto 1413/1,-1643.900,786.000,25,0
    .goto 1413/1,-1605.300,818.300,20 >>Sube por la montaña
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-1635.400,838.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWalton|r
    .turnin 95495 >>Entrega la misión El peletero ermitaño
    .accept 95621 >>Acepta la misión Problemas en el valle
    .target Walton
    .isQuestTurnedIn 95494
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-1611.500,549.000
    >>Mata al |cffff5a4aCabo Adamore|r
    >>|cffff9a3c¡Ten cuidado! Podrías llamar la atención (aggro) de 2 o 3 bichos a la vez|r
    .complete 95621,1 --|1/1 Learn why the Kul Tirans are here
    .mob Corporal Adamore
    .isQuestTurnedIn 95494
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #completewith next
    .goto 1413/1,-1736.900,650.300,25,0
    .goto 1413/1,-1741.700,721.400,25,0
    .goto 1413/1,-1643.900,786.000,25,0
    .goto 1413/1,-1605.300,818.300,20 >>Sube por la montaña
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-1635.500,838.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWalton|r
    .turnin 95621 >>Entrega la misión Problemas en el valle
    .accept 95508 >>Acepta la misión Huéspedes no deseados
    .timer 67,Unwelcome Guests RP
    .target Walton
    .isQuestTurnedIn 95494
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-1629.200,835.600
    >>Ponte detrás de la casa mientras esperas a que termine el RP para evitar llamar la atención (aggro) de todos los bichos a la vez
    >>|cffff9a3cEn realidad no necesitas ayudar a |cff5cf05cWalton|r, sobrevivirá con la ayuda de|r |cff5cf05cVrang Sangrevaje|r
    .complete 95508,1 --|1/1 Assist Walton
    .mob Terry Longdrink
    .isQuestTurnedIn 95494
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-1635.400,838.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWalton|r
    .turnin 95508 >>Entrega la misión Huéspedes no deseados
    .target Walton
    .isQuestTurnedIn 95494
step
    #completewith EcheyakeePickup
    .hs >> Usa tu Piedra de hogar para ir a El Cruce
    .cooldown item,6948,>0
    .use 6948
    .bindlocation 380,1
    .subzoneskip 380
step
    #label FoodandWater2
    .goto 1413/1,-2645.40,-406.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Boorand|r
	.vendor >>|cffe07cf5Vende la basura y luego reabastécete de comida y agua si es necesario|r << !Rogue !Warrior
    .vendor >>|cffe07cf5Vende tu basura, luego reabastécete de comida si es necesario|r << Rogue/Warrior
    .target Innkeeper Boorand Plainswind
    .isQuestAvailable 901,881
step
    .goto 1413/1,-2639.32,-436.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGazrog|r
    .turnin 869 >>Entrega la misión Raptores ladrones
    .accept 3281 >>Acepta la misión Plata robada
    .target Gazrog
    .isQuestComplete 869
step
    #optional
    .goto 1413/1,-2639.32,-436.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGazrog|r
    .accept 3281 >>Acepta la misión Plata robada
    .target Gazrog
    .isQuestTurnedIn 869
step
    .goto 1413/1,-2589.67,-424.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHelbrim|r
    .turnin 848 >> Entrega la misión Esporas de hongos
    .target Apothecary Helbrim
    .isQuestComplete 848
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-2607.91,-475.180
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDarsok|r
    .turnin 867 >>Entrega la misión Arpías saqueadoras
    --.accept 875 >>Acepta la misión Las tenientes arpías
    .target Darsok Swiftdagger
step
    .goto 1413/1,-2641.35,-521.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMankrik|r
    .accept 899 >>Acepta la misión Consumido por el odio
    .accept 4921 >>Acepta la misión Perdida en la batalla
    .target Mankrik
step
    .goto 1413/1,-2672.76,-544.77
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTonga|r
    .turnin 870 >>Entrega la misión Las Charcas del Olvido
    .accept 877 >>Acepta la misión El Oasis Estancado
    .target Tonga Runetotem
step
    #label EcheyakeePickup
    .goto 1413/1,-2670.74,-482.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSergra|r
    .turnin 903 >>Entrega la misión Merodeadores en Los Baldíos
    .accept 881 >>Acepta la misión Echeyakee
    .target Sergra Darkthorn
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #completewith SamophlangeComplete
    >>Mata a cada |cffff5a4aRaptor|r que veas. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Lashtail
    .mob Sunscale Screecher
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-3031.48,461.91
    >>Usa el |T134227:0|t[Cuerno de Echeyakee] para invocar a |cffff5a4aEcheyakee|r
    >>Mata a |cffff5a4aEcheyakee|r. Despójalo para obtener |cff4fc3f7Pellejo de Echeyakee|r
    >>|cffff9a3cSi |cffff5a4aEcheyakee|r no aparece después de usar el|r |T134227:0|t[Cuerno de Echeyakee]|cffff9a3c o no le diste el primer golpe al aparecer, salta este paso|r
    .complete 881,1 --Echeyakee's Hide (1)
    .mob Echeyakee
    .use 10327
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #optional
    .goto 1413/1,-2669.72,-481.94
    .abandon 881 >>|cffff9a3cSi |cffff5a4aEcheyakee|r no apareció después de usar el|r |T134227:0|t[Cuerno de Echeyakee]|cffff9a3c o no le diste el primer golpe al aparecer, abandona la misión Echeyakee, luego regresa a la ciudad y acéptala de nuevo|r
    .itemcount 5100,<1 --Echeyakee's Hide (0)
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-2670.74,-482.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSergra|r
    .accept 881 >>Acepta la misión Echeyakee
    .target Sergra Darkthorn
    .itemcount 5100,<1 --Echeyakee's Hide (0)
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-3031.48,461.91
    >>Usa el |T134227:0|t[Cuerno de Echeyakee] para invocar a |cffff5a4aEcheyakee|r
    >>Mata a |cffff5a4aEcheyakee|r. Despójalo para obtener |cff4fc3f7Pellejo de Echeyakee|r
    .complete 881,1 --Echeyakee's Hide (1)
    .mob Echeyakee
    .use 10327
step << Tauren/Hunter/Orc Shaman/Troll Shaman
	#label Samophlange
    .goto 1413/1,-2686.95,825.40
    >>Haz clic en la |cffe07cf5Consola de control|r
    .turnin 894 >>Entrega la misión El churumbele
    .accept 900 >>Acepta la misión El churumbele
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-2686.95,842.290
    >>Haz clic en la |cffe07cf5Válvula|r
    >>|cffff9a3c¡Ten cuidado! Dos enemigos aparecerán después de que cierres la Válvula|r
    .complete 900,1 --Shut off Main Control Valve (1)
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-2675.80,842.290
    >>Haz clic en la |cffe07cf5Válvula|r
    >>|cffff9a3cUn enemigo aparecerá después de que cierres la Válvula|r
    .complete 900,3 --Shut off Regulator Valve (1)
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-2679.86,830.80
    >>Haz clic en la |cffe07cf5Válvula|r
    .complete 900,2 --Shut off Fuel Control Valve (1)
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-2686.95,825.40
    >>Haz clic en la |cffe07cf5Consola de control|r
    .turnin 900 >>Entrega la misión El churumbele
    .accept 901 >>Acepta la misión El churumbele
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-2731.54,909.850
    >>Mata a |cffff5a4aManitas el Risitas|r en el edificio. Despójalo para obtener su |cff4fc3f7Llave de la consola|r
    .complete 901,1 --Console Key (1)
    .mob Tinkerer Sniggles
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #label SamophlangeComplete
    .goto 1413/1,-2686.95,825.40
    >>Haz clic en la |cffe07cf5Consola de control|r
    .turnin 901 >>Entrega la misión El churumbele
    .accept 902 >>Acepta la misión El churumbele
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #loop
    .goto 1413/1,-2879.48,781.48,0
    .goto 1413/1,-2879.48,781.48,90,0
    .goto 1413/1,-2909.88,484.21,90,0
    .goto 1413/1,-2666.500,719.600,90,0
    .goto 1413/1,-2965.400,1009.100,90,0
    >>Mata a los |cffff5a4aRaptores|r. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Lashtail
    .mob Sunscale Screecher
    .mob Sunscale Scytheclaw
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #optional
    .goto 1413/1,-3102.42,1105.78
    >>Sube al nivel 16 aquí matando enemigos, es importante, porque las próximas 3 misiones son bastante difíciles
	.xp 16
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #label Ignition
    .goto 1413/1,-3104.44,1109.16
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el|r |cff5cf05cMachacador de Rabiaire|r en el Fangal
    >>|cff5cf05cMachacador de Rabiaire|r |cffff9a3ctiene un tiempo de reaparición largo. Considera omitir esta misión si hay mucha competencia|r
    .accept 858 >>Acepta la misión La llave de contacto
    .target Wizzlecrank's Shredder
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #completewith next
    +|cffff9a3cTen cuidado si el|r |cffff5a4aSupervisor Asas|r |cffff9a3co la|r |cffff5a4aBestia de lodo|r |cffff9a3cestán vivos. Son élites raros de nivel 19 muy fuertes|r
    .unitscan Foreman Grills
    .unitscan Sludge Beast
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-3104.44,1040.25,20,0
    .goto 1413/1,-3086.20,1055.78,12,0
    .goto 1413/1,-3063.91,1049.70,12,0
    .goto 1413/1,-3056.82,1038.89,12,0
    .goto 1413/1,-3064.92,1034.16,12,0
    .goto 1413/1,-3086.20,1055.78
    >>Mata al |cffff5a4aSupervisor Palarrastre|r. Despójalo para obtener su |cff4fc3f7Llave|r
    >>|cffff9a3cPatrulla subiendo y bajando la plataforma|r
    .complete 858,1 --Ignition Key (1)
    .mob Supervisor Lugwizzle
    .isOnQuest 858
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1413/1,-3104.44,1109.16
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el|r |cff5cf05cMachacador de Rabiaire|r
    >>|cff5cf05cMachacador de Rabiaire|r |cffff9a3ctiene un tiempo de reaparición largo. Considera omitir esta misión si hay mucha competencia|r
    >>|cffff9a3cEsto iniciará una escolta. Asegúrate de estar a plena salud|r
    .turnin 858 >>Entrega la misión La llave de contacto
    .accept 863,1 >>Acepta la misión La fuga
    .target Wizzlecrank's Shredder
    .isQuestComplete 858
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #optional
    .goto 1413/1,-3104.44,1109.16
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el|r |cff5cf05cMachacador de Rabiaire|r
    >>|cff5cf05cMachacador de Rabiaire|r |cffff9a3ctiene un tiempo de reaparición largo. Considera omitir esta misión si hay mucha competencia|r
    >>|cffff9a3cEsto iniciará una escolta. Asegúrate de estar a plena salud|r
    .accept 863,1 >>Acepta la misión La fuga
    .target Wizzlecrank's Shredder
    .isQuestTurnedIn 858
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #label Slugs
    .goto 1413/1,-3031.48,1088.21,30,0
    .goto 1413/1,-3002.10,1130.78
    >>|cffff9a3cDos|r |cffff5a4aMercenarios de Ventura y Cía.|r |cffff9a3caparecerán cuando la trituradora suba al terreno elevado. Mátalos y luego espera por su evento de RP al final|r
    .complete 863,1 --Escort Wizzlecrank out of the Venture Co. drill site (1)
    .mob Venture Co. Mercenary
    .mob Venture Co. Drudger
    .mob Overseer Glibby
    .isOnQuest 863
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #optional
    #completewith next
    >>Mata a los |cffff5a4aZancudos de llanura|r. Despójalos para obtener sus |cff4fc3f7Riñones|r
    .complete 821,2 --Plainstrider Kidney (5)
    .mob Greater Plainstrider
    .mob Fleeting Plainstrider
    .mob Ornery Plainstrider
    .isQuestTurnedIn 819
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #label CatsEye
    #loop
    .goto 1413/1,-3610.1,1313.2,0
    .goto 1413/1,-3605.03,1308.47,40,0
    .goto 1413/1,-3564.5,1367.25,40,0
    .goto 1413/1,-3622.26,1384.81,40,0
    .goto 1413/1,-3673.94,1374.68,40,0
    .goto 1413/1,-3653.67,1306.44,40,0
    .goto 1413/1,-3644.55,1249.69,40,0
    .goto 1413/1,-3603.0,1236.85,40,0
    .goto 1413/1,-3575.64,1271.31,40,0
    .goto 1413/1,-3610.1,1313.2,40,0
    >>Mata |cffff5a4aDéspotas de Ventura y Cía.|r y |cffff5a4aSobrestantes de Ventura y Cía.|r. Despójalos para obtener la |cff4fc3f7Esmeralda ojo de gato|r
    >>|cffff9a3cSi no ha caído después de 25+ enemigos, puedes omitir esta misión|r
    .complete 896,1 -- Cats Eye Emerald (1)
    .mob Venture Co. Enforcer
    .mob Venture Co. Overseer
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #ssf
    .goto 1413/1,-3610.1,1313.2,0
    .goto 1413/1,-3605.03,1308.47,40,0
    .goto 1413/1,-3564.5,1367.25,40,0
    .goto 1413/1,-3622.26,1384.81,40,0
    .goto 1413/1,-3673.94,1374.68,40,0
    .goto 1413/1,-3653.67,1306.44,40,0
    .goto 1413/1,-3644.55,1249.69,40,0
    .goto 1413/1,-3603.0,1236.85,40,0
    .goto 1413/1,-3575.64,1271.31,40,0
    .goto 1413/1,-3610.1,1313.2,40,0
    >>Mata |cffff5a4aSobrestantes de Ventura y Cía.|r. Despójalos para obtener su |T132794:0|t[|cff4fc3f7Frasco de aceite|r]
    .collect 814,5,103,1 --Flask of Oil (5)
    .dungeon DM
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #ah
    .goto 1413/1,-3610.1,1313.2,0
    .goto 1413/1,-3605.03,1308.47,40,0
    .goto 1413/1,-3564.5,1367.25,40,0
    .goto 1413/1,-3622.26,1384.81,40,0
    .goto 1413/1,-3673.94,1374.68,40,0
    .goto 1413/1,-3653.67,1306.44,40,0
    .goto 1413/1,-3644.55,1249.69,40,0
    .goto 1413/1,-3603.0,1236.85,40,0
    .goto 1413/1,-3575.64,1271.31,40,0
    .goto 1413/1,-3610.1,1313.2,40,0
    >>Mata |cffff5a4aSobrestantes de Ventura y Cía.|r. Despójalos para obtener su |T132794:0|t[|cff4fc3f7Frasco de aceite|r]
    >>|cffff9a3cTambién puedes comprarlos en la casa de subastas|r
    .collect 814,5,103,1 --Flask of Oil (5)
    .dungeon DM
step << skip
    .goto 1413/1,-3505.72,1358.46
    .goto 1454/1,-4242.34,1637.33,30 >>|cffff9a3cSalta a la viga de madera. Haz un Logout Skip desconectando y volviendo a entrar. Regresa a Orgrimmar si no lo logras|r
    .link https://www.youtube.com/watch?v=U7YfoaO-X8E >> |cffff9a3cHAZ CLIC AQUÍ para ver un ejemplo|r
    .zoneskip Orgrimmar

]=], "Horde"}
R[#R + 1] = {[=[
#forever
<< Horde
#name 16-17 Sima Ígnea
#version 11
#group Forever Guía de Mazmorras (H)
#subgroup Mazmorras 1-22
#next 17-18 Ruinas de Lordaeron

step
    #sticky
    #completewith EnterRFC
    .subzone 2437 >> Ahora deberías buscar un grupo para Sima Ígnea
step
    #optional
    #completewith EnterRFC
    >>|cffff9a3cSi es posible, haz que los miembros del grupo compartan la siguiente misión|r
    >>|cffff9a3cSi es necesario, pide a alguien en Entrañas que comparta la misión|r
    .accept 5725 >> Acepta la misión Poder destructivo
step
    #optional
    #completewith EnterRFC
    >>|cffff9a3cSi es posible, haz que los miembros del grupo compartan las siguientes misiones|r
    >>|cffff9a3cSi es necesario, pide a alguien en Cima del Trueno que comparta la misión|r
    .accept 5722 >> Acepta la misión Buscando la cartera perdida
    .accept 5723 >> Acepta la misión Midiendo fuerzas con el enemigo
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #completewith EnterRFC
    .goto 1414/1,-3839.37,1644.65
    .zone Orgrimmar >>Entra en Orgrimmar por la entrada occidental
step << !Tauren !Hunter !Shaman/Skyborne
    #completewith EnterRFC
    .goto 1413/1,-2595.75,-437.35--c:The Barrens,51.50,30.34
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDevrak|r
    .fly Orgrimmar >> Vuela a Orgrimmar
    .zoneskip Orgrimmar
    .target Devrak
step
    #completewith next
    .skill firstaid,40 >> |cffff9a3cCrea|r |T133685:0|t[Vendas de lino] |cffff9a3chasta que tu habilidad sea 40 o superior|r
    .skill firstaid,<1,1
step
    .goto 1454/1,-4160.01,1483.17
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cArnok|r
    >>|cffff9a3cOmitir este paso si no tuviste suficiente|r |T132889:0|t[Paño de lino] |cffff9a3cpara llegar a 40 de habilidad|r
    .train 3276 >> Aprende |T133688:0|t[Venda de lino gruesa]
    .target Arnok
    .skill firstaid,<1,1
step
    #completewith next
    .skill firstaid,50 >> |cffff9a3cCrea|r |T133688:0|t[Vendas de lino gruesas] |cffff9a3chasta que tu habilidad sea 50 o superior|r
    .skill firstaid,<1,1
step
    .goto 1454/1,-4160.01,1483.17
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cArnok|r
    >>|cffff9a3cOmite este paso si no tuviste suficiente|r |T132889:0|t[Paño de lino] |cffff9a3cpara alcanzar a 50 de habilidad|r
    .train 3274 >> Aprende Oficial de primeros auxilios
    .target Arnok
    .skill firstaid,<40,1
step << !Tauren !Hunter !Shaman/Skyborne
    #completewith EnterRFC
    +|cffff9a3cAsegúrate de no vender tu|r |T132794:0|t[|cff4fc3f7Frasco de aceite|r]
    .itemcount 814,5
    .dungeon DM
step << Priest
    #optional
    .goto 1454/1,-4179.79,1452.580
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cUr'kyo|r
    .train 8102 >> Aprende tus hechizos de clase
    .target Ur'kyo
    .xp <16,1
    .xp >18,1
step << Priest
    #optional
    .goto 1454/1,-4179.79,1452.580
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cUr'kyo|r
    .train 970 >> Aprende tus hechizos de clase
    .target Ur'kyo
    .xp <18,1
step << Mage
    .goto 1454/1,-4218.64,1473.72
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cPephredo|r
    .train 2120 >> Aprende tus hechizos de clase
    .target Pephredo
    .xp <16,1
    .xp >18,1
step << Mage
    #optional
    .goto 1454/1,-4218.64,1473.72
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cPephredo|r
    .train 3140 >> Aprende tus hechizos de clase
    .target Pephredo
    .xp <18,1
step << Orc/Troll
    .goto 1454/1,-4439.37,1633.99
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cGryshka|r
    .turnin 6384 >>Entrega la misión Un viaje a Orgrimmar
    .accept 6385 >>Acepta la misión Doras, maestro de jinetes del viento
    .target Innkeeper Gryshka
    .isOnQuest 6384
step << Orc/Troll
    .goto 1454/1,-4313.46,1676.25--c:Orgrimmar,45.120,63.889
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cDoras|r
    .turnin 6385 >> Entrega la misión Doras, maestro de jinetes del viento
    .accept 6386 >> Acepta la misión Regreso a El Cruce
    .target Doras
    .isOnQuest 6385
step << Orc/Troll
    .goto 1454/1,-4313.46,1676.25--c:Orgrimmar,45.120,63.889
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cDoras|r
    .accept 6386 >> Acepta la misión Regreso a El Cruce
    .target Doras
    .isQuestTurnedIn 6385
step << Tauren
    .goto 1454/1,-4313.60,1676.24
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDoras|r
    >>|cffff9a3c¡No vueles a ningún lado!|r
    .fp Orgrimmar >> Consigue la ruta de vuelo de Orgrimmar
    .target Doras
    .isQuestAvailable 4921
step << Warrior
    .goto 1454/1,-4801.42,1980.53
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGrezz|r
    .train 285 >> Aprende tus hechizos de clase
    .target Grezz Ragefist
    .xp <16,1
    .xp >18,1
step << Warrior
    #optional
    .goto 1454/1,-4801.42,1980.53
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGrezz|r
    .train 8198 >> Aprende tus hechizos de clase
    .target Grezz Ragefist
    .xp <18,1
step << Hunter
    .goto 1454/1,-4607.02,2100.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOrmak|r
    .train 13795 >> Aprende tus hechizos de clase
    .target Ormak Grimshot
    .xp <16,1
    .xp >18,1
step << Hunter
    #optional
    .goto 1454/1,-4607.02,2100.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOrmak|r
    .train 2643 >> Aprende tus hechizos de clase
    .target Ormak Grimshot
    .xp <18,1
step << Hunter
    .goto 1454/1,-4611.09,2135.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cXao'tsu|r
    .train 24557 >> Entrena los hechizos de tu mascota
    .target Xao'tsu
    .xp <18,1
step << Troll Hunter/Orc Hunter/Priest/Warlock
    .goto 1454/1,-4824.00,2090.540
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHanashi|r
    .train 227 >>Aprende el uso de Bastones
    .target Hanashi
    .money <0.100
step << Tauren Hunter
    .goto 1454/1,-4824.00,2090.540
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHanashi|r
    .train 264 >>Aprende el uso de Arcos
    .target Hanashi
step << Warrior !Skyborne
    .goto 1454/1,-4824.00,2090.540
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHanashi|r
    .train 197 >>Aprende el uso de Hachas de dos manos
    .train 227 >>Aprende el uso de Bastones
    .target Hanashi
    .money <0.020
step << Warrior/Paladin/Shaman !Skyborne
    #optional
    .goto 1454/1,-4824.00,2090.540
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHanashi|r
    .train 197 >>Aprende el uso de Hachas de dos manos
    .target Hanashi
    .money <0.010
step << Hunter
    .goto 1454/1,-4819.1,2099.05
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cZendo'jian|r|cffe07cf5. Compra un|r |T135490:0|t[Arco reforzado] |cffe07cf5a este vendedor|r
    .collect 3026,1,3281,1 --Collect Reinforced Bow (1)
    .money <0.3588
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<7.4
    .target Zendo'jian
    .train 227,3
step << Hunter
    #optional
    #completewith FoodandWater2
    +|cffff9a3cEquipa el|r |T135490:0|t[Arco reforzado]
    .use 3026
    .itemcount 3026,1
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<7.4
step << Warrior
    .goto 1454/1,-4819.1,2099.05
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cZendo'jian|r|cffe07cf5. Compra un|r |T135423:0|t[Hacha de batalla] |cffe07cf5a este vendedor|r
    .collect 926,1,3281,1 --Collect Battle Axe (1)
    .money <1.021
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.2
    .target Zendo'jian
    .train 227,3
step << Warrior
    #optional
    #completewith FoodandWater2
    +|cffff9a3cEquipa el|r |T135423:0|t[Hacha de batalla] |cffff9a3ccuando alcances nivel 20|r
    .use 926
    .itemcount 926,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.2
    .xp >20,1
step << Warrior
    #optional
    #completewith FoodandWater2
    +|cffff9a3cEquipa el|r |T135423:0|t[Hacha de batalla]
    .use 926
    .itemcount 926,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.2
    .xp <20,1
step << Shaman
    .goto 1454/1,-4225.09,1933.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKardris|r
    .train 8019 >> Aprende tus hechizos de clase
    .target Kardris Dreamseeker
    .xp <16,1
    .xp >18,1
step << Shaman
    #optional
    .goto 1454/1,-4225.09,1933.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKardris|r
    .train 913 >> Aprende tus hechizos de clase
    .target Kardris Dreamseeker
    .xp <18,1
step
    .goto 1454/1,-4125.79,1920.10--c:Orgrimmar,31.74,37.82
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThrall|r
    .accept 5726 >>Acepta la misión Enemigos ocultos
    .target Thrall
step
    #completewith next
    .goto 1454/1,-4367.46,1405.44,50,0
    .zone Durotar >>Sal de Orgrimmar
step
    #completewith Gazzuz
    >>Mata a los |cffff5a4aOrcos Filo Ardiente|r. Despójalos para obtener una |cff4fc3f7Insignia de Teniente|r
    >>|cffff9a3cEsta misión es un prerrequisito para Sima Ígnea. Tiene una baja probabilidad de caída|r
    .complete 5726,1 --Lieutenant's Insignia (1)
    .mob Burning Blade Fanatic
    .mob Burning Blade Apprentice
step
    #label Gazzuz
    .goto 1411/1,-4701.42,1455.83
    >>Mata a |cffff5a4aGazz'uz|r. Despójalo para obtener su |T134085:0|t[|cff4fc3f7Ojo de la Sombra ardiente|r]
    >>|cffff9a3cUsa el |T134085:0|t[|cff4fc3f7Ojo de la Sombra ardiente|r] para empezar la misión|r
    >>|cffff9a3cCorta la línea de visión (LoS) para evitar las Descargas de las Sombras de |cffff5a4aGazz'uz|r|r
    >>|cffff9a3cPuedes correr hacia las zonas de agua que hay dentro de la cueva para evadir al|r |cffff5a4aAbisario|r |cffff9a3cdespués de matar a|r |cffff5a4aGazz'uz|r
    >>|cffff9a3cTen cuidado, ya que es difícil. Puedes saltarte esta misión si lo necesitas|r
    .collect 4903,1,832,1 --Collect Eye of Burning Shadow
    .accept 832 >>Acepta la misión Sombras Ardientes
    .use 4903
	.unitscan Gazz'uz
    .isOnQuest 5726
step
    #loop
    .goto 1411/1,-4805.59,1495.67,0
    .goto 1411/1,-4855.82,1498.84,15,0
    .goto 1411/1,-4833.08,1494.96,15,0
    .goto 1411/1,-4805.59,1495.67,15,0
    .goto 1411/1,-4784.44,1535.85,15,0
    .goto 1411/1,-4750.60,1531.62,15,0
    .goto 1411/1,-4734.21,1505.54,15,0
    .goto 1411/1,-4693.49,1519.64,15,0
    .goto 1411/1,-4679.75,1501.31,15,0
    .goto 1411/1,-4684.50,1466.06,15,0
    .goto 1411/1,-4805.59,1495.67,15,0
    >>Mata a los |cffff5a4aOrcos Filo Ardiente|r. Despójalos para obtener una |cff4fc3f7Insignia de Teniente|r
    >>|cffff9a3cEsta misión es un prerrequisito para Sima Ígnea. Tiene una baja probabilidad de caída|r
    .complete 5726,1 --Lieutenant's Insignia (1)
    .mob Burning Blade Fanatic
    .mob Burning Blade Apprentice
step
    #completewith next
    .goto 1454/1,-4367.46,1405.44,50,0
    .zone Orgrimmar >> Entra en Orgrimmar
step
    .goto 1454/1,-4125.79,1920.10--c:Orgrimmar,31.74,37.82
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThrall|r
    .turnin 5726 >> Entrega la misión Enemigos ocultos
    .accept 5727 >> Acepta la misión Enemigos ocultos
    .target Thrall
step << Rogue
    .goto 1454/1,-4284.42,1771.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShenthul|r
    .train 1804 >> Aprende |T136058:0|t[Forzar cerradura]
    .train 921 >> Aprende |T133644:0|t[Robar]
    .accept 2379 >> Acepta la misión Zando'zan
    .target Shenthul
step << Orc Rogue/Troll Rogue
    .goto 1454/1,-4280.07,1772.96
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTherzok|r
    .turnin 1963 >> Entrega la misión Mano Destrozada
    .accept 1858 >> Acepta la misión Mano Destrozada
    .target Therzok
step << Rogue
    .goto 1454/1,-4279.79,1778.57
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZando'zan|r
    .turnin 2379 >>Entrega la misión Zando'zan
    .accept 2382 >>Acepta la misión Desdio de Trinquete
    .target Zando'zan
step << Orc Rogue/Troll Rogue
    #optional
    #completewith next
    .goto 1454/1,-4271.1,1810.75
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cRekkul|r|cffe07cf5. Compra |r |T134065:0|t[Herramientas de ladrón] |cffe07cf5a este vendedor|r
    .collect 5060,1,1858,1 --Collect Thieves' Tools (1)
    .target Rekkul
    .money <0.15
step << Orc Rogue/Troll Rogue
    .goto 1454/1,-4280.07,1773.24
    >>|cffff9a3cUsa|r |T136058:0|t[Forzar cerradura] |cffff9a3cpara abrir la|r |T133626:0|t[Cartera de Tazan]
    .complete 1858,1 --Tazan's Logbook (1)
    .money <0.15
step << Orc Rogue/Troll Rogue
    .goto 1454/1,-4280.07,1772.96
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTherzok|r
    .turnin 1858 >>Entrega la misión Mano Destrozada
    .target Therzok
step << Orc Rogue/Troll Rogue
    .goto 1454/1,-4437.87,1637.33
    >>|cffff9a3cUsa|r |T133644:0|t[Robar] |cffff9a3ccon|r |cffff5a4aGamon|r |cffff9a3cen la Posada. Usa su llave para abrir la|r |T133626:0|t[Cartera de Tazan]
	.collect 7208,1,1858,1 --Tazan's Key
	.complete 1858,1 --Tazan's Logbook (1)
    .isOnQuest 1858
step << Orc Rogue/Troll Rogue
    .goto 1454/1,-4280.07,1772.96
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTherzok|r
    .turnin 1858 >>Entrega la misión Mano Destrozada
    .target Therzok
step << Warlock
    .goto 1454/1,-4362.55,1834.70
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMirket|r
    .train 1455 >> Aprende tus hechizos de clase
    .target Mirket
    .xp <16,1
    .xp >18,1
step << Warlock
    #optional
    .goto 1454/1,-4362.55,1834.70
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMirket|r
    .train 1014 >> Aprende tus hechizos de clase
    .target Mirket
    .xp <18,1
step << Warlock
    .goto 1454/1,-4347.4,1836.57
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKurgul|r y compra |T133738:0|t[Grimorio Sacrificio]
    .collect 16351,1,896,1 --Grimoire of Sacrifice (Rank 1) (1)
    .target Kurgul
    .xp <16,1
    .xp >18,1
step << Warlock
    .goto 1454/1,-4347.4,1836.57
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKurgul|r y compra |T133738:0|t[Grimorio Descarga de Fuego (Rango 3)]
    .collect 16316,1,896,1 --Grimoire of Firebolt (Rank 3) (1)
    .target Kurgul
    .xp <18,1
step
    .goto 1454/1,-4376.29,1802.43--c:Orgrimmar,49.6,50.4
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cNeeru Hojafuego|r
    .accept 5761 >>Acepta la misión Matar a la bestia
    .target Neeru Fireblade
step
    .goto 1454/1,-4374.75,1800.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cNeeru|r
    .turnin 832 >>Entrega la misión Sombras Ardientes
    .target Neeru Fireblade
    .isOnQuest 832
step
    .goto 1454/1,-4376.29,1802.43--c:Orgrimmar,49.6,50.4
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cNeeru Hojafuego|r
    .complete 5727,1 --Gauge Neeru Fireblade's reaction to you being a member of the Burning Blade
    .skipgossip
    .target Neeru Fireblade
step
    #label HiddenEnemiesPickup
    .goto 1454/1,-4125.79,1920.10--c:Orgrimmar,31.74,37.82
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThrall|r
    .turnin 5727 >> Entrega la misión Enemigos ocultos
    .accept 5728 >> Acepta la misión Enemigos ocultos
    .target Thrall
step
    #completewith EnterRFC
    .destroy 14544 >>|cffff9a3cDestruye la|r |T134417:0|t[Insignia de Teniente] |cffff9a3cya que ya no la necesitas|r
step
.enabledungeon RFC
    #label EnterRFC
    .goto 1454/1,-4420.76,1815.80--c:Orgrimmar,52.77,48.97
    .subzone 2437 >> Entra por el portal de la instancia a Sima Ígnea. Entra en la mazmorra
step
    #optional
    #completewith next
    >>Mata |cffff5a4aTroggs Furia Ardiente|r y |cffff5a4aChamanes Furia Ardiente|r
    .complete 5723,1 --Ragefire Trogg (8)
    .mob +Ragefire Trogg
    .complete 5723,2 --Ragefire Shaman (8)
    .mob +Ragefire Shaman
    .isOnQuest 5723
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMaur|r
    .turnin 5722 >> Entrega la misión Buscando la cartera perdida
    .accept 5724 >> Acepta la misión La vuelta de la cartera perdida
    .target Maur Grimtotem
    .isOnQuest 5722
step
    #optional
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMaur|r
    .accept 5724 >> Acepta la misión La vuelta de la cartera perdida
    .target Maur Grimtotem
    .isQuestTurnedIn 5722
step
    #label TroggsShamans
    >>Mata |cffff5a4aTroggs Furia Ardiente|r y |cffff5a4aChamanes Furia Ardiente|r
    .complete 5723,1 --Ragefire Trogg (8)
    .mob +Ragefire Trogg
    .complete 5723,2 --Ragefire Shaman (8)
    .mob +Ragefire Shaman
    .isOnQuest 5723
step
    #optional
    #requires TroggsShamans
    #completewith BazzalanandJergosh
    >>Mata |cffff5a4aCultores Hoja Abrasadora|r y |cffff5a4aBrujos Hoja Abrasadora|r. Despójalos para obtener los |cff4fc3f7Hechizos de las Sombras|r y los |cff4fc3f7Encantamientos desde el infierno|r
    .complete 5725,1 --Spells of Shadow (1)
    .complete 5725,2 --	Incantations from the Nether (1)
    .mob Searing Blade Cultist
    .mob Searing Blade Warlock
    .isOnQuest 5725
step
    >>Mata a |cffff5a4aTaragaman el Hambriento|r. Despójalo para obtener su |cff4fc3f7Corazón|r
    .complete 5761,1 -- Taragaman the Hungerer's Heart
    .mob Taragaman the Hungerer
    .isOnQuest 5761
step
    #label BazzalanandJergosh
    >>Mata a |cffff5a4aBazzalan|r y a |cffff5a4aJergosh el Convocador|r
    .complete 5728,1 --Bazzalan (1)
    .mob +Bazzalan
    .complete 5728,2 --Jergosh the Invoker (1)
    .mob +Jergosh the Invoker
    .isOnQuest 5728
step
    >>Mata |cffff5a4aCultores Hoja Abrasadora|r y |cffff5a4aBrujos Hoja Abrasadora|r. Despójalos para obtener los |cff4fc3f7Hechizos de las Sombras|r y los |cff4fc3f7Encantamientos desde el infierno|r
    .complete 5725,1 --Spells of Shadow (1)
    .complete 5725,2 --	Incantations from the Nether (1)
    .mob Searing Blade Cultist
    .mob Searing Blade Warlock
    .isOnQuest 5725
step
    .goto 1454/1,-4376.29,1802.43--c:Orgrimmar,49.6,50.4
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cNeeru Hojafuego|r
    .turnin 5761 >>Entrega la misión Matar a la bestia
    .target Neeru Fireblade
    .isQuestComplete 5761
step
    .goto 1454/1,-4125.79,1920.10--c:Orgrimmar,31.74,37.82
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThrall|r
    .turnin 5728 >> Entrega la misión Enemigos ocultos
    .accept 5729 >> Acepta la misión Enemigos ocultos
    .target Thrall
    .isQuestComplete 5728
step
    .goto 1454/1,-4125.79,1920.10--c:Orgrimmar,31.74,37.82
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThrall|r
    .accept 5729 >> Acepta la misión Enemigos ocultos
    .target Thrall
    .isQuestTurnedIn 5728
step
    .goto 1454/1,-4376.29,1802.43--c:Orgrimmar,49.6,50.4
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cNeeru Hojafuego|r
    .turnin 5729 >> Entrega la misión Enemigos ocultos
    .accept 5730 >> Acepta la misión Enemigos ocultos
    .target Neeru Fireblade
    .isQuestTurnedIn 5728
step
    .goto 1454/1,-4125.79,1920.10--c:Orgrimmar,31.74,37.82
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThrall|r
    .turnin 5730 >> Entrega la misión Enemigos ocultos
    .target Thrall
    .isQuestTurnedIn 5728

    ]=], "Horde"}
R[#R + 1] = {[=[
#forever
<< Horde
#name 17-18 Ruinas de Lordaeron
#version 11
#group Forever Guía de Mazmorras (H)
#subgroup Mazmorras 1-22
#next 18-21 Los Baldíos

step
    #sticky
    #completewith EnterRoL
    .subzone 16611 >> Ahora deberías estar buscando grupo para Ruinas de Lordaeron
step
    #completewith next
    .zone Durotar >> Sal de Orgrimmar
    .zoneskip Tirisfal Glades
    .zoneskip Undercity
    .zoneskip Silverpine Forest
step
    .goto 1411/1,-4648.55,1321.88,40 >>Sube a la Torre del Zepelín
    .zone Tirisfal Glades >>Toma el zepelín hacia los Claros de Tirisfal
    >>|cffff9a3cCrea agua mientras esperas|r << Mage
    .zoneskip Undercity
    .zoneskip Silverpine Forest
step
    #completewith next
    .subzone 159 >> Viaja a Rémol
step
    .goto 1420/0,265.15,2305.94--c:Tirisfal Glades,61.26,50.84
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSevren|r
    .turnin 440 >> Entrega la misión El anillo grabado
    .accept 441 >> Acepta la misión Raleigh y Entrañas
    .target Magistrate Sevren
    .isOnQuest 440
step
    #optional
    .goto 1420/0,265.15,2305.94--c:Tirisfal Glades,61.26,50.84
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSevren|r
    .accept 441 >> Acepta la misión Raleigh y Entrañas
    .target Magistrate Sevren
    .isQuestTurnedIn 440
step
    .goto 1420/0,74.200,2022.700
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cGuardia de la Muerte Linnea::1495|r
    >>|cffff9a3cEsta es una misión previa para "La furia de Rath'mael"|r
    .accept 356 >>Acepta la misión Patrulla de la retaguardia
    .target Deathguard Linnea::1495
step
    #loop
	.goto 1420/0,-324.55,2000.48,0
	.goto 1420/0,-324.55,2000.48,50,0
	.goto 1420/0,-330.88,2040.84,50,0
	.goto 1420/0,-359.34,2073.38,50,0
	.goto 1420/0,-421.25,2070.07,50,0
	.goto 1420/0,-464.63,2070.37,50,0
	.goto 1420/0,-516.14,2017.05,50,0
	.goto 1420/0,-466.44,1986.02,50,0
	.goto 1420/0,-436.61,1951.670,50,0
	.goto 1420/0,-355.28,1970.35,50,0
    >>Mata |cffff5a4aHorrores sangrantes|r y |cffff5a4aEspíritus deambulantes|r
    .complete 356,1 --Bleeding Horror (8)
    .mob +Bleeding Horror
    .complete 356,2 --Wandering Spirit (8)
    .mob +Wandering Spirit
step
    .goto 1420/0,73.800,2022.300
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cGuardia de la Muerte Linnea::1495|r
    >>|cffff9a3cEsta es una misión previa para "La furia de Rath'mael"|r
    .turnin 356 >>Entrega la misión Patrulla de la retaguardia
    .target Deathguard Linnea::1495
    .accept 99156 >>Acepta la misión Patrulla de la retaguardia
step
    .goto 1420/0,-765.200,2518.700
    >>Mata al |cffff5a4aRasgallanto|r |cffff9a3c(nivel 13 élite)|r. Despójalo para obtener |T134339:0|t[|cff4fc3f7Riptear's Corazón|r]
    >>|cffff9a3cEsta es una misión previa para "La furia de Rath'mael"|r
    .complete 99156,1 --|1/1 Riptear's Heart
    .mob Riptear
step
    .goto 1420/0,74.200,2022.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cGuardia de la Muerte Linnea::1495|r
    >>|cffff9a3cEsta es una misión previa para "La furia de Rath'mael"|r
    .turnin 99156 >>Entrega la misión Patrulla de la retaguardia
    .target Deathguard Linnea::1495
step
    .goto 1420/0,84.900,2023.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cGuardia de la Muerte Kristof::251001|r
    .accept 92422 >>Acepta la misión La furia de Rath'mael
    .target Deathguard Kristof::251001
    .isQuestTurnedIn 99156
step
    #completewith UCPickups
    >>|cffff9a3cSi es posible, haz que alguien en tu grupo comparta la siguiente misión|r
    .accept 92401 >>Acepta la misión Una pregunta con miedo
step
    #completewith UCPickups
    .goto 1420/0,240.75,1877.57
    .zone Undercity >>Viaja a Entrañas
step
    #completewith UCPickups
    .goto 1458/0,239.14,1749.54,35,0
    .goto 1458/0,255.64,1724.70,35,0
    .goto 1458/0,240.68,1706.97,10,0
    .goto 1458/0,241.06,1660.12,10,0
    .goto 1458/0,257.08,1623.38,10,0
    .goto 1458/0,244.51,1598.73,15,0
    .goto 1458/0,266.300,1567.200,20 >>Toma el ascensor para bajar a Entrañas
step
    .goto 1458/0,278.19,1604.24--c:Undercity,62.02,42.76
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRaleigh|r
    .turnin 441 >>Entrega la misión Raleigh y Entrañas
    .accept 530 >>Acepta la misión La venganza de un esposo
    .target Raleigh Andrean
    .isQuestTurnedIn 440
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .goto 1458/0,266.300,1567.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMichael Garrett::4551|r
    .fp Undercity >>Consigue la ruta de vuelo de Entrañas
    .target Michael Garrett::4551
step
    .goto 1458/0,404.63,1434.67
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cFaranell|r y |cff5cf05cZinge|r en El Apothecarium
    >>|cffff9a3cEsta es una pre-misión para "La nueva peste"|r
    .accept 450 >>Acepta la misión Una fórmula mortal
    .target Master Apothecary Faranell
    .isQuestTurnedIn 447
step
    #optional
    .goto 1458/0,344.000,1423.800,50,0
    .goto 1458/0,373.200,1362.100,50,0
    .goto 1458/0,428.400,1417.700
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTheodore Griffs::11835|r
    .accept 95216 >>Acepta la misión La nueva peste
    .target Theodore Griffs::11835
    .isQuestTurnedIn 451
step
    .goto 1458/0,415.400,1389.900,50,0
    .goto 1458/0,373.500,1362.200,50,0
    .goto 1458/0,341.400,1434.800,50,0
    .goto 1458/0,369.400,1467.800,50,0
    .goto 1458/0,427.900,1413.700,50,0
    .goto 1458/0,438.100,1352.900,50,0
    .goto 1458/0,396.100,1308.800,50,0
    .goto 1458/0,316.000,1304.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMorbin Flageluz::266484|r
    .accept 92421 >>Acepta la misión Justicia de la Luz
    .target Morbin Lightbane::266484
step
    #label UCPickups
    .isQuestComplete 5725
    .goto 1458/0,334.02,1262.17
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVarimathras::2425|r
    .turnin 5725 >>Entrega la misión Poder destructivo
    .target Varimathras::2425
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .isQuestAvailable 92401
    .isNotOnQuest 92401
    .zoneskip Undercity,1
    .zoneskip Silverpine Forest
    .goto 1458/0,419.89,1627.54,50,0
    .goto 1458/0,428.52,1597.20,10,0
    .goto 1458/0,439.17,1626.06,10,0
    .goto 1458/0,476.78,1632.150,10,0
    .goto 1458/0,482.34,1660.63,10,0
    .goto 1458/0,539.33,1665.49,15,0
    .goto 1458/0,610.42,1684.44,35,0
    .goto 1458/0,663.19,1600.46,35,0
    .goto 1420/0,724.25,1682.66,50,0
    .zone Tirisfal Glades >>Abandona Entrañas por las Cloacas
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    .isQuestAvailable 92401
    .isNotOnQuest 92401
    .zoneskip Silverpine Forest
    .goto 1420/0,629.36,1553.42,50,0
    .goto 1421/0,1204.68,1290.07
    .zone Silverpine Forest >>Viaja al Bosque de Argénteos
step << Tauren/Hunter/Orc Shaman/Troll Shaman
    #completewith AFrightenedRequest
    .isQuestAvailable 92401
    .isNotOnQuest 92401
    .subzoneskip 228
    .goto 1421/0,1204.68,1290.07,50,0
    .goto 1421/0,1359.66,864.19,50,0
    .goto 1421/0,1359.66,741.27,50,0
    .goto 1421/0,1365.12,607.15,100,0
    .goto 1421/0,1538.58,511.39
    .subzone 228 >>Viaja a El Sepulcro
step << !Tauren !Hunter !Shaman/Skyborne
    #completewith AFrightenedRequest
    .isQuestAvailable 92401
    .isNotOnQuest 92401
    .subzoneskip 228
    .goto 1458/0,266.300,1567.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMichael Garrett::4551|r
    .fly Sepulcher >>Vuela a El Sepulcro
    .target Michael Garrett::4551
step
    .goto 1421/0,1579.600,461.700
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTabitha Tejecorazones::250686|r
    .accept 92401 >>Acepta la misión Una pregunta con miedo
    .target Tabitha Heartweaver::250686
step
    .goto Silverpine Forest,42.98,73.22
    >>Mata al |cffff5a4aBoticario Berard|r. Despoja su |cff4fc3f7Libro|r ubicado en la estantería
    >>|cffff9a3cEsto debería completarse en grupo|r
    .complete 450,1 --Berard's Journal (1)
    .mob Apothecary Berard
    .isQuestTurnedIn 447
step
    .goto 1421/0,1649.400,522.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cBoticario Renferrel::1937|r
    >>|cffff9a3cEsta es una pre-misión para "La nueva peste"|r
    .turnin 450 >>Entrega la misión Una fórmula mortal
    .accept 451 >>Acepta la misión Una fórmula mortal
    .target Apothecary Renferrel::1937
    .isQuestTurnedIn 447
step
    #completewith LakeSkulkerMoss
    >>Mata a los |cffff5a4aVile Fins|r. Despójalos para obtener |T134339:0|t[|cff4fc3f7Tumor endurecido|r]
    .complete 451,3 --|1/1 Hardened Tumor
    .mob Vile Fin Shorecreeper
    .mob Vile Fin Tidecaller
    .mob Vile Fin Tidehunter
    .mob Vile Fin Shredder
    .mob Vile Fin Lakestalker
    .mob Vile Fin Oracle
    .isQuestTurnedIn 447
step
    #loop
    .goto 1421/0,214.000,871.700,0
    .goto 1421/0,214.000,871.700,35,0
    .goto 1421/0,134.800,932.100,35,0
    .goto 1421/0,287.100,1117.300,35,0
    >>Mata al |cffff5a4aLake Trepador|r. Despójalo para obtener |T134186:0|t[|cff4fc3f7Lake Trepador Moss|r]
    .complete 451,2 --|6/6 Lake Creeper Moss
    .mob Lake Creeper
    .mob Elder Lake Creeper
    .isQuestTurnedIn 447
step
    #label LakeSkulkerMoss
    #loop
    .goto 1421/0,499.300,645.000,0
    .goto 1421/0,499.300,645.000,35,0
    .goto 1421/0,300.300,724.800,35,0
    >>Mata al |cffff5a4aVagador del Lago|r. Despójalo para obtener |T134186:0|t[|cff4fc3f7Lake Skuler Moss|r]
    .complete 451,1 --|6/6 Lake Skulker Moss
    .mob Lake Skulker
    .mob Elder Lake Skulker
    .isQuestTurnedIn 447
step
    #label AFrightenedRequest
    #loop
    .goto 1421/0,694.600,1323.800,0
    .goto 1421/0,694.600,1323.800,30,0
    .goto 1421/0,964.900,1167.900,30,0
    .goto 1421/0,1061.100,1032.000,30,0
    .goto 1421/0,1089.000,884.900,30,0
    >>Mata a los |cffff5a4aVile Fins|r. Despójalos para obtener |T134339:0|t[|cff4fc3f7Tumor endurecido|r]
    .complete 451,3 --|1/1 Hardened Tumor
    .mob Vile Fin Shorecreeper
    .mob Vile Fin Tidecaller
    .mob Vile Fin Tidehunter
    .mob Vile Fin Shredder
    .mob Vile Fin Lakestalker
    .mob Vile Fin Oracle
    .isQuestTurnedIn 447
step
    #completewith EnterRoL
    .zone Undercity >>Viaja a Entrañas
step
    .goto 1458/0,344.000,1423.800,50,0
    .goto 1458/0,373.200,1362.100,50,0
    .goto 1458/0,404.500,1434.700
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cMaestro boticario Faranell::2055|r
    >>|cffff9a3cEsta es una pre-misión para "La nueva peste"|r
    .target Master Apothecary Faranell::2055
    .turnin 451 >>Entrega la misión Una fórmula mortal
    .isQuestComplete 451
step
    .goto 1458/0,428.400,1417.70
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTheodore Griffs::11835|r
    .accept 95216 >>Acepta la misión La nueva peste
    .target Theodore Griffs::11835
    .isQuestTurnedIn 451
step
    #optional
    #completewith next
    .zoneskip Silverpine Forest,1
    .goto 1421/0,1533.96,474.43
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKaros Razok::2226|r
    .fly Undercity >>Vuela a Entrañas
    .target Karos Razok::2226
    .zoneskip Undercity
step
.enabledungeon ROL
    #label EnterRoL
    .goto 1458/0,188.400,1804.500
    .subzone 16611 >>Entra en Ruinas de Lordaeron encima de Entrañas
step
    #completewith RuinsRathma
    .isOnQuest 92421
    >>Mata a los |cffff5a4aNo-muertos|r. Despójalos para obtener sus |T458717:0|t[|cff4fc3f7Extremidades intactas|r]
    >>|cffff9a3cAsegúrate de matar a todos los monstruos de la mazmorra; de lo contrario, puede que no completes esta misión|r
    .complete 92421,1 --Intact Limbs (25)
    .mob Skeleton::250618
    --.mob Cadaver::250621
    --.mob Ragged Ghoul::250622
    --.mob Mangled Cadaver::250623
    --.mob Skeletal Mage::250624
    --.mob Skeletal Soldier::250626
    --.mob Ghoul::250627
    --.mob Plague Ghoul::250630
    .mob Fallen Berserker::250656
    --.mob Living Monstrosity::250689
    .mob Flesh Golem::255109
    .mob Fallen Necromancer::255964
step
    #completewith RuinsLimbs
    .isQuestAvailable 95204
    .isNotOnQuest 95204
    >>Despoja y usa el |T4504543:0|t[|cff4fc3f7Blasón de Lordaeron|r] para iniciar la misión
    >>|cffff9a3cTiene 5 posibles ubicaciones de aparición|r
    .collect 275521,1,95204 --Crest of Lordaeron (1)
    .accept 95204 >>Acepta la misión El blasón de Lordaeron
    .use 275521
step
    .isOnQuest 95216
    >>Mata a |cffff5a4aMarchitacolmillos::250483|r. Despójalo para obtener una |T132108:0|t[|cff4fc3f7Cepa muy tóxica|r]
    .complete 95216,1 --Highly Toxic Strain (1)
    .mob Witherfang::250483
step
    .isQuestAvailable 97288
    .isNotOnQuest 97288
    >>Mata a |cffff5a4aEl barón::250660|r. Despoja y usa su |T2492254:0|t[|cff4fc3f7Cabeza abominable|r] para iniciar la misión
    .collect 280438,1,97288 --Abominable Head (1)
    .accept 97288 >>Acepta la misión Tormento interminable
    .use 280438
    .mob The Baron::250660
step
    #label RuinsRathma
    .isOnQuest 92422
    >>Mata a |cffff5a4aRath'mael::250657|r
    .complete 92422,1 --Rath'mael Slain (1)
    .mob Rath'mael::250657
    .target Edward Heartweaver::250842
step
    .isOnQuest 92401
    >>Acércate al cuerpo de |cff5cf05cEdward Tejecorazones::250842|r cerca de |cffff5a4aRath'mael::250657|r
    .complete 92401,1
    .target Edward Heartweaver::250842
step
    #label RuinsLimbs
    .isOnQuest 92421
    >>Mata a los |cffff5a4aNo-muertos|r. Despójalos para obtener sus |T458717:0|t[|cff4fc3f7Extremidades intactas|r]
    >>|cffff9a3cAsegúrate de matar a todos los monstruos de la mazmorra; de lo contrario, puede que no completes esta misión|r
    .complete 92421,1 --Intact Limbs (25)
    .mob Skeleton::250618
    --.mob Cadaver::250621
    --.mob Ragged Ghoul::250622
    --.mob Mangled Cadaver::250623
    --.mob Skeletal Mage::250624
    --.mob Skeletal Soldier::250626
    --.mob Ghoul::250627
    --.mob Plague Ghoul::250630
    .mob Fallen Berserker::250656
    --.mob Living Monstrosity::250689
    .mob Flesh Golem::255109
    .mob Fallen Necromancer::255964
step
    .isQuestAvailable 95204
    .isNotOnQuest 95204
    >>Despoja y usa el |T4504543:0|t[|cff4fc3f7Blasón de Lordaeron|r] para iniciar la misión
    >>|cffff9a3cTiene 5 posibles ubicaciones de aparición|r
    .collect 275521,1,95204 --Crest of Lordaeron (1)
    .accept 95204 >>Acepta la misión El blasón de Lordaeron
    .use 275521
step
    .goto 1458/0,188.400,1804.500
    .zone Undercity >>Sal de Ruinas de Lordaeron
step
    .isQuestComplete 92422
    .goto 1420/0,84.900,2023.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cGuardia de la Muerte Kristof::251001|r
    .turnin 92422 >>Entrega la misión La furia de Rath'mael
    .target Deathguard Kristof::251001
step
    .goto 1420/0,240.75,1877.57
    .zone Undercity >>Regresa a Entrañas
step
    .goto 1458/0,239.14,1749.54,35,0
    .goto 1458/0,255.64,1724.70,35,0
    .goto 1458/0,240.68,1706.97,10,0
    .goto 1458/0,241.06,1660.12,10,0
    .goto 1458/0,257.08,1623.38,10,0
    .goto 1458/0,244.51,1598.73,15,0
    .goto 1458/0,266.300,1567.200,20 >>Toma el ascensor para bajar a Entrañas
step
    .goto 1458/0,241.700,1633.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTawny Grisette::4554|r
    >>|cffff9a3cElla patrulla por el Barrio del Comercio|r
    >>|cffe07cf5Compra un|r |T134522:0|t[|cff4fc3f7Capacete tóxico|r]
    .collect 281246,1,97291,1 --Toxic Skullcap (1)
    .target Tawny Grisette::4554
step
    .isOnQuest 95204
    .goto 1458/0,172.100,1667.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOran Snakewrithe::7825|r
    .turnin 95204 >>Entrega la misión El blasón de Lordaeron
    .target Oran Snakewrithe::7825
step
    .goto 1458/0,151.500,1550.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cEzekiel Tumbas::4585|r
    >>|cffe07cf5Compra una|r |T134799:0|t[|cff4fc3f7Esencia de agonía|r]
    .collect 8923,1,97291,1 --Essence of Agony (1)
    .target Ezekiel Graves::4585
step
    .isQuestComplete 95216
    .goto 1458/0,344.000,1423.800,15,0
    .goto 1458/0,373.200,1362.100,15,0
    .goto 1458/0,428.400,1417.700
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTheodore Griffs::11835|r
    .turnin 95216 >>Entrega la misión La nueva peste
    .target Theodore Griffs::11835
step
    .isOnQuest 97288
    .goto 1458/0,404.800,1434.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cMaestro boticario Faranell::2055|r
    .turnin 97288 >>Entrega la misión Tormento interminable
    .accept 97289 >>Acepta la misión Tormento interminable
    .target Master Apothecary Faranell::2055
step
    #optional
    .isQuestTurnedIn 97288
    .goto 1458/0,404.800,1434.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cMaestro boticario Faranell::2055|r
    .accept 97289 >>Acepta la misión Tormento interminable
    .target Master Apothecary Faranell::2055
step
    .isOnQuest 97289
    .goto 1458/0,433.300,1482.600
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cAbominación incompleta::271613|r
    .turnin 97289 >>Entrega la misión Tormento interminable
    .accept 97290 >>Acepta la misión Tormento interminable
    .target Unfinished Abomination::271613
step
    #optional
    .isQuestTurnedIn 97289
    .goto 1458/0,433.300,1482.600
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cAbominación incompleta::271613|r
    .accept 97290 >>Acepta la misión Tormento interminable
    .target Unfinished Abomination::271613
step
    .isOnQuest 97290
    .goto 1458/0,404.800,1434.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cMaestro boticario Faranell::2055|r
    .turnin 97290 >>Entrega la misión Tormento interminable
    .accept 97291 >>Acepta la misión Tormento interminable
    .target Master Apothecary Faranell::2055
step
    #optional
    .isQuestTurnedIn 97290
    .goto 1458/0,404.800,1434.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cMaestro boticario Faranell::2055|r
    .accept 97291 >>Acepta la misión Tormento interminable
    .target Master Apothecary Faranell::2055
step
    .goto 1458/0,357.62,1529.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBel'dugur|r
    .accept 1013 >>Acepta la misión El Libro de Ur
    .target Keeper Bel'dugur
step
    .goto 1458/0,356.700,1563.500
    >>|cffff9a3cDespoja una|r |T134181:0|t[|cff4fc3f7Hierba ampolla|r] |cffff9a3cde la olla detrás de|r |cff5cf05cMartha Alliestar|r
    .collect 281300,1,97291,1 --Blisterweed (1)
    .target Martha Alliestar
step
    .isOnQuest 97291
    .goto 1458/0,404.800,1434.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cMaestro boticario Faranell::2055|r
    .turnin 97291 >>Entrega la misión Tormento interminable
    .accept 97292 >>Acepta la misión Tormento interminable
    .target Master Apothecary Faranell::2055
step
    #optional
    .isQuestTurnedIn 97291
    .goto 1458/0,404.800,1434.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cMaestro boticario Faranell::2055|r
    .accept 97292 >>Acepta la misión Tormento interminable
    .target Master Apothecary Faranell::2055
step
    .isOnQuest 97292
    .goto 1458/0,444.300,1421.500,10,0
    .goto 1458/0,455.400,1442.500,10,0
    .goto 1458/0,438.800,1468.700
    .use 281327 >>|cffff9a3cUsa|r |T134837:0|t[|cff4fc3f7Suero siseante|r] |cffff9a3ccerca del gusano de arriba|r
    .complete 97292,1
step
    .isQuestComplete 97292
    .goto 1458/0,404.800,1434.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMaestro boticario Faranell::2055|r
    .turnin 97292 >>Entrega la misión Tormento interminable
    .target Master Apothecary Faranell::2055
step
    .isQuestComplete 92421
    .goto 1458/0,377.100,1461.700,15,0
    .goto 1458/0,431.500,1407.800,10,0
    .goto 1458/0,429.200,1340.400,10,0
    .goto 1458/0,368.600,1305.000,10,0
    .goto 1458/0,315.600,1304.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMorbin Flageluz::266484|r
    .turnin 92421 >>Entrega la misión Justicia de la Luz
    .target Morbin Lightbane::266484
step << Rogue
    #completewith RuinsRogueTurnin
    #optional
    .isQuestComplete 92401
    .zoneskip Undercity,1
    .goto 1458/0,266.300,1567.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMichael Garrett::4551|r
    .fly Sepulcher >>Vuela a El Sepulcro si tienes la ruta de vuelo
    .target Michael Garrett::4551
step << Rogue
    #label RuinsRogueTurnin
    #optional
    .isQuestComplete 92401
    .goto 1421/0,1579.600,461.700
    >>|cffff9a3cEntrégala ahora solo para conseguir una mejora de mano izquierda (off-hand)|r
    >>Toma las cloacas y sigue el camino hacia El Sepulcro si no puedes volar
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTabitha Tejecorazones::250686|r
    .turnin 92401 >>Entrega la misión Una pregunta con miedo
    .target Tabitha Heartweaver::250686


    ]=], "Horde"}
R[#R + 1] = {[=[
#forever
<< Horde
#name 18-21 Los Baldíos
#version 11
#group Forever Guía de Mazmorras (H)
#subgroup Mazmorras 1-22
#next 21-22 Cuevas de los Lamentos

step
    #completewith FoodandWater2
    .hs >> Usa tu Piedra de hogar para ir a El Cruce
    .use 6948
    .bindlocation 380,1
    .zoneskip The Barrens
step
    #label FoodandWater2
    .goto 1413/1,-2645.40,-406.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Boorand|r
	.vendor >>|cffe07cf5Vende la basura y luego reabastécete de comida y agua si es necesario|r << !Rogue !Warrior
    .vendor >>|cffe07cf5Vende tu basura, luego reabastécete de comida si es necesario|r << Rogue/Warrior
    .target Innkeeper Boorand Plainswind
    .isQuestAvailable 3281,865,905
step << Orc/Troll
    .goto 1413/1,-2709.24,-404.24
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZargh|r
    .turnin 6386 >> Entrega la misión Regreso a El Cruce
    .target Zargh
    .isOnQuest 6386
step << !Tauren !Hunter !Shaman/Skyborne
    #completewith Ignition
    >>Mata a cada |cffff5a4aRaptor|r que veas. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Lashtail
    .mob Sunscale Screecher
step << !Tauren !Hunter !Shaman/Skyborne
    .goto 1413/1,-3031.48,461.91
    >>Usa el |T134227:0|t[Cuerno de Echeyakee] para invocar a |cffff5a4aEcheyakee|r
    >>Mata a |cffff5a4aEcheyakee|r. Despójalo para obtener |cff4fc3f7Pellejo de Echeyakee|r
    >>|cffff9a3cSi |cffff5a4aEcheyakee|r no aparece después de usar el|r |T134227:0|t[Cuerno de Echeyakee]|cffff9a3c o no le diste el primer golpe al aparecer, salta este paso|r
    .complete 881,1 --Echeyakee's Hide (1)
    .mob Echeyakee
    .use 10327
step << !Tauren !Hunter !Shaman/Skyborne
    #optional
    .goto 1413/1,-2669.72,-481.94
    .abandon 881 >>|cffff9a3cSi |cffff5a4aEcheyakee|r no apareció después de usar el|r |T134227:0|t[Cuerno de Echeyakee]|cffff9a3c o no le diste el primer golpe al aparecer, abandona la misión Echeyakee, luego regresa a la ciudad y acéptala de nuevo|r
    .itemcount 5100,<1 --Echeyakee's Hide (0)
step << !Tauren !Hunter !Shaman/Skyborne
    .goto 1413/1,-2670.74,-482.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSergra|r
    .accept 881 >>Acepta la misión Echeyakee
    .target Sergra Darkthorn
    .itemcount 5100,<1 --Echeyakee's Hide (0)
step << !Tauren !Hunter !Shaman/Skyborne
    .goto 1413/1,-3031.48,461.91
    >>Usa el |T134227:0|t[Cuerno de Echeyakee] para invocar a |cffff5a4aEcheyakee|r
    >>Mata a |cffff5a4aEcheyakee|r. Despójalo para obtener |cff4fc3f7Pellejo de Echeyakee|r
    .complete 881,1 --Echeyakee's Hide (1)
    .mob Echeyakee
    .use 10327
step << !Tauren !Hunter !Shaman/Skyborne
	#label Samophlange
    .goto 1413/1,-2686.95,825.40
    >>Haz clic en la |cffe07cf5Consola de control|r
    .turnin 894 >>Entrega la misión El churumbele
    .accept 900 >>Acepta la misión El churumbele
step << !Tauren !Hunter !Shaman/Skyborne
    .goto 1413/1,-2686.95,842.290
    >>Haz clic en la |cffe07cf5Válvula|r
    >>|cffff9a3c¡Ten cuidado! Dos enemigos aparecerán después de que cierres la Válvula|r
    .complete 900,1 --Shut off Main Control Valve (1)
step << !Tauren !Hunter !Shaman/Skyborne
    .goto 1413/1,-2675.80,842.290
    >>Haz clic en la |cffe07cf5Válvula|r
    >>|cffff9a3cUn enemigo aparecerá después de que cierres la Válvula|r
    .complete 900,3 --Shut off Regulator Valve (1)
step << !Tauren !Hunter !Shaman/Skyborne
    .goto 1413/1,-2679.86,830.80
    >>Haz clic en la |cffe07cf5Válvula|r
    .complete 900,2 --Shut off Fuel Control Valve (1)
step << !Tauren !Hunter !Shaman/Skyborne
    .goto 1413/1,-2686.95,825.40
    >>Haz clic en la |cffe07cf5Consola de control|r
    .turnin 900 >>Entrega la misión El churumbele
    .accept 901 >>Acepta la misión El churumbele
step << !Tauren !Hunter !Shaman/Skyborne
    .goto 1413/1,-2731.54,909.850
    >>Mata a |cffff5a4aManitas el Risitas|r en el edificio. Despójalo para obtener su |cff4fc3f7Llave de la consola|r
    .complete 901,1 --Console Key (1)
    .mob Tinkerer Sniggles
step << !Tauren !Hunter !Shaman/Skyborne
    #label SamophlangeComplete
    .goto 1413/1,-2686.95,825.40
    >>Haz clic en la |cffe07cf5Consola de control|r
    .turnin 901 >>Entrega la misión El churumbele
    .accept 902 >>Acepta la misión El churumbele
step << !Tauren !Hunter !Shaman/Skyborne
    #label Ignition
    .goto 1413/1,-3104.44,1109.16
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el|r |cff5cf05cMachacador de Rabiaire|r en el Fangal
    >>|cff5cf05cMachacador de Rabiaire|r |cffff9a3ctiene un tiempo de reaparición largo. Considera omitir esta misión si hay mucha competencia|r
    .accept 858 >>Acepta la misión La llave de contacto
    .target Wizzlecrank's Shredder
step << !Tauren !Hunter !Shaman/Skyborne
    #completewith next
    +|cffff9a3cTen cuidado si el|r |cffff5a4aSupervisor Asas|r |cffff9a3co la|r |cffff5a4aBestia de lodo|r |cffff9a3cestán vivos. Son élites raros de nivel 19 muy fuertes|r
    .unitscan Foreman Grills
    .unitscan Sludge Beast
step << !Tauren !Hunter !Shaman/Skyborne
    .goto 1413/1,-3104.44,1040.25,20,0
    .goto 1413/1,-3086.20,1055.78,12,0
    .goto 1413/1,-3063.91,1049.70,12,0
    .goto 1413/1,-3056.82,1038.89,12,0
    .goto 1413/1,-3064.92,1034.16,12,0
    .goto 1413/1,-3086.20,1055.78
    >>Mata al |cffff5a4aSupervisor Palarrastre|r. Despójalo para obtener su |cff4fc3f7Llave|r
    >>|cffff9a3cPatrulla subiendo y bajando la plataforma|r
    .complete 858,1 --Ignition Key (1)
    .mob Supervisor Lugwizzle
    .isOnQuest 858
step << !Tauren !Hunter !Shaman/Skyborne
    .goto 1413/1,-3104.44,1109.16
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el|r |cff5cf05cMachacador de Rabiaire|r
    >>|cff5cf05cMachacador de Rabiaire|r |cffff9a3ctiene un tiempo de reaparición largo. Considera omitir esta misión si hay mucha competencia|r
    >>|cffff9a3cEsto iniciará una escolta. Asegúrate de estar a plena salud|r
    .turnin 858 >>Entrega la misión La llave de contacto
    .accept 863,1 >>Acepta la misión La fuga
    .target Wizzlecrank's Shredder
    .isQuestComplete 858
step << !Tauren !Hunter !Shaman/Skyborne
    #optional
    .goto 1413/1,-3104.44,1109.16
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el|r |cff5cf05cMachacador de Rabiaire|r
    >>|cff5cf05cMachacador de Rabiaire|r |cffff9a3ctiene un tiempo de reaparición largo. Considera omitir esta misión si hay mucha competencia|r
    >>|cffff9a3cEsto iniciará una escolta. Asegúrate de estar a plena salud|r
    .accept 863,1 >>Acepta la misión La fuga
    .target Wizzlecrank's Shredder
    .isQuestTurnedIn 858
step << !Tauren !Hunter !Shaman/Skyborne
    #label Slugs
    .goto 1413/1,-3031.48,1088.21,30,0
    .goto 1413/1,-3002.10,1130.78
    >>|cffff9a3cDos|r |cffff5a4aMercenarios de Ventura y Cía.|r |cffff9a3caparecerán cuando la trituradora suba al terreno elevado. Mátalos y luego espera por su evento de RP al final|r
    .complete 863,1 --Escort Wizzlecrank out of the Venture Co. drill site (1)
    .mob Venture Co. Mercenary
    .mob Venture Co. Drudger
    .mob Overseer Glibby
    .isOnQuest 863
step << !Tauren !Hunter !Shaman/Skyborne
    #loop
    .goto 1413/1,-2879.48,781.48,0
    .goto 1413/1,-2879.48,781.48,90,0
    .goto 1413/1,-2909.88,484.21,90,0
    .goto 1413/1,-2666.500,719.600,90,0
    .goto 1413/1,-2965.400,1009.100,90,0
    >>Mata a los |cffff5a4aRaptores|r. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Lashtail
    .mob Sunscale Screecher
    .mob Sunscale Scytheclaw
step << !Tauren !Hunter !Shaman/Skyborne
    #optional
    #completewith FoodandWater2
    .hs >> Usa tu Piedra de hogar para ir a El Cruce
    .use 6948
    .bindlocation 380,1
    .zoneskip The Barrens
    .cooldown item,6948,>0
step << !Tauren !Hunter !Shaman/Skyborne
    #completewith
    .subzone 380 >>Viaja a El Cruce
    .cooldown item,6948,<0
step
    .goto 1413/1,-2639.32,-436.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGazrog|r
    .turnin 869 >>Entrega la misión Raptores ladrones
    .accept 3281 >>Acepta la misión Plata robada
    .target Gazrog
step
    .goto 1413/1,-2670.74,-482.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSergra|r
    .turnin 881 >>Entrega la misión Echeyakee
    .accept 905 >>Acepta la misión Los segadores furiosos
    .target Sergra Darkthorn
step
    #optional
    #completewith RapHornsPickup
    .destroy 10327 >>|cffff9a3cDestruye el|r |T134227:0|t[Cuerno de Echeyakee] |cffff9a3cya que ya no lo necesitas|r
step << Hunter
    .goto 1413/1,-2612.98,-411.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cBarg|r
    >>|cffe07cf5Compra|r |T132382:0|t[Flechas afiladas] |cffe07cf5a este vendedor|r
    .collect 2515,1800,888,1 << Hunter --Sharp Arrow (1800)
    .target Barg
step
    #completewith RapHornsPickup
    .goto 1413/1,-2595.75,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDevrak|r
    .fly Ratchet >>Vuela a Trinquete
    .target Devrak
    .subzoneskip 392
step << Rogue
    .goto 1413/1,-3767.800,-842.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDesdio|r
    .turnin 2382 >>Entrega la misión Desdio de Trinquete
    .accept 2381 >>Acepta la misión Saquear a los saqueadores
    .target Wrenix the Wretched
step << Rogue
    .goto 1413/1,-3773.24,-841.37
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cAparato Gizmotrónico de Wrenix|r
    >>Obtén un|cffff9a3c |T134059:0|t[G.E.A.Q.] |ry una|cffff9a3c |T134065:0|t[Herramientas de ladrón]|r
    .collect 7970,1,888,1 --E.C.A.C. (1)
    .collect 5060,1,888,1 --Thieves' Tools (1)
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cPetardol|r
    .turnin 902 >>Entrega la misión El churumbele
    .turnin 863 >> Entrega la misión La fuga
    .target +Sputtervalve
    .goto 1413/1,-3759.06,-902.18
    .isQuestComplete 863
step
    #optional
    .goto 1413/1,-3759.06,-902.18
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cPetardol|r
    .turnin 902 >>Entrega la misión El churumbele
    .target Sputtervalve
step << skip
    .goto 1413/1,-3796.55,-985.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con  |cff5cf05cVertipeluca|r
    .turnin 896 >> Entrega la misión La fortuna de un minero
    .target Wharfmaster Dizzywig
    .isQuestComplete 896
step
    #label RapHornsPickup
    .goto 1413/1,-3697.24,-929.20
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMebok|r
    .accept 865 >>Acepta la misión Cuernos de raptor
    .target Mebok Mizzyrix
step << skip
    .goto 1413/1,-3664.82,-1050.14
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Wiley|r
    -->>|cffe07cf5Buy|r |T133918:0|t[Longjaw Mud Snappers] |cffe07cf5from him|r
    >>|cffe07cf5Compra|r |T132796:0|t[Zumo de melón] |cffe07cf5a este vendedor|r << Mage/Warlock/Priest/Shaman/Druid
    -->>|T133918:0|t[Longjaw Mud Snappers] |cffff9a3care extremely cheap, buy as many as you want|r
    .vendor >> Vende la Basura
    --.collect 4592,20,888,1 --Longjaw Mud Snapper (20)
    .collect 1205,10,888,1 << Mage/Warlock/Priest/Shaman/Druid --Melon Juice (10)
    .target Innkeeper Wiley
step << Rogue
	#completewith next
    .goto 1413/1,-3967.8,-1457.54
    +|cffff9a3cSalta al barco, baja al 2.º piso y sube tu habilidad de Forzar cerraduras al menos hasta 70|r
step << Rogue
    .goto 1413/1,-3958.68,-1457.54
    >>Cuando tengas Forzar cerraduras al 70, ve al piso inferior del barco y abre |cffe07cf5La joya de los Mares del Sur|r
    >>|cffff9a3cUsa el|r |T134059:0|t[G.E.A.Q.] |cffff9a3ccon|r |cffff5a4aPolly|r
    .complete 2381,1 --Southsea Treasure (1)
    .use 7970
    .mob Polly
step
    #label LeaveRatchet
    .goto 1413/1,-3819.86,-1714.95
    >>Despoja el |cffe07cf5Cajón|r del suelo
    .complete 888,2 --Telescopic Lens (1)
step
    .goto 1413/1,-3723.59,-1741.30
    >>Despoja el |cffe07cf5Cajón|r del suelo
    .complete 888,1 --Shipment of Boots (1)
step
    #optional
    #completewith TestSeeds
    >>Mata a los |cffff5a4aZancudos de llanura|r. Despójalos para obtener sus |cff4fc3f7Riñones|r
    .complete 821,2 --Plainstrider Kidney (5)
    .mob Greater Plainstrider
    .mob Fleeting Plainstrider
    .mob Ornery Plainstrider
    .isQuestTurnedIn 819
step
    #optional
    #completewith TestSeeds
    >>Mata a los |cffff5a4aSegadores Solescama|r. Despójalos para obtener sus |cff4fc3f7Cuernos|r y sus |cff4fc3f7Plumas|r
    >>|cffff9a3cTen cuidado, ya que lanzan|r |T132152:0|t[Vapulear] |cffff9a3c(Carga 2 ataques extra cada 10 segundos)|r
    .complete 865,1 --Intact Raptor Horn (5)
    .collect 5165,3,905,3 --Sunscale Feather (3)
    .mob Sunscale Scytheclaw
step
    .goto 1413/1,-3192.60,-1919.67,60,0
    .goto 1413/1,-3258.47,-2027.09
    >>Despoja la |cffe07cf5Plata robada|r del suelo
    .complete 3281,1 --Stolen Silver (1)
step
    #optional
    #completewith TestSeeds
    >>Mata a los |cffff5a4aKolkar|r alrededor del oasis. Despójalos para obtener sus |cff4fc3f7Brazales|r
    .complete 855,1 --Centaur Bracers (15)
    .mob Kolkar Bloodcharger
    .mob Kolkar Pack runner
    .mob Kolkar Marauder
    .isOnQuest 851
step
    #optional
    #completewith Verog
    >>Recoge los |cff4fc3f7Champiñones cargados|r alrededor de El Oasis Estancado
    .complete 848,1 --Collect Fungal Spores (x4)
step
    #label TestSeeds
    .goto 1413/1,-3012.23,-1275.80
    >>Haz clic en la |cffe07cf5Fisura burbujeante|r bajo el agua
    .complete 877,1 --Test the Dried Seeds (1)
step
    #optional
    #completewith next
    #loop
    .goto 1413/1,-3031.48,-1480.51,50,0
    .goto 1413/1,-3127.75,-1320.39,50,0
    .goto 1413/1,-3154.1,-1172.43,50,0
    .goto 1413/1,-2996.02,-1182.56,50,0
    .goto 1413/1,-2949.4,-1146.75,50,0
    .goto 1413/1,-2789.3,-1107.57,50,0
    .goto 1413/1,-2746.74,-1409.57,50,0
    .goto 1413/1,-2880.5,-1550.1,50,0
    >>Mata a los |cffff5a4aKolkar|r alrededor del oasis. Despójalos para obtener sus |cff4fc3f7Brazales|r
    .complete 855,1 --Centaur Bracers (15)
    .mob Kolkar Bloodcharger
    .mob Kolkar Pack runner
    .mob Kolkar Marauder
    .isOnQuest 851
step
    #label Verog
    .goto 1413/1,-2742.68,-1208.23
    >>Mata a |cffff5a4aVerog|r. Despójalo para obtener su |cff4fc3f7Cabeza|r
    >>|cffff9a3cTiene probabilidad de aparecer cada vez que un |cffff5a4aKolkar|r muere|r
    >>|cffff9a3cEn un servidor muy poblado o en un lanzamiento nuevo, tu mejor opción es acampar en su punto de aparición|r
    .complete 851,1 --Verog's Head (1)
    .unitscan Verog the Dervish
    .isOnQuest 851
step
    #loop
    .goto 1413/1,-3023.38,-1234.58,0
    .goto 1413/1,-3023.38,-1234.58,30,0
    .goto 1413/1,-3000.07,-1208.23,30,0
    .goto 1413/1,-2959.54,-1196.75,30,0
    .goto 1413/1,-2953.46,-1241.34,30,0
    .goto 1413/1,-2977.78,-1304.17,30,0
    .goto 1413/1,-3029.46,-1324.44,30,0
    .goto 1413/1,-3066.95,-1311.61,30,0
    .goto 1413/1,-3059.86,-1264.31,30,0
    >>Recoge los |cff4fc3f7Champiñones cargados|r alrededor de El Oasis Estancado
    .complete 848,1 --Collect Fungal Spores (x4)
step
    #optional
    #completewith LakotaMani1
    >>Mata a los |cffff5a4aZancudos de llanura|r. Despójalos para obtener sus |cff4fc3f7Riñones|r
    .complete 821,2 --Plainstrider Kidney (5)
    .mob Greater Plainstrider
    .mob Fleeting Plainstrider
    .mob Ornery Plainstrider
    .isQuestTurnedIn 819
step
    .goto 1413/1,-2707.22,-1502.130
    >>Haz clic en el |cffe07cf5Nido de raptor azul|r. Mata a más |cffff5a4aSegadores Solescama|r si no tienes una |T132914:0|t[Pluma de Solescama]
    >>|cffff9a3cTen cuidado, ya que lanzan|r |T132152:0|t[Vapulear] |cffff9a3c(Carga 2 ataques extra cada 10 segundos)|r
    .complete 905,1 --Visit Blue Raptor Nest (1)
    .collect 5165,3,905,7,3
    .mob Sunscale Scytheclaw
step
    .goto 1413/1,-2692.02,-1533.89
    >>Haz clic en el |cffe07cf5Nido de raptor rojo|r. Mata a más |cffff5a4aSegadores Solescama|r si no tienes una |T132914:0|t[Pluma de Solescama]
    >>|cffff9a3cTen cuidado, ya que lanzan|r |T132152:0|t[Vapulear] |cffff9a3c(Carga 2 ataques extra cada 10 segundos)|r
    .complete 905,3 --Visit Red Raptor Nest (1)
    .collect 5165,3,905,7,3
    .mob Sunscale Scytheclaw
step
    #label Nest
    .goto 1413/1,-2648.44,-1527.13
    >>Haz clic en el |cffe07cf5Nido de raptor amarillo|r. Mata a más |cffff5a4aSegadores Solescama|r si no tienes una |T132914:0|t[Pluma de Solescama]
    >>|cffff9a3cTen cuidado, ya que lanzan|r |T132152:0|t[Vapulear] |cffff9a3c(Carga 2 ataques extra cada 10 segundos)|r
    .complete 905,2 --Visit Yellow Raptor Nest (1)
    .collect 5165,3,905,7,3
    .mob Sunscale Scytheclaw
step
    #optional
    #completewith next
    >>Mata |cffff5a4aSegadores Solescama|r. Despójalos para obtener sus |cff4fc3f7Cuernos|r
    >>|cffff9a3cTen cuidado, ya que lanzan|r |T132152:0|t[Vapulear] |cffff9a3c(Carga 2 ataques extra cada 10 segundos)|r
    .complete 865,1 --Intact Raptor Horn (5)
    .mob Sunscale Scytheclaw
step
    #label LostmyWife
    .goto 1413/1,-2375.86,-1787.24
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cCadáver apaleado|r
    .complete 4921,1 --Find Mankrik's Wife (1)
    .target Beaten Corpse
    .skipgossip
step
    #optional
    #completewith CampTArrive
    >>Mata |cffff5a4aMorrotormentas|r. Despójalos para obtener un |cff4fc3f7Cuerno de truenagarto|r
    .complete 821,3 --Thunder Lizard Horn (1)
    .mob Stormsnout
    .isQuestTurnedIn 819
step
    #label LakotaMani1
    #completewith CampTArrive
    .goto 1413/1,-1951.27,-1956.15,0
    .goto 1413/1,-2031.32,-1703.47,0
    .goto 1413/1,-2183.32,-1858.19,0
    .goto 1413/1,-2453.88,-1991.28,0
	>>Mata a |cffff5a4aLakota'mani|r. Despójalo para obtener la |T132318:0|t[|cff4fc3f7Pezuña de Lakota'mani|r]
    >>Usa la |T132318:0|t[|cffff9a3cPezuña de Lakota'mani|cff4fc3f7] |rpara iniciar la misión|r
    >>|cffff9a3cTiene 4 puntos de aparición (marcados en el mapa)|r
    >>|cffff9a3cOmite este paso si no puedes encontrarlo o matarlo. Puedes volver a por él más tarde|r
	.collect 5099,1,883 --Collect Hoof of Lakota'Mani
	.accept 883 >>Acepta la misión Lakota'mani
    .use 5099
    .unitscan Lakota'mani
    .xp <18,1
step
    #label CampTArrive
    #completewith next
    .goto 1413/1,-1960.39,-2333.83,120 >> Viaja al Campamento Taurajo
    .subzoneskip 378
step
    #requires CampTArrive
    #label SetCampTaurajoHS
    .goto 1413/1,-1995.86,-2376.39
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Byula|r
    .home >>Establece tu Piedra de hogar en el Campamento Taurajo
    .target Innkeeper Byula
    .bindlocation 378
    .isQuestAvailable 1093
step
    .goto 1413/1,-1921.88,-2383.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJorn Vidente del Cielo|r
    .turnin 883 >>Entrega la misión Lakota'mani
    .target Jorn Skyseer
    .isOnQuest 883
step
    .goto 1413/1,-1891.48,-2391.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cQuebrantadientes|r
    .accept 878 >>Acepta la misión Tribus en guerra
    .target Mangletooth
step
    #completewith Xroadsturnins2
    .goto 1413/1,-1881.35,-2384.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOmusa|r
    .fp Camp Taurajo >> Consigue la ruta de vuelo del Campamento Taurajo << !Tauren
    .fly Crossroads >>Vuela a El Cruce
    .target Omusa Thunderhorn
    .zoneskip The Barrens,1
    .subzoneskip 380
step
    .goto 1413/1,-2589.67,-424.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHelbrim|r
    .turnin 848 >> Entrega la misión Esporas de hongos
    .target Apothecary Helbrim
    .isQuestComplete 848
step
    #label Xroadsturnins2
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMankrik|r, |cff5cf05cTonga|r, |cff5cf05cSergra|r y |cff5cf05cGazrog|r
    .turnin 4921 >>Entrega la misión Perdida en la batalla
    .accept 95774 >>Acepta la misión Su nombre es Olgra
    .target +Mankrik
    .goto 1413/1,-2641.35,-521.12
    .turnin 877 >>Entrega la misión El Oasis Estancado
    .accept 880 >>Acepta la misión Seres alterados
    .target +Tonga Runetotem
    .goto 1413/1,-2672.76,-544.77
    .turnin 905 >>Entrega la misión Los segadores furiosos
    .accept 3261 >>Acepta la misión Jorn Vidente del Cielo
    .target +Sergra Darkthorn
    .goto 1413/1,-2670.74,-482.61
    .turnin 3281 >>Entrega la misión Plata robada
    .target +Gazrog
    .goto 1413/1,-2639.32,-436.00
step
    #optional
    #completewith Hezrul
    .destroy 5165 >>|cffff9a3cElimina cualquier|r |T132914:0|t[Pluma de Solescama] |cffff9a3csobrante que aún tengas|r
    .itemcount 5165,1
step << Hunter
    .goto 1413/1,-2556.23,-351.54
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cUthrok|r|cffe07cf5. Compra un|r |T134410:0|t[Carcaj medio] |cffe07cf5a este vendedor|r
    .collect 11362,1,896,1 --Medium Quiver (1)
    .collect 2515,2200,896,1 --Sharp Arrow (2200)
    .target Uthrok
step << Druid
    #completewith DruidTraining2
    .cast 18960 >>|cffff9a3cLanza|r |T135758:0|t[Teletransporte a: Claro de la Luna]
    .zoneskip Moonglade
step << Druid
    .goto 1450/1,-2593.82,7866.90
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLoganaar|r
    .train 1430 >> Aprende tus hechizos de clase
    .target Loganaar
    .xp <18,1
    .xp >20,1
    .cooldown item,6948,>0
step << Druid
    #label DruidTraining2
    .goto 1450/1,-2593.82,7866.90
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLoganaar|r
    .train 768 >> Aprende tus hechizos de clase
    .target Loganaar
    .xp <20,1
    .cooldown item,6948,>0
step
    #completewith JornSkyseerTurnin
    .hs >> Usa tu Piedra de hogar para ir al Campamento Taurajo
    .use 6948
    .bindlocation 378,1
    .subzoneskip 378
    .cooldown item,6948,>0
step
    #completewith JornSkyseerTurnin
    .goto 1413/1,-2595.75,-437.35--c:The Barrens,51.50,30.34
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDevrak|r
    .fly Camp Taurajo >> Vuela al Campamento Taurajo
    .subzoneskip 378
    .target Devrak
    .cooldown item,6948,<0
step
    .goto 1413/1,-1995.86,-2375.71
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Byula|r
	.vendor >>|cffe07cf5Vende la basura y luego reabastécete de comida y agua si es necesario|r << !Rogue !Warrior
    .vendor >>|cffe07cf5Vende tu basura, luego reabastécete de comida si es necesario|r << Rogue/Warrior
    .target Innkeeper Byula
    .isOnQuest 3261
step
    #label JornSkyseerTurnin
    .goto 1413/1,-1921.88,-2383.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJorn Vidente del Cielo|r
    .turnin 3261 >>Entrega la misión Jorn Vidente del Cielo
    .accept 882 >>Acepta la misión Ishamuhale
    .target Jorn Skyseer
step
    #completewith LakotaMani2
    >>Mata a los |cffff5a4aAsaltantes Crines de Acero|r. Despójalos para obtener los |cff4fc3f7Adornos de Olgra|r
    .complete 95774,1 --|4/4 Olgra's Adornments
    .mob Razormane Raider
step
	#completewith Adornments
    >>Mata |cffff5a4aMorrotormentas|r. Despójalos para obtener un |cff4fc3f7Cuerno|r
    .complete 821,3 --Thunder Lizard Horn (1)
    .mob Stormsnout
    .isQuestTurnedIn 819
step
    #completewith Adornments
    >>Mata |cffff5a4aJabaespines Erizapúas|r. Despójalos para obtener sus |cff4fc3f7Colmillos|r. Guarda las |T134128:0|t[|cff4fc3f7Esquirla de sangre|r] que obtengas
	.complete 878,1 --Kill Bristleback Water Seeker (x6)
    .mob +Bristleback Water Seeker
    .complete 878,2 --Kill Bristleback Thornweaver (x12)
    .mob +Bristleback Thornweaver
    .complete 878,3 --Kill Bristleback Geomancer (x12)
    .mob +Bristleback Geomancer
    .complete 899,1 --Collect Bristleback Quilboar Tusk (x60)
    .mob +Bristleback Water Seeker
    .mob +Bristleback Thornweaver
    .mob +Bristleback Geomancer
step
    #label LakotaMani2
    #loop
    .goto 1413/1,-1951.27,-1956.15,0
    .goto 1413/1,-2031.32,-1703.47,0
    .goto 1413/1,-2183.32,-1858.19,0
    .goto 1413/1,-2453.88,-1991.28,0
    .goto 1413/1,-1951.27,-1956.15,80,0
    .goto 1413/1,-2031.32,-1703.47,80,0
    .goto 1413/1,-2183.32,-1858.19,80,0
    .goto 1413/1,-2453.88,-1991.28,80,0
	>>Mata a |cffff5a4aLakota'mani|r. Despójalo para obtener la |T132318:0|t[|cff4fc3f7Pezuña de Lakota'mani|r]
    >>Usa la |T132318:0|t[|cffff9a3cPezuña de Lakota'mani|cff4fc3f7] |rpara iniciar la misión|r
    >>|cffff9a3cTiene 4 puntos de aparición (marcados en el mapa)|r
    >>|cffff9a3cOmite este paso si no puedes encontrarlo|r
	.collect 5099,1,883 --Collect Hoof of Lakota'Mani
	.accept 883 >>Acepta la misión Lakota'mani
    .use 5099
    .unitscan Lakota'mani
step
    #label Adornments
    #loop
    .goto 1413/1,-2241.200,-1988.500,0
    .goto 1413/1,-2241.200,-1988.500,50,0
    .goto 1413/1,-2346.200,-1788.600,50,0
    .goto 1413/1,-2458.300,-1824.400,50,0
    .goto 1413/1,-2381.000,-2061.000,50,0
    >>Mata a los |cffff5a4aAsaltantes Crines de Acero|r. Despójalos para obtener los |cff4fc3f7Adornos de Olgra|r
    .complete 95774,1 --|4/4 Olgra's Adornments
    .mob Razormane Raider
step
    #optional
    #completewith next
    >>Mata |cffff5a4aMorrotormentas|r. Despójalos para obtener un |cff4fc3f7Cuerno|r
    .complete 821,3 --Thunder Lizard Horn (1)
    .mob Stormsnout
    .isQuestTurnedIn 819
step
    #loop
    .goto 1413/1,-2515.7,-2076.41,0
    .goto 1413/1,-2515.7,-2076.41,60,0
    .goto 1413/1,-2518.74,-2125.73,60,0
    .goto 1413/1,-2517.72,-2223.7,60,0
    .goto 1413/1,-2486.31,-2254.1,60,0
    .goto 1413/1,-2494.42,-2282.48,60,0
    .goto 1413/1,-2531.91,-2272.34,60,0
    .goto 1413/1,-2571.43,-2295.31,60,0
    .goto 1413/1,-2620.07,-2285.18,60,0
    .goto 1413/1,-2625.14,-2245.32,60,0
    .goto 1413/1,-2755.86,-2082.49,60,0
    .goto 1413/1,-2813.62,-2054.12,60,0
    .goto 1413/1,-2811.59,-2004.12,60,0
    .goto 1413/1,-2783.22,-1949.39,60,0
    .goto 1413/1,-2747.75,-1889.26,60,0
    .goto 1413/1,-2709.24,-1913.59,60,0
    .goto 1413/1,-2706.2,-1948.72,60,0
    .goto 1413/1,-2687.96,-1973.04,60,0
    .goto 1413/1,-2678.84,-2016.28,60,0
    .goto 1413/1,-2584.6,-2050.74,60,0
    >>Mata |cffff5a4aJabaespines Erizapúas|r. Despójalos para obtener sus |cff4fc3f7Colmillos|r. Guarda las |T134128:0|t[|cff4fc3f7Esquirla de sangre|r] que obtengas
	.complete 878,1 --Kill Bristleback Water Seeker (x6)
    .mob +Bristleback Water Seeker
    .complete 878,2 --Kill Bristleback Thornweaver (x12)
    .mob +Bristleback Thornweaver
    .complete 878,3 --Kill Bristleback Geomancer (x12)
    .mob +Bristleback Geomancer
    .complete 899,1 --Collect Bristleback Quilboar Tusk (x60)
    .mob +Bristleback Water Seeker
    .mob +Bristleback Thornweaver
    .mob +Bristleback Geomancer
step << Warlock
    #loop
	.goto 1413/1,-2515.7,-2076.41,60,0
	.goto 1413/1,-2518.74,-2125.73,60,0
	.goto 1413/1,-2517.72,-2223.7,60,0
	.goto 1413/1,-2486.31,-2254.1,60,0
	.goto 1413/1,-2494.42,-2282.48,60,0
	.goto 1413/1,-2531.91,-2272.34,60,0
	.goto 1413/1,-2571.43,-2295.31,60,0
	.goto 1413/1,-2620.07,-2285.18,60,0
	.goto 1413/1,-2625.14,-2245.32,60,0
	.goto 1413/1,-2755.86,-2082.49,60,0
	.goto 1413/1,-2813.62,-2054.12,60,0
	.goto 1413/1,-2811.59,-2004.12,60,0
	.goto 1413/1,-2783.22,-1949.39,60,0
	.goto 1413/1,-2747.75,-1889.26,60,0
	.goto 1413/1,-2709.24,-1913.59,60,0
	.goto 1413/1,-2706.2,-1948.72,60,0
	.goto 1413/1,-2687.96,-1973.04,60,0
	.goto 1413/1,-2678.84,-2016.28,60,0
	.goto 1413/1,-2584.6,-2050.74,60,0
    .xp 19+9500 >> Mata enemigos hasta alcanzar 9500+/21300xp
step
    #loop
    .goto 1413/1,-2532.92,-1965.61,0
    .goto 1413/1,-2532.92,-1965.61,50,0
    .goto 1413/1,-2449.83,-1953.45,50,0
    .goto 1413/1,-2377.88,-2018.31,50,0
    .goto 1413/1,-2397.14,-2108.84,50,0
    .goto 1413/1,-2345.46,-2187.21,50,0
    .goto 1413/1,-2415.38,-2179.78,50,0
    >>Mata |cffff5a4aMorrotormentas|r. Despójalos para obtener un |cff4fc3f7Cuerno|r
    .complete 821,3 --Thunder Lizard Horn (1)
    .mob Stormsnout
    .isQuestTurnedIn 819
step
    #completewith next
    >>Mata |cffff5a4aSegadores Solescama|r. Despójalos para obtener sus |cff4fc3f7Cuernos|r
    >>|cffff9a3cTen cuidado, ya que lanzan|r |T132152:0|t[Vapulear] |cffff9a3c(Carga 2 ataques extra cada 10 segundos)|r
    .complete 865,1 --Intact Raptor Horn (5)
    .mob Sunscale Scytheclaw
step
    #loop
    .goto 1413/1,-2847.06,-1879.13,0
    .goto 1413/1,-2847.06,-1879.13,50,0
    .goto 1413/1,-2859.22,-1804.81,50,0
    .goto 1413/1,-2833.88,-1749.41,50,0
    .goto 1413/1,-2881.51,-1723.74,50,0
    .goto 1413/1,-2932.18,-1698.06,50,0
    .goto 1413/1,-2973.72,-1627.8,50,0
    >>Termina de matar |cffff5a4aZancudos de llanura|r. Despójalos para obtener sus |cff4fc3f7Riñones|r
    .complete 821,2 --Plainstrider Kidney (5)
    .mob Greater Plainstrider
    .isQuestTurnedIn 819
step
    #loop
    .goto 1413/1,-3183.48,-2015.61,0
    .goto 1413/1,-2646.42,-1529.16,0
    .goto 1413/1,-3183.48,-2015.61,90,0
    .goto 1413/1,-2646.42,-1529.16,90,0
    >>Termina de matar |cffff5a4aSegadores Solescama|r. Despójalos para obtener sus |cff4fc3f7Cuernos|r
    >>|cffff9a3cTen cuidado, ya que lanzan|r |T132152:0|t[Vapulear] |cffff9a3c(Carga 2 ataques extra cada 10 segundos)|r
    .complete 865,1 --Intact Raptor Horn (5)
    .mob Sunscale Scytheclaw
step
    #completewith next
    >>Mata cualquier |cffff5a4aZhebra|r. Despójala para obtener un |cff4fc3f7Cadáver reciente de zhebra|r
	.collect 10338,1 --Collect Fresh Zhevra Carcass
    .mob Zhevra Charger
step
    #loop
    .goto 1413/1,-3010.20,-1319.04,0
    .goto 1413/1,-3010.20,-1319.04,40,0
    .goto 1413/1,-2959.54,-1292.69,40,0
    .goto 1413/1,-2953.46,-1239.31,40,0
    .goto 1413/1,-2998.04,-1192.02,40,0
    .goto 1413/1,-3050.74,-1225.13,40,0
    .goto 1413/1,-3066.95,-1260.93,40,0
    .goto 1413/1,-3052.76,-1319.710,40,0
    >>Mata |cffff5a4aQuijafortes de oasis|r en y alrededor del lago. Despójalos para obtener sus |cff4fc3f7Caparazones|r
    .complete 880,1 --Altered Snapjaw Shell (8)
    .mob Oasis Snapjaw
step
    #completewith next
    >>Mata cualquier |cffff5a4aZhebra|r. Despójala para obtener un |cff4fc3f7Cadáver reciente de zhebra|r
	.collect 10338,1 --Collect Fresh Zhevra Carcass
    .mob Zhevra Charger
step
    #label IshamuhalesFang
    .goto 1413/1,-3427.70,-436.67
    .use 10338 >>Usa el |T134368:0|t[|cff4fc3f7Cadáver reciente de zhebra|r] en el árbol muerto para invocar a |cffff5a4aIshamuhale|r. Mata y despójalo para obtener su |cff4fc3f7Colmillo|r
    >>|cffff9a3c¡El cadáver solo tiene una duración de 30 minutos!|r
    .complete 882,1 --Ishamuhale's Fang (1)
    .mob Ishamuhale
step
    #completewith BootyTurnin
    .subzone 392 >> Viaja a Trinquete
step
    .goto 1413/1,-3767.800,-842.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDesdio|r
    .turnin 2381 >>Entrega la misión Saquear a los saqueadores << Rogue
    .target Wrenix the Wretched
step << Rogue
    #optional
    .goto 1413/1,-3767.800,-842.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDesdio|r
    .turnin 2381 >>Entrega la misión Saquear a los saqueadores
    .target Wrenix the Wretched
step
    #label BootyTurnin
    .goto 1413/1,-3728.66,-835.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGazlowe|r
    .turnin 888 >>Entrega la misión Botín robado
    .target Gazlowe
step
    .goto 1413/1,-3720.300,-920.000
    >>Haz clic en el |cffe07cf5Cartel de Se busca|r
    .accept 92706 >>Acepta la misión SE BUSCA: Bruuz
    .group << Rogue/Warrior
step
    .goto 1413/1,-3697.24,-929.20
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMebok|r
    .turnin 865 >>Entrega la misión Cuernos de raptor
    .accept 1491 >>Acepta la misión Bebidas de inteligencia
    .target Mebok Mizzyrix
step
    .goto 1413/1,-3687.11,-981.22
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDrohn|r
    .turnin 821 >>Entrega la misión El barril vacío de Chen
    .target Brewmaster Drohn
    .isQuestComplete 821
step << Warrior
    .goto 1413/1,-3680.02,-982.58
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGrazlix|r
    .vendor >>Cómprale |T134583:0|t[|cff5cf05cPantalones de anillas poderosos|r] si está disponible
    .target Grazlix
    .money <0.619
    .itemStat 7,ITEM_MOD_ARMOR_SHORT,<155
    .equip 7,4800
    .isQuestTurnedIn 865
step << Rogue/Hunter/Warrior/Shaman/Druid
    .goto 1413/1,-3675.96,-985.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVexeje|r
    .vendor >> Cómprale |T132603:0|t[|cff5cf05cBrazales de lobo|r] si están disponibles
    .target Vexspindle
    .money <0.3515
    .itemStat 9,ITEM_MOD_ARMOR_SHORT,<37
    .equip 9,4794
    .isQuestTurnedIn 865
step << Warrior
    #optional
    #completewith FlytoXroads
    +|cffff9a3cEquipa los|r |T134583:0|t[|cff5cf05cPantalones de anillas poderosos|r]
    .use 4800
    .itemcount 4800,1
    .itemStat 7,ITEM_MOD_ARMOR_SHORT,<155
    .isQuestTurnedIn 865
    .equip 7,4800
step << Rogue/Hunter/Warrior/Shaman/Druid
    #optional
    #completewith FlytoXroads
    +|cffff9a3cEquipa los|r |T132603:0|t[|cff5cf05cBrazales de lobo|r]
    .use 4794
    .itemcount 4794,1
    .itemStat 9,ITEM_MOD_ARMOR_SHORT,<37
    .isQuestTurnedIn 865
    .xp <20,1
    .equip 9,4794
step
    #loop
    .goto 1413/1,-3911.900,-1049.200
    .goto 1413/1,-3951.600,-1093.500
    .goto 1413/1,-4012.800,-1081.800
    .goto 1413/1,-3973.000,-1028.700
    >>Mata a |cffe07cf5Bruuz|r (nivel 20 élite) en el mar cerca de Trinquete
    >>|cffff9a3c¡Esto es difícil! Monta grupo si es posible|r << !Rogue !Warrior
    >>|cffff9a3cIntenta "kitearlo" hasta Trinquete hacia los guardias para que te ayuden, ¡pero asegúrate de infligir al menos el 50% del daño!|r
    .complete 92706,1 --Kill Bruuz
    .mob Bruuz
    .isOnQuest 92706
    .group << Rogue/Warrior
step
    .goto 1413/1,-3728.66,-835.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGazlowe|r
    .turnin 92706 >>Entrega la misión SE BUSCA: Bruuz
    .target Gazlowe
    .group << Rogue/Warrior
    .isQuestComplete 92706
step
    .goto 1413/1,-3770.20,-928.53
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cPelardo|r
    .accept 959 >>Acepta la misión ¡A por la botella!
    .target Crane Operator Bigglefuzz
step
    #label FlytoXroads
    #completewith XroadsHS2
    .goto 1413/1,-3770.20,-898.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBragok|r
    .fly Crossroads >>Vuela a El Cruce
    .target Bragok
    .subzoneskip 380
step << Hunter
    .goto 1413/1,-2595.75,-473.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThork|r
    .accept 6541 >>Acepta la misión Preséntate ante Kadrak
    .target Thork
step
    #label XroadsHS2
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMankrik|r y |cff5cf05cTonga|r
    .turnin 899 >>Entrega la misión Consumido por el odio
    .turnin 95774 >>Entrega la misión Su nombre es Olgra
    .target +Mankrik
    .goto 1413/1,-2641.35,-521.12
    .turnin 880 >>Entrega la misión Seres alterados
    .accept 1489 >>Acepta la misión Hamuul Tótem de Runa
    .accept 3301 >>Acepta la misión Mura Tótem de Runa
    .target +Tonga Runetotem
    .goto 1413/1,-2672.76,-544.77
step
    #optional
    #completewith IshamuhaleTurnin
    .destroy 5085 >>|cffff9a3cElimina los|r |T133721:0|t[Colmillos de jabaespín Erizapúas] |cffff9a3csobrantes que aún puedas tener|r
    .itemcount 5085,1
step
    .goto 1413/1,-2645.40,-406.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Boorand|r
    .home >>Establece tu Piedra de hogar en El Cruce
	.vendor >>|cffe07cf5Vende la basura y luego reabastécete de comida y agua si es necesario|r << !Rogue !Warrior
    .vendor >>|cffe07cf5Vende tu basura, luego reabastécete de comida si es necesario|r << Rogue/Warrior
    .target Innkeeper Boorand Plainswind
    .dungeon DM
step
    .goto 1413/1,-2555.22,-387.350
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKorran|r
    .accept 868 >> Acepta la misión ¡A cazar huevos!
    .target Korran
step << Warlock
    #completewith next
    .goto 1413/1,-2595.75,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDevrak|r
    .fly Orgrimmar >> Vuela a Orgrimmar
    .zoneskip Orgrimmar
    .target Devrak
step << Warlock
    .goto 1454/1,-4357.36,1850.41
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGan'rul|r
    .trainer >> Aprende tus hechizos de clase
    .accept 1507 >>Acepta la misión Devoradora de almas
    .target Gan'rul Bloodeye
step << Warlock
    .goto 1454/1,-4347.4,1836.57
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKurgul|r y compra |T133738:0|t[Grimorio Tormento (Rango 2)]
    .collect 16346,1,1507,1 --Grimoire of Torment (Rank 2)
    .target Kurgul
step << Warlock
    .goto 1454/1,-4340.53,1839.19
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCazul|r
    .turnin 1507 >>Entrega la misión Devoradora de almas
    .accept 1508 >>Acepta la misión Cazul, el ciego
    .target Cazul
step << Warlock
    .goto 1454/1,-4299.99,1820.67
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cKatis|r|cffe07cf5. Compra una|r |T135139:0|t[Varita ardiente] |cffe07cf5a esta vendedora|r
    .collect 5210,1,1507,1 --Collect Burning Wand (1)
    .money <0.5808
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<17.4
    .target Katis
step << Warlock
    .goto 1454/1,-4199.99,1717.49
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZankaja|r
    .turnin 1508 >>Entrega la misión Cazul, el ciego
    .accept 1509 >>Acepta la misión Noticias de Dogran
    .target Zankaja
step
    #completewith EnterDM
    .subzone 1581 >> Ahora deberías buscar un grupo para Las Minas de la Muerte
    .dungeon DM
step
    #completewith ZepptoSTVforDM
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDevrak|r
    .fly Orgrimmar >> Vuela a Orgrimmar
    .zoneskip Orgrimmar
    .target Devrak
    .dungeon DM
step << Shaman
    .goto 1454/1,-4225.09,1933.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKardris|r
    .train 8052 >> Aprende tus hechizos de clase
    .target Kardris Dreamseeker
    .xp <18,1
    .xp >20,1
    .dungeon DM
step << Shaman
    #optional
    .goto 1454/1,-4225.09,1933.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKardris|r
    .train 2645 >> Aprende tus hechizos de clase
    .target Kardris Dreamseeker
    .xp <20,1
    .dungeon DM
step << Hunter
    .goto 1454/1,-4607.02,2100.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOrmak|r
	.train 14318 >>Aprende tus hechizos de clase
    .target Ormak Grimshot
    .xp <18,1
    .xp >20,1
    .dungeon DM
step << Hunter
    #optional
    .goto 1454/1,-4607.02,2100.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOrmak|r
	.train 14290 >>Aprende tus hechizos de clase
    .target Ormak Grimshot
    .xp <20,1
    .dungeon DM
step << Hunter
    .goto 1454/1,-4610.95,2135.15
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cXao'tsu|r
	.train 5118 >>Entrena los hechizos de tu mascota
	.target Xao'tsu
    .xp <20,1
    .dungeon DM
step << Warrior
    .goto 1454/1,-4801.42,1980.53
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGrezz|r
	.train 8198 >>Aprende tus hechizos de clase
    .target Grezz Ragefist
    .xp <18,1
    .xp >20,1
    .dungeon DM
step << Warrior
    #optional
    .goto 1454/1,-4801.42,1980.53
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGrezz|r
    .train 845 >> Aprende tus hechizos de clase
    .target Grezz Ragefist
    .xp <20,1
    .dungeon DM
step << Rogue
    .goto 1454/1,-4296.34,1762.67
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOrmok|r
    .train 1943 >> Aprende tus hechizos de clase
    .target Ormok
    .xp <20,1
    .dungeon DM
step << Warlock
    .goto 1454/1,-4353.57,1844.24--c:Orgrimmar,47.98,45.93
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZevrost|r
    .train 1014 >> Aprende tus hechizos de clase
	.target Zevrost
    .xp <18,1
    .xp >20,1
    .dungeon DM
step << Warlock
    #optional
    .goto 1454/1,-4353.57,1844.24--c:Orgrimmar,47.98,45.93
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZevrost|r
    .train 706 >> Aprende tus hechizos de clase
	.target Zevrost
    .xp <20,1
    .dungeon DM
step << Mage
    .goto 1454/1,-4218.64,1473.72
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cPephredo|r
    .train 3140 >> Aprende tus hechizos de clase
    .target Pephredo
    .xp <18,1
    .xp >20,1
    .dungeon DM
step << Mage
    #optional
    .goto 1454/1,-4218.64,1473.72
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cPephredo|r
    .train 1953 >> Aprende tus hechizos de clase
    .target Pephredo
    .xp <20,1
    .dungeon DM
step << Priest
    .goto 1454/1,-4179.79,1452.580
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cUr'kyo|r
    .train 970 >> Aprende tus hechizos de clase
    .target Ur'kyo
    .xp <18,1
    .xp >20,1
    .dungeon DM
step << Priest
    #optional
    .goto 1454/1,-4179.79,1452.580
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cUr'kyo|r
    .train 14914 >> Aprende tus hechizos de clase
    .target Ur'kyo
    .xp <20,1
    .dungeon DM
step
    #ah
    .goto 1454/1,-4460.31,1685.31
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThathung|r
    >>|cffe07cf5Compra|r |T132794:0|t[Frasco de aceite] |cffe07cf5de la Casa de Subastas si es posible|r
    .collect 814,5,103,1 --Flask of Oil (5)
	.target Auctioneer Thathung
    .dungeon DM
step
    #completewith next
    .zone Durotar >> Sal de Orgrimmar
    .zoneskip Durotar
    .dungeon DM
step
    #label ZepptoSTVforDM
    .goto 1411/1,-4648.55,1321.88,40 >>Sube a la Torre del Zepelín
    .zone Stranglethorn Vale >>Toma el Zepelín a Vega de Tuercespina
    .zoneskip Stranglethorn Vale
    .dungeon DM
step
    .goto 1434/0,273.91,-12406.71,40,0
    .goto 1434/0,492.15,-12499.03,40,0
    .goto 1434/0,759.53,-12494.77,60,0
    .goto 1434/0,1004.57,-12317.37,60,0
    .goto 1434/0,1178.78,-12166.78,60,0
    .goto 1434/0,1360.0,-11978.74,60,0
    .goto 1436/0,1578.87,-11699.5,60,0
    .goto 1436/0,1718.17,-11480.4,40,0
    .goto 1436/0,1966.32,-11407.13,200 >> Nada directamente al oeste desde Grom'Gol hacia el Arrecife Mortal y luego nada al norte hacia Páramos de Poniente
    >>|cffff9a3cEvita la isla. ¡Sigue la ruta marcada por seguridad!|r
    .dungeon DM
step
    #completewith next
    .goto 1436/0,1966.32,-11407.13,40 >> Viaja al Faro de Poniente
    .dungeon DM
step
    .goto 1436/0,1966.32,-11407.13
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cCapitán Grisillo|r
    .accept 103 >> Acepta la misión Guardián de la Llama
    .target Captain Grayson
    .itemcount 814,5 -- Flask of Oil (5)
    .dungeon DM
step
    .goto 1436/0,1966.32,-11407.13
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cCapitán Grisillo|r
    .turnin 103 >> Entrega la misión Guardián de la Llama
    .itemcount 814,5 -- Flask of Oil (5)
    .target Captain Grayson
    .dungeon DM
step
    .goto 1436/0,1966.32,-11407.13
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cCapitán Grisillo|r
    .accept 104 >> Acepta la misión La amenaza costera
    .target Captain Grayson
    .dungeon DM
step
    .goto 1436/0,1811.62,-11358.37
    .line Westfall,34.43,83.93,34.43,83.93,33.88,83.32,33.08,82.86,32.56,82.71,32.08,82.49,31.91,82.36,31.55,81.88,30.86,81.42,30.63,81.16,30.33,80.81,30.02,80.11,29.68,79.22,29.32,78.19,29.29,77.60,29.27,77.31,29.18,76.26,29.07,75.29,28.95,74.14,28.85,73.29,28.79,72.48,28.37,71.94,27.84,71.29,27.44,70.25,27.29,69.47,27.13,68.65,27.09,67.57,27.07,67.01,26.74,66.09,27.07,67.01,27.09,67.57,27.13,68.65,27.29,69.47,27.44,70.25,27.84,71.29,28.37,71.94,28.79,72.48,28.85,73.29,28.95,74.14,29.07,75.29,29.18,76.26,29.27,77.31,29.29,77.60,29.32,78.19,29.68,79.22,30.02,80.11,30.33,80.81,30.63,81.16,30.86,81.42,31.55,81.88,31.91,82.36,32.08,82.49,32.56,82.71,33.08,82.86,33.88,83.32,34.43,83.93
    >>Mata a |cffff5a4aViejo Ojosombrío|r. Despójalo para obtener su |cff4fc3f7Escama|r
    >>|cffff5a4aViejo Ojosombrío|r |cffff9a3cpatrulla de arriba a abajo por la Playa Larga. Si no lo ves a lo largo de Playa Larga, espera a que aparezca en el campamento |cffff5a4aMúrloc|r más al sur|r
    .complete 104,1 -- Scale of Old Murk-Eye (1)
    .unitscan Old Murk-Eye
    .dungeon DM
step
    .goto 1436/0,1966.32,-11407.13
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cCapitán Grisillo|r
    .turnin 104 >> Entrega la misión La amenaza costera
    .target Captain Grayson
    .dungeon DM
step
    #optional
    .abandon 103 >> Abandona la misión Guardián de la Llama
    .dungeon DM
step
    #label EnterDM
    .goto 1415/0,1596.2,-11768.97,8,0
    .goto 1415/0,1596.2,-11780.71,8,0
    .goto 1415/0,1606.76,-11797.13,8,0
    .goto 1415/0,1582.12,-11799.48,8,0
    .goto 1415/0,1596.2,-11813.56,15,0
    .goto 1415/0,1631.4,-11846.41,15,0
    .goto 1415/0,1649.0,-11898.04,15,0
    .goto 1415/0,1659.56,-11919.16,15,0
    .goto 1415/0,1698.28,-11891.0,15,0
    .goto 1415/0,1744.04,-11881.61
    .zone 291 >> Entra por el portal de la instancia a las Minas de la Muerte. Entra en la mazmorra
    .dungeon DM
step
    .hs >> Usa tu Piedra de hogar hacia Los Baldíos después de completar Minas de la Muerte
    .zone The Barrens >> Llega a Los Baldíos
    .use 6948
    .dungeon DM
step
    #optional
    .goto 1413/1,-2645.40,-406.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Boorand|r
	.vendor >>|cffe07cf5Vende la basura y luego reabastécete de comida y agua si es necesario|r << !Rogue !Warrior
    .vendor >>|cffe07cf5Vende tu basura, luego reabastécete de comida si es necesario|r << Rogue/Warrior
    .target Innkeeper Boorand Plainswind
    .subzoneskip 380,1
    .dungeon DM
step << Warlock
    #completewith TurninDogran
    .goto 1454/1,-4313.60,1676.24
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDoras|r
	.fly Crossroads >> Vuela a El Cruce
    .zoneskip Orgrimmar,1
    .target Doras
step << Warlock
    #label TurninDogran
    .goto 1413/1,-2639.32,-436.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGazrog|r
    .turnin 1509 >>Entrega la misión Noticias de Dogran
    .accept 1510 >>Acepta la misión Noticias de Dogran
    .target Gazrog
step
    .goto 1413/1,-2589.67,-424.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHelbrim|r
    >>|cff5cf05cHelbrim|r |cffff9a3cInicia una misión cronometrada de 45 minutos|r
    .accept 853 >> Acepta la misión Boticaria Zamah
    .target Apothecary Helbrim
    .isQuestTurnedIn 848
    .isQuestAvailable 853
step
    #sticky
    #completewith ZamahTurnin
    +|cffff9a3cEstás en una misión cronometrada, no te vayas AFK. Se entregará 20-30 minutos después de aceptarla|r
    .isOnQuest 853
step
    #completewith TribesTurnin
    .goto 1413/1,-2595.75,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDevrak|r
    .fly Camp Taurajo >> Vuela al Campamento Taurajo
    .target Devrak
step
    .goto 1413/1,-2515.7,-2076.41
    >>Mata |cffff5a4aJabaespines Erizapúas|r. Despójalos para obtener una |T134128:0|t[|cff4fc3f7Esquirla de sangre|r]
    .collect 5075,1,5052,1 --Blood Shard (1)
    .mob Bristleback Water Seeker
    .mob Bristleback Thornweaver
    .mob Bristleback Geomancer
step
    #label TribesTurnin
    .goto 1413/1,-1891.48,-2391.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cQuebrantadientes|r
    .turnin 878 >>Entrega la misión Tribus en guerra
    .accept 5052 >>Acepta la misión Esquirlas de sangre de Agamaggan
    .turnin 5052 >>Entrega la misión Esquirlas de sangre de Agamaggan
    .target Mangletooth
step
    #completewith IshamuhaleTurnin
    .goto 1413/1,-1891.48,-2391.93,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cQuebrantadientes|r
    +|cffff9a3cUsa tus|r |T134128:0|t[|cff4fc3f7Esquirlas sangrientas|r] |cffff9a3cpara obtener buffs. Guarda al menos 4 de ellas para después|r << Tauren/Shaman/Orc Warrior/Troll Warrior
    +|cffff9a3cUsa tus|r |T134128:0|t[|cff4fc3f7Esquirlas sangrientas|r] |cffff9a3cpara obtener buffs. Guarda al menos 4 de ellas para después|r << !Tauren !Shaman !Warrior/Undead
    +|cffff9a3c¡Asegúrate de desactivar cualquier función de autocompletar de addons como Questie o Leatrix Plus para esto!|r
    .target Mangletooth
step
    .goto 1413/1,-1921.88,-2383.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJorn Vidente del Cielo|r
    .turnin 882 >>Entrega la misión Ishamuhale
    .accept 907 >>Acepta la misión Los truenagartos iracundos
    .turnin 883 >>Entrega la misión Lakota'mani
    .target Jorn Skyseer
    .isOnQuest 883
step
    #label IshamuhaleTurnin
    .goto 1413/1,-1921.88,-2383.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJorn Vidente del Cielo|r
    .turnin 882 >>Entrega la misión Ishamuhale
    .accept 907 >>Acepta la misión Los truenagartos iracundos
    .target Jorn Skyseer
step
    #completewith SleepingBag1
    >>Mata a los |cffff5a4aTruenagartos|r. Despójalos para obtener su |cff4fc3f7Sangre|r
    .complete 907,1 --Thunder Lizard Blood (3)
    .mob Thunderhead
    .mob Stormsnout
step
    #completewith LizardBlood
    .goto 1413/1,-1899.59,-2624.34,0
    .goto 1413/1,-2016.12,-2650.02,0
    .goto 1413/1,-2400.18,-2398.01,0
    .goto 1413/1,-2363.70,-2537.19,0
    >>Mata a |cffff5a4aOwatanka|r. Despójalo para obtener |T133723:0|t[|cff4fc3f7Punta de cola de Owatanka|r]
    >>|cffff9a3cUsa la |T133723:0|t[|cff4fc3f7Punta de cola de Owatanka|r] para iniciar la misión|r
    >>|cffff9a3cTiene 4 puntos de aparición (marcados en el mapa)|r
    .collect 5102,1,884,1 --Collect Owatanka's Tailspike
    .accept 884 >>Acepta la misión Owatanka
    .use 5102
    .unitscan Owatanka
step
    #label SleepingBag1
    .goto 1413/1,-2075.00,-3380.64--c:The Barrens,46.361,73.904
    >>Haz clic en los |cffe07cf5Restos quemados|r en el suelo
    .accept 79007 >> Acepta la misión ... y la nota que encontraste
step
    #label LizardBlood
    #loop
    .goto 1413/1,-1868.18,-2498.00,0
    .goto 1413/1,-1868.18,-2498.00,60,0
    .goto 1413/1,-1861.08,-2561.51,60,0
    .goto 1413/1,-1842.84,-2618.94,60,0
    .goto 1413/1,-1888.44,-2650.690,60,0
    .goto 1413/1,-2004.98,-2683.80,60,0
    .goto 1413/1,-2133.67,-2590.56,60,0
    .goto 1413/1,-2182.31,-2479.76,60,0
    .goto 1413/1,-2232.98,-2478.41,60,0
    .goto 1413/1,-2273.51,-2456.79,60,0
    .goto 1413/1,-2356.60,-2513.54,60,0
    .goto 1413/1,-2428.55,-2517.60,60,0
    .goto 1413/1,-2406.26,-2424.36,60,0
    .goto 1413/1,-2363.70,-2395.98,60,0
    .goto 1413/1,-2253.24,-2345.99,60,0
    >>Mata a los |cffff5a4aTruenagartos|r. Despójalos para obtener su |cff4fc3f7Sangre|r
    .complete 907,1 --Thunder Lizard Blood (3)
    .mob Thunderhead
    .mob Stormsnout
step
    .goto 1413/1,-1921.88,-2383.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJorn|r
    .turnin 884 >>Entrega la misión Owatanka
    .turnin 907 >>Entrega la misión Los truenagartos iracundos
    .accept 913 >>Acepta la misión El chillido del halcón trueno
    .target Jorn Skyseer
    .isOnQuest 884
step
    #label Thunderhawk
    .goto 1413/1,-1921.88,-2383.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJorn|r
    .turnin 907 >>Entrega la misión Los truenagartos iracundos
    .accept 913 >>Acepta la misión El chillido del halcón trueno
    .target Jorn Skyseer
step
    #completewith next
    .goto 1413/1,-1899.59,-2624.34,0
    .goto 1413/1,-2016.12,-2650.02,0
    .goto 1413/1,-2400.18,-2398.01,0
    .goto 1413/1,-2363.70,-2537.19,0
    .goto 1413/1,-1899.59,-2624.34,80,0
    .goto 1413/1,-2016.12,-2650.02,80,0
    .goto 1413/1,-2363.70,-2537.19,80,0
    .goto 1413/1,-2400.18,-2398.01,80,0
    >>Mata a |cffff5a4aOwatanka|r. Despójalo para obtener |T133723:0|t[|cff4fc3f7Punta de cola de Owatanka|r]
    >>|cffff9a3cUsa la |T133723:0|t[|cff4fc3f7Punta de cola de Owatanka|r] para iniciar la misión|r
    >>|cffff9a3cTiene 4 puntos de aparición (marcados en el mapa)|r
    .collect 5102,1,884,1 --Collect Owatanka's Tailspike
    .accept 884 >>Acepta la misión Owatanka
    .use 5102
    .unitscan Owatanka
step
    #loop
    .goto 1413/1,-1919.86,-2652.04,0
    .goto 1413/1,-1919.86,-2652.04,60,0
    .goto 1413/1,-2096.18,-2531.11,60,0
    .goto 1413/1,-2341.4,-2352.74,60,0
    .goto 1413/1,-1982.68,-2217.62,60,0
    .goto 1413/1,-1775.96,-2235.86,60,0
    >>Mata a una |cffff5a4aProle de Halcón Trueno|r o a un |cffff5a4aDesechanube Halcón Trueno|r. Despójalo para obtener |cff4fc3f7Alas de halcón trueno|r
    .complete 913,1 --Thunderhawk Wings (1)
    .mob Thunderhawk Hatchling
    .mob Thunderhawk Cloudscraper
step
    .goto 1413/1,-1921.88,-2383.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJorn Vidente del Cielo|r
    .turnin 884 >>Entrega la misión Owatanka
    .turnin 913 >>Entrega la misión El chillido del halcón trueno
    .accept 874 >>Acepta la misión Mahren Vidente del Cielo
    .accept 6382 >>Acepta la misión La Caza de Vallefresno << Hunter
    .target Jorn Skyseer
    .isOnQuest 884
step
    #label ThunderhawkTurnin
    .goto 1413/1,-1921.88,-2383.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJorn Vidente del Cielo|r
    .turnin 913 >>Entrega la misión El chillido del halcón trueno
    .accept 874 >>Acepta la misión Mahren Vidente del Cielo
    .accept 6382 >>Acepta la misión La Caza de Vallefresno << Hunter
    .target Jorn Skyseer
step
    #optional
    .xp 20 >>Mata enemigos hasta subir al nivel 20
step << !Tauren !Skyborne
    .goto 1413/1,-1891.48,-2391.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cQuebrantadientes|r
    .aura 16618 >>|cffff9a3cSi te quedan 10|r |T134128:0|t[|cff4fc3f7Esquirlas de sangre|r] |cffff9a3c, úsalas para obtener|r |T136022:0|t[Espíritu del viento] |cffff9a3cde|r |cff5cf05cQuebrantadientes|r
    >>|cffff9a3cOmite este paso si tienes la ruta de vuelo de Cima del Trueno|r
    .itemcount 5075,10
    .target Mangletooth
    .train 2645,1 << Shaman --skip if ghost wolf trained
    .train 5118,1 << Hunter --skip if cheetah trained
step << !Tauren !Skyborne
    #completewith next
    .goto 1412/1,-1480.52,-2339.56,120,0
    .zone Mulgore >>Viaja a Mulgore
step << !Tauren !Skyborne
    #completewith DeathDUPpickup
    .goto 1456/1,184.96,-1308.69
    .zone Thunder Bluff >>Toma el ascensor hacia Cima del Trueno
    >>|cffff9a3cSi tienes la ruta de vuelo de Cima del Trueno, vuela allí en su lugar|r
step << Tauren/Skyborne
    #completewith DeathDUPpickup
    .goto 1413/1,-1881.35,-2384.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOmusa|r
    .fly Thunder Bluff >>Vuela a Cima del Trueno
    .target Omusa Thunderhorn
    .zoneskip Thunder Bluff
step << Undead Warrior/Orc Warrior/Troll Warrior/Troll Shaman/Orc Shaman
    .goto 1456/1,89.46,-1286.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAnsekhwa|r
    .train 199 >>Aprende el uso de Mazas de dos manos
    .train 227 >>Aprende el uso de Bastones
    .target Ansekhwa
step << Troll Hunter/Orc Hunter/Undead Warrior/Warlock/Priest
    .goto 1456/1,89.46,-1286.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAnsekhwa|r
    .train 227 >>Aprende el uso de Bastones
    .target Ansekhwa
step << Rogue !Skyborne
    .goto 1456/1,89.46,-1286.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAnsekhwa|r
    .train 198 >>Aprende el uso de Mazas
    .target Ansekhwa
step << skip --Rogue
    .goto 1456/1,110.13,-1299.65
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cKuruk|r|cffe07cf5. Compra |r |T135423:0|t[Hacha arrojadiza mortal] |cffe07cf5a este vendedor|r
    .collect 3137,1,6562,1 --Deadly Throwing Axe (200)
    .target Kuruk
step << Rogue
    #optional
    .goto 1456/1,104.500,-1308.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBoarton Totemsombrío|r
    >>|cffff9a3cEstá|r |T132320:0|t[En sigilo] 
    .train 6761 >>Aprende tus hechizos de clase
    .target Boarton Shadetotem
    .xp <16,1
    .xp >20,1
step << Rogue
    .goto 1456/1,104.500,-1308.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBoarton Totemsombrío|r
    >>|cffff9a3cEstá|r |T132320:0|t[En sigilo] 
    .train 1943 >>Aprende tus hechizos de clase
    .target Boarton Shadetotem
    .xp <20,1
step
    .goto 1456/1,24.85,-1252.75
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cChesmu|r
    .bankdeposit 5075 >> Deposita tus |T134128:0|t[Esquirlas de sangre]
    .bankdeposit 5059 >> Deposita tu |T132938:0|t[Garra de excavación]
    .target Chesmu
    .isOnQuest 868
step
    #optional
    .goto 1456/1,24.85,-1252.75
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cChesmu|r
    .bankdeposit 5075 >> Deposita tus |T134128:0|t[Esquirlas de sangre]
    .target Chesmu
    .isNotOnQuest 868
step
    .goto 1456/1,38.32,-1300.48
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cTabernera Pala|r
    .home >>Establece tu Piedra de hogar en Cima del Trueno
    .target Innkeeper Pala
    .bindlocation 1638
    .isQuestAvailable 6442
    .dungeon !WC
step << Hunter
    #completewith HunterTraining2
    .goto 1456/1,-123.26,-1394.49,60 >> Viaja al Alto de los Cazadores
step << Hunter
    .goto 1456/1,-100.50,-1454.75
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cUrek|r
    .train 5118 >> Aprende tus hechizos de clase
    .target Urek Thunderhorn
    .xp <20,1
    .xp >22,1
step << Hunter
    #label HunterTraining2
    #optional
    .goto 1456/1,-100.50,-1454.75
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cUrek|r
    .train 5118 >> Aprende tus hechizos de clase
    .target Urek Thunderhorn
    .xp <22,1
step << Hunter
    .goto 1456/1,-47.69,-1434.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHesuwa|r
    .train 24494 >> Entrena los hechizos de tu mascota
    .target Hesuwa Thunderhorn
step << Warrior
    #completewith next
    .goto 1456/1,-123.26,-1394.49,60 >> Viaja al Alto de los Cazadores
step << Warrior
    .goto 1456/1,-81.09,-1457.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTorm|r
    .train 845 >>Aprende tus hechizos de clase
    .accept 1823 >>Acepta la misión Habla con Ruga
    .target Torm Ragetotem
step
    #completewith next
    .goto 1456/1,222.96,-1079.42,40,0
    .goto 1456/1,219.09,-1051.44,10 >> Viaja al Alto de los Espíritus y entra en las pozas de las visiones
step
    #sticky
    #completewith DeathDUPpickup
    .goto 1456/1,218.68,-1028.41
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cClarice|r
    .accept 264 >> Acepta la misión Hasta que la muerte nos separe
    .target Clarice Foster
step
    .goto 1456/1,278.48,-995.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZamah|r
    .turnin 853 >> Entrega la misión Boticaria Zamah
    .accept 962 >> Acepta la misión Reptilia
    .target Apothecary Zamah
    .isOnQuest 853
step
    #label ZamahTurnin
    #optional
    .goto 1456/1,278.48,-995.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZamah|r
    .accept 962 >> Acepta la misión Reptilia
    .target Apothecary Zamah
step << Priest
    .goto 1456/1,252.49,-956.04
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMiles|r
    .accept 5644 >> Acepta la misión Peste devoradora << Undead Priest
    .accept 5642 >> Acepta la misión Guardia de las Sombras << Troll Priest
    .trainer >> Aprende tus hechizos de clase
    .target Miles Welsh
step << Mage
    .goto 1456/1,279.32,-950.76
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShymm|r
    .train 12051 >> Aprende tus hechizos de clase
    .target Archmage Shymm
    .xp <20,1
    .xp >22,1
step << Mage
    #optional
    .goto 1456/1,279.32,-950.76
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShymm|r
    .train 2138 >> Aprende tus hechizos de clase
    .target Archmage Shymm
    .xp <22,1
step << Paladin
    .goto 1456/1,253.900,-950.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAlodan|r
    .train 1866 >>Aprende tus hechizos de clase
    .target Alodan the Hopeful 
    .xp <20,1
    .xp >22,1
step << Paladin
    #optional
    .goto 1456/1,253.900,-950.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAlodan|r
    .train 1026 >>Aprende tus hechizos de clase
    .target Alodan the Hopeful 
    .xp <22,1
step
    #optional
    #label DeathDUPpickup
step << Shaman
    .goto 1456/1,269.92,-980.40
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTigor|r |cffff9a3cfuera|r
    .train 2645 >> Aprende tus hechizos de clase
    .target Tigor Skychaser
    .xp <20,1
    .xp >22,1
step << Shaman
    #optional
    .goto 1456/1,269.92,-980.40
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTigor|r |cffff9a3cfuera|r
    .train 8498 >> Aprende tus hechizos de clase
    .target Tigor Skychaser
    .xp <22,1
step << Shaman
    .goto 1456/1,253.54,-992.30--c:Thunder Bluff,25.21,20.45
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cXanis|r
    .accept 1529 >>Acepta la misión La llamada del agua
    .target Xanis Flameweaver
    .isQuestAvailable 1530
    .isNotOnQuest 1528,2985,2986
step
    #completewith next
    .skill firstaid,80 >> |cffff9a3cCrea|r |T133688:0|t[Vendas de lino gruesa] |cffff9a3chasta que tu habilidad sea 80 o superior|r
    .skill firstaid,<1,1
step
    .goto 1456/1,206.88,-997.45
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cPand|r
    >>|cffff9a3cOmite este paso si no tuviste suficiente|r |T132889:0|t[Paño de lino] |cffff9a3cpara llegar a 80 de habilidad|r
    .train 3277 >> Aprende |T133684:0|t[Venda de lana]
    .train 7934 >> Aprende |T134437:0|t[Contraveneno] << Rogue
    .target Pand Stonebinder
    .skill firstaid,<1,1
step << Rogue
    >>|cffff9a3cCrea|r |T134437:0|t[Contraveneno] |cffff9a3csi encontraste alguna|r |T134339:0|t[Glándula de veneno pequeña]
    >>|cffff9a3cGuárdalos para más adelante|r
    .collect 6452,1 --Anti Venom
    .itemcount 1475,1
step
    #completewith NaraWild
    .goto 1456/1,-212.71,-1065.010,80 >> Viaja al Alto de los Ancestros
step
    .goto 1456/1,-218.13,-1055.97--c:Thunder Bluff,70.4,29.6
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRahauro|r
    .turnin 5724 >> Entrega la misión La vuelta de la cartera perdida
    .turnin 5723 >> Entrega la misión Midiendo fuerzas con el enemigo
    .target Rahauro
    .isOnQuest 5724
    .isQuestComplete 5723
step
    #optional
    .goto 1456/1,-218.13,-1055.97--c:Thunder Bluff,70.4,29.6
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRahauro|r
    .turnin 5724 >> Entrega la misión La vuelta de la cartera perdida
    .target Rahauro
    .isOnQuest 5724
step
    #optional
    #label RFCTurninsTB1
    .goto 1456/1,-218.13,-1055.97--c:Thunder Bluff,70.4,29.6
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRahauro|r
    .turnin 5723 >> Entrega la misión Midiendo fuerzas con el enemigo
    .target Rahauro
    .isQuestComplete 5723
step
    .goto 1456/1,-303.83,-1048.66
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHamuul|r
    .turnin 1489 >> Entrega la misión Hamuul Tótem de Runa
    .accept 1490 >> Acepta la misión Nara Ferocrín
    .target Arch Druid Hamuul Runetotem
step
    .goto 1456/1,-272.93,-1069.67
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cNara|r
    .turnin 1490 >> Entrega la misión Nara Ferocrín
    .accept 914 >> Acepta la misión Líderes del Colmillo
    .target Nara Wildmane
step
    #label NaraWild
    .goto 1456/1,-272.93,-1069.67
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cNara|r
    .turnin 1490 >> Entrega la misión Nara Ferocrín
    .target Nara Wildmane
step << Druid
    .goto 1456/1,-281.59,-1039.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTurak|r
    .trainer >>Aprende tus hechizos de clase
    .accept 27 >>Acepta la misión Una lección que aprender
    .accept 98340 >>Acepta la misión El gran espíritu felino
    .target Turak Runetotem
step << Druid
    #completewith next
    .cast 18960 >>|cffff9a3cLanza|r |T135758:0|t[Teletransporte a: Claro de la Luna]
    .zoneskip Moonglade
step << Druid
    .goto 1450/1,-2678.76,8019.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDendrita|r
    .turnin 27 >>Entrega la misión Una lección que aprender
    .accept 28 >>Acepta la misión La prueba del lago
    .turnin 98340 >>Entrega la misión El gran espíritu felino
    .accept 98341 >>Acepta la misión El espíritu del gran felino natoviento << Skyborne
    .accept 98405 >>Acepta la misión El gran espíritu felino << !Skyborne
    .target Dendrite Starblaze
step << Druid
    #completewith next
    .goto 1450/1,-2634.67,7634.43
    .collect 15877,1,28,1 >>Despoja el |cffe07cf5Adorno contenedor|r en el fondo del lago para un |T134125:0|t[Adorno de altar]
    >>|cffff9a3cNO te sumerjas hasta que estés justo encima del Adorno|r
step << Druid
    .goto 1450/1,-2221.48,7844.89
    .cast 19719 >> |cffff9a3cUsa el|r |T134125:0|t[Adorno de altar] |cffff9a3cen el Santuario de Remulos|r
    .complete 28,1 -- Complete the Trial of the Lake
    .use 15877
step << Druid
    .goto 1450/1,-2224.25,7874.290
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTajarri|r
    .turnin 28 >> Entrega la misión La prueba del lago
    .accept 30 >> Acepta la misión La prueba del león marino
    .target Tajarri
step << Druid !Skyborne
    .goto 1450/1,-2640.000,7338.900
     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGran espíritu felino|r
    .turnin 98405 >>Entrega la misión El gran espíritu felino
    .accept 98342 >>Acepta la misión El gran espíritu felino
    .target Great Cat Spirit
step << Druid Skyborne
    .goto 1450/1,-2352.700,7375.600,10,0
    .goto 1450/1,-2394.300,7361.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cAvatar de Saeyleenan::272054|r
    .target Avatar of Saeyleenan::272054
    .turnin 98341 >>Entrega la misión El espíritu del gran felino natoviento
    .accept 98404 >>Acepta la misión El espíritu del gran felino natoviento
step << Druid
    #completewith next
    .goto 1450/1,-3046.700,7534.400
    --aura 1309054?
    .subzone 2363 >> Dirígete al Túmulo de Tempestira
step << Druid
    >>Ve al fondo de la cueva, cruza el puente, busca una estatua de gato dentro de un hueco y haz clic en el pequeño orbe junto a la estatua
    >>Despoja la |cff4fc3f7Reliquia de la garra|r
    .goto 1450/1,-3117.400,7455.300
    .complete 98404,2 << Skyborne --|1/1 Relic of the Claw
    .complete 98342,2 << !Skyborne --|1/1 Relic of the Claw
step << Druid
    >>Haz clic en el pequeño orbe junto a la estatua de gato
    >>Despoja la |cff4fc3f7Reliquia de la sombra silenciosa|r
    .goto 1450/1,-3099.200,7485.700
    .complete 98404,3  << Skyborne --|1/1 Relic of the Silent Shadow
    .complete 98342,3  << !Skyborne --|1/1 Relic of the Silent Shadow
step << Druid
    >>Haz clic en el pequeño orbe junto a la estatua de gato
    >>Despoja la |cff4fc3f7Reliquia del colmillo|r
    .goto 1450/1,-3054.100,7476.800
    .complete 98404,1  << Skyborne --|1/1 Relic of the Fang
    .complete 98342,1  << !Skyborne --|1/1 Relic of the Fang
step << Druid !Skyborne
    .goto 1450/1,-2640.000,7338.900
     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGran espíritu felino|r
    .turnin 98342 >>Entrega la misión El gran espíritu felino
    .accept 98739 >>Acepta la misión Bendiciones del gran espíritu felino
    .target Great Cat Spirit
step << Druid Skyborne
    .goto 1450/1,-2395.400,7361.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cAvatar de Saeyleenan::272054|r
    .target Avatar of Saeyleenan::272054
    .turnin 98404 >>Entrega la misión El espíritu del gran felino natoviento
    .accept 98738 >>Acepta la misión Bendiciones del gran espíritu felino natoviento
step << Druid
    #completewith next
    .cast 18960 >>|cffff9a3cLanza|r |T135758:0|t[Teletransporte a: Claro de la Luna]
    .zoneskip Moonglade
step << Druid
    .goto 1450/1,-2678.200,8021.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDendrita Rafagaestelar::11802|r
    .turnin 98738 >>Entrega la misión Bendiciones del gran espíritu felino natoviento << Skyborne
    .turnin 98739 >>Entrega la misión Bendiciones del gran espíritu felino << !Skyborne
    .accept 98362 >>Acepta la misión Viaje a Cima del Trueno
    .target Dendrite Starblaze::11802
step << Druid
    .hs >> Usa tu Piedra de hogar para ir a Cima del Trueno
    .use 6948
    .cooldown item,6948,>0
    .bindlocation 1638,1
    .zoneskip Thunder Bluff
step << Druid
    #completewith next
    .goto 1450/1,-2403.61,7785.31
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBunthen|r
    .fly Thunder Bluff >> Vuela a Cima del Trueno
    .target Bunthen Plainswind
    .zoneskip Thunder Bluff
    .cooldown item,6948,<0
step << Druid
    .goto 1456/1,-281.59,-1039.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTurak|r
    .turnin 98362 >>Entrega la misión Viaje a Cima del Trueno
    .target Turak Runetotem
step << Rogue
    .goto 1456/1,-36.52,-1244.05
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cKard|r|cffe07cf5. Compra una|r |T135324:0|t[Tizona] |cffe07cf5a este vendedor.|r
    .collect 923,1,493,1 --Collect Longsword (1)
    .money <0.8743
    .target Kard Ragetotem
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.1
step << Rogue
    #optional
    #completewith KayaLives
    +|cffff9a3cEquipa la|r |T135324:0|t[Tizona]
    .use 923
    .itemcount 923,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.1
    .xp <21,1
step << Warrior/Shaman
    #optional
    #completewith next
    #ah
    +|cff5cf05cSi es más barato puedes comprar un arma verde de la casa de subastas en su lugar|r
step << Warrior
    .goto 1456/1,-38.71,-1255.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cEtu|r|cffe07cf5. Compra un|r |T135157:0|t[Bastón largo] |cffe07cf5a este vendedor|r
    .collect 928,1,493,1 --Collect Long Staff (1)
    .money <0.9860
    .target Etu Ragetotem
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.2
step << Warrior
    #optional
    #completewith KayaLives
    +|cffff9a3cEquipa el|r |T135157:0|t[Bastón largo]
    .use 928
    .itemcount 928,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.2
    .xp <20,1
step << Shaman
    .goto 1456/1,-38.71,-1255.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cEtu|r|cffe07cf5. Compra un|r |T135157:0|t[Bastón largo] |cffe07cf5a este vendedor|r
    .collect 928,1,493,1 --Collect Long Staff (1)
    .money <0.9860
    .target Etu Ragetotem
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.2
step << Shaman
    #optional
    #completewith KayaLives
    +|cffff9a3cEquipa el|r |T135157:0|t[Bastón largo]
    .use 928
    .itemcount 928,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.2
    .xp <21,1
step << Hunter
    .goto 1456/1,26.31,-1167.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cKuna|r|cffe07cf5. Compra un|r |T135489:0|t[Arco corvo pesado] |cffe07cf5a esta vendedora|r
    .collect 3027,1,493,1 --Collect Heavy Recurve Bow (1)
    .money <0.5643
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<9.1
    .target Kuna Thunderhorn
step << Hunter
    #completewith KayaLives
    #optional
    +|cffff9a3cEquipa el|r |T135489:0|t[Arco corvo pesado]
    .use 3027
    .itemcount 3027,1
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<9.1
    .xp <20,1
step << Hunter
    .goto 1456/1,26.31,-1167.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cKuna|r
    >>|cffe07cf5Compra|r |T132382:0|t[Flechas afiladas] |cffe07cf5a esta vendedora|r
    .collect 2515,1600,493,1 << Hunter --Sharp Arrow (1600)
    .target Kuna Thunderhorn
step
    #completewith next
    .goto 1456/1,26.1,-1196.66
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTal|r
    .fly Crossroads >>Vuela a El Cruce
    .target Tal
    .zoneskip The Barrens
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 851 >>Entrega la misión Verog el Derviche
    .accept 852 >>Acepta la misión Hezrul Marcasangre
    .turnin 855 >>Entrega la misión Los brazales centauro
    .target Regthar Deathgate
    .isQuestComplete 855
step
    #label Leaders
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 851 >>Entrega la misión Verog el Derviche
    .accept 852 >>Acepta la misión Hezrul Marcasangre
    .target Regthar Deathgate
step << Warlock
    #label EnterSTM2
    #completewith DogranNews
    .zone Stonetalon Mountains >> Viaja a Sierra Espolón
    .zoneskip Stonetalon Mountains
step << Warlock
    #completewith DogranNews
    .goto 1442/1,-786.33,-294.97,60,0
    .goto 1442/1,-665.72,-280.97,40,0
    .goto 1442/1,-522.63,-294.32,40 >> Sigue el camino de la izquierda hacia arriba
step << Warlock
    #label DogranNews
    .goto 1442/1,-331.21,-181.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKen'zigla|r
    .turnin 1510 >>Entrega la misión Noticias de Dogran
    .accept 1511 >>Acepta la misión Jarabe de Ken'zigla
    .target Ken'zigla

    ]=], "Horde"}
R[#R + 1] = {[=[
#forever
<< Horde
#name 21-22 Cuevas de los Lamentos
#next 22-24 Laderas de Trabalomas
#version 11
#group Forever Guía de Mazmorras (H)
#subgroup Mazmorras 1-22

step
    #sticky
    #completewith EnterWC
    .goto 1414/1,-2216.5,-742.43,30 >>Ahora debes buscar un grupo para Cuevas de los Lamentos
step << Warlock
    #completewith EnterWC
    .zone The Barrens >>Vuelve corriendo a Los Baldíos
step
    #completewith EnterWC
    .subzone 387 >> Viaja al Oasis Aguaverde
    .isQuestTurnedIn 851
step
    #loop
    #label Hezrul
    .goto 1413/1,-2001.94,-965.69,0
    .goto 1413/1,-2001.94,-965.69,50,0
    .goto 1413/1,-2022.20,-945.42,50,0
    .goto 1413/1,-2016.12,-915.01,50,0
    .goto 1413/1,-2033.35,-894.74,50,0
    .goto 1413/1,-2031.32,-881.23,50,0
    .goto 1413/1,-2052.60,-877.18,50,0
    .goto 1413/1,-2057.67,-879.21,50,0
    .goto 1413/1,-2066.79,-877.85,50,0
    .goto 1413/1,-2085.03,-898.80,50,0
    .goto 1413/1,-2097.19,-908.26,50,0
    .goto 1413/1,-2102.26,-950.15,50,0
    .goto 1413/1,-2114.42,-981.22,50,0
    .goto 1413/1,-2167.11,-1021.09,50,0
    .goto 1413/1,-2187.38,-1040.68,50,0
    .goto 1413/1,-2261.35,-1060.95,50,0
    .goto 1413/1,-2281.62,-1061.62,50,0
    .goto 1413/1,-2301.88,-1056.89,50,0
    .goto 1413/1,-2295.80,-1087.30,50,0
    .goto 1413/1,-2299.86,-1125.13,50,0
    .goto 1413/1,-2268.44,-1145.40,50,0
    .goto 1413/1,-2247.16,-1145.40,50,0
    .goto 1413/1,-2226.90,-1166.35,50,0
    .goto 1413/1,-2189.40,-1179.86,50,0
    .goto 1413/1,-2174.20,-1198.78,50,0
    .goto 1413/1,-2162.04,-1200.80,50,0
    .goto 1413/1,-2124.55,-1228.50,50,0
    .goto 1413/1,-2095.16,-1220.40,50,0
    .goto 1413/1,-2065.78,-1208.91,50,0
    .goto 1413/1,-2041.46,-1167.70,50,0
    .goto 1413/1,-2024.23,-1179.18,50,0
    .goto 1413/1,-2047.54,-1156.21,50,0
    .goto 1413/1,-2046.52,-1135.94,50,0
    .goto 1413/1,-2009.03,-1127.84,50,0
    .goto 1413/1,-2001.94,-965.69,50,0
    >>Encuentra y mata a |cffff5a4aHezrul Marcasangre|r. Despójalo para obtener su |cff4fc3f7Cabeza|r
    >>|cffff5a4aHezrul|r |cffff9a3cpatrulla alrededor del lago|r
    .complete 852,1 --Hezrul's Head
    .unitscan Hezrul Bloodmark
    .isQuestTurnedIn 851
step
    #completewith next
    .goto 1413/1,-2134.68,-764.35,0
    .goto 1413/1,-2134.68,-764.35,30,0
    .goto 1413/1,-2122.52,-734.62,20,0
    .goto 1414/1,-2061.94,-781.68,20,0
    .goto 1414/1,-2028.82,-828.29,10,0
    .goto 1414/1,-2021.46,-816.030,10 >>Sube por la montaña hasta la roca de encuentro de Las Cavernas de los Lamentos
    >>|cffff9a3cSigue de cerca la flecha para llegar a la cueva oculta|r
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cNalpak|r y |cff5cf05cEbru|r
    >>|cffff9a3cSe encuentran arriba de la entrada de las Cuevas de los Lamentos|r
    .accept 1486 >> Acepta la misión Pellejos descarriados
    .target +Nalpak
    .goto 1414/1,-2036.18,-796.40
    .accept 1487 >> Acepta la misión Erradicación de descarriados
    .target +Ebru
    .goto 1414/1,-2039.86,-801.31
step
    #completewith EnterWC
    +|cffff9a3cSe recomienda dividir las misiones "Reptilia" y "Pellejos descarriados" si solo vas a hacerla 1 vez|r
    >>|cffff9a3cNo habrá suficientes |cffe07cf5Reptilia|r ni |cff4fc3f7Pellejos descarriados|r para todos|r
    .isOnQuest 962,1486
step
    #optional
    #completewith EnterWC
    >>Despoja la |cffe07cf5Reptilia|r del suelo
    >>|cffff9a3cLanza|r |T133939:0|t[Buscar hierbas] |cffff9a3cpara verlas en tu minimapa|r
    .complete 962,1 --Serpentbloom (10)
    .skill herbalism,<1,1
    .isOnQuest 962
step
    #completewith EnterWC
    >>Despoja la |cffe07cf5Reptilia|r del suelo
    .complete 962,1 --Serpentbloom (10)
    .skill herbalism,1,1
    .isOnQuest 962
step
    #completewith EnterWC
    >>Mata a todas los |cffff5a4aBestias descarriadas|r que veas. Despójalas para obtener sus |cff4fc3f7Pellejos|r
    .complete 1486,1 --Deviate Hide (20)
    .isOnQuest 1486
    --Too many .mobs, would clutter target box
step
    #completewith EnterWC
    >>Mata a los |cffff5a4aEctoplasmas|r. Despójalos para obtener su |cff4fc3f7Esencia|r
    .complete 1491,1 --Wailing Essence (6)
    .isOnQuest 1491
step
    #label MadMagg
    #loop
    .goto 1414/1,-2058.26,-749.79,0
    .goto 1414/1,-2003.06,-659.01,0
    .goto 1414/1,-2072.98,-698.27,0
    .goto 1414/1,-2124.50,-730.16,0
    .goto 1414/1,-2058.26,-749.79,30,0
    .goto 1414/1,-2003.06,-659.01,30,0
    .goto 1414/1,-2072.98,-698.27,30,0
    .goto 1414/1,-2124.50,-730.16,30,0
    >>Mata al |cffff5a4aLoco Magglish|r. Despójalo para obtener el |cff4fc3f7Oporto con 99 años de antigüedad|r
    >>|cffff9a3cTiene un tiempo de reaparición largo. Omite este paso si no puedes encontrarlo|r
    .complete 959,1 --99-Year-Old Port (1)
    .mob Mad Magglish
    .isOnQuest 959
step
.enabledungeon WC
    #label EnterWC
    .goto 1414/1,-2028.82,-636.93,20,0
    .goto 1414/1,-2050.90,-585.41,20,0
    .goto 1414/1,-2168.66,-607.49,30,0
    .goto 1414/1,-2216.5,-742.43,30 >> Entra por el portal de la instancia a las Cuevas de los Lamentos. Entra en la mazmorra
step
    #optional
    #completewith GlowingShard
    >>Despoja la |cffe07cf5Reptilia|r del suelo
    >>|cffff9a3cSe recomienda que máximo 3 jugadores intenten completar esta misión si solo vas a hacerla 1 vez. No hay suficientes|r |cffe07cf5Reptilia|r |cffff9a3cpara todos|r
    >>|cffff9a3cLanza|r |T133939:0|t[Buscar hierbas] |cffff9a3cpara verlas en tu minimapa|r
    .complete 962,1 --Serpentbloom (10)
    .skill herbalism,<1,1
    .isOnQuest 962
step
    #optional
    #completewith GlowingShard
    >>Despoja la |cffe07cf5Reptilia|r del suelo
    >>|cffff9a3cSe recomienda que máximo 3 jugadores intenten completar esta misión si solo vas a hacerla 1 vez. No hay suficientes|r |cffe07cf5Reptilia|r |cffff9a3cpara todos|r
    .complete 962,1 --Serpentbloom (10)
    .skill herbalism,1,1
    .isOnQuest 962
step
    #optional
    #completewith GlowingShard
    >>Mata a los |cffff5a4aEctoplasmas|r. Despójalos para obtener su |cff4fc3f7Esencia|r
    >>|cffff9a3cSe recomienda que máximo 3 jugadores intenten completar esta misión si solo vas a hacerla 1 vez. No hay suficientes|r |cff4fc3f7Pellejos |r |cffff9a3cpara todos|r
    .complete 1491,1 --Wailing Essence (6)
    .isOnQuest 1491
step
    #completewith GlowingShard
    >>Mata |cffff5a4aDevastadores descarriados|r, |cffff5a4aVíboras|r, |cffff5a4aArrastrapiés|r y |cffff5a4aColminfernos|r
    .complete 1487,1 --Deviate Ravager (7)
    .mob +Deviate Ravager
    .complete 1487,2 --Deviate Viper (7)
    .mob +Deviate Viper
    .complete 1487,3 --Deviate Shambler (7)
    .mob +Deviate Shambler
    .complete 1487,4 --Deviate Dreadfang (7)
    .mob +Deviate Dreadfang
    .complete 1486,1 --Deviate Hide (20)
    .isOnQuest 1487
step
    #label Gems
    >>Mata a |cffff5a4aLord Cobrahn|r, |cffff5a4aLady Anacondra|r, |cffff5a4aLord Pythas|r y a |cffff5a4aLord Serpentis|r. Despójalos para obtener sus |cff4fc3f7Gemas|r
    .complete 914,1 --Gem of Cobrahn (1)
    .mob +Lord Cobrahn
    .complete 914,2 --Gem of Anacondra (1)
    .mob +Lady Anacondra
    .complete 914,3 --Gem of Pythas (1)
    .mob +Lord Pythas
    .complete 914,4 --Gem of Serpentis (1)
    .mob +Lord Serpentis
    .isOnQuest 914
step
    #requires Gems
    #completewith next
    +|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cDiscípulo de Naralex|r en la entrada de Cuevas de los Lamentos. Escóltalo a salvo hasta |cff5cf05cNaralex|r
    .target Disciple of Naralex
    .skipgossip
step
    #label GlowingShard
    >>Una vez que hayas llegado a |cff5cf05cNaralex|r, serás atacado por dos oleadas de enemigos y finalmente por |cffff5a4aMutanus el Devorador|r
    >>Mátalo y despójalo para obtener el |T135229:0|t[|cff4fc3f7Fragmento resplandeciente|r] y úsalo para iniciar la misión
    .collect 10441,1 --Collect Glowing Shard (x1)
    .accept 6981 >> Acepta la misión El fragmento resplandeciente
    .use 10441
    .mob Mutanus the Devourer
step
    #optional
    #completewith DeviateRaptors
    >>Mata a los |cffff5a4aEctoplasmas|r. Despójalos para obtener su |cff4fc3f7Esencia|r
    .complete 1491,1 --Wailing Essence (6)
    .isOnQuest 1491
step
    #optional
    #completewith Ectoplasms
    >>Despoja la |cffe07cf5Reptilia|r del suelo
    >>|cffff9a3cLanza|r |T133939:0|t[Buscar hierbas] |cffff9a3cpara verlas en tu minimapa|r
    >>|cffff9a3c¡La mayor parte de la |cffe07cf5Reptilia|r debería haber reaparecido después de matar al jefe final!|r
    .complete 962,1 --Serpentbloom (10)
    .skill herbalism,<1,1
    .isOnQuest 962
step
    #optional
    #completewith Ectoplasms
    >>Despoja la |cffe07cf5Reptilia|r del suelo
    >>|cffff9a3c¡La mayor parte de la |cffe07cf5Reptilia|r debería haber reaparecido después de matar al jefe final!|r
    .complete 962,1 --Serpentbloom (10)
    .skill herbalism,1,1
    .isOnQuest 962
step
    #optional
    >>Mata |cffff5a4aDevastadores descarriado|r, |cffff5a4aVíboras|r, |cffff5a4aArrastrapiés|r y |cffff5a4aColminfernos|r. . Despójalos para obtener sus |cffff5a4aPellejos|r
    .complete 1487,1 --Deviate Ravager (7)
    .mob +Deviate Ravager
    .complete 1487,2 --Deviate Viper (7)
    .mob +Deviate Viper
    .complete 1487,3 --Deviate Shambler (7)
    .mob +Deviate Shambler
    .complete 1487,4 --Deviate Dreadfang (7)
    .mob +Deviate Dreadfang
    .complete 1486,1 --Deviate Hide (20)
    .disablecheckbox
    .isOnQuest 1487
    .isOnQuest 1486
 step
    >>Mata |cffff5a4aDevastadores descarriados|r, |cffff5a4aVíboras|r, |cffff5a4aArrastrapiés|r y |cffff5a4aColminfernos|r
    .complete 1487,1 --Deviate Ravager (7)
    .mob +Deviate Ravager
    .complete 1487,2 --Deviate Viper (7)
    .mob +Deviate Viper
    .complete 1487,3 --Deviate Shambler (7)
    .mob +Deviate Shambler
    .complete 1487,4 --Deviate Dreadfang (7)
    .mob +Deviate Dreadfang
    .isOnQuest 1487
step
    #label DeviateRaptors
    >>Mata |cffff5a4aRaptores descarriados|r. Despójalos para obtener sus |cffff5a4aPellejos|r
    .complete 1486,1 --Deviate Hide (20)
    .mob Deviate Ravager
    .mob Deviate Viper
    .mob Deviate Shambler
    .mob Deviate Dreadfang
    .isOnQuest 1486
step
    #label Ectoplasms
    >>Mata a los |cffff5a4aEctoplasmas|r. Despójalos para obtener su |cff4fc3f7Esencia|r
    .complete 1491,1 --Wailing Essence (6)
    .mob Devouring Ectoplasm
    .mob Evolving Ectoplasm
    .mob Nightmare Ectoplasm
    .isOnQuest 1491
step
    #optional
    >>Despoja la |cffe07cf5Reptilia|r del suelo
    >>|cffff9a3cSe recomienda que máximo 3 jugadores intenten completar esta misión si solo vas a hacerla 1 vez. No hay suficientes|r |cffe07cf5Reptilia|r |cffff9a3cpara todos|r
    >>|cffff9a3cLanza|r |T133939:0|t[Buscar hierbas] |cffff9a3cpara verlas en tu minimapa|r
    .complete 962,1 --Serpentbloom (10)
    .skill herbalism,<1,1
    .isOnQuest 962
step
    >>Despoja la |cffe07cf5Reptilia|r del suelo
    >>|cffff9a3cSe recomienda que máximo 3 jugadores intenten completar esta misión si solo vas a hacerla 1 vez. No hay suficientes|r |cffe07cf5Reptilia|r |cffff9a3cpara todos|r
    .complete 962,1 --Serpentbloom (10)
    .skill herbalism,1,1
    .isOnQuest 962
step
    #completewith GShard
    .subzone 380 >>Abandona tu grupo mientras estés dentro de Cuevas de los Lamentos para teletransportarte al cementerio de El Cruce (tras 1 minuto)
    .subzoneskip 392
step
    #completewith Cholaruk
    >>|cffff9a3cConsulta con tu grupo si quieren hacer la misión "Chol'aruk, el Insaciable"|r (élite nivel 20)
    .isQuestAvailable 97003
step
    .goto 1413/1,-2711.800,-350.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGur'ak|r
    .accept 97003 >>Acepta la misión Chol'aruk, el Insaciable
    .target Gur'ak
step
    #completewith next
    .goto 1413/1,-3257.300,-113.100,15,0
    .goto 1413/1,-3217.100,-147.700,10,0
    .goto 1413/1,-3236.000,-178.100,10,0
    .goto 1413/1,-3259.700,-205.400,10,0
    .goto 1413/1,-3226.900,-237.900,10 >>Ve hacia |cffff5a4aChol'aruk El Insaciable|r al fondo de la cueva
step
    #label Cholaruk
    .goto 1413/1,-3206.800,-220.200
    >>Mata a |cffff5a4aChol'aruk El Insaciable|r. Despójalo para obtener su |cff4fc3f7Cabeza|r
    .complete 97003,1 --Chol'aruk's Head (x1)
    .mob Chol'aruk the Ravener
    .isOnQuest 97003
step
    #completewith GShard
    .subzone 392 >>Viaja a Trinquete
    .subzoneskip 1699,1 --Thorn Hill
step
    #completewith GShard
    .goto 1413/1,-2595.75,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDevrak|r
    .fly Ratchet >> Vuela a Trinquete
    .target Devrak
    .subzoneskip 392
    .subzoneskip 1699 --Thorn Hill
step
    .goto 1413/1,-3697.24,-929.20
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMebok|r
    .turnin 1491 >>Entrega la misión Bebidas de inteligencia
    .accept 1221 >> Acepta la misión Los tubérculos hojazul
    .target Mebok Mizzyrix
    .isQuestComplete 1491
step
    #optional
    .goto 1413/1,-3697.24,-928.86--c:The Barrens,62.370,37.615
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMebok|r
    .accept 1221 >> Acepta la misión Los tubérculos hojazul
    .target Mebok Mizzyrix
step
    .goto 1413/1,-3770.20,-928.53
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cPelardo|r
    .turnin 959 >> Entrega la misión ¡A por la botella!
    .target Crane Operator Bigglefuzz
    .isQuestComplete 959
step
    #label GShard
    .goto 1413/1,-3760.07,-902.18
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cPetardol|r
    .complete 6981,1 --Speak with someone in Ratchet about the Glowing Shard
    .skipgossip
    .target Sputtervalve
    .isOnQuest 6981
step << Shaman
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cIslen|r y |cff5cf05cMahren Vidente del Cielo|r
    .turnin 1529 >>Entrega la misión La llamada del agua
    .accept 1530 >>Acepta la misión La llamada del agua
    .target +Islen Waterseer
    .goto 1413/1,-4047.86,-1345.39--c:The Barrens,65.83,43.78
    .turnin 874 >>Entrega la misión Mahren Vidente del Cielo
    .accept 873 >>Acepta la misión Isha Awak
    .target +Mahren Skyseer
    .goto 1413/1,-4047.86,-1350.79--c:The Barrens,65.83,43.86
    .isOnQuest 1529
step << Shaman
    #optional
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cIslen|r y |cff5cf05cMahren Vidente del Cielo|r
    .turnin 1528 >>Entrega la misión La llamada del agua
    .accept 1530 >>Acepta la misión La llamada del agua
    .target +Islen Waterseer
    .goto 1413/1,-4047.86,-1345.39--c:The Barrens,65.83,43.78
    .turnin 874 >>Entrega la misión Mahren Vidente del Cielo
    .accept 873 >>Acepta la misión Isha Awak
    .target +Mahren Skyseer
    .goto 1413/1,-4047.86,-1350.79--c:The Barrens,65.83,43.86
    .isOnQuest 1528
step << Shaman
    #optional
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cIslen|r y |cff5cf05cMahren Vidente del Cielo|r
    .accept 1530 >>Acepta la misión La llamada del agua
    .target +Islen Waterseer
    .goto 1413/1,-4047.86,-1345.39--c:The Barrens,65.83,43.78
    .turnin 874 >>Entrega la misión Mahren Vidente del Cielo
    .accept 873 >>Acepta la misión Isha Awak
    .target +Mahren Skyseer
    .goto 1413/1,-4047.86,-1350.79--c:The Barrens,65.83,43.86
    .isQuestTurnedIn 1529
step << Shaman
    #optional
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cIslen|r y |cff5cf05cMahren Vidente del Cielo|r
    .accept 1530 >>Acepta la misión La llamada del agua
    .target +Islen Waterseer
    .goto 1413/1,-4047.86,-1345.39--c:The Barrens,65.83,43.78
    .turnin 874 >>Entrega la misión Mahren Vidente del Cielo
    .accept 873 >>Acepta la misión Isha Awak
    .target +Mahren Skyseer
    .goto 1413/1,-4047.86,-1350.79--c:The Barrens,65.83,43.86
    .isQuestTurnedIn 1528
step
    #optional << Shaman
    .goto 1413/1,-4048.87,-1350.79
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMahren|r
    .turnin 874 >>Entrega la misión Mahren Vidente del Cielo
    .accept 873 >>Acepta la misión Isha Awak
    .target Mahren Skyseer
    .isOnQuest 874
step
    #optional
    .goto 1413/1,-4048.87,-1350.79
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMahren|r
    .accept 873 >>Acepta la misión Isha Awak
    .target Mahren Skyseer
    .isQuestTurnedIn 874
step
    #loop
    .goto 1413/1,-4031.64,-1537.94,0
    .goto 1413/1,-3937.4,-1789.27,0
    .goto 1413/1,-3821.88,-2004.8,0
    .goto 1413/1,-4041.78,-1446.73,50,0
    .goto 1413/1,-4031.64,-1537.94,50,0
    .goto 1413/1,-3937.4,-1789.27,50,0
    .goto 1413/1,-3821.88,-2004.8,50,0
    >>Mata a |cffff5a4aIsha Awak|r. Despójalo para obtener el |cff4fc3f7Corazón de Isha Awak|r
    >>|cffff9a3cÉl tiene cuatro ubicaciones de aparición diferentes a lo largo de la costa|r
    .complete 873,1 --Heart of Isha Awak
    .unitscan Isha Awak
    .isQuestTurnedIn 874
step
    .goto 1413/1,-4048.87,-1350.79
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMahren|r
    .turnin 873 >> Entrega la misión Isha Awak
    .target Mahren Skyseer
    .isQuestComplete 873
step
    #completewith TopofWCturnins
    .goto 1413/1,-3770.20,-898.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBragok|r
    .fly Crossroads >> Vuela a El Cruce
    .target Bragok
    .subzoneskip 380
step
    .goto 1413/1,-2711.800,-350.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGur'ak|r
    .turnin 97003 >>Entrega la misión Chol'aruk, el Insaciable
    .target Gur'ak
    .isQuestComplete 97003
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 852 >>Entrega la misión Hezrul Marcasangre
    .target Regthar Deathgate
    .isQuestComplete 852
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 855 >>Entrega la misión Los brazales centauro
    .target Regthar Deathgate
    .isQuestComplete 855
step
    #completewith CounterattackTurnin2
    +|cffff9a3cLa próxima misión es muy difícil y se recomienda formar un grupo. Puedes kitear al |cffff5a4aSeñor de la guerra Krom'zar|r alrededor del edificio donde se encuentra el PNJ que da la misión|r
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .accept 4021 >>Acepta la misión ¡Contraataca!
    .target Regthar Deathgate
    --.timer 183,Warlord Krom'zar Spawn
    .isQuestTurnedIn 852
    --timer is random, generally somewhere between 120-210 seconds
step
    .goto 1413/1,-1884.39,-289.38
    >>Mata al |cffff5a4aSeñor de la Guerra Krom'zar|r una vez que aparece. Despoja el |cffe07cf5Estandarte|r que deja en el suelo
    >>|cffff9a3c¡Ten cuidado! Es un élite fuerte y está custodiado por al menos dos|r |cffff5a4aKolkar|r |cffff9a3cenemigos|r
    >>|cffff9a3cPuede tardar hasta 3 minutos en reaparecer|r
    .link https://www.youtube.com/watch?v=xrm0PWe5wf4 >>|cffff9a3cHaz clic aquí para una guía en video sobre cómo hacer "kiting" al|r |cffff5a4aSeñor de la Guerra Krom'zar|r
    .complete 4021,1 --Piece of Krom'zar's Banner (1)
    .unitscan Warlord Krom'zar
    .isQuestTurnedIn 852
step
    #label CounterattackTurnin2
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 4021 >>Entrega la misión ¡Contraataca!
    .target Regthar Deathgate
    .isQuestComplete 4021
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 855 >>Entrega la misión Los brazales centauro
    .target Regthar Deathgate
    .isQuestComplete 855
step
    #optional
    #completewith TopofWCturnins
    .abandon 855 >>Abandona la misión Los brazales centauro
step
    #optional
    #completewith TopofWCturnins
    .abandon 97003 >>Abandona la misión Chol'aruk, el Insaciable
step
    #optional
    #completewith TopofWCturnins
    .abandon 4021 >>Abandona la misión ¡Contraataca!
step
    #completewith next
    .goto 1413/1,-2493.40,-708.95,20,0
    .goto 1413/1,-2404.23,-721.11,20,0
    .goto 1413/1,-2356.60,-685.98,20,0
    .goto 1413/1,-2259.32,-602.20,50 >> Sube por la montaña
step
    .goto 1413/1,-2259.32,-602.20
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cFala|r
    .turnin 6981 >> Entrega la misión El fragmento resplandeciente
    .accept 3369 >> Acepta la misión En las pesadillas
    .target Falla Sagewind
    .isOnQuest 6981
step
    .goto 1413/1,-2259.32,-602.20
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cFala|r
    .accept 3369 >> Acepta la misión En las pesadillas
    .target Falla Sagewind
    .isQuestTurnedIn 6981
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cNalpak|r y |cff5cf05cEbru|r
    >>|cffff9a3cSe encuentran arriba de la entrada de las Cuevas de los Lamentos|r
    .turnin 1486 >> Entrega la misión Pellejos descarriados
    .target +Nalpak
    .goto 1414/1,-2036.18,-796.40
    .turnin 1487 >> Entrega la misión Erradicación de descarriados
    .target +Ebru
    .goto 1414/1,-2039.86,-801.31
    .isQuestComplete 1487
    .isQuestComplete 1486
step
    #optional
    .goto 1414/1,-2039.86,-801.31
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cEbru|r
    >>|cffff9a3cSe encuentra encima de la entrada de las Cuevas de los Lamentos|r
    .turnin 1487 >> Entrega la misión Erradicación de descarriados
    .target Ebru
    .isQuestComplete 1487
step
    #optional
    #label TopofWCturnins
    .goto 1414/1,-2036.18,-796.40
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cNalpak|r
    >>|cffff9a3cSe encuentra encima de la entrada de las Cuevas de los Lamentos|r
    .turnin 1486 >> Entrega la misión Pellejos descarriados
    .target Nalpak
    .isQuestComplete 1486
step
    #completewith WCEnd
    .hs >> Usa tu Piedra de hogar para ir a Cima del Trueno
    .bindlocation 1638,1
    .zoneskip Thunder Bluff
    .use 6948
step
    .goto 1456/1,-272.93,-1069.67
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cNara|r
    .turnin 914 >>Entrega la misión Líderes del Colmillo
    .target Nara Wildmane
    .isQuestComplete 914
step
    .goto 1456/1,-303.83,-1048.66
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHamuul|r
    .turnin 3369 >> Entrega la misión En las pesadillas
    .target Arch Druid Hamuul Runetotem
    .isOnQuest 3369
step
    #completewith next
    .goto 1456/1,219.09,-1051.44,10 >> Viaja al Alto de los Espíritus y entra en las pozas de las visiones
    .isQuestComplete 962
step
    #label WCEnd
    .goto 1456/1,276.6,-996.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cBoticaria Zamah|r
    .turnin 962 >>Entrega la misión Reptilia
    .target Apothecary Zamah
    .isQuestComplete 962
step << Paladin
    #optional
    .goto 1456/1,253.900,-950.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAlodan|r
    .train 1866 >>Aprende tus hechizos de clase
    .target Alodan the Hopeful 
    .xp <20,1
    .xp >22,1
step << Paladin
    .goto 1456/1,253.900,-950.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAlodan|r
    .train 1026 >>Aprende tus hechizos de clase
    .target Alodan the Hopeful 
    .xp <22,1
step
    #optional
    .abandon 1486 >>Abandona la misión Pellejos descarriados
step
    #optional
    .abandon 1487 >>Abandona la misión Erradicación de descarriados
step
    #optional
    .abandon 1491 >>Abandona la misión Bebidas de inteligencia
step
    #optional
    .abandon 959 >>Abandona la misión ¡A por la botella!
step
    #optional
    .abandon 914 >>Abandona la misión Líderes del Colmillo
step
    #optional
    .abandon 962 >>Abandona la misión Reptilia
step << Warlock/Shaman
    .goto 1456/1,26.1,-1196.66
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTal|r
    .fly Camp Taurajo >>Vuela al Campamento Taurajo
    .target Tal
    .zoneskip The Barrens
step << Warlock
    .goto 1413/1,-1898.58,-2391.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLogmar|r
    .turnin 1511 >>Entrega la misión Jarabe de Ken'zigla
    .accept 1515 >>Acepta la misión El cautiverio de Dogran
    .target Grunt Logmar
step << Warlock
    .goto 1413/1,-1765.83,-1622.39
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDogran|r
    .turnin 1515 >>Entrega la misión El cautiverio de Dogran
    .accept 1512 >>Acepta la misión Un regalo de amor
    .target Grunt Dogran
step << Shaman
    #completewith CallofWater2
    .goto 1413/1,-1776.98,-3617.51,60>> Viaja al sur hacia |cff5cf05cSalmuera|r
step << Shaman
    #label CallofWater2
    .goto 1413/1,-1776.98,-3617.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSalmuera|r
    .turnin 1530 >>Entrega la misión La llamada del agua
    .accept 1535 >>Acepta la misión La llamada del agua
    .target Brine
step << Shaman
    .goto 1413/1,-1858.04,-3572.92
    .use 7766 >> |cffff9a3cLlena tu|r |T132825:0|t[Odre de agua marrón vacío] |cffff9a3cen la charca debajo de la cabaña de Salmuera|r
    .complete 1535,1 --Filled Brown Waterskin (1)
step << Shaman
    .goto 1413/1,-1776.98,-3617.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSalmuera|r
    .turnin 1535 >>Entrega la misión La llamada del agua
    .accept 1536 >>Acepta la misión La llamada del agua
    .target Brine
step << Warlock/Shaman
    #completewith next
    .subzone 378 >>Viaja de vuelta hacia Campamento Taurajo
step << Warlock/Shaman
    .goto 1413/1,-1881.35,-2384.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOmusa|r
    .fly Orgrimmar >>Vuela a Orgrimmar
    .target Omusa Thunderhorn
    .zoneskip Orgrimmar
step << !Warlock
    .goto 1456/1,26.1,-1196.66
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTal|r
    .fly Orgrimmar >>Vuela a Orgrimmar
    .target Tal
    .zoneskip Orgrimmar
step << Warlock
    .goto 1454/1,-4357.36,1850.41
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGan'rul|r
    .turnin 1512 >>Entrega la misión Un regalo de amor
    .accept 1513 >>Acepta la misión El vínculo
    .target Gan'rul Bloodeye
step << Warlock
    #completewith next
    .cast 9224 >>|cffff9a3cUsa el|r |T133290:0|t[Colgante de Dogran] |cffff9a3cen el Círculo de Invocación|r
    .use 6626
step << Warlock
    .goto 1454/1,-4377.13,1804.77
    >>Mata a la |cffff5a4aSúcubo invocado|r
    .complete 1513,1 --Kill Summoned Succubus (1)
    .mob Summoned Succubus
    .use 6626
step << Warlock
    .goto 1454/1,-4357.36,1850.41
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGan'rul|r
    .turnin 1513 >>Entrega la misión El vínculo
    .target Gan'rul Bloodeye
step << Warlock
    .goto 1454/1,-4362.55,1834.70
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMirket|r
    .train 6202 >> Aprende tus hechizos de clase
    .target Mirket
    .xp <22,1
    .xp >24,1
step << Warlock
    #optional
    .goto 1454/1,-4362.55,1834.70
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMirket|r
    .train 6223 >> Aprende tus hechizos de clase
    .target Mirket
    .xp <24,1
step << Rogue
    #completewith next
    .goto 1454/1,-4320.75,1750.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cKareth|r|cffe07cf5. Cómprale una|r |T135640:0|t[Jambiya] |cffe07cf5si no tienes una daga|r
    .collect 2207,1 --Collect Jambiya (1)
    .target Kareth
step << Rogue
    .goto 1454/1,-4284.42,1771.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShenthul|r
    .train 921 >>Aprende |T133644:0|t[Robar]
    .train 8676 >>Aprende |T132282:0|t[Emboscada]
    .train 1943 >>Aprende |T132302:0|t[Ruptura]
    .train 1856 >>Aprende |T132331:0|t[Esfumarse]
    .train 1725 >>Aprende |T132289:0|t[Distraer]
    .train 1785 >>Aprende |T132320:0|t[Sigilo Rango 2]
    .accept 2460 >>Acepta la misión El saludo de los Mano Destrozada
    .target Shenthul
step << Rogue
    .goto 1454/1,-4284.42,1771.28
    >>Después de que |cff5cf05cShenthul|r haga su saludo, escribe /Salute mientras lo tienes seleccionado como objetivo
    .complete 2460,1 --Shattered Salute Performed (1)
    .target Shenthul
step << Rogue
    .goto 1454/1,-4284.42,1771.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShenthul|r
    .turnin 2460 >>Entrega la misión El saludo de los Mano Destrozada
    .accept 2458 >>Acepta la misión Agente encubierto
    .target Shenthul
step << Rogue
    .goto 1454/1,-4271.1,1810.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cRekkul|r|cffe07cf5. Compra |r |T134387:0|t[Pólvora cegadora] |cffe07cf5a este vendedor|r
    .collect 2928,40,2479,1 --Collect Dust of Decay (40)
    .collect 3371,40,2479,1 --Collect Empty Vial (40)
    .collect 5140,20,2479,1 --Collect Flash Powder (20)
    .target Rekkul
step << Priest/Warlock
    .goto 1454/1,-4299.99,1820.67
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cKatis|r|cffe07cf5. Compra una|r |T135139:0|t[Varita ardiente] |cffe07cf5a esta vendedora|r
    .collect 5210,1,1507,1 --Collect Burning Wand (1)
    .money <0.5808
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<17.4
    .target Katis
step << Mage
    .goto 1454/1,-4218.64,1473.72
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cPephredo|r
    .train 2138 >> Aprende tus hechizos de clase
    .target Pephredo
    .xp <22,1
    .xp >24,1
step << Mage
    #optional
    .goto 1454/1,-4218.64,1473.72
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cPephredo|r
    .train 2121 >> Aprende tus hechizos de clase
    .target Pephredo
    .xp <24,1
step << Mage
    .goto 1454/1,-4222.85,1474.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cThuul|r en lo alto de la cabaña
    .train 3567 >> Aprende |T135759:0|t[Teletransporte a: Orgrimmar]
    .target Thuul
step << Troll Priest
    .goto 1454/1,-4179.79,1452.580
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cUr'kyo|r
    .turnin 5642 >> Entrega la misión Guardia de las Sombras
    .trainer >> Aprende tus hechizos de clase
    .target Ur'kyo
step << Undead Priest
    .goto 1454/1,-4179.79,1452.580
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cUr'kyo|r
    .train 8103 >> Aprende tus hechizos de clase
    .target Ur'kyo
    .xp <22,1
    .xp >24,1
step << Undead Priest
    #optional
    .goto 1454/1,-4179.79,1452.580
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cUr'kyo|r
    .train 3747 >> Aprende tus hechizos de clase
    .target Ur'kyo
    .xp <24,1
step << Rogue/Druid
    #completewith MissionProbable
    .goto 1454/1,-4048.36,1697.85,80,0
    .goto 1454/1,-3900.25,1681.48,30,0
    .goto 1454/1,-3933.49,1707.86,50 >> Entra en Los Baldíos a través de la salida occidental
    .zoneskip The Barrens
step << Rogue/Druid
    #completewith MissionProbable
    .goto 1413/1,-3216.92,1107.13,120 >> Viaja hacia el Fangal
step << Druid
    .goto 1413/1,-3119.64,1050.38
    >>Despoja el |cffe07cf5Arcón extraño|r en el agua para obtener la |T133443:0|t[Medio colgante de Agilidad acuática]
    .collect 15883,1,31,1 --Half Pendant of Aquatic Agility (1)
step << Rogue
    #completewith next
    .goto 1413/1,-3021.35,1214.56
	+Selecciona al |cff5cf05cCapataz Fizzule|r, luego usa tu |T134536:0|t[Pistola de bengalas] DOS VECES y escribe /Salute
    >>|cffff9a3c¡Ten cuidado! ¡NO te acerques a él hasta que se vuelva amistoso o te atacará!|r
    .use 8051
    .target Taskmaster Fizzule
step << Rogue
    .goto 1413/1,-2995.0,1236.85
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el|r |cff5cf05cCapataz Fizzule|r
    .turnin 2458 >>Entrega la misión Agente encubierto
    .accept 2478 >>Acepta la misión Misión: Posible, pero no probable
    .target Taskmaster Fizzule
step << Rogue/Druid
    #optional
    #label MissionProbable
step << Rogue
    .goto 1413/1,-2930.15,1209.15
    >>Usa |T133644:0|t[Robar] en el |cffff5a4aSupervisor Silixiz|r para obtener su |cff4fc3f7Llave de la torre|r
    .complete 2478,5 --Silixiz's Tower Key (1)
    .mob Foreman Silixiz
step << Rogue
    #completewith roguetowerq
    +|cffff9a3cCada enemigo aquí recibirá más daño de ciertas habilidades|r
    >>Usa |T132282:0|t[Emboscada] sobre los |cffff5a4aZánganos mutados de Ventura y Cía.|r
    >>Usa |T132302:0|t[Ruptura] sobre las |cffff5a4aPatrullas de Ventura y Cía.|r
    >>Usa |T132292:0|t[Eviscerar] sobre los |cffff5a4aOteadores de Ventura y Cía.|r una vez (1 punto de combo)
step << Rogue
    #label roguetowerq
    .goto 1413/1,-2922.04,1224.69
    >>Corre hacia la Torre del Pícaro y mata a los |cffff5a4aZánganos|r, |cffff5a4aPatrullas|r y |cffff5a4aOteadores|r
    .complete 2478,1 --Mutated Venture Co. Drone (2)
    .mob +Mutated Venture Co. Drone
    .complete 2478,3 --Venture Co. Patroller (2)
    .mob +Venture Co. Patroller
    .complete 2478,2 --Venture Co. Lookout (2)
    .mob +Venture Co. Lookout
step << Rogue
    .goto 1413/1,-2927.11,1236.18
    >>En la cima de la torre encontrarás a |cffff5a4aGallywix|r. Despójalo para obtener su |cff4fc3f7Cabeza|r
    >>|cffff9a3cUsa|r |T132282:0|t[Emboscada] |cffff9a3cpara reducir su vida a la mitad. Usa|r |T132155:0|t[Gubia] |cffff9a3cpara restaurar energía y usa|r |T136205:0|t[Evasión]
	>>|cffff9a3cRecuerda usar una Poción y|r |T132819:0|t[Té de cardo] |cffff9a3csi es necesario|r
    .complete 2478,4 --Gallywix's Head (1)
    .mob Grand Foreman Puzik Gallywix
    --VV Video?
step << Rogue
    .goto 1413/1,-2927.11,1236.18
    >>Usa tu Forzar cerraduras para abrir el |cffe07cf5Arcón de Gallywix|r y despoja la |cff4fc3f7Mezcla|r
    .complete 2478,6 --Cache of Zanzil's Altered Mixture (1)
step << skip --Rogue/Druid
    #hardcore
    #completewith next
    .goto 1413/1,-3591.86,1328.06,120 >>Viaja hacia la Mina Pedrusco
step << skip --Rogue/Druid
    #hardcore
    .goto 1413/1,-3505.72,1358.46
    .goto 1454/1,-4242.34,1637.33,30 >>|cffff9a3cSalta a la viga de madera. Haz un Logout Skip desconectando y volviendo a entrar. Regresa a Orgrimmar si no lo logras|r
    .link https://www.youtube.com/watch?v=U7YfoaO-X8E >> |cffff9a3cHAZ CLIC AQUÍ para ver un ejemplo|r
    .zoneskip Orgrimmar
step << Rogue/Druid
    #softcore
    #completewith next
    .deathskip >> Muere y reaparece en el |cff5cf05cÁngel de la Resurrección|r
step << Rogue/Druid
    #softcore
    .goto 1413/1,-2595.75,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDevrak|r
    .fly Orgrimmar >> Vuela a Orgrimmar
    .zoneskip Orgrimmar
    .target Devrak
step << Rogue/Druid
    #hardcore
    #completewith flytoORG
    .goto 1414/1,-3839.37,1644.65
    .zone Orgrimmar >>Entra en Orgrimmar por la entrada occidental
step << Rogue
    .goto 1454/1,-4284.42,1771.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShenthul|r
    .turnin 2478 >>Entrega la misión Misión: Posible, pero no probable
    .accept 2479 >>Acepta la misión La ayuda de Hinott
    .target Shenthul
step << Rogue
    .goto 1454/1,-4271.1,1810.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cRekkul|r|cffe07cf5. Compra|r |T133849:0|t[Polvo de Decadencia] |cffe07cf5y|r |T132793:0|t[Viales vacíos] |cffe07cf5a este vendedor|r
    .collect 2928,20,2479,1 --Collect Dust of Decay (20)
    .collect 3371,20,2479,1 --Collect Empty Vial (20)
    .target Rekkul
step << Shaman
    .goto 1454/1,-4225.09,1933.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKardris|r
    .train 8498 >> Aprende tus hechizos de clase
    .target Kardris Dreamseeker
    .xp <22,1
    .xp >24,1
step << Shaman
    #optional
    .goto 1454/1,-4225.09,1933.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKardris|r
    .train 905 >> Aprende tus hechizos de clase
    .target Kardris Dreamseeker
    .xp <24,1
step << Troll Warrior/Undead Warrior/Tauren Warrior/Undead Paladin
    .goto 1454/1,-4824.00,2090.540
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHanashi|r
    .train 197 >>Aprende el uso de Hachas de dos manos
    .train 2567 >> Aprende el uso de Arrojadizas << !Paladin
    .target Hanashi
step << Orc Warrior
    .goto 1454/1,-4824.00,2090.540
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHanashi|r
    .train 2567 >> Aprende el uso de Arrojadizas
    .target Hanashi
step << Warrior
    .goto 1454/1,-4801.42,1980.53
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGrezz|r
    .train 6192 >> Aprende tus hechizos de clase
    .target Grezz Ragefist
    .xp <22,1
    .xp >24,1
step << Warrior
    #optional
    .goto 1454/1,-4801.42,1980.53
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGrezz|r
    .train 5308 >> Aprende tus hechizos de clase
    .target Grezz Ragefist
    .xp <24,1
step << Hunter
    .goto 1454/1,-4607.02,2100.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOrmak|r
    .train 14323 >> Aprende tus hechizos de clase
    .target Ormak Grimshot
    .xp <22,1
    .xp >24,1
step << Hunter
    #optional
    .goto 1454/1,-4607.02,2100.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOrmak|r
    .train 14262 >> Aprende tus hechizos de clase
    .target Ormak Grimshot
    .xp <24,1
step << Hunter
    .goto 1454/1,-4611.09,2135.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cXao'tsu|r
    .train 24558 >> Entrena los hechizos de tu mascota
    .target Xao'tsu
    .xp <24,1
step << skip --Rogue
    .goto 1454/1,-4355.53,1520.68
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cTrak'gen|r|cffe07cf5. Compra|r |T135423:0|t[Hacha arrojadiza mortal] |cffe07cf5a este vendedor|r
    .collect 3137,1,6544,1 --Deadly Throwing Axe (200)
    .target Trak'gen
step << Rogue
    >>|cffff9a3cSi tienes algún|r |T134437:0|t[Contraveneno]|cffff9a3c, úsalo para curarte del|r |T136230:0|t[Toque de Zanzil]
    .itemcount 6452,1
    .use 6452
    .aura -9991
step << Rogue
    #optional
    .destroy 8051 >> |cffff9a3cBorra la|r |T134536:0|t[Pistola de bengalas] |cffff9a3cde tu inventario, ya que ya no la necesitas|r
    .destroy 8066 >> |cffff9a3cBorra|r |T134374:0|t[Silbato de Fizzule] |cffff9a3cde tu inventario, ya que ya no lo necesitas|r
step
    #optional
    #label flytoORG
]=], "Horde"}
