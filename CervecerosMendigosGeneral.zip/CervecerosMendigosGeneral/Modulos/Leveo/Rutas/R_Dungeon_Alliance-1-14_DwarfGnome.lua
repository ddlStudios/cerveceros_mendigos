-- GENERADO por _suite/herramientas/leveo_rutas.py: no editar a mano.
-- Ruta de subida de RestedXP (RXPGuides), traducida y adaptada a WoW Forever por Brudda FastXP.
-- Licencia de este archivo: CC BY-NC-SA 4.0 (ver LICENCIA_RUTAS.txt).
local _, ns = ...
local R = ns.LeveoRutas or {}
ns.LeveoRutas = R
R[#R + 1] = {[=[
#forever
#version 1
<< Alliance
#group Forever Guía de Mazmorras (A)
#subgroup Mazmorras 1-20
#name 1-5 Valle de Crestanevada
#next 5-11 Dun Morogh
#defaultfor Dwarf/Gnome

step
#include Guía Forever (A)\1-5 Valle de Crestanevada
]=], "Alliance"}
R[#R + 1] = {[=[
#forever
#version 1
<< Alliance
#group Forever Guía de Mazmorras (A)
#subgroup Mazmorras 1-20
#name 5-11 Dun Morogh
#next 11-12 Elwynn (Enano/Gnomo);11-12 Misión del Abisario;12-14 Loch Modan (Enano/Gnomo);11-13 Loch Modan (Cazador)
#defaultfor Dwarf/Gnome

step
#include Guía Forever (A)\5-11 Dun Morogh
]=], "Alliance"}
R[#R + 1] = {[=[
#forever
<< Alliance !Hunter
#group Forever Guía de Mazmorras (A)
#subgroup Mazmorras 1-20
#name 11-12 Elwynn (Enano/Gnomo)
#version 1
#defaultfor Gnome/Dwarf
#next 12-14 Loch Modan (Enano/Gnomo)

step
#include Guía Forever (A)\11-12 Elwynn (Enano/Gnomo)
]=], "Alliance"}
R[#R + 1] = {[=[
#forever
#version 1
<< Alliance !Hunter
#group Forever Guía de Mazmorras (A)
#subgroup Mazmorras 1-20
#name 12-14 Loch Modan (Enano/Gnomo)
#next 13-15 Páramos de Poniente
#defaultfor Gnome/Dwarf

step
#include Guía Forever (A)\12-14 Loch Modan (Enano/Gnomo)
]=], "Alliance"}
R[#R + 1] = {[=[
#forever
#version 1
<< Alliance Hunter
#group Forever Guía de Mazmorras (A)
#subgroup Mazmorras 1-20
#name 11-13 Loch Modan (Cazador)
#next 13-15 Páramos de Poniente
#defaultfor Dwarf

step
#include Guía Forever (A)\11-13 Loch Modan (Cazador)@NormalRouteStart-NormalRouteEnd
]=], "Alliance"}
