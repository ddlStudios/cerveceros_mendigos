-- GENERADO por _suite/herramientas/leveo_rutas.py: no editar a mano.
-- Ruta de subida de RestedXP (RXPGuides), traducida y adaptada a WoW Forever por Brudda FastXP.
-- Licencia de este archivo: CC BY-NC-SA 4.0 (ver LICENCIA_RUTAS.txt).
local _, ns = ...
local R = ns.LeveoRutas or {}
ns.LeveoRutas = R
R[#R + 1] = {[=[
#forever
#season 0,1
<< Alliance
#name 1-6 Cañada Umbría
#version 1
#group Forever Guía de Mazmorras (A)
#subgroup Mazmorras 1-20
#defaultfor NightElf
#next 6-11 Teldrassil
step
#include Guía Forever (A)\1-6 Cañada Umbría
]=], "Alliance"}
R[#R + 1] = {[=[
#forever
#season 0,1
<< Alliance
#name 6-11 Teldrassil
#version 1
#group Forever Guía de Mazmorras (A)
#subgroup Mazmorras 1-20
#defaultfor NightElf
#next 11-16 Costa Oscura/Loch Modan

step
#include Guía Forever (A)\6-11 Teldrassil
]=], "Alliance"}
