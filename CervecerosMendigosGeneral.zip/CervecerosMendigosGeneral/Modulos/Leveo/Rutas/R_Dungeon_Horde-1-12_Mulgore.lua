-- GENERADO por _suite/herramientas/leveo_rutas.py: no editar a mano.
-- Ruta de subida de RestedXP (RXPGuides), traducida y adaptada a WoW Forever por Brudda FastXP.
-- Licencia de este archivo: CC BY-NC-SA 4.0 (ver LICENCIA_RUTAS.txt).
local _, ns = ...
local R = ns.LeveoRutas or {}
ns.LeveoRutas = R
R[#R + 1] = {[=[
#forever
<< Horde
#name 1-6 Mulgore
#version 11
#group Forever Guía de Mazmorras (H)
#subgroup Mazmorras 1-22
#defaultfor Tauren
#next 6-12 Mulgore;6-13 Mulgore

step
.enabledungeon RFC
#include Guía Forever (H)\1-6 Mulgore
]=], "Horde"}
R[#R + 1] = {[=[
#forever
<< Horde
#name 6-12 Mulgore
#version 11
#group Forever Guía de Mazmorras (H)
#subgroup Mazmorras 1-22
#defaultfor Tauren
#next 12-16 Los Baldíos


step
.enabledungeon RFC
#include Guía Forever (H)\6-12 Mulgore
]=], "Horde"}
