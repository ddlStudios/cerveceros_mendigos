-- GENERADO por _suite/herramientas/leveo_rutas.py: no editar a mano.
-- Ruta de subida de RestedXP (RXPGuides), traducida y adaptada a WoW Forever por Brudda FastXP.
-- Licencia de este archivo: CC BY-NC-SA 4.0 (ver LICENCIA_RUTAS.txt).
local _, ns = ...
local R = ns.LeveoRutas or {}
ns.LeveoRutas = R
R[#R + 1] = {[=[
#forever
#version 1
#name 1-9 Isla de Zephras
#displayname 1-9 Cielonato << Alliance
#displayname 1-9 Cielonato << Horde
#group Forever Guía de Mazmorras (A) << Alliance
#group Forever Guía de Mazmorras (H) << Horde
#subgroup Mazmorras 1-20 << Alliance
#subgroup Mazmorras 1-22 << Horde
#defaultfor Skyborne
#next 9-13 Isla de Zephras

step << Horde
    .enabledungeon RFC
    #include Guía Forever (H)\1-9 Isla de Zephras
step << Alliance
    #include Guía Forever (A)\1-9 Isla de Zephras
]=], nil}
R[#R + 1] = {[=[
#forever
#version 1
#name 9-13 Isla de Zephras
#displayname 9-13 Cielonato << Alliance
#displayname 9-12 Cielonato << Horde
#group Forever Guía de Mazmorras (A) << Alliance
#group Forever Guía de Mazmorras (H) << Horde
#subgroup Mazmorras 1-20 << Alliance
#subgroup Mazmorras 1-22 << Horde
#defaultfor Skyborne
#next 13-15 Páramos de Poniente << Alliance
#next 12-14 Bosque de Argénteos << Horde !Hunter
#next 12-16 Los Baldíos << Horde Hunter

step << Horde
    .enabledungeon RFC
    #include Guía Forever (H)\9-13 Isla de Zephras
step << Alliance
    #include Guía Forever (A)\9-13 Isla de Zephras
]=], nil}
