-- GENERADO por _suite/herramientas/leveo_rutas.py: no editar a mano.
-- Ruta de subida de RestedXP (RXPGuides), traducida y adaptada a WoW Forever por Brudda FastXP.
-- Licencia de este archivo: CC BY-NC-SA 4.0 (ver LICENCIA_RUTAS.txt).
local _, ns = ...
local R = ns.LeveoRutas or {}
ns.LeveoRutas = R
R[#R + 1] = {[=[
#forever
#disabledungeons
<< Horde
#name 12-17 Los Baldíos
#displayname 14-18 Los Baldíos << !Shaman !Hunter !Tauren
#displayname 15-18 Los Baldíos << Paladin
#version 11
#group Guía Forever (H)
#subgroup Guía Speedrun 1-22
#next 17-22 Sierra Espolón/Baldíos/Vallefresno


step << Tauren Shaman
    .goto 1411/1,-4648.55,271.43
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTakrin|r
    .accept 840 >>Acepta la misión Nuevo recluta de la Horda
    .target Takrin Pathseeker
step << Tauren Shaman
    #completewith next
    .goto 1411/1,-4834.14,418.07,30,0
    .goto 1411/1,-4754.3,796.66,20 >> Entra en la Cueva Viento Seco
step << Tauren Shaman
    #loop
    .goto 1411/1,-4706.71,902.41,0
    .goto 1411/1,-4774.39,780.80,20,0
    .goto 1411/1,-4749.01,822.39,12,0
    .goto 1411/1,-4767.52,825.92,12,0
    .goto 1411/1,-4772.28,848.12,12,0
    .goto 1411/1,-4756.41,863.630,12,0
    .goto 1411/1,-4715.70,861.87,12,0
    .goto 1411/1,-4706.71,902.41,12,0
    >>Mata a los |cffff5a4aCultores|r. Despójalos para obtener una |cff4fc3f7Faltriquera de componentes|r
    .complete 1525,2 --Reagent Pouch (1)
    .mob Burning Blade Cultist
step << Tauren Shaman
    .goto 1413/1,-3687.11,303.14
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKargal|r
    .turnin 840 >>Entrega la misión Nuevo recluta de la Horda
    .accept 842 >>Acepta la misión Servicio militar en El Cruce
    .target Kargal Battlescar
step << Tauren Warrior
    #completewith next
    .goto 1413/1,-2902.79,-276.55,30,0
    .goto 1413/1,-3004.12,-298.17,30,0
    .goto 1413/1,-3110.52,-320.46,30 >>Viaja a la cima de la montaña
step << Tauren Warrior
    .goto 1413/1,-3176.39,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThun'grim|r
    .turnin -1502 >>Entrega la misión Thun'grim Vistafuego
    .accept 1503 >>Acepta la misión Acero fundido
    .target Thun'grim Firegaze
step << Tauren Warrior
    .goto 1413/1,-2955.48,-188.04
    >>Despoja el |cffe07cf5Cofre de hierro robado|r para obtener sus |cff4fc3f7Barras de acero forjado|r
    .complete 1503,1 --Forged Steel Bars (1)
step << Tauren Warrior
    #completewith next
    .goto 1413/1,-2902.79,-276.55,30,0
    .goto 1413/1,-3004.12,-298.17,30,0
    .goto 1413/1,-3110.52,-320.46,30 >>Viaja a la cima de la montaña
step << Tauren Warrior
    .goto 1413/1,-3176.39,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThun'grim|r
    .turnin 1503 >>Entrega la misión Acero fundido
    .target Thun'grim Firegaze
step << skip --!Tauren
    #softcore
    #completewith ThievesPickup
    .goto 1413/1,-2516.71,-590.71
    .deathskip >> Muere y reaparece en el |cff5cf05cÁngel de la Resurrección|r
    .xp >15,1
step << skip --!Tauren
    #softcore
    #completewith ThievesPickup
    .subzone 380 >> Viaja a El Cruce
    .xp <15,1
step << !Tauren
    --#hardcore
    #completewith ThievesPickup
    .subzone 380 >> Viaja a El Cruce
step << !Tauren
    #softcore
    .goto 1413/1,-2672.76,-544.77
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTonga|r
    .accept 870 >>Acepta la misión Las Charcas del Olvido
    .target Tonga Runetotem
step << Orc/Troll
    #hardcore
    .goto 1413/1,-2709.24,-403.57
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZargh|r
    .accept 6365 >>Acepta la misión Entrega de carne a Orgrimmar
    .target Zargh
step << !Tauren
    .goto 1413/1,-2670.74,-482.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSergra|r
    .turnin 842 >>Entrega la misión Servicio militar en El Cruce << !Druid
    .accept 844 >>Acepta la misión La amenaza de los zancudos de llanura
    .target Sergra Darkthorn
    .isOnQuest 842
step << !Tauren
    .goto 1413/1,-2670.74,-482.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSergra|r
    .accept 844 >>Acepta la misión La amenaza de los zancudos de llanura
    .target Sergra Darkthorn
step << !Tauren
    #hardcore
    .goto 1413/1,-2672.76,-544.77
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTonga|r
    .accept 870 >>Acepta la misión Las Charcas del Olvido
    .target Tonga Runetotem
step << !Tauren
    .goto 1413/1,-2595.75,-473.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThork|r
    .turnin -98024 >>Entrega la misión Viaje a El Cruce << Skyborne
    .accept 871 >>Acepta la misión Interrupción de los ataques
    .accept 5041 >>Acepta la misión Suministros para El Cruce
    .target Thork
    .maxlevel 15
step << Skyborne
    #optional
    .goto 1413/1,-2595.75,-473.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThork|r
    .turnin -98024 >>Entrega la misión Viaje a El Cruce
    .target Thork
    .maxlevel 15
step << Orc/Troll
    #hardcore
    .goto 1413/1,-2595.75,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDevrak|r
    >>|cffff9a3c¡NO vueles a Orgrimmar!|r
    .turnin 6365 >>Entrega la misión Entrega de carne a Orgrimmar
    .accept 6384 >>Acepta la misión Un viaje a Orgrimmar
    .target Devrak
step << Undead/Skyborne
    .goto 1413/1,-2595.75,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDevrak|r
    .fp >> Consigue la ruta de vuelo de El Cruce
    .target Devrak
    .isQuestAvailable 1492
step << !Tauren
    .goto 1413/1,-2589.67,-424.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHelbrim|r
    .accept 1492 >>Acepta la misión Maestro de muelles Vertipeluca
    .accept 848 >>Acepta la misión Esporas de hongos
    .turnin 1358 >>Entrega la misión Muestra para Helbrim
    .target Apothecary Helbrim
    .isOnQuest 1358
step << !Tauren
    .goto 1413/1,-2589.67,-424.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHelbrim|r
    .accept 1492 >>Acepta la misión Maestro de muelles Vertipeluca
    .accept 848 >>Acepta la misión Esporas de hongos
    .target Apothecary Helbrim
step << Orc Hunter/Troll Hunter/Skyborne Hunter
    .goto 1413/1,-2556.23,-351.54
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cUthrok|r|cffe07cf5. Compra un|r |T135499:0|t[Arco corvo laminado] |cffe07cf5a este vendedor|r
    .collect 2507,1,871,1 --Collect Laminated Recurve Bow (1)
    .money <0.1751
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<5.7
    .target Uthrok
step << Orc Hunter/Troll Hunter/Skyborne Hunter
    #optional
    #completewith DisruptTheAttacks
    +|cffff9a3cEquipa el|r |T135499:0|t[Arco corvo laminado]
    .use 2507
    .itemcount 2507,1
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<5.7
step << Tauren Hunter
    .goto 1413/1,-2556.23,-351.54
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cUthrok|r|cffe07cf5. Compra una|r |T135613:0|t[Bocarda de cazador] |cffe07cf5a este vendedor|r
    .collect 2511,1,871,1 --Collect Hunter's Boomstick (1)
    .money <0.1324
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<4.9
    .target Uthrok
step << Tauren Hunter
    #optional
    #completewith DisruptTheAttacks
    +|cffff9a3cEquipa la|r |T135613:0|t[Bocarda de cazador]
    .use 2511
    .itemcount 2511,1
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<4.9
step << !Tauren
    #label ThievesPickup
    .goto 1413/1,-2639.32,-436.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGazrog|r
    .accept 869 >>Acepta la misión Raptores ladrones
    .target Gazrog
step << !Tauren
    .goto 1413/1,-2645.40,-406.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Boorand|r
    .home >> Establece tu Piedra de hogar en El Cruce
    .target Innkeeper Boorand Plainswind
    .bindlocation 380
    .isQuestAvailable 1492
step << Orc/Troll
    #softcore
    .goto 1413/1,-2709.24,-403.57
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZargh|r
    .accept 6365 >>Acepta la misión Entrega de carne a Orgrimmar
    .target Zargh
step
    #optional
    #completewith DisruptTheAttacks
    >>Mata a cada |cffff5a4aRaptor|r que veas. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Lashtail
    .mob Sunscale Screecher
step
    #optional
    #completewith DisruptTheAttacks
    >>Mata a los |cffff5a4aZancudos de llanura|r. Despójalos para obtener sus |cff4fc3f7Picos|r
    .complete 844,1 --Plainstrider Beak (7)
    .mob Greater Plainstrider
    .mob Fleeting Plainstrider
step << !Tauren !Undead !Skyborne
    #completewith DemonSeed
    #label DemonMountain
    .goto 1413/1,-2554.2,80.18,40,0
    .goto 1413/1,-2477.19,136.26,40,0
    .goto 1413/1,-2363.7,232.87,40,0
    .goto 1413/1,-2205.62,314.62,100 >> Viaja a la cima de la montaña
    .isOnQuest 924
step << !Tauren !Undead !Skyborne
    #completewith next
    #requires DemonMountain
    .goto 1413/1,-2205.62,314.62,15 >> Entra en Cubil Calígine
    .isOnQuest 924
step << !Tauren !Undead !Skyborne
    #label DemonSeed
    .goto 1413/1,-2238.04,324.08
    >>Haz clic derecho en el |cffe07cf5Altar|r
    >>|cffff9a3cAsegúrate de tener una|r |T134095:0|t[Piedra de energía con imperfecciones] |cffff9a3c(duración de 30 minutos) contigo|r
    .collect 4986,1,924 --Collect Flawed Power Stone
    .complete 924,1 --Destroy the Demon Seed (1)
    .isOnQuest 924
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #sticky
    #label FireTar2
    .goto 1413/1,-2947.38,-92.1,50,0
    .goto 1413/1,-2869.35,-49.54,50,0
    .goto 1413/1,-2805.51,-111.02
    >>Mata a un |cffff5a4aBuscaqua Crines de Acero|r o a un |cffff5a4aTejespina Crines de Acero|r. Despójalos para obtener un |cff4fc3f7Alquitrán|r
    .complete 1525,1 --Fire Tar (1)
    .mob Razormane Water Seeker
    .mob Razormane Thornweaver
step
    #optional
    #completewith next
    >>Mata a los |cffff5a4aBuscaqua|r, a los |cffff5a4aTejespina|r y a los |cffff5a4aCazadores|r
    .complete 871,1 --Razormane Water Seeker (8)
    .mob +Razormane Water Seeker
    .complete 871,2 --Razormane Thornweaver (8)
    .mob +Razormane Thornweaver
    .complete 871,3 --Razormane Hunter (3)
    .mob +Razormane Hunter
    .isOnQuest 871
step
    .goto 1413/1,-3021.35,-231.960
    .use 4926 >> Despoja el |cffe07cf5Barril vacío de Chen|r del suelo y comienza la misión
    >>|cffff9a3cPuedes conseguirlo más tarde si no está allí|r
    .collect 4926,1,819 --Collect Chen's Empty Keg
    .accept 819 >> Acepta la misión El barril vacío de Chen
    .isOnQuest 871
step
    #requires FireTar2 << Shaman
    #label DisruptTheAttacks
    #loop
	.goto 1413/1,-2811.59,-42.780,0
	.goto 1413/1,-2811.59,-42.780,50,0
	.goto 1413/1,-2875.43,-52.24,50,0
	.goto 1413/1,-2931.16,-89.40,50,0
	.goto 1413/1,-3001.08,-117.78,50,0
	.goto 1413/1,-3037.56,-164.390,50,0
	.goto 1413/1,-3034.52,-221.82,50,0
	.goto 1413/1,-2991.96,-239.39,50,0
	.goto 1413/1,-2899.75,-209.66,50,0
	.goto 1413/1,-2854.15,-151.56,50,0
	.goto 1413/1,-2799.43,-92.78,50,0
    >>Mata a los |cffff5a4aBuscaqua|r, a los |cffff5a4aTejespina|r y a los |cffff5a4aCazadores|r
    .complete 871,1 --Razormane Water Seeker (8)
    .mob +Razormane Water Seeker
    .complete 871,2 --Razormane Thornweaver (8)
    .mob +Razormane Thornweaver
    .complete 871,3 --Razormane Hunter (3)
    .mob +Razormane Hunter
    .isOnQuest 871
step
    #completewith next
    >>Mata a cada |cffff5a4aRaptor|r que veas. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Lashtail
    .mob Sunscale Screecher
step
    #loop
    .goto 1413/1,-2819.70,-359.65,0
    .goto 1413/1,-2784.23,-163.04,80,0
    .goto 1413/1,-2771.06,-306.95,80,0
    .goto 1413/1,-2805.51,-386.00,80,0
    .goto 1413/1,-2738.63,-610.310,80,0
    .goto 1413/1,-2576.50,-610.98,80,0
    .goto 1413/1,-2494.42,-485.32,80,0
    .goto 1413/1,-2448.82,-398.84,80,0
    .goto 1413/1,-2537.99,-260.33,80,0
    .goto 1413/1,-2730.52,-273.17,80,0
    .goto 1413/1,-2819.70,-359.65,80,0
    >>Mata a los |cffff5a4aZancudos de llanura|r. Despójalos para obtener sus |cff4fc3f7Picos|r
    .complete 844,1 --Plainstrider Beak (7)
    .mob Greater Plainstrider
    .mob Fleeting Plainstrider
step
    .goto 1413/1,-2670.74,-482.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSergra|r
    .turnin 842 >>Entrega la misión Servicio militar en El Cruce << Tauren Shaman
    .turnin 844 >>Entrega la misión La amenaza de los zancudos de llanura
    .accept 845 >>Acepta la misión La zhebra
    .target Sergra Darkthorn
    .isOnQuest 842 << Tauren Shaman
step << Tauren Shaman
    #optional
    .goto 1413/1,-2670.74,-482.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSergra|r
    .turnin 844 >>Entrega la misión La amenaza de los zancudos de llanura
    .accept 845 >>Acepta la misión La zhebra
    .target Sergra Darkthorn
step
    .goto 1413/1,-2595.75,-473.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThork|r
    .turnin 871 >>Entrega la misión Interrupción de los ataques
    .accept 872 >>Acepta la misión La perturbación termina
    .target Thork
    .isQuestComplete 871
step
    #optional
    .goto 1413/1,-2595.75,-473.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThork|r
    .accept 872 >>Acepta la misión La perturbación termina
    .target Thork
    .isQuestTurnedIn 871
step
    .goto 1413/1,-2607.91,-475.180
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDarsok|r
    >>|cffff9a3cEstá en la cima de la torre|r
    .accept 867 >>Acepta la misión Arpías saqueadoras
    .target Darsok Swiftdagger
step << Orc/Troll
    #softcore
    .goto 1413/1,-2595.75,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDevrak|r
    >>|cffff9a3c¡NO vueles a Orgrimmar!|r
    .turnin 6365 >>Entrega la misión Entrega de carne a Orgrimmar
    .accept 6384 >>Acepta la misión Un viaje a Orgrimmar
    .target Devrak
step << Orc Hunter/Troll Hunter/Skyborne Hunter
    #optional
    .goto 1413/1,-2556.23,-351.54
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cUthrok|r|cffe07cf5. Compra un|r |T135499:0|t[Arco corvo laminado] |cffe07cf5a este vendedor|r
    .collect 2507,1,871,1 --Collect Laminated Recurve Bow (1)
    .money <0.1751
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<5.7
    .target Uthrok
step << Tauren Hunter
    #optional
    .goto 1413/1,-2556.23,-351.54
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cUthrok|r|cffe07cf5. Compra una|r |T135613:0|t[Bocarda de cazador] |cffe07cf5a este vendedor|r
    .collect 2511,1,871,1 --Collect Hunter's Boomstick (1)
    .money <0.1324
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<4.9
    .target Uthrok
step << Orc Warrior/Troll Warrior/Tauren Warrior/Skyborne Warrior
    #sticky
    #completewith KreenigSnarlsnout
    .goto 1413/1,-2697.08,-461.67,0
    .vendor >>|cffff9a3cRevisa si|r |cff5cf05cLizzarik|r |cffff9a3cestá en El Cruce. Vende pociones y|r |T133476:0|t[|cff5cf05cMaza con pinchos pesada|r] |cffff9a3cque es un objeto de suministro limitado|r
	.unitscan Lizzarik
    .subzoneskip 380,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
step
    .goto 1413/1,-2645.40,-406.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Boorand|r
    .vendor >>Abastécete de comida y agua << !Rogue !Warrior
    .vendor >>Abastécete de comida << Rogue/Warrior
    .target Innkeeper Boorand Plainswind
    .isOnQuest 872,5041,845
step
    .goto 1413/1,-3021.35,-231.96,20,0
    .goto 1413/1,-3029.46,261.25
    .use 4926 >> Despoja el |cffe07cf5Barril vacío de Chen|r del suelo y comienza la misión
    >>|cffff9a3cEspera a la reaparición si no ha aparecido|r
    .collect 4926,1,819 --Collect Chen's Empty Keg
    .accept 819 >> Acepta la misión El barril vacío de Chen
    .isOnQuest 872
step
    #optional
    #completewith KreenigSnarlsnout
    .goto 1413/1,-3127.75,-55.62,50,0
    .goto 1413/1,-3382.10,-54.27,50,0
    >>Mata a las |cffff5a4aGeománticas Crines de Acero|r y a los |cffff5a4aDefensores Crines de Acero|r
    .complete 872,1 --Razormane Geomancer (8)
    .mob +Razormane Geomancer
    .complete 872,2 --Razormane Defender (8)
    .mob +Razormane Defender
    .isOnQuest 872
step
    #optional
    #completewith next
    >>Despoja los |cffe07cf5Cajones de suministro de El Cruce|r
    >>|cffff9a3cTiene múltiples localizaciones de aparición|r
    .complete 5041,1 --Crossroads' Supply Crates (1)
    .isOnQuest 872
step
    #label KreenigSnarlsnout
    .goto 1413/1,-3324.34,-217.09
    >>Mata a |cffff5a4aKreenig Gruñucico|r. Despójalo para obtener su |cff4fc3f7Colmillo|r
    .complete 872,3 --Kreenig Snarlsnout's Tusk (1)
    .mob Kreenig Snarlsnout
    .isOnQuest 872
step
    #optional
    #completewith next
    .goto 1413/1,-3127.75,-55.62,0
    .goto 1413/1,-3382.10,-54.27,0
    >>Mata a las |cffff5a4aGeománticas Crines de Acero|r y a los |cffff5a4aDefensores Crines de Acero|r
    .complete 872,1 --Razormane Geomancer (8)
    .mob +Razormane Geomancer
    .complete 872,2 --Razormane Defender (8)
    .mob +Razormane Defender
    .isOnQuest 872
step
    #loop
    .goto 1413/1,-3292.92,-212.36,30,0
    .goto 1413/1,-3402.36,-48.19,30,0
    .goto 1413/1,-3292.92,-212.36,0
    .goto 1413/1,-3402.36,-48.19,0
    >>Despoja los |cffe07cf5Cajones de suministro de El Cruce|r
    >>|cffff9a3cTiene múltiples localizaciones de aparición|r
    .complete 5041,1 --Crossroads' Supply Crates (1)
    .isOnQuest 872
step
    #loop
	.goto 1413/1,-3345.62,-101.56,0
	.goto 1413/1,-3393.24,-102.24,50,0
	.goto 1413/1,-3419.59,-40.08,50,0
	.goto 1413/1,-3419.59,-0.89,50,0
	.goto 1413/1,-3361.83,-1.57,50,0
	.goto 1413/1,-3317.24,-7.65,50,0
	.goto 1413/1,-3237.19,-27.92,50,0
	.goto 1413/1,-3139.91,-46.16,50,0
	.goto 1413/1,-3126.74,-101.56,50,0
	.goto 1413/1,-3178.42,-107.64,50,0
	.goto 1413/1,-3205.78,-119.13,50,0
	.goto 1413/1,-3218.95,-81.97,50,0
	.goto 1413/1,-3278.74,-75.21,50,0
	.goto 1413/1,-3345.62,-101.56,50,0
    >>Mata a las |cffff5a4aGeománticas Crines de Acero|r y a los |cffff5a4aDefensores Crines de Acero|r
    .complete 872,1 --Razormane Geomancer (8)
    .mob +Razormane Geomancer
    .complete 872,2 --Razormane Defender (8)
    .mob +Razormane Defender
    .isOnQuest 872
step << !Tauren !Undead !Skyborne
    #optional
    #completewith next
    >>Mata a cualquier |cffff5a4aZhebra|r que veas. Despójalas para obtener sus |cff4fc3f7Pezuñas|r
    .complete 845,1 --Zhevra Hooves (4)
    .mob Zhevra Runner
    .isQuestComplete 924
step << !Tauren !Undead !Skyborne
    .goto 1413/1,-3694.2,256.52
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAk'Zeloth|r
    .turnin 924 >>Entrega la misión La Semilla del Demonio
    .target Ak'Zeloth
    .isQuestComplete 924
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #optional
    #completewith ShamanDurotar
    >>Mata a cada |cffff5a4aRaptor|r que veas. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Lashtail
    .mob Sunscale Screecher
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #optional
    #completewith ShamanDurotar
    >>Mata a cualquier |cffff5a4aZhebra|r que veas. Despójalas para obtener sus |cff4fc3f7Pezuñas|r
    .complete 845,1 --Zhevra Hooves (4)
    .mob Zhevra Runner
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #completewith CallofFire3
    #label ShamanDurotar
    .goto 1411/1,-3905.13,-228.41
    .zone Durotar >> Viaja hacia Durotar
    .isOnQuest 1525
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #requires ShamanDurotar
    #completewith next
    .goto 1411/1,-3905.13,-228.41,10,0
    .goto 1411/1,-3899.31,-241.45,8,0
    .goto 1411/1,-3899.31,-241.45,8,0
    .goto 1411/1,-3906.71,-270.71,8,0
    .goto 1411/1,-3910.94,-247.45,8,0
    .goto 1411/1,-3931.56,-240.75,8,0
    .goto 1411/1,-3964.35,-242.51,8,0
    .goto 1411/1,-3974.39,-228.76,8,0
    .goto 1411/1,-4020.92,-219.95,8,0
    .goto 1411/1,-4034.67,-232.64,8,0
    .goto 1411/1,-4033.08,-255.91,10 >> Sigue el camino montaña arriba hacia |cff5cf05cTelf|r
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #label CallofFire3
    #requires ShamanDurotar
    .goto 1411/1,-3999.24,-268.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTelf|r
    .turnin -1525 >>Entrega la misión La llamada del fuego
    .accept 1526 >>Acepta la misión La llamada del fuego
    .target Telf Joolam
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #completewith next
    .goto 1411/1,-3981.27,-256.61
    .cast 8898 >>|cffff9a3cUsa la|r |T134732:0|t[La sapta de fuego]
    .use 6636
step << Orc Shaman/Troll Shaman/Tauren Shaman
    .goto 1411/1,-4022.51,-243.92
    >>Mata a la |cffff5a4aManifestación Menor de Fuego|r. Despójalo para obtener un |cff4fc3f7Ascua resplandeciente|r
    .complete 1526,1 --Glowing Ember (1)
    .mob Minor Manifestation of Fire
step << Orc Shaman/Troll Shaman/Tauren Shaman
    .goto 1411/1,-4022.51,-243.92
    >>Haz clic en el |cffe07cf5Blandón|r del suelo
    .turnin 1526 >>Entrega la misión La llamada del fuego
    .accept 1527 >>Acepta la misión La llamada del fuego
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #optional
    #completewith FireEnd
    >>Mata a cada |cffff5a4aRaptor|r que veas. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Lashtail
    .mob Sunscale Screecher
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #optional
    #completewith next
    >>Mata a cualquier |cffff5a4aZhebra|r que veas. Despójalas para obtener sus |cff4fc3f7Pezuñas|r
    .complete 845,1 --Zhevra Hooves (4)
    .mob Zhevra Runner
step << Orc Shaman/Troll Shaman/Tauren Shaman
    #label FireEnd
    .goto 1413/1,-3037.56,264.63
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKranal|r
    .turnin 1527 >>Entrega la misión La llamada del fuego
    .target Kranal Fiss
step << Orc Shaman/Troll Shaman/Tauren Shaman
    .goto 1413/1,-3029.46,261.25
    .use 4926 >> Despoja el |cffe07cf5Barril vacío de Chen|r del suelo y comienza la misión
    >>|cffff9a3cEspera a la reaparición si no ha aparecido|r
    .collect 4926,1,819 --Collect Chen's Empty Keg
    .accept 819 >> Acepta la misión El barril vacío de Chen
step
    #completewith RatchetEnter
    >>Mata a los |cffff5a4aRaptores|r. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Screecher
step
    #optional
    #completewith RatchetEnter
    .goto 1413/1,-3851.27,-526.53,100,0
    >>Mata |cffff5a4aGalopadores zhebra|r. Despójalos para obtener sus |cff4fc3f7Pezuñas|r
    .complete 845,1 --Zhevra Hooves (4)
    .mob Zhevra Runner
    .isOnQuest 872
step
    #label RatchetEnter
    .goto 1413/1,-3728.66,-835.29
    .subzone 392 >> Viaja a Trinquete
    .isOnQuest 845
step
    .goto 1413/1,-3767.800,-842.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDesdio|r
    .accept 97253 >>Acepta la misión Partes y piezas
    .target Wrenix the Wretched
step
    .goto 1413/1,-3728.66,-835.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGazlowe|r
    .accept 887 >>Acepta la misión Los filibusteros de los Mares del Sur
    .target Gazlowe
step
    #completewith next
    .goto 1413/1,-3770.20,-898.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBragok|r
    .fp Ratchet >> Consigue la ruta de vuelo de Trinquete
    .target Bragok
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cPetardol|r y el |cff5cf05cCartel de Se busca|r
    .accept 894 >>Acepta la misión El churumbele
    .goto 1413/1,-3759.06,-902.18
    .accept 895 >>Acepta la misión SE BUSCA: Barón Longavera
    .goto 1413/1,-3719.54,-919.07
    .target Sputtervalve
step << Undead Warrior/Skyborne Warrior
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra un|r |T135353:0|t[Espadón] |cffe07cf5a este vendedor|r
    .collect 2024,1,895,1 --Collect Espadon (1)
    .money <0.6397
    .target Ironzar
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
step << Undead Warrior/Skyborne Warrior
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa el|r |T135353:0|t[Espadón] |cffff9a3ccuando alcances el nivel 16|r
    .use 2024
    .itemcount 2024,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
    .xp >16,1
step << Undead Warrior/Skyborne Warrior
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa el|r |T135353:0|t[Espadón]
    .use 2024
    .itemcount 2024,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
    .xp <16,1
step << Troll Warrior
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra un|r |T135147:0|t[Bastón nudoso] |cffe07cf5a este vendedor|r
    .collect 2030,1,850,1 --Collect Gnarled Staff (1)
    .money <0.5544
    .target Ironzar
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.9
step << Troll Warrior
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa el|r |T135147:0|t[Bastón nudoso]
    .use 2030
    .itemcount 2030,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.9
step << Orc Warrior
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra una|r |T132394:0|t[Hacha barbada] |cffe07cf5a este vendedor|r
    .collect 2025,1,850,1 --Collect Bearded Axe (1)
    .money <0.5304
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.8
step << Orc Warrior
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa el|r |T132394:0|t[Hacha barbada]
    .use 2025
    .itemcount 2025,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.8
step << Tauren Warrior
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra un|r |T133046:0|t[Martillo de roca] |cffe07cf5a este vendedor|r
    .collect 2026,1,850,1 --Collect Rock Hammer (1)
    .money <0.6286
    .target Ironzar
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
step << Tauren Warrior
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa el|r |T133046:0|t[Martillo de roca] |cffff9a3ccuando estés en el nivel 16|r
    .use 2026
    .itemcount 2026,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
    .xp >16,1
step << Tauren Warrior
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa el|r |T133046:0|t[Martillo de roca]
    .use 2026
    .itemcount 2026,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
    .xp <16,1
step << Shaman
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra un|r |T135147:0|t[Bastón nudoso] |cffe07cf5a este vendedor|r
    .collect 2030,1,895,1 --Collect Gnarled Staff (1)
    .money <0.5544
    .target Ironzar
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.9
step << Shaman
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa el|r |T135147:0|t[Bastón nudoso]
    .use 2030
    .itemcount 2030,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.9
step << Rogue
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra una|r |T135343:0|t[Cimitarra] |cffe07cf5a este vendedor|r
    .collect 2027,1,895,1 --Collect Scimitar (1)
    .money <0.3815
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.6
    .target Ironzar
step << Rogue
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa la|r |T135343:0|t[Cimitarra]
    .use 2027
    .itemcount 2027,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.6
step << Rogue
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Cómprale una segunda|r |T135343:0|t[Cimitarra] |cffe07cf5para tu mano izquierda|r
    .collect 2027,2,895,1 --Collect Scimitar(1)
    .money <0.3815
    .itemStat 17,QUALITY,<7
    .itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.6
    .target Ironzar
step << skip
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa la segunda|r |T135343:0|t[Cimitarra] |cffff9a3cen tu mano izquierda|r
    .use 2027
    .itemcount 2027,1
    .itemStat 17,QUALITY,<7
    .itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.6
step
    .goto 1413/1,-3687.11,-981.22
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDrohn|r
    .turnin 819 >>Entrega la misión El barril vacío de Chen
    .accept 821 >>Acepta la misión El barril vacío de Chen
    .target Brewmaster Drohn
    .isOnQuest 819
step
    #optional
    .goto 1413/1,-3687.11,-981.22
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDrohn|r
    .accept 821 >>Acepta la misión El barril vacío de Chen
    .target Brewmaster Drohn
    .isQuestTurnedIn 819
step << Mage/Priest/Warlock/Shaman/Druid
    .goto 1413/1,-3664.82,-1050.14
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Wiley|r
    -->>|cffe07cf5Buy|r |T133918:0|t[Longjaw Mud Snappers] |cffe07cf5from him|r
    >>|cffe07cf5Compra|r |T132796:0|t[Zumo de melón] |cffe07cf5a este vendedor|r << Mage/Warlock/Priest/Shaman/Druid
    -->>|T133918:0|t[Longjaw Mud Snappers] |cffff9a3care extremely cheap, buy as many as you want|r
    .vendor >> Vende la Basura
    --.collect 4592,20,895,1 --Longjaw Mud Snapper (20)
    .collect 1205,10,895,1 << Mage/Warlock/Priest/Shaman/Druid --Melon Juice (10)
    .target Innkeeper Wiley
    .isOnQuest 887
    .xp <15,1
step
    #optional
    #completewith BaronLongshore
    .destroy 5088 >> |cffff9a3cElimina el|r |T133735:0|t[Manual de instrucciones de la consola de control] |cffff9a3cde tus bolsas, ya que ya no se necesita|r
step
    #optional
    #completewith BaronLongshore
    >>Mata a los |cffff5a4aSalteadores de los Mares del Sur|r y a los |cffff5a4aCañoneros de los Mares del Sur|r
    .complete 887,1 --Southsea Brigand (12)
    .mob +Southsea Brigand
    .complete 887,2 --Southsea Cannoneer (6)
    .mob +Southsea Cannoneer
step << Orc Rogue/Troll Rogue
    #optional
	#completewith SouthSea
	>>Mata a |cffff5a4aTazan|r. Despójalo para obtener su |cff4fc3f7Cartera|r
    >>|cffff9a3cAparece en el primer campamento y patrulla subiendo la colina|r
	.complete 1963,1 --Tazan's Satchel (1)
    .unitscan Tazan
step
    #label BaronLongshore
    #loop
    .goto 1413/1,-3883.70,-1572.40,0
    .goto 1413/1,-3818.84,-1707.52,0
    .goto 1413/1,-3724.60,-1746.71,0
    .goto 1413/1,-3883.70,-1572.40,50,0
    .goto 1413/1,-3818.84,-1707.52,50,0
    .goto 1413/1,-3724.60,-1746.71,50,0
    >>Mata al |cffff5a4aBarón Longavera|r. Despójalo para obtener su |cff4fc3f7Cabeza|r
    >>|cffff9a3cSe le puede encontrar en uno de los campamentos|r
    .complete 895,1 --Baron Longshore's Head (1)
    .unitscan Baron Longshore
step
    #loop
    .goto 1413/1,-3885.72,-1569.690,0
    .goto 1413/1,-3902.95,-1366.33,50,0
    .goto 1413/1,-3823.91,-1512.94,50,0
    .goto 1413/1,-3885.72,-1569.690,50,0
    >>Mata a los |cffff5a4aSalteadores de los Mares del Sur|r y a los |cffff5a4aCañoneros de los Mares del Sur|r
    .complete 887,1 --Southsea Brigand (12)
    .mob +Southsea Brigand
    .complete 887,2 --Southsea Cannoneer (6)
    .mob +Southsea Cannoneer
step
    #label SouthSea
    #loop
    .goto 1413/1,-3657.700,-1435.500,0
    .goto 1413/1,-3675.100,-1364.100,40,0
    .goto 1413/1,-3598.900,-1378.800,40,0
    .goto 1413/1,-3657.700,-1435.500,40,0
    .goto 1413/1,-3654.900,-1482.400,40,0
    .goto 1413/1,-3680.100,-1593.000,40,0
    .goto 1413/1,-3614.800,-1632.800,40,0
    .goto 1413/1,-3611.500,-1692.500,40,0
    >>Despoja el |cffe07cf5Puñado de piezas complicadas|r del suelo
    .complete 97253,1 --|5/5 Handful of Complicated Parts
    .isOnQuest 97253
step << Orc Rogue/Troll Rogue
    #loop
    .goto 1413/1,-3895.600,-1365.000,0
    .goto 1413/1,-3677.99,-1392.00,50,0
    .goto 1413/1,-3895.600,-1365.000,50,0
    .goto 1413/1,-3826.300,-1487.300,50,0
	>>Mata a |cffff5a4aTazan|r. Despójalo para obtener su |cff4fc3f7Cartera|r
    >>|cffff9a3cAparece en el primer campamento y patrulla subiendo la colina|r
	.complete 1963,1 --Tazan's Satchel (1)
    .unitscan Tazan
step
    .goto 1413/1,-3728.66,-835.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGazlowe|r
    .turnin 887 >>Entrega la misión Los filibusteros de los Mares del Sur
    .turnin 895 >>Entrega la misión SE BUSCA: Barón Longavera
    .accept 890 >>Acepta la misión El envío perdido
    .target Gazlowe
step
    .goto 1413/1,-3767.800,-842.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDesdio|r
    .turnin 97253 >>Entrega la misión Partes y piezas
    .target Wrenix the Wretched
    .isQuestComplete 97253
step
    .goto 1413/1,-3796.55,-985.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVertipeluca|r
    .turnin 1492 >>Entrega la misión Maestro de muelles Vertipeluca
    .turnin 890 >>Entrega la misión El envío perdido
    .accept 892 >>Acepta la misión El envío perdido
    .accept 896 >>Acepta la misión La fortuna de un minero
    .target Wharfmaster Dizzywig
step
    .goto 1413/1,-3728.66,-835.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGazlowe|r
    .turnin 892 >>Entrega la misión El envío perdido
    .accept 888 >>Acepta la misión Botín robado
    .target Gazlowe
step << Undead Warrior/Skyborne Warrior
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra un|r |T135353:0|t[Espadón] |cffe07cf5a este vendedor|r
    .collect 2024,1,850,1 --Collect Espadon (1)
    .money <0.6397
    .target Ironzar
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
step << Undead Warrior/Skyborne Warrior
    #optional
    #completewith FlyToXroads1
    +|cffff9a3cEquipa el|r |T135353:0|t[Espadón] |cffff9a3ccuando alcances el nivel 16|r
    .use 2024
    .itemcount 2024,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
    .xp >16,1
step << Undead Warrior/Skyborne Warrior
    #optional
    #completewith FlyToXroads1
    +|cffff9a3cEquipa el|r |T135353:0|t[Espadón]
    .use 2024
    .itemcount 2024,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
    .xp <16,1
step << Troll Warrior
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra un|r |T135147:0|t[Bastón nudoso] |cffe07cf5a este vendedor|r
    .collect 2030,1,850,1 --Collect Gnarled Staff (1)
    .money <0.5544
    .target Ironzar
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.9
step << Troll Warrior
    #optional
    #completewith FlyToXroads1
    +|cffff9a3cEquipa el|r |T135147:0|t[Bastón nudoso]
    .use 2030
    .itemcount 2030,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.9
step << Orc Warrior
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra una|r |T132394:0|t[Hacha barbada] |cffe07cf5a este vendedor|r
    .collect 2025,1,850,1 --Collect Bearded Axe (1)
    .money <0.5304
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.8
step << Orc Warrior
    #optional
    #completewith FlyToXroads1
    +|cffff9a3cEquipa el|r |T132394:0|t[Hacha barbada]
    .use 2025
    .itemcount 2025,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.8
step << Tauren Warrior
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra un|r |T133046:0|t[Martillo de roca] |cffe07cf5a este vendedor|r
    .collect 2026,1,850,1 --Collect Rock Hammer (1)
    .money <0.6286
    .target Ironzar
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
step << Tauren Warrior
    #optional
    #completewith FlyToXroads1
    +|cffff9a3cEquipa el|r |T133046:0|t[Martillo de roca] |cffff9a3ccuando estés en el nivel 16|r
    .use 2026
    .itemcount 2026,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
    .xp >16,1
step << Tauren Warrior
    #optional
    #completewith FlyToXroads1
    +|cffff9a3cEquipa el|r |T133046:0|t[Martillo de roca]
    .use 2026
    .itemcount 2026,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.5
    .xp <16,1
step << Shaman
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra un|r |T135147:0|t[Bastón nudoso] |cffe07cf5a este vendedor|r
    .collect 2030,1,850,1 --Collect Gnarled Staff (1)
    .money <0.5544
    .target Ironzar
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.9
step << Shaman
    #optional
    #completewith BaronLongshore
    +|cffff9a3cEquipa el|r |T135147:0|t[Bastón nudoso]
    .use 2030
    .itemcount 2030,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.9
step << Rogue
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Compra una|r |T135343:0|t[Cimitarra] |cffe07cf5a este vendedor|r
    .collect 2027,1,850,1 --Collect Scimitar (1)
    .money <0.3815
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.6
    .target Ironzar
step << Rogue
    #optional
    #completewith FlyToXroads1
    +|cffff9a3cEquipa la|r |T135343:0|t[Cimitarra]
    .use 2027
    .itemcount 2027,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.6
step << Rogue
    .goto 1413/1,-3684.07,-919.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cHierrozar|r|cffe07cf5. Cómprale una segunda|r |T135343:0|t[Cimitarra] |cffe07cf5para tu mano izquierda|r
    .collect 2027,2,850,1 --Collect Scimitar (1)
    .money <0.3815
    .itemStat 17,QUALITY,<7
    .itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.6
    .target Ironzar
step << skip
    #optional
    #completewith FlyToXroads1
    +|cffff9a3cEquipa la|r |T135343:0|t[Cimitarra]
    .use 2027
    .itemcount 2027,1
    .itemStat 17,QUALITY,<7
    .itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.6
step << !Tauren
    #label FlyToXroads1
    #completewith XroadsTurnins3
    .goto 1413/1,-3770.20,-898.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBragok|r
    .fly Crossroads >> Vuela a El Cruce
    .target Bragok
    .subzoneskip 380
    .isQuestComplete 845
step
    #optional
    #completewith next
    >>Mata a cada |cffff5a4aRaptor|r que veas. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Lashtail
    .mob Sunscale Screecher
step
    #loop
    .goto 1413/1,-2977.78,-942.71,0
    .goto 1413/1,-2274.52,-870.42,0
    .goto 1413/1,-2977.78,-942.71,80,0
    .goto 1413/1,-2832.87,-990.01,80,0
    .goto 1413/1,-2710.26,-959.6,80,0
    .goto 1413/1,-2392.07,-900.83,80,0
    .goto 1413/1,-2274.52,-870.42,80,0
    >>Termina de matar |cffff5a4aZhebras|r. Despójalas para obtener sus |cff4fc3f7Pezuñas|r
    .complete 845,1 --Zhevra Hooves (4)
    .mob Zhevra Runner
step << Tauren Druid
    #completewith DruidTraining1
    .cast 18960 >>|cffff9a3cLanza|r |T135758:0|t[Teletransporte a: Claro de la Luna]
    .zoneskip Moonglade
step << Tauren Druid
    .goto 1450/1,-2593.82,7866.90
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLoganaar|r
    .train 782 >> Aprende tus hechizos de clase
    .target Loganaar
    .bindlocation 1638,1
    .cooldown item,6948,>0
    .xp <14,1
    .xp >16,1
step << Tauren Druid
    #label DruidTraining1
    .goto 1450/1,-2593.82,7866.90
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLoganaar|r
    .train 8925 >> Aprende tus hechizos de clase
    .target Loganaar
    .bindlocation 1638,1
    .cooldown item,6948,>0
    .xp <16,1
step << Tauren
    #completewith FlyXroads2
    .hs >> Usa tu Piedra de hogar para ir a Cima del Trueno
    .bindlocation 1638,1
    .zoneskip Thunder Bluff
    .cooldown item,6948,>0
    .use 6948
step << Tauren
    .goto 1456/1,40.72,-1238.97--c:Thunder Bluff,45.6,55.9
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAhanu|r
    .turnin -6362 >>Entrega la misión Un viaje a Cima del Trueno
    .accept 6363 >>Acepta la misión Tal, maestro de jinetes del viento
    .target Ahanu
step << Tauren Shaman
    .goto 1456/1,269.92,-980.40
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTigor|r
    .train 2645 >> Aprende tus hechizos de clase
    .target Tigor Skychaser
    .xp <14,1
    .xp >16,1
step << Tauren Shaman
    #optional
    .goto 1456/1,269.92,-980.40
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTigor|r
    .train 8498 >> Aprende tus hechizos de clase
    .target Tigor Skychaser
    .xp <16,1
step << Tauren Hunter/Tauren Warrior
    #completewith HunterTraining1 << Tauren Hunter
    #completewith WarriorTraining1 << Tauren Warrior
    .goto 1456/1,-123.26,-1394.49,60 >> Viaja al Alto de los Cazadores
step << Tauren Hunter
    #label HunterTraining1
    .goto 1456/1,-100.50,-1454.75
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cUrek|r
    .train 13795 >> Aprende tus hechizos de clase
    .target Urek Thunderhorn
    .xp <16,1
step << Tauren Hunter
    .goto 1456/1,-47.69,-1434.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHesuwa|r
    .train 24556 >> Entrena los hechizos de tu mascota
    .target Hesuwa Thunderhorn
step << Tauren Warrior
    .goto 1456/1,-81.09,-1457.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTorm|r
    .train 1160 >>Aprende tus hechizos de clase
    .target Torm Ragetotem
    .xp <14,1
    .xp >16,1
step << Tauren Warrior
    #label WarriorTraining1
    .goto 1456/1,-81.09,-1457.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTorm|r
    .train 285 >>Aprende tus hechizos de clase
    .target Torm Ragetotem
    .xp <16,1
step << Tauren
    .goto 1456/1,26.10,-1196.66--c:Thunder Bluff,47.00,49.82
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTal|r
    .turnin 6363 >>Entrega la misión Tal, maestro de jinetes del viento
    .accept 6364 >>Acepta la misión Regresa con Jahan
    .target Tal
step << Tauren
    #label FlyXroads2
    #completewith HidesTurnIn
    .goto 1456/1,26.1,-1196.66
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTal|r
    .fly Crossroads >>Vuela a El Cruce
    .target Tal
    .zoneskip The Barrens
step << Tauren
    .goto 1413/1,-2645.40,-406.94--c:The Barrens,51.99,29.89
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Boorand|r
    .home >>Establece tu Piedra de hogar en El Cruce
    .target Innkeeper Boorand Plainswind
    .bindlocation 380
    .isQuestAvailable 903,850,867,901
step
    .goto 1413/1,-2595.75,-473.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThork|r
    .turnin 5041 >>Entrega la misión Suministros para El Cruce
    .turnin 872 >>Entrega la misión La perturbación termina
    .target Thork
    .isQuestTurnedIn 871
step
    #label XroadsTurnins3
    .goto 1413/1,-2669.72,-481.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSergra|r
    .turnin 845 >>Entrega la misión La zhebra
    .accept 903 >>Acepta la misión Merodeadores en Los Baldíos
    .target Sergra Darkthorn
step << Tauren
    #label HidesTurnIn
    .goto 1413/1,-2566.36,-350.19--c:The Barrens,51.21,29.05
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJahan|r
    .turnin 6364 >>Entrega la misión Regresa con Jahan
    .target Jahan Hawkwing
    .isOnQuest 6364
step << Troll Hunter/Orc Hunter
    .goto 1413/1,-2612.98,-411.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cBarg|r
    >>|cffe07cf5Compra|r |T132382:0|t[Flechas afiladas] |cffe07cf5a este vendedor|r
    .collect 2515,1200,850,1 << Hunter --Sharp Arrow (1200)
    .target Barg
step << Tauren Hunter
    .goto 1413/1,-2612.98,-411.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cBarg|r
    >>|cffe07cf5Compra|r |T132384:0|t[Perdigones pesados] |cffe07cf5a este vendedor|r
    .collect 2519,1000,850,1 << Hunter --Heavy Shot (1000)
    .target Barg
step << Troll Hunter/Orc Hunter/Skyborne Hunter
    .goto 1413/1,-2556.23,-351.54
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cUthrok|r
    .vendor >> |cffe07cf5Cómprale un|r |T135490:0|t[|cff5cf05cArco largo refinado|r] |cffe07cf5si está disponible y abastécete de flechas|r
    >>|cffff9a3cSi no está disponible, compra un|r |T135490:0|t[Arco reforzado] |cffff9a3cen su lugar|r
    .collect 2515,1200,870,1 << Hunter --Sharp Arrow (1200)
    .target Uthrok
    .isOnQuest 903
step << Tauren Hunter
    .goto 1413/1,-2556.23,-351.54
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cUthrok|r|cffe07cf5. Compra una|r |T135613:0|t[Bocarda de cazador] |cffe07cf5a este vendedor|r
    .collect 2511,1,871,1 --Collect Hunter's Boomstick (1)
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<4.9
    .target Uthrok
step
    #optional
    #completewith RegtharDeathgate1
    >>Mata a los |cffff5a4aZancudos de llanura|r. Despójalos para obtener sus |cff4fc3f7Riñones|r
    .complete 821,2 --Plainstrider Kidney (5)
    .mob Greater Plainstrider
    .mob Fleeting Plainstrider
    .isQuestTurnedIn 819
step
    #optional
    #completewith next
    >>Mata a cada |cffff5a4aRaptor|r que veas. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Lashtail
    .mob Sunscale Screecher
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .accept 850 >>Acepta la misión Los jefes Kolkar
    .accept 855 >>Acepta la misión Los brazales centauro
    .target Regthar Deathgate
step
    #optional
    #label RegtharDeathgate1
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .accept 850 >>Acepta la misión Los jefes Kolkar
    .target Regthar Deathgate
step
    #optional
    #completewith KodobaneTurnin
    >>Mata |cffff5a4aRetadores Kolkar|r y |cffff5a4aAgitadoras Kolkar|r. Despójalos para obtener sus |cff4fc3f7Brazales|r
    >>|cffff9a3cEsta misión no tiene que ser completada ahora|r
    .complete 855,1 --Centaur Bracers (15)
    .mob Kolkar Wrangler
    .mob Kolkar Stormer
    .isOnQuest 855
step
    #optional
    #completewith Barak
    >>Recoge |cff4fc3f7Champiñones cargados|r alrededor de Las Charcas del Olvido
    >>|cffff9a3cEsta misión no tiene que ser completada ahora|r
    .complete 848,1 --Collect Fungal Spores (x4)
step
    .goto 1413/1,-1943.16,89.64
    >>Sumérgete bajo el agua hacia la |cffe07cf5Fisura burbujeante|r
    .complete 870,1 --Explore the waters of the Forgotten Pools
step
    #label Barak
    .goto 1413/1,-1716.18,23.43
    >>Mata a |cffff5a4aBarak Aterrakodos|r. Despójalo para obtener su |cff4fc3f7Cabeza|r
    >>|cffff9a3cTen cuidado ya que los golpes de |cffff5a4aBarak Aterrakodos|r causan MUCHO daño y está protegido por un |cffff5a4aRetador Kolkar|r. Pueden atraparte con una red y dispararte desde la distancia|r
    .complete 850,1 --Kodobane's Head (1)
    .mob Barak Kodobane
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 850 >>Entrega la misión Los jefes Kolkar
    .accept 851 >>Acepta la misión Verog el Derviche
    .turnin 855 >>Entrega la misión Los brazales centauro
    .target Regthar Deathgate
    .isQuestComplete 855
step
    #label KodobaneTurnin
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 850 >>Entrega la misión Los jefes Kolkar
    .accept 851 >>Acepta la misión Verog el Derviche
    .target Regthar Deathgate
step
    #optional
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .accept 851 >>Acepta la misión Verog el Derviche
    .target Regthar Deathgate
    .isQuestTurnedIn 850
step
    #optional
    #completewith HarpyTalons
    >>Mata a cada |cffff5a4aRaptor|r que veas. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Lashtail
    .mob Sunscale Screecher
step
    #completewith HarpyTalons
    .goto 1413/1,-1594.58,30.19,0
    .goto 1413/1,-1594.58,30.19,50,0
    .goto 1413/1,-1562.15,-29.94,50,0
    .goto 1413/1,-1483.11,66.67,50,0
    .goto 1413/1,-1531.75,180.85,50,0
    .goto 1413/1,-1462.84,214.63,50,0
    >>Mata |cffff5a4aMerodeadores de la sabana|r. Despójalos para obtener sus |cff4fc3f7Garras|r y |cff4fc3f7Colmillos|r
    .complete 903,1 --Prowler Claws (7)
    .complete 821,1 --Savannah Lion Tusk (5)
    .disablecheckbox
    .mob Savannah Prowler
    .isQuestTurnedIn 819
step
    #optional
    #completewith HarpyTalons
    .goto 1413/1,-1594.58,30.19,0
    .goto 1413/1,-1594.58,30.19,50,0
    .goto 1413/1,-1562.15,-29.94,50,0
    .goto 1413/1,-1483.11,66.67,50,0
    .goto 1413/1,-1531.75,180.85,50,0
    .goto 1413/1,-1462.84,214.63,50,0
    >>Mata |cffff5a4aMerodeadores de la sabana|r. Despójalos para obtener sus |cff4fc3f7Garras|r
    .complete 903,1 --Prowler Claws (7)
    .mob Savannah Prowler
    .isQuestAvailable 819
step
    #label HarpyTalons
    #loop
    .goto 1413/1,-1616.87,611.90,0
    .goto 1413/1,-1583.43,322.73,60,0
    .goto 1413/1,-1513.51,380.84,60,0
    .goto 1413/1,-1526.68,477.450,60,0
    .goto 1413/1,-1555.06,545.69,60,0
    .goto 1413/1,-1553.03,615.95,60,0
    .goto 1413/1,-1616.87,611.90,60,0
    >>Mata |cffff5a4aArpías Alabruja|r y |cffff5a4aMalaplumas Alabruja|r. Despójalas para obtener sus |cff4fc3f7Garras|r
    .complete 867,1 --Witchwing Talon (8)
    .mob Witchwing Harpy
    .mob Witchwing Roguefeather
step
    #completewith Samophlange
    +|cffff9a3cTen cuidado con los|r |cffff5a4aSegadores Solescama|r |cffff9a3cen la zona. Tienen hasta nivel 18 y pueden usar|r |T132152:0|t[Vapulear]
    .xp >17,1
step
    #optional
    #completewith Samophlange
    >>Mata a los |cffff5a4aZancudos de llanura|r. Despójalos para obtener sus |cff4fc3f7Riñones|r
    .complete 821,2 --Plainstrider Kidney (5)
    .mob Greater Plainstrider
    .mob Fleeting Plainstrider
    .mob Ornery Plainstrider
    .isQuestTurnedIn 819
step
    .goto 1413/1,-1812.500,790.000
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVrang|r
    .accept 95494 >>Acepta la misión El orgullo herido y la piel del león
    .accept 95507 >>Acepta la misión Las presas de Vrang
    .target Vrang Wildgore
step
    .goto 1413/1,-1815.48,786.89
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVrang|r
    >>|cff5cf05cVrang|r |cffff9a3cvende|r |T133476:0|t[|cff5cf05cMaza con pinchos pesada|r] |cffff9a3cque es un objeto de suministro limitado|r << Tauren Warrior/Tauren Shaman/Druid
	.vendor	>> Vende la basura y repara
    .target Vrang Wildgore
    .isQuestAvailable 95494,95507
step
    #completewith next
    >>Despoja las |cffe07cf5Trampas activadas|r del suelo
    .complete 95507,1 --|8/8 Trapped Game
step
    #loop
    .goto 1413/1,-1848.200,486.900,0
    .goto 1413/1,-1848.200,486.900,50,0
    .goto 1413/1,-1937.500,480.000,50,0
    .goto 1413/1,-1983.100,579.700,50,0
    .goto 1413/1,-1960.600,653.700,50,0
    .goto 1413/1,-1871.600,653.700,50,0
    .goto 1413/1,-1729.700,592.400,50,0
    >>Mata |cffff5a4aPatriarcas de la sabana|r. Despójalos para obtener sus |cff4fc3f7Cueros|r y |cff4fc3f7Colmillos|r
    >>|cffff9a3cSi los |cffff5a4aPatriarcas de la sabana|r están muy disputados, considera omitir esta misión por ahora, se puede completar más tarde|r
    .complete 95494,1 --|6/6 Savannah Lion Hide
    .complete 821,1 --Savannah Lion Tusk (5)
    .disablecheckbox
    .mob Savannah Patriarch
    .isQuestTurnedIn 819
step
    #optional
    #loop
    .goto 1413/1,-1848.200,486.900,0
    .goto 1413/1,-1848.200,486.900,50,0
    .goto 1413/1,-1937.500,480.000,50,0
    .goto 1413/1,-1983.100,579.700,50,0
    .goto 1413/1,-1960.600,653.700,50,0
    .goto 1413/1,-1871.600,653.700,50,0
    .goto 1413/1,-1729.700,592.400,50,0
    >>Mata a los |cffff5a4aPatriarcas de la sabana|r. Despójalos para obtener sus |cff4fc3f7Cueros|r
    >>|cffff9a3cSi los |cffff5a4aPatriarcas de la sabana|r están muy disputados, considera omitir esta misión por ahora, se puede completar más tarde|r
    .complete 95494,1 --|6/6 Savannah Lion Hide
    .mob Savannah Patriarch
    .isQuestAvailable 819
step
    #loop
    .goto 1413/1,-1960.600,653.700,0
    .goto 1413/1,-1848.200,486.900,50,0
    .goto 1413/1,-1937.500,480.000,50,0
    .goto 1413/1,-1983.100,579.700,50,0
    .goto 1413/1,-1960.600,653.700,50,0
    .goto 1413/1,-1871.600,653.700,50,0
    .goto 1413/1,-1729.700,592.400,50,0
    >>Despoja las |cffe07cf5Trampas activadas|r del suelo
    .complete 95507,1 --|8/8 Trapped Game
step
    .goto 1413/1,-1812.600,789.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVrang Sangrevaje|r
    .turnin 95494 >>Entrega la misión El orgullo herido y la piel del león
    .turnin 95507 >>Entrega la misión Las presas de Vrang
    .accept 95495 >>Acepta la misión El peletero ermitaño
    .target Vrang Wildgore
    .isQuestComplete 95494
step
    #completewith next
    .goto 1413/1,-1778.100,684.200,25,0
    .goto 1413/1,-1741.700,721.400,25,0
    .goto 1413/1,-1643.900,786.000,25,0
    .goto 1413/1,-1605.300,818.300,20 >>Sube por la montaña
step
    .goto 1413/1,-1635.400,838.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWalton|r
    .turnin 95495 >>Entrega la misión El peletero ermitaño
    .accept 95621 >>Acepta la misión Problemas en el valle
    .target Walton
    .isQuestTurnedIn 95494
step
    .goto 1413/1,-1611.500,549.000
    >>Mata al |cffff5a4aCabo Adamore|r
    >>|cffff9a3c¡Ten cuidado! Podrías llamar la atención (aggro) de 2 o 3 bichos a la vez|r
    .complete 95621,1 --|1/1 Learn why the Kul Tirans are here
    .mob Corporal Adamore
    .isQuestTurnedIn 95494
step
    #completewith next
    .goto 1413/1,-1736.900,650.300,25,0
    .goto 1413/1,-1741.700,721.400,25,0
    .goto 1413/1,-1643.900,786.000,25,0
    .goto 1413/1,-1605.300,818.300,20 >>Sube por la montaña
step
    .goto 1413/1,-1635.500,838.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWalton|r
    .turnin 95621 >>Entrega la misión Problemas en el valle
    .accept 95508 >>Acepta la misión Huéspedes no deseados
    .timer 67,Unwelcome Guests RP
    .target Walton
    .isQuestTurnedIn 95494
step
    .goto 1413/1,-1629.200,835.600
    >>Ponte detrás de la casa mientras esperas a que termine el RP para evitar llamar la atención (aggro) de todos los bichos a la vez
    >>|cffff9a3cEn realidad no necesitas ayudar a |cff5cf05cWalton|r, sobrevivirá con la ayuda de|r |cff5cf05cVrang Sangrevaje|r
    .complete 95508,1 --|1/1 Assist Walton
    .mob Terry Longdrink
    .isQuestTurnedIn 95494
step
    .goto 1413/1,-1635.400,838.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWalton|r
    .turnin 95508 >>Entrega la misión Huéspedes no deseados
    .target Walton
    .isQuestTurnedIn 95494
step
	#label Samophlange
    .goto 1413/1,-2686.95,825.40
    >>Haz clic en la |cffe07cf5Consola de control|r
    .turnin 894 >>Entrega la misión El churumbele
    .accept 900 >>Acepta la misión El churumbele
step
    .goto 1413/1,-2686.95,842.290
    >>Haz clic en la |cffe07cf5Válvula|r
    >>|cffff9a3c¡Ten cuidado! Dos enemigos aparecerán después de que cierres la Válvula|r
    .complete 900,1 --Shut off Main Control Valve (1)
step
    .goto 1413/1,-2675.80,842.290
    >>Haz clic en la |cffe07cf5Válvula|r
    >>|cffff9a3cUn enemigo aparecerá después de que cierres la Válvula|r
    .complete 900,3 --Shut off Regulator Valve (1)
step
    .goto 1413/1,-2679.86,830.80
    >>Haz clic en la |cffe07cf5Válvula|r
    .complete 900,2 --Shut off Fuel Control Valve (1)
step
    .goto 1413/1,-2686.95,825.40
    >>Haz clic en la |cffe07cf5Consola de control|r
    .turnin 900 >>Entrega la misión El churumbele
    .accept 901 >>Acepta la misión El churumbele
step
    .goto 1413/1,-2731.54,909.850
    >>Mata a |cffff5a4aManitas el Risitas|r en el edificio. Despójalo para obtener su |cff4fc3f7Llave de la consola|r
    .complete 901,1 --Console Key (1)
    .mob Tinkerer Sniggles
step
    .goto 1413/1,-2686.95,825.40
    >>Haz clic en la |cffe07cf5Consola de control|r
    .turnin 901 >>Entrega la misión El churumbele
    .accept 902 >>Acepta la misión El churumbele
step
    #optional
    #completewith Ignition
    >>Mata a los |cffff5a4aZancudos de llanura|r. Despójalos para obtener sus |cff4fc3f7Riñones|r
    .complete 821,2 --Plainstrider Kidney (5)
    .mob Greater Plainstrider
    .mob Fleeting Plainstrider
    .mob Ornery Plainstrideridneys
    .isQuestTurnedIn 819
step
    #completewith RaptorHeadsComplete
    >>Mata |cffff5a4aMerodeadores de la sabana|r. Despójalos para obtener sus |cff4fc3f7Garras|r y |cff4fc3f7Colmillos|r
    .complete 903,1 --Prowler Claws (7)
    .complete 821,1 --Savannah Lion Tusk (5)
    .mob Savannah Prowler
    .isQuestTurnedIn 819
step
    #optional
    #completewith RaptorHeadsComplete
    >>Mata |cffff5a4aMerodeadores de la sabana|r. Despójalos para obtener sus |cff4fc3f7Garras|r
    .complete 903,1 --Prowler Claws (7)
    .mob Savannah Prowler
    .isQuestAvailable 819
step
    #label RaptorHeadsComplete
    #loop
    .goto 1413/1,-2879.48,781.48,0
    .goto 1413/1,-2879.48,781.48,90,0
    .goto 1413/1,-2909.88,484.21,90,0
    .goto 1413/1,-2666.500,719.600,90,0
    .goto 1413/1,-2965.400,1009.100,90,0
    >>Mata a los |cffff5a4aRaptores|r. Despójalos para obtener sus |cff4fc3f7Cabezas|r
    .complete 869,1 --Raptor Head (12)
    .mob Sunscale Lashtail
    .mob Sunscale Screecher
    .mob Sunscale Scytheclaw
step
    #loop
    .goto 1413/1,-2783.900,568.700,0
    .goto 1413/1,-2783.900,568.700,50,0
    .goto 1413/1,-2859.800,565.900,50,0
    .goto 1413/1,-3023.000,530.700,50,0
    .goto 1413/1,-2897.500,642.200,50,0
    >>Mata |cffff5a4aMerodeadores de la sabana|r. Despójalos para obtener sus |cff4fc3f7Garras|r y |cff4fc3f7Colmillos|r
    .complete 903,1 --Prowler Claws (7)
    .complete 821,1 --Savannah Lion Tusk (5)
    .mob Savannah Prowler
    .isQuestTurnedIn 819
step
    #optional
    #loop
    .goto 1413/1,-2783.900,568.700,0
    .goto 1413/1,-2783.900,568.700,50,0
    .goto 1413/1,-2859.800,565.900,50,0
    .goto 1413/1,-3023.000,530.700,50,0
    .goto 1413/1,-2897.500,642.200,50,0
    >>Mata |cffff5a4aMerodeadores de la sabana|r. Despójalos para obtener sus |cff4fc3f7Garras|r
    .complete 903,1 --Prowler Claws (7)
    .mob Savannah Prowler
    .isQuestAvailable 819
step
    #optional
    .goto 1413/1,-3102.42,1105.78
    >>Sube al nivel 16 aquí matando enemigos, es importante, porque las próximas 3 misiones son bastante difíciles
	.xp 16
step
    #label Ignition
    .goto 1413/1,-3104.44,1109.16
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el|r |cff5cf05cMachacador de Rabiaire|r en el Fangal
    >>|cff5cf05cMachacador de Rabiaire|r |cffff9a3ctiene un tiempo de reaparición largo. Considera omitir esta misión si hay mucha competencia|r
    .accept 858 >>Acepta la misión La llave de contacto
    .target Wizzlecrank's Shredder
step
    #completewith next
    +|cffff9a3cTen cuidado si el|r |cffff5a4aSupervisor Asas|r |cffff9a3co la|r |cffff5a4aBestia de lodo|r |cffff9a3cestán vivos. Son élites raros de nivel 19 muy fuertes|r
    .unitscan Foreman Grills
    .unitscan Sludge Beast
step
    .goto 1413/1,-3104.44,1040.25,20,0
    .goto 1413/1,-3086.20,1055.78,12,0
    .goto 1413/1,-3063.91,1049.70,12,0
    .goto 1413/1,-3056.82,1038.89,12,0
    .goto 1413/1,-3064.92,1034.16,12,0
    .goto 1413/1,-3086.20,1055.78
    >>Mata al |cffff5a4aSupervisor Palarrastre|r. Despójalo para obtener su |cff4fc3f7Llave|r
    >>|cffff9a3cPatrulla subiendo y bajando la plataforma|r
    .complete 858,1 --Ignition Key (1)
    .mob Supervisor Lugwizzle
    .isOnQuest 858
step
    .goto 1413/1,-3104.44,1109.16
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el|r |cff5cf05cMachacador de Rabiaire|r
    >>|cff5cf05cMachacador de Rabiaire|r |cffff9a3ctiene un tiempo de reaparición largo. Considera omitir esta misión si hay mucha competencia|r
    >>|cffff9a3cEsto iniciará una escolta. Asegúrate de estar a plena salud|r
    .turnin 858 >>Entrega la misión La llave de contacto
    .accept 863,1 >>Acepta la misión La fuga
    .target Wizzlecrank's Shredder
    .isQuestComplete 858
step
    #optional
    .goto 1413/1,-3104.44,1109.16
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el|r |cff5cf05cMachacador de Rabiaire|r
    >>|cff5cf05cMachacador de Rabiaire|r |cffff9a3ctiene un tiempo de reaparición largo. Considera omitir esta misión si hay mucha competencia|r
    >>|cffff9a3cEsto iniciará una escolta. Asegúrate de estar a plena salud|r
    .accept 863,1 >>Acepta la misión La fuga
    .target Wizzlecrank's Shredder
    .isQuestTurnedIn 858
step
    #label Slugs
    .goto 1413/1,-3031.48,1088.21,30,0
    .goto 1413/1,-3002.10,1130.78
    >>|cffff9a3cDos|r |cffff5a4aMercenarios de Ventura y Cía.|r |cffff9a3caparecerán cuando la trituradora suba al terreno elevado. Mátalos y luego espera por su evento de RP al final|r
    .complete 863,1 --Escort Wizzlecrank out of the Venture Co. drill site (1)
    .mob Venture Co. Mercenary
    .mob Venture Co. Drudger
    .mob Overseer Glibby
    .isOnQuest 863
step
    #optional
    #completewith next
    >>Mata a los |cffff5a4aZancudos de llanura|r. Despójalos para obtener sus |cff4fc3f7Riñones|r
    .complete 821,2 --Plainstrider Kidney (5)
    .mob Greater Plainstrider
    .mob Fleeting Plainstrider
    .mob Ornery Plainstrider
    .isQuestTurnedIn 819
step
    #label CatsEye
    #loop
    .goto 1413/1,-3610.1,1313.2,0
    .goto 1413/1,-3605.03,1308.47,40,0
    .goto 1413/1,-3564.5,1367.25,40,0
    .goto 1413/1,-3622.26,1384.81,40,0
    .goto 1413/1,-3673.94,1374.68,40,0
    .goto 1413/1,-3653.67,1306.44,40,0
    .goto 1413/1,-3644.55,1249.69,40,0
    .goto 1413/1,-3603.0,1236.85,40,0
    .goto 1413/1,-3575.64,1271.31,40,0
    .goto 1413/1,-3610.1,1313.2,40,0
    >>Mata |cffff5a4aDéspotas de Ventura y Cía.|r y |cffff5a4aSobrestantes de Ventura y Cía.|r. Despójalos para obtener la |cff4fc3f7Esmeralda ojo de gato|r
    >>|cffff9a3cSi no ha caído después de 25+ enemigos, puedes omitir esta misión|r
    .complete 896,1 -- Cats Eye Emerald (1)
    .mob Venture Co. Enforcer
    .mob Venture Co. Overseer
step << skip
    .goto 1413/1,-3505.72,1358.46
    .goto 1454/1,-4242.34,1637.33,30 >>|cffff9a3cSalta a la viga de madera. Haz un Logout Skip desconectando y volviendo a entrar. Regresa a Orgrimmar si no lo logras|r
    .link https://www.youtube.com/watch?v=U7YfoaO-X8E >> |cffff9a3cHAZ CLIC AQUÍ para ver un ejemplo|r
    .zoneskip Orgrimmar
step
    #completewith SpiritsPickup
    .goto 1414/1,-3839.37,1644.65
    .zone Orgrimmar >>Entra en Orgrimmar por la entrada occidental
step
    #completewith next
    .skill firstaid,40 >> |cffff9a3cCrea|r |T133685:0|t[Vendas de lino] |cffff9a3chasta que tu habilidad sea 40 o superior|r
    .skill firstaid,<1,1
step
    .goto 1454/1,-4160.01,1483.17
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cArnok|r
    >>|cffff9a3cOmitir este paso si no tuviste suficiente|r |T132889:0|t[Paño de lino] |cffff9a3cpara llegar a 40 de habilidad|r
    .train 3276 >> Aprende |T133688:0|t[Venda de lino gruesa]
    .target Arnok
    .skill firstaid,<1,1
step
    #completewith next
    .skill firstaid,50 >> |cffff9a3cCrea|r |T133688:0|t[Vendas de lino gruesas] |cffff9a3chasta que tu habilidad sea 50 o superior|r
    .skill firstaid,<1,1
step
    .goto 1454/1,-4160.01,1483.17
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cArnok|r
    >>|cffff9a3cOmite este paso si no tuviste suficiente|r |T132889:0|t[Paño de lino] |cffff9a3cpara alcanzar a 50 de habilidad|r
    .train 3274 >> Aprende Oficial de primeros auxilios
    .target Arnok
    .skill firstaid,<40,1
step << Priest
    #optional
    .goto 1454/1,-4179.79,1452.580
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cUr'kyo|r
    .train 8102 >> Aprende tus hechizos de clase
    .target Ur'kyo
    .xp <16,1
    .xp >18,1
step << Priest
    #optional
    .goto 1454/1,-4179.79,1452.580
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cUr'kyo|r
    .train 970 >> Aprende tus hechizos de clase
    .target Ur'kyo
    .xp <18,1
step << Mage
    .goto 1454/1,-4218.64,1473.72
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cPephredo|r
    .train 2120 >> Aprende tus hechizos de clase
    .target Pephredo
    .xp <16,1
    .xp >18,1
step << Mage
    #optional
    .goto 1454/1,-4218.64,1473.72
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cPephredo|r
    .train 3140 >> Aprende tus hechizos de clase
    .target Pephredo
    .xp <18,1
step << Orc/Troll
    .goto 1454/1,-4439.37,1633.99
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cGryshka|r
    .turnin 6384 >>Entrega la misión Un viaje a Orgrimmar
    .accept 6385 >>Acepta la misión Doras, maestro de jinetes del viento
    .target Innkeeper Gryshka
    .isOnQuest 6384
step << Orc/Troll
    .goto 1454/1,-4313.46,1676.25--c:Orgrimmar,45.120,63.889
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cDoras|r
    .turnin 6385 >> Entrega la misión Doras, maestro de jinetes del viento
    .accept 6386 >> Acepta la misión Regreso a El Cruce
    .target Doras
    .isOnQuest 6385
step << Orc/Troll
    #optional
    .goto 1454/1,-4313.46,1676.25--c:Orgrimmar,45.120,63.889
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cDoras|r
    .accept 6386 >> Acepta la misión Regreso a El Cruce
    .target Doras
    .isQuestTurnedIn 6385
step << Tauren/Undead
    .goto 1454/1,-4313.60,1676.24
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDoras|r
    >>|cffff9a3c¡No vueles a ningún lado!|r
    .fp Orgrimmar >> Consigue la ruta de vuelo de Orgrimmar
    .target Doras
    .isQuestAvailable 4921
step << Warrior
    .goto 1454/1,-4801.42,1980.53
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGrezz|r
    .train 285 >> Aprende tus hechizos de clase
    .target Grezz Ragefist
    .xp <16,1
    .xp >18,1
step << Warrior
    #optional
    .goto 1454/1,-4801.42,1980.53
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGrezz|r
    .train 8198 >> Aprende tus hechizos de clase
    .target Grezz Ragefist
    .xp <18,1
step << Hunter
    .goto 1454/1,-4607.02,2100.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOrmak|r
    .train 13795 >> Aprende tus hechizos de clase
    .target Ormak Grimshot
    .xp <16,1
    .xp >18,1
step << Hunter
    #optional
    .goto 1454/1,-4607.02,2100.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOrmak|r
    .train 2643 >> Aprende tus hechizos de clase
    .target Ormak Grimshot
    .xp <18,1
step << Hunter
    .goto 1454/1,-4611.09,2135.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cXao'tsu|r
    .train 24557 >> Entrena los hechizos de tu mascota
    .target Xao'tsu
    .xp <18,1
step << Troll Hunter/Orc Hunter/Priest
    .goto 1454/1,-4824.00,2090.540
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHanashi|r
    .train 227 >>Aprende el uso de Bastones
    .target Hanashi
    .money <0.100
step << Tauren Hunter
    .goto 1454/1,-4824.00,2090.540
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHanashi|r
    .train 264 >>Aprende el uso de Arcos
    .target Hanashi
step << Warrior !Skyborne
    .goto 1454/1,-4824.00,2090.540
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHanashi|r
    .train 197 >>Aprende el uso de Hachas de dos manos
    .train 227 >>Aprende el uso de Bastones
    .target Hanashi
    .money <0.020
step << Warrior/Paladin/Shaman !Skyborne
    #optional
    .goto 1454/1,-4824.00,2090.540
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHanashi|r
    .train 197 >>Aprende el uso de Hachas de dos manos
    .target Hanashi
    .money <0.010
step << Hunter
    .goto 1454/1,-4819.1,2099.05
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cZendo'jian|r|cffe07cf5. Compra un|r |T135490:0|t[Arco reforzado] |cffe07cf5a este vendedor|r
    .collect 3026,1,3281,1 --Collect Reinforced Bow (1)
    .money <0.3588
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<7.4
    .target Zendo'jian
    .train 227,3
step << Hunter
    #optional
    #completewith FoodandWater2
    +|cffff9a3cEquipa el|r |T135490:0|t[Arco reforzado]
    .use 3026
    .itemcount 3026,1
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<7.4
step << Warrior
    .goto 1454/1,-4819.1,2099.05
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cZendo'jian|r|cffe07cf5. Compra un|r |T135423:0|t[Hacha de batalla] |cffe07cf5a este vendedor|r
    .collect 926,1,3281,1 --Collect Battle Axe (1)
    .money <1.021
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.2
    .target Zendo'jian
    .train 227,3
step << Warrior
    #optional
    #completewith FoodandWater2
    +|cffff9a3cEquipa el|r |T135423:0|t[Hacha de batalla] |cffff9a3ccuando alcances nivel 20|r
    .use 926
    .itemcount 926,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.2
    .xp >20,1
step << Warrior
    #optional
    #completewith FoodandWater2
    +|cffff9a3cEquipa el|r |T135423:0|t[Hacha de batalla]
    .use 926
    .itemcount 926,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.2
    .xp <20,1
step << Shaman
    .goto 1454/1,-4225.09,1933.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKardris|r
    .train 8019 >> Aprende tus hechizos de clase
    .target Kardris Dreamseeker
    .xp <16,1
    .xp >18,1
step << Shaman
    #optional
    .goto 1454/1,-4225.09,1933.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKardris|r
    .train 913 >> Aprende tus hechizos de clase
    .target Kardris Dreamseeker
    .xp <18,1
step
    .goto 1454/1,-4226.78,1914.77
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZor|r
    .accept 1061 >>Acepta la misión Los espíritus del Espolón
    .target Zor Lonetree
step << Rogue
    .goto 1454/1,-4284.42,1771.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShenthul|r
    .train 1804 >> Aprende |T136058:0|t[Forzar cerradura]
    .train 921 >> Aprende |T133644:0|t[Robar]
    .accept 2379 >> Acepta la misión Zando'zan
    .target Shenthul
step << Orc Rogue/Troll Rogue
    .goto 1454/1,-4280.07,1772.96
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTherzok|r
    .turnin -1963 >> Entrega la misión Mano Destrozada
    .accept 1858 >> Acepta la misión Mano Destrozada
    .target Therzok
step << Rogue
    .goto 1454/1,-4279.79,1778.57
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZando'zan|r
    .turnin 2379 >>Entrega la misión Zando'zan
    .accept 2382 >>Acepta la misión Desdio de Trinquete
    .target Zando'zan
step << Orc Rogue/Troll Rogue
    #optional
    #completewith next
    .goto 1454/1,-4271.1,1810.75
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cRekkul|r|cffe07cf5. Compra |r |T134065:0|t[Herramientas de ladrón] |cffe07cf5a este vendedor|r
    .collect 5060,1,1858,1 --Collect Thieves' Tools (1)
    .target Rekkul
    .money <0.15
step << Orc Rogue/Troll Rogue
    .goto 1454/1,-4280.07,1773.24
    >>|cffff9a3cUsa|r |T136058:0|t[Forzar cerradura] |cffff9a3cpara abrir la|r |T133626:0|t[Cartera de Tazan]
    .complete 1858,1 --Tazan's Logbook (1)
    .money <0.15
step << Orc Rogue/Troll Rogue
    .goto 1454/1,-4280.07,1772.96
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTherzok|r
    .turnin 1858 >>Entrega la misión Mano Destrozada
    .target Therzok
step << Orc Rogue/Troll Rogue
    .goto 1454/1,-4437.87,1637.33
    >>|cffff9a3cUsa|r |T133644:0|t[Robar] |cffff9a3ccon|r |cffff5a4aGamon|r |cffff9a3cen la Posada. Usa su llave para abrir la|r |T133626:0|t[Cartera de Tazan]
	.collect 7208,1,1858,1 --Tazan's Key
	.complete 1858,1 --Tazan's Logbook (1)
    .isOnQuest 1858
step << Orc Rogue/Troll Rogue
    .goto 1454/1,-4280.07,1772.96
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTherzok|r
    .turnin 1858 >>Entrega la misión Mano Destrozada
    .target Therzok
step << Warlock
    .goto 1454/1,-4362.55,1834.70
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMirket|r
    .train 1455 >> Aprende tus hechizos de clase
    .target Mirket
    .xp <16,1
    .xp >18,1
step << Warlock
    #optional
    .goto 1454/1,-4362.55,1834.70
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMirket|r
    .train 1014 >> Aprende tus hechizos de clase
    .target Mirket
    .xp <18,1
step << Warlock
    .goto 1454/1,-4347.4,1836.57
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKurgul|r y compra |T133738:0|t[Grimorio Sacrificio]
    .collect 16351,1,896,1 --Grimoire of Sacrifice (Rank 1) (1)
    .target Kurgul
    .xp <16,1
    .xp >18,1
step << Warlock
    .goto 1454/1,-4347.4,1836.57
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKurgul|r y compra |T133738:0|t[Grimorio Descarga de Fuego (Rango 3)]
    .collect 16316,1,896,1 --Grimoire of Firebolt (Rank 3) (1)
    .target Kurgul
    .xp <18,1
step
    #optional
    #label SpiritsPickup
step
    #completewith FoodandWater2
    .hs >> Usa tu Piedra de hogar para ir a El Cruce
    .cooldown item,6948,>0
    .use 6948
    .bindlocation 380,1
    .subzoneskip 380
step
    #completewith FoodandWater2
    .goto 1454/1,-4313.46,1676.25--c:Orgrimmar,45.120,63.889
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cDoras|r
    .fly Crossroads >>Vuela a El Cruce
    .target Doras
    .cooldown item,6948,<0
    .subzoneskip 380
step
    #label FoodandWater2
    .goto 1413/1,-2645.40,-406.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Boorand|r
	.vendor >>|cffe07cf5Vende la basura y luego reabastécete de comida y agua si es necesario|r << !Rogue !Warrior
    .vendor >>|cffe07cf5Vende tu basura, luego reabastécete de comida si es necesario|r << Rogue/Warrior
    .target Innkeeper Boorand Plainswind
    .isQuestAvailable 3281
step
    .goto 1413/1,-2639.32,-436.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGazrog|r
    .turnin 869 >>Entrega la misión Raptores ladrones
    .accept 3281 >>Acepta la misión Plata robada
    .target Gazrog
step
    .goto 1413/1,-2589.67,-424.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHelbrim|r
    .turnin 848 >> Entrega la misión Esporas de hongos
    .target Apothecary Helbrim
    .isQuestComplete 848
step
    .goto 1413/1,-2607.91,-475.180
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDarsok|r
    .turnin 867 >>Entrega la misión Arpías saqueadoras
    .accept 875 >>Acepta la misión Las tenientes arpías
    .target Darsok Swiftdagger
step
    .goto 1413/1,-2641.35,-521.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMankrik|r
    .accept 899 >>Acepta la misión Consumido por el odio
    .accept 4921 >>Acepta la misión Perdida en la batalla
    .target Mankrik
step
    .goto 1413/1,-2672.76,-544.77
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTonga|r
    .turnin 870 >>Entrega la misión Las Charcas del Olvido
    .accept 877 >>Acepta la misión El Oasis Estancado
    .target Tonga Runetotem
step
    #label EcheyakeePickup
    .goto 1413/1,-2670.74,-482.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSergra|r
    .turnin 903 >>Entrega la misión Merodeadores en Los Baldíos
    .accept 881 >>Acepta la misión Echeyakee
    .target Sergra Darkthorn
step << Orc/Troll
    .goto 1413/1,-2709.24,-404.24
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZargh|r
    .turnin 6386 >> Entrega la misión Regreso a El Cruce
    .target Zargh
    .isOnQuest 6386
step
    .goto 1413/1,-2711.800,-350.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGur'ak|r
    .accept 97003 >>Acepta la misión Chol'aruk, el Insaciable
    .target Gur'ak
step
    #completewith RapHornsPickup
    .goto 1413/1,-3262.600,-99.400,0
    +|cffff9a3cMientras sigues haciendo misiones en Los Baldíos, intenta encontrar un grupo de 5 personas para "Chol'aruk, el Insaciable" en algún momento|r
    >>|cffff9a3cCompletar esto otorgará 4100 xp. La entrada a la cueva donde se encuentra está marcada en tu mapa (zona de |cffff5a4aCrines de Acero|r)|r
    .isOnQuest 97003
step
    .goto 1413/1,-3031.48,461.91
    >>Usa el |T134227:0|t[Cuerno de Echeyakee] para invocar a |cffff5a4aEcheyakee|r
    >>Mata a |cffff5a4aEcheyakee|r. Despójalo para obtener |cff4fc3f7Pellejo de Echeyakee|r
    >>|cffff9a3cSi |cffff5a4aEcheyakee|r no aparece después de usar el|r |T134227:0|t[Cuerno de Echeyakee]|cffff9a3c o no le diste el primer golpe al aparecer, salta este paso|r
    .complete 881,1 --Echeyakee's Hide (1)
    .mob Echeyakee
    .use 10327
step
    #optional
    .goto 1413/1,-2669.72,-481.94
    .abandon 881 >>|cffff9a3cSi |cffff5a4aEcheyakee|r no apareció después de usar el|r |T134227:0|t[Cuerno de Echeyakee]|cffff9a3c o no le diste el primer golpe al aparecer, abandona la misión Echeyakee, luego regresa a la ciudad y acéptala de nuevo|r
    .itemcount 5100,<1 --Echeyakee's Hide (0)
step
    .goto 1413/1,-2670.74,-482.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSergra|r
    .accept 881 >>Acepta la misión Echeyakee
    .target Sergra Darkthorn
    .itemcount 5100,<1 --Echeyakee's Hide (0)
step
    .goto 1413/1,-3031.48,461.91
    >>Usa el |T134227:0|t[Cuerno de Echeyakee] para invocar a |cffff5a4aEcheyakee|r
    >>Mata a |cffff5a4aEcheyakee|r. Despójalo para obtener |cff4fc3f7Pellejo de Echeyakee|r
    .complete 881,1 --Echeyakee's Hide (1)
    .mob Echeyakee
    .use 10327
step
    .goto 1413/1,-2670.74,-482.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSergra|r
    .turnin 881 >>Entrega la misión Echeyakee
    .accept 905 >>Acepta la misión Los segadores furiosos
    .target Sergra Darkthorn
step
    #optional
    #completewith RapHornsPickup
    .destroy 10327 >>|cffff9a3cDestruye el|r |T134227:0|t[Cuerno de Echeyakee] |cffff9a3cya que ya no lo necesitas|r
step << Hunter
    .goto 1413/1,-2612.98,-411.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cBarg|r
    >>|cffe07cf5Compra|r |T132382:0|t[Flechas afiladas] |cffe07cf5a este vendedor|r
    .collect 2515,1800,888,1 << Hunter --Sharp Arrow (1800)
    .target Barg
step
    #completewith RapHornsPickup
    .goto 1413/1,-2595.75,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDevrak|r
    .fly Ratchet >>Vuela a Trinquete
    .target Devrak
    .subzoneskip 392
step << Rogue
    .goto 1413/1,-3767.800,-842.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDesdio|r
    .turnin 2382 >>Entrega la misión Desdio de Trinquete
    .accept 2381 >>Acepta la misión Saquear a los saqueadores
    .target Wrenix the Wretched
step << Rogue
    .goto 1413/1,-3773.24,-841.37
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cAparato Gizmotrónico de Wrenix|r
    >>Obtén un|cffff9a3c |T134059:0|t[G.E.A.Q.] |ry una|cffff9a3c |T134065:0|t[Herramientas de ladrón]|r
    .collect 7970,1,888,1 --E.C.A.C. (1)
    .collect 5060,1,888,1 --Thieves' Tools (1)
step
    .goto 1413/1,-3759.06,-902.18
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cPetardol|r y |cff5cf05cVertipeluca|r
    .turnin 902 >>Entrega la misión El churumbele
    .turnin 863 >> Entrega la misión La fuga
    .accept 3921 >> Acepta la misión Wenikee Tuercasmil << Hunter
    .accept 1483 >> Acepta la misión Ziz Fizziks
    .target Sputtervalve
    .isQuestComplete 863
step
    #optional
    .goto 1413/1,-3759.06,-902.18
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cPetardol|r y |cff5cf05cVertipeluca|r
    .turnin 902 >>Entrega la misión El churumbele
    .accept 3921 >> Acepta la misión Wenikee Tuercasmil << Hunter
    .accept 1483 >> Acepta la misión Ziz Fizziks
    .target Sputtervalve
step
    .goto 1413/1,-3796.55,-985.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con  |cff5cf05cVertipeluca|r
    .turnin 896 >> Entrega la misión La fortuna de un minero
    .target Wharfmaster Dizzywig
    .isQuestComplete 896
step
    #label RapHornsPickup
    .goto 1413/1,-3697.24,-929.20
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMebok|r
    .accept 865 >>Acepta la misión Cuernos de raptor
    .accept 1069 >>Acepta la misión Huevos de araña musgondo
    .target Mebok Mizzyrix
step << skip
    .goto 1413/1,-3664.82,-1050.14
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Wiley|r
    -->>|cffe07cf5Buy|r |T133918:0|t[Longjaw Mud Snappers] |cffe07cf5from him|r
    >>|cffe07cf5Compra|r |T132796:0|t[Zumo de melón] |cffe07cf5a este vendedor|r << Mage/Warlock/Priest/Shaman/Druid
    -->>|T133918:0|t[Longjaw Mud Snappers] |cffff9a3care extremely cheap, buy as many as you want|r
    .vendor >> Vende la Basura
    --.collect 4592,20,888,1 --Longjaw Mud Snapper (20)
    .collect 1205,10,888,1 << Mage/Warlock/Priest/Shaman/Druid --Melon Juice (10)
    .target Innkeeper Wiley
step << Rogue
	#completewith next
    .goto 1413/1,-3967.8,-1457.54
    +|cffff9a3cSalta al barco, baja al 2.º piso y sube tu habilidad de Forzar cerraduras al menos hasta 70|r
step << Rogue
    .goto 1413/1,-3958.68,-1457.54
    >>Cuando tengas Forzar cerraduras al 70, ve al piso inferior del barco y abre |cffe07cf5La joya de los Mares del Sur|r
    >>|cffff9a3cUsa el|r |T134059:0|t[G.E.A.Q.] |cffff9a3ccon|r |cffff5a4aPolly|r
    .complete 2381,1 --Southsea Treasure (1)
    .use 7970
    .mob Polly
step
    #label LeaveRatchet
    .goto 1413/1,-3819.86,-1714.95
    >>Despoja el |cffe07cf5Cajón|r del suelo
    .complete 888,2 --Telescopic Lens (1)
step
    .goto 1413/1,-3723.59,-1741.30
    >>Despoja el |cffe07cf5Cajón|r del suelo
    .complete 888,1 --Shipment of Boots (1)
step
    #optional
    #completewith TestSeeds
    >>Mata a los |cffff5a4aZancudos de llanura|r. Despójalos para obtener sus |cff4fc3f7Riñones|r
    .complete 821,2 --Plainstrider Kidney (5)
    .mob Greater Plainstrider
    .mob Fleeting Plainstrider
    .mob Ornery Plainstrider
    .isQuestTurnedIn 819
step
    #optional
    #completewith TestSeeds
    >>Mata a los |cffff5a4aSegadores Solescama|r. Despójalos para obtener sus |cff4fc3f7Cuernos|r y sus |cff4fc3f7Plumas|r
    >>|cffff9a3cTen cuidado, ya que lanzan|r |T132152:0|t[Vapulear] |cffff9a3c(Carga 2 ataques extra cada 10 segundos)|r
    .complete 865,1 --Intact Raptor Horn (5)
    .collect 5165,3,905,3 --Sunscale Feather (3)
    .mob Sunscale Scytheclaw
step
    .goto 1413/1,-3192.60,-1919.67,60,0
    .goto 1413/1,-3258.47,-2027.09
    >>Despoja la |cffe07cf5Plata robada|r del suelo
    .complete 3281,1 --Stolen Silver (1)
step
    #optional
    #completewith TestSeeds
    >>Mata a los |cffff5a4aKolkar|r alrededor del oasis. Despójalos para obtener sus |cff4fc3f7Brazales|r
    .complete 855,1 --Centaur Bracers (15)
    .mob Kolkar Bloodcharger
    .mob Kolkar Pack runner
    .mob Kolkar Marauder
    .isOnQuest 851
step
    #optional
    #completewith Verog
    >>Recoge los |cff4fc3f7Champiñones cargados|r alrededor de El Oasis Estancado
    .complete 848,1 --Collect Fungal Spores (x4)
step
    #label TestSeeds
    .goto 1413/1,-3012.23,-1275.80
    >>Haz clic en la |cffe07cf5Fisura burbujeante|r bajo el agua
    .complete 877,1 --Test the Dried Seeds (1)
step
    #optional
    #completewith next
    #loop
    .goto 1413/1,-3031.48,-1480.51,50,0
    .goto 1413/1,-3127.75,-1320.39,50,0
    .goto 1413/1,-3154.1,-1172.43,50,0
    .goto 1413/1,-2996.02,-1182.56,50,0
    .goto 1413/1,-2949.4,-1146.75,50,0
    .goto 1413/1,-2789.3,-1107.57,50,0
    .goto 1413/1,-2746.74,-1409.57,50,0
    .goto 1413/1,-2880.5,-1550.1,50,0
    >>Mata a los |cffff5a4aKolkar|r alrededor del oasis. Despójalos para obtener sus |cff4fc3f7Brazales|r
    .complete 855,1 --Centaur Bracers (15)
    .mob Kolkar Bloodcharger
    .mob Kolkar Pack runner
    .mob Kolkar Marauder
    .isOnQuest 851
step
    #label Verog
    .goto 1413/1,-2742.68,-1208.23
    >>Mata a |cffff5a4aVerog|r. Despójalo para obtener su |cff4fc3f7Cabeza|r
    >>|cffff9a3cTiene probabilidad de aparecer cada vez que un |cffff5a4aKolkar|r muere|r
    >>|cffff9a3cEn un servidor muy poblado o en un lanzamiento nuevo, tu mejor opción es acampar en su punto de aparición|r
    .complete 851,1 --Verog's Head (1)
    .unitscan Verog the Dervish
    .isOnQuest 851
step
    #loop
    .goto 1413/1,-3023.38,-1234.58,0
    .goto 1413/1,-3023.38,-1234.58,30,0
    .goto 1413/1,-3000.07,-1208.23,30,0
    .goto 1413/1,-2959.54,-1196.75,30,0
    .goto 1413/1,-2953.46,-1241.34,30,0
    .goto 1413/1,-2977.78,-1304.17,30,0
    .goto 1413/1,-3029.46,-1324.44,30,0
    .goto 1413/1,-3066.95,-1311.61,30,0
    .goto 1413/1,-3059.86,-1264.31,30,0
    >>Recoge los |cff4fc3f7Champiñones cargados|r alrededor de El Oasis Estancado
    .complete 848,1 --Collect Fungal Spores (x4)
step
    #optional
    #completewith LakotaMani1
    >>Mata a los |cffff5a4aZancudos de llanura|r. Despójalos para obtener sus |cff4fc3f7Riñones|r
    .complete 821,2 --Plainstrider Kidney (5)
    .mob Greater Plainstrider
    .mob Fleeting Plainstrider
    .mob Ornery Plainstrider
    .isQuestTurnedIn 819
step
    .goto 1413/1,-2707.22,-1502.130
    >>Haz clic en el |cffe07cf5Nido de raptor azul|r. Mata a más |cffff5a4aSegadores Solescama|r si no tienes una |T132914:0|t[Pluma de Solescama]
    >>|cffff9a3cTen cuidado, ya que lanzan|r |T132152:0|t[Vapulear] |cffff9a3c(Carga 2 ataques extra cada 10 segundos)|r
    .complete 905,1 --Visit Blue Raptor Nest (1)
    .collect 5165,3,905,7,3
    .mob Sunscale Scytheclaw
step
    .goto 1413/1,-2692.02,-1533.89
    >>Haz clic en el |cffe07cf5Nido de raptor rojo|r. Mata a más |cffff5a4aSegadores Solescama|r si no tienes una |T132914:0|t[Pluma de Solescama]
    >>|cffff9a3cTen cuidado, ya que lanzan|r |T132152:0|t[Vapulear] |cffff9a3c(Carga 2 ataques extra cada 10 segundos)|r
    .complete 905,3 --Visit Red Raptor Nest (1)
    .collect 5165,3,905,7,3
    .mob Sunscale Scytheclaw
step
    #label Nest
    .goto 1413/1,-2648.44,-1527.13
    >>Haz clic en el |cffe07cf5Nido de raptor amarillo|r. Mata a más |cffff5a4aSegadores Solescama|r si no tienes una |T132914:0|t[Pluma de Solescama]
    >>|cffff9a3cTen cuidado, ya que lanzan|r |T132152:0|t[Vapulear] |cffff9a3c(Carga 2 ataques extra cada 10 segundos)|r
    .complete 905,2 --Visit Yellow Raptor Nest (1)
    .collect 5165,3,905,7,3
    .mob Sunscale Scytheclaw
step
    #optional
    #completewith next
    >>Mata |cffff5a4aSegadores Solescama|r. Despójalos para obtener sus |cff4fc3f7Cuernos|r
    >>|cffff9a3cTen cuidado, ya que lanzan|r |T132152:0|t[Vapulear] |cffff9a3c(Carga 2 ataques extra cada 10 segundos)|r
    .complete 865,1 --Intact Raptor Horn (5)
    .mob Sunscale Scytheclaw
step
    #label LostmyWife
    .goto 1413/1,-2375.86,-1787.24
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cCadáver apaleado|r
    .complete 4921,1 --Find Mankrik's Wife (1)
    .target Beaten Corpse
    .skipgossip
step
    #optional
    #completewith CampTArrive
    >>Mata |cffff5a4aMorrotormentas|r. Despójalos para obtener un |cff4fc3f7Cuerno de truenagarto|r
    .complete 821,3 --Thunder Lizard Horn (1)
    .mob Stormsnout
    .isQuestTurnedIn 819
step
    #label LakotaMani1
    #completewith CampTArrive
    .goto 1413/1,-1951.27,-1956.15,0
    .goto 1413/1,-2031.32,-1703.47,0
    .goto 1413/1,-2183.32,-1858.19,0
    .goto 1413/1,-2453.88,-1991.28,0
	>>Mata a |cffff5a4aLakota'mani|r. Despójalo para obtener la |T132318:0|t[|cff4fc3f7Pezuña de Lakota'mani|r]
    >>Usa la |T132318:0|t[|cffff9a3cPezuña de Lakota'mani|cff4fc3f7] |rpara iniciar la misión|r
    >>|cffff9a3cTiene 4 puntos de aparición (marcados en el mapa)|r
    >>|cffff9a3cOmite este paso si no puedes encontrarlo o matarlo. Puedes volver a por él más tarde|r
	.collect 5099,1,883 --Collect Hoof of Lakota'Mani
	.accept 883 >>Acepta la misión Lakota'mani
    .use 5099
    .unitscan Lakota'mani
    .xp <18,1
step
    #label CampTArrive
    #completewith next
    .goto 1413/1,-1960.39,-2333.83,120 >> Viaja al Campamento Taurajo
    .subzoneskip 378
step
    #requires CampTArrive
    #label SetCampTaurajoHS
    .goto 1413/1,-1995.86,-2376.39
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Byula|r
    .home >>Establece tu Piedra de hogar en el Campamento Taurajo
    .target Innkeeper Byula
    .bindlocation 378
    .isQuestAvailable 1093
step
    .goto 1413/1,-1921.88,-2383.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJorn Vidente del Cielo|r
    .turnin 883 >>Entrega la misión Lakota'mani
    .target Jorn Skyseer
    .isOnQuest 883
step
    .goto 1413/1,-1891.48,-2391.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cQuebrantadientes|r
    .accept 878 >>Acepta la misión Tribus en guerra
    .target Mangletooth
step
    #completewith Xroadsturnins2
    .goto 1413/1,-1881.35,-2384.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOmusa|r
    .fp Camp Taurajo >> Consigue la ruta de vuelo del Campamento Taurajo << !Tauren
    .fly Crossroads >>Vuela a El Cruce
    .target Omusa Thunderhorn
    .zoneskip The Barrens,1
    .subzoneskip 380
step
    .goto 1413/1,-2589.67,-424.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHelbrim|r
    .turnin 848 >> Entrega la misión Esporas de hongos
    .target Apothecary Helbrim
    .isQuestComplete 848
step
    #label Xroadsturnins2
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMankrik|r, |cff5cf05cTonga|r, |cff5cf05cSergra|r y |cff5cf05cGazrog|r
    .turnin 4921 >>Entrega la misión Perdida en la batalla
    .accept 95774 >>Acepta la misión Su nombre es Olgra
    .target +Mankrik
    .goto 1413/1,-2641.35,-521.12
    .turnin 877 >>Entrega la misión El Oasis Estancado
    .accept 880 >>Acepta la misión Seres alterados
    .target +Tonga Runetotem
    .goto 1413/1,-2672.76,-544.77
    .turnin 905 >>Entrega la misión Los segadores furiosos
    .accept 3261 >>Acepta la misión Jorn Vidente del Cielo
    .target +Sergra Darkthorn
    .goto 1413/1,-2670.74,-482.61
    .turnin 3281 >>Entrega la misión Plata robada
    .target +Gazrog
    .goto 1413/1,-2639.32,-436.00
step
    #optional
    #completewith Hezrul
    .destroy 5165 >>|cffff9a3cElimina cualquier|r |T132914:0|t[Pluma de Solescama] |cffff9a3csobrante que aún tengas|r
    .itemcount 5165,1
step << Hunter
    .goto 1413/1,-2556.23,-351.54
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cUthrok|r|cffe07cf5. Compra un|r |T134410:0|t[Carcaj medio] |cffe07cf5a este vendedor|r
    .collect 11362,1,896,1 --Medium Quiver (1)
    .collect 2515,2200,896,1 --Sharp Arrow (2200)
    .target Uthrok
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 851 >>Entrega la misión Verog el Derviche
    .accept 852 >>Acepta la misión Hezrul Marcasangre
    .turnin 855 >>Entrega la misión Los brazales centauro
    .target Regthar Deathgate
    .isQuestComplete 855
step
    #label Leaders
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 851 >>Entrega la misión Verog el Derviche
    .accept 852 >>Acepta la misión Hezrul Marcasangre
    .target Regthar Deathgate
step
    #completewith Hezrul
    .subzone 387 >> Viaja al Oasis Aguaverde
    .isQuestTurnedIn 851
step
    #optional
    #completewith Hezrul
    >>Mata a los |cffff5a4aQuijafortes de oasis|r mientras buscas a |cffff5a4aHezrul Marcasangre|r. Despójalos para obtener sus |cff4fc3f7Caparazones|r
    .complete 880,1 --Altered Snapjaw Shell (8)
    .mob Oasis Snapjaw
step
    #optional
    #completewith next
    >>Mata a los |cffff5a4aKolkar|r alrededor del oasis. Despójalos para obtener sus |cff4fc3f7Brazales|r
    .complete 855,1 --Centaur Bracers (15)
    .mob Kolkar Bloodcharger
    .mob Kolkar Pack runner
    .mob Kolkar Marauder
    .isOnQuest 855
step
    #loop
    #label Hezrul
    .goto 1413/1,-2001.94,-965.69,0
    .goto 1413/1,-2001.94,-965.69,50,0
    .goto 1413/1,-2022.20,-945.42,50,0
    .goto 1413/1,-2016.12,-915.01,50,0
    .goto 1413/1,-2033.35,-894.74,50,0
    .goto 1413/1,-2031.32,-881.23,50,0
    .goto 1413/1,-2052.60,-877.18,50,0
    .goto 1413/1,-2057.67,-879.21,50,0
    .goto 1413/1,-2066.79,-877.85,50,0
    .goto 1413/1,-2085.03,-898.80,50,0
    .goto 1413/1,-2097.19,-908.26,50,0
    .goto 1413/1,-2102.26,-950.15,50,0
    .goto 1413/1,-2114.42,-981.22,50,0
    .goto 1413/1,-2167.11,-1021.09,50,0
    .goto 1413/1,-2187.38,-1040.68,50,0
    .goto 1413/1,-2261.35,-1060.95,50,0
    .goto 1413/1,-2281.62,-1061.62,50,0
    .goto 1413/1,-2301.88,-1056.89,50,0
    .goto 1413/1,-2295.80,-1087.30,50,0
    .goto 1413/1,-2299.86,-1125.13,50,0
    .goto 1413/1,-2268.44,-1145.40,50,0
    .goto 1413/1,-2247.16,-1145.40,50,0
    .goto 1413/1,-2226.90,-1166.35,50,0
    .goto 1413/1,-2189.40,-1179.86,50,0
    .goto 1413/1,-2174.20,-1198.78,50,0
    .goto 1413/1,-2162.04,-1200.80,50,0
    .goto 1413/1,-2124.55,-1228.50,50,0
    .goto 1413/1,-2095.16,-1220.40,50,0
    .goto 1413/1,-2065.78,-1208.91,50,0
    .goto 1413/1,-2041.46,-1167.70,50,0
    .goto 1413/1,-2024.23,-1179.18,50,0
    .goto 1413/1,-2047.54,-1156.21,50,0
    .goto 1413/1,-2046.52,-1135.94,50,0
    .goto 1413/1,-2009.03,-1127.84,50,0
    .goto 1413/1,-2001.94,-965.69,50,0
    >>Encuentra y mata a |cffff5a4aHezrul Marcasangre|r. Despójalo para obtener su |cff4fc3f7Cabeza|r
    >>|cffff5a4aHezrul|r |cffff9a3cpatrulla alrededor del lago|r
    .complete 852,1 --Hezrul's Head
    .unitscan Hezrul Bloodmark
    .isQuestTurnedIn 851
step
    .goto 1413/1,-2001.94,-965.69,0
    .goto 1413/1,-2001.94,-965.69,50,0
    .goto 1413/1,-2022.20,-945.42,50,0
    .goto 1413/1,-2016.12,-915.01,50,0
    .goto 1413/1,-2033.35,-894.74,50,0
    .goto 1413/1,-2031.32,-881.23,50,0
    .goto 1413/1,-2052.60,-877.18,50,0
    .goto 1413/1,-2057.67,-879.21,50,0
    .goto 1413/1,-2066.79,-877.85,50,0
    .goto 1413/1,-2085.03,-898.80,50,0
    .goto 1413/1,-2097.19,-908.26,50,0
    .goto 1413/1,-2102.26,-950.15,50,0
    .goto 1413/1,-2114.42,-981.22,50,0
    .goto 1413/1,-2167.11,-1021.09,50,0
    .goto 1413/1,-2187.38,-1040.68,50,0
    .goto 1413/1,-2261.35,-1060.95,50,0
    .goto 1413/1,-2281.62,-1061.62,50,0
    .goto 1413/1,-2301.88,-1056.89,50,0
    .goto 1413/1,-2295.80,-1087.30,50,0
    .goto 1413/1,-2299.86,-1125.13,50,0
    .goto 1413/1,-2268.44,-1145.40,50,0
    .goto 1413/1,-2247.16,-1145.40,50,0
    .goto 1413/1,-2226.90,-1166.35,50,0
    .goto 1413/1,-2189.40,-1179.86,50,0
    .goto 1413/1,-2174.20,-1198.78,50,0
    .goto 1413/1,-2162.04,-1200.80,50,0
    .goto 1413/1,-2124.55,-1228.50,50,0
    .goto 1413/1,-2095.16,-1220.40,50,0
    .goto 1413/1,-2065.78,-1208.91,50,0
    .goto 1413/1,-2041.46,-1167.70,50,0
    .goto 1413/1,-2024.23,-1179.18,50,0
    .goto 1413/1,-2047.54,-1156.21,50,0
    .goto 1413/1,-2046.52,-1135.94,50,0
    .goto 1413/1,-2009.03,-1127.84,50,0
    .goto 1413/1,-2001.94,-965.69,50,0
    >>Mata a los |cffff5a4aKolkar|r alrededor del oasis. Despójalos para obtener sus |cff4fc3f7Brazales|r
    >>|cffff9a3cSi todavía no has obtenido muchos objetos, puedes omitir esta misión sin problema|r
    .complete 855,1 --Centaur Bracers (15)
    .mob Kolkar Bloodcharger
    .mob Kolkar Pack runner
    .mob Kolkar Marauder
    .itemcount 5030,5 --Centaur Bracers (5)
    .isOnQuest 855
step
    #optional
    #completewith CounterattackComplete
    .abandon 855 >> Abandona la misión Los brazales centauro si no has despojado suficientes objetos anteriormente para que valga la pena terminarla
    .itemcount 5030,<5 --Centaur Bracers (5)
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 852 >>Entrega la misión Hezrul Marcasangre
    .turnin 855 >>Entrega la misión Los brazales centauro
    .target Regthar Deathgate
    .isQuestComplete 852
    .isQuestComplete 855
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 852 >>Entrega la misión Hezrul Marcasangre
    .target Regthar Deathgate
    .isQuestComplete 852
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 855 >>Entrega la misión Los brazales centauro
    .target Regthar Deathgate
    .isQuestComplete 855
step
    #completewith CounterattackComplete
    +|cffff9a3cLa próxima misión es muy difícil y se recomienda formar un grupo. Puedes kitear al |cffff5a4aSeñor de la guerra Krom'zar|r alrededor del edificio donde se encuentra el PNJ que da la misión|r
    >>|cffff9a3cOmite si no puedes hacer esta misión. Tendrás otra oportunidad de completarla a un nivel superior|r
    .isQuestTurnedIn 852
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .accept 4021 >>Acepta la misión ¡Contraataca!
    .target Regthar Deathgate
    --.timer 183,Warlord Krom'zar Spawn
    .isQuestTurnedIn 852
    --timer is random, generally somewhere between 120-210 seconds
step
    #label CounterattackComplete
    .goto 1413/1,-1884.39,-289.38
    >>Mata al |cffff5a4aSeñor de la Guerra Krom'zar|r (élite lvl 20) una vez que aparece. Despoja el |cffe07cf5Estandarte|r que deja en el suelo
    >>|cffff9a3c¡Ten cuidado! Es fuerte y está protegido por al menos dos esbirros|r |cffff5a4aKolkar|r |cffff9a3c|r
    >>|cffff9a3cPuede tardar hasta 3 minutos en reaparecer|r
    .link https://www.youtube.com/watch?v=xrm0PWe5wf4 >>|cffff9a3cHaz clic aquí para una guía en video sobre cómo hacer "kiting" al|r |cffff5a4aSeñor de la Guerra Krom'zar|r
    .complete 4021,1 --Piece of Krom'zar's Banner (1)
    .unitscan Warlord Krom'zar
    .isOnQuest 4021
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 4021 >>Entrega la misión ¡Contraataca!
    .target Regthar Deathgate
    .isQuestComplete 4021
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 855 >>Entrega la misión Los brazales centauro
    .target Regthar Deathgate
    .isQuestComplete 855
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 4021 >>Entrega la misión ¡Contraataca!
    .target Regthar Deathgate
    .isQuestComplete 4021
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 855 >>Entrega la misión Los brazales centauro
    .target Regthar Deathgate
    .isQuestComplete 855
step
    #optional
    #completewith StonetalonPickups
    >>Mata a los |cffff5a4aZancudos de llanura|r. Despójalos para obtener sus |cff4fc3f7Riñones|r
    .complete 821,2 --Plainstrider Kidney (5)
    .mob Greater Plainstrider
    .mob Fleeting Plainstrider
    .mob Ornery Plainstrider
    .isQuestTurnedIn 819
step
    #loop
    .goto 1413/1,-1458.79,565.96,0
    .goto 1413/1,-1458.79,565.96,40,0
    .goto 1413/1,-1379.75,620.68,40,0
    .goto 1413/1,-1376.71,717.97,40,0
    .goto 1413/1,-1323.0,747.7,40,0
    .goto 1413/1,-1245.99,763.91,40,0
    .goto 1413/1,-1223.7,699.05,40,0
    .goto 1413/1,-1290.58,670.0,40,0
    .goto 1413/1,-1245.99,624.74,40,0
    .goto 1413/1,-1241.94,559.2,40,0
    .goto 1413/1,-1155.8,553.12,40,0
    .goto 1413/1,-1150.74,513.93,40,0
    .goto 1413/1,-1194.31,508.53,40,0
    .goto 1413/1,-1263.22,458.53,40,0
    .goto 1413/1,-1311.86,415.97,40,0
    .goto 1413/1,-1366.58,449.75,40,0
    .goto 1413/1,-1417.24,486.91,40,0
    .goto 1413/1,-1445.62,532.85,40,0
    >>Mata a las |cffff5a4aDestripadoras Alabruja|r. Despójalas para obtener sus |cff4fc3f7Anillos|r
    >>|cffff9a3cTen cuidado ya que las |cffff5a4aDestripadoras Alabruja|r lanzan|r |T135358:0|t[Ejecutar] |cffff9a3c(causa MUCHO daño cuando estás por debajo del 20% de salud), y las |cffff5a4aEmboscadoras Alabruja|r están en|r |T132320:0|t[Sigilo] |cffff9a3cy patrullan alrededor|r
    >>|cffff9a3cTen cuidado con las|r |cffff5a4aEmboscadoras Alabruja|r|cffff9a3c. Están en sigilo y patrullan la zona|r
    .complete 875,1 --Harpy Lieutenant Ring (6)
    .mob Witchwing Slayer
    .mob Witchwing Ambusher
    .isOnQuest 875
step
    #label StonetalonPickups
    #completewith next
    .goto 1413/1,-950.10,-271.14,30 >> Viaja hacia |cff5cf05cSeereth|r
    .zoneskip Stonetalon Mountains
step
    #map Stonetalon Mountains
    #label StonetalonPickups
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSeereth|r y |cff5cf05cMakaba|r
    .turnin 1061 >> Entrega la misión Los espíritus del Espolón
    .accept 1062 >> Acepta la misión Los invasores goblin
    .target +Seereth Stonebreak
    .goto 1413/1,-950.10,-271.14
    .accept 6548 >> Acepta la misión Venga mi aldea
    .target +Makaba Flathoof
    .goto 1413/1,-943.00,-265.06
    .maxlevel 20 << !Druid
step
    #optional
    #map Stonetalon Mountains
    #label StonetalonPickups
    .goto 1413/1,-950.10,-271.14
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSeereth|r
    .turnin 1061 >> Entrega la misión Los espíritus del Espolón
    .accept 1062 >> Acepta la misión Los invasores goblin
    .target Seereth Stonebreak
]=], "Horde"}
R[#R + 1] = {[=[
#forever
#disabledungeons
<< Horde
#name 17-22 Sierra Espolón/Baldíos/Vallefresno
#displayname 18-22 Espolón/Baldíos/Vallefresno << !Shaman !Hunter !Tauren
#version 11
#group Guía Forever (H)
#subgroup Guía Speedrun 1-22
#next 22-24 Laderas de Trabalomas


step
    #loop
    .goto 1442/1,-691.11,-13.63,0
    .goto 1442/1,-691.11,-13.63,40,0
    .goto 1442/1,-650.58,26.74,40,0
    .goto 1442/1,-718.94,65.49,40,0
    .goto 1442/1,-743.85,101.96,40,0
    .goto 1442/1,-771.20,113.040,40,0
    .goto 1442/1,-785.36,141.69,40,0
    .goto 1442/1,-838.59,148.20,40,0
    .goto 1442/1,-865.93,142.34,40,0
    .goto 1442/1,-846.4,103.92,40,0
    .goto 1442/1,-819.54,76.24,40,0
    .goto 1442/1,-774.61,-5.17,40,0
    .goto 1442/1,-774.61,-27.96,40,0
    .goto 1442/1,-726.27,-39.36,40,0
    >>Mata |cffff5a4aRufianes Tótem Siniestro|r y |cffff5a4aMercenarios Tótem Siniestro|r
    .complete 6548,1 --Kill Grimtotem Ruffian (x8)
    .mob +Grimtotem Ruffian
    .complete 6548,2 --Kill Grimtotem Mercenary (x6)
    .mob +Grimtotem Mercenary
    .isOnQuest 6548
step
    #map Stonetalon Mountains
    .goto 1413/1,-943.00,-265.06
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMakaba|r
    .turnin 6548 >> Entrega la misión Venga mi aldea
    .accept 6629 >> Acepta la misión Mata a Grundig Nube Negra
    .target Makaba Flathoof
    .isQuestComplete 6548
step
    #optional
    #label AvengeVillageTurnin
    #map Stonetalon Mountains
    .goto 1413/1,-943.00,-265.06
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMakaba|r
    .accept 6629 >> Acepta la misión Mata a Grundig Nube Negra
    .target Makaba Flathoof
    .isQuestTurnedIn 6548
step
    #completewith next
    .goto 1442/1,-460.13,67.77,30 >>Sube por el camino hacia la hoguera
    .isQuestTurnedIn 6548
step
    .goto 1442/1,-350.74,112.06
    >>Mata a |cffff5a4aGrundig Nube Negra|r y a los |cffff5a4aToscos Tótem Siniestro|r
    >>|cffff9a3cAsegúrate de matar a los seis|r |cffff5a4aTosco Tótem Siniestro|r |cffff9a3cantes de iniciar la misión adentro|r
    .complete 6629,1 --Kill Grundig Darkcloud (x1)
    .mob +Grundig Darkcloud
    .complete 6629,2 --Kill Grimtotem Brute (x6)
    .mob +Grimtotem Brute
    .isQuestTurnedIn 6548
step
    .goto 1442/1,-342.44,129.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKaya|r
    .accept 6523,1 >> Acepta la misión Protege a Kaya
    .target Kaya Flathoof
    .isQuestTurnedIn 6548
step
    .goto 1442/1,-261.38,90.57,40,0
    .goto 1442/1,-261.86,-7.12,40,0
    .goto 1442/1,-501.15,-41.64
    >>Escolta a |cff5cf05cKaya|r y permanece cerca de ella
    >>|cffff9a3c¡Ten cuidado! Tres|r |cffff5a4aTótem Siniestro|r |cffff9a3caparecerán cuando llegues a la hoguera en el Campamento Aparaje|r
    .complete 6523,1 --Kaya Escorted to Camp Aparaje
    .target Kaya Flathoof
    .isQuestTurnedIn 6548
step
    .goto 1442/1,-233.54,-177.42
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cXen'Zilla|r
    .accept 6461 >> Acepta la misión Chupasangres
    .target Xen'Zilla
step << Priest/Mage/Warlock
    #completewith next
    .goto 1442/1,-103.64,40.10,100,0
    .goto 1442/1,74.11,185.32,100,0
    .goto 1442/1,244.05,262.50,100,0
    >>Mata a cada |cffff5a4aTrepador Musgondo|r que veas
    .complete 6461,1 --Kill Deepmoss Creeper (x10)
    .mob Deepmoss Creeper
    .group 0 << Priest/Mage
step << Warlock/Priest/Mage
    .goto 1442/1,360.76,451.690
    >>Haz clic en el |cff5cf05cCartel de Se busca|r
    .accept 6284 >>Acepta la misión Aracnofobia
    .group << Priest/Mage
step << Warlock/Priest/Mage
    #completewith Besseleth1
    >>Mata |cffff5a4aEscupetósigos Musgondo|r y |cffff5a4aTrepadores Musgondo|r
    .complete 6461,2 --Kill Deepmoss Venomspitter (x7)
    .mob +Deepmoss Venomspitter
    .complete 6461,1 --Kill Deepmoss Creeper (x10)
    .mob +Deepmoss Creeper
    .group 0 << Priest/Mage
step << Warlock/Priest/Mage
    #completewith next
    >>Despoja los |cffe07cf5Huevos de araña|r cerca de los árboles
    >>|cffff9a3c¡Ten cuidado! Las|r Proles de Musgondo|cffff5a4a tienen probabilidad de invocar a una|r |cffff9a3cMatriarca Musgondo |r |cffff5a4ade nivel 22|r
    .complete 1069,1 --Collect Deepmoss Egg (x15)
    .group 0 << Priest/Mage
step << Warlock/Priest/Mage
    #label Besseleth1
    #loop
    .goto 1442/1,569.77,573.79,0
    .goto 1442/1,711.87,513.23,50,0
    .goto 1442/1,684.04,582.91,50,0
    .goto 1442/1,569.77,573.79,50,0
    >>Mata a |cffff5a4aBesseleth|r. Despójala para obtener su |cff4fc3f7Colmillo|r
    >>|cffff9a3cDespeja la zona alrededor de|r |cffff5a4aBesseleth|r|cffff9a3c. Ten cuidado, ya que te enreda en telarañas. Mantenla en Miedo de forma permanente con habilidades de daño en el tiempo|r << Warlock
    >>|cffff9a3cEsta misión es opcional. Si no puedes hacerla, omite esta misión. Puedes intentarlo de nuevo más tarde|r << Warlock
    .complete 6284,1 --Collect Besseleth's Fang (x1)
	.unitscan Besseleth
    .group 2 << Priest/Mage
step << Warlock/Priest/Mage
    .goto 1442/1,560.49,440.94
    >>Mata |cffff5a4aTrepadores Musgondo|r
    .complete 6461,1 --Kill Deepmoss Creeper (x10)
    .mob Deepmoss Creeper
    .group 0 << Priest/Mage
step << !Warlock
    .goto 1442/1,-44.56,84.05,80,0
    .goto 1442/1,245.51,255.01,80,0
    .goto 1442/1,392.01,445.17,40,0
    .goto 1442/1,560.49,440.94
    >>Mata |cffff5a4aTrepadores Musgondo|r
    >>|cffff9a3cGuarda cualquier|r |T134339:0|t[Glándula de veneno pequeña] |cffff9a3cque despojes|r << Rogue
    .complete 6461,1 --Kill Deepmoss Creeper (x10)
    .mob Deepmoss Creeper
step
    #completewith next
    .goto 1442/1,735.8,925.8,50,0
    .goto 1442/1,806.12,929.05
    .subzone 460 >>Viaja al Refugio Roca del Sol
step
    .goto 1442/1,927.72,893.56
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cTabernera Jayka|r
	.vendor >>|cffe07cf5Vende la basura y luego reabastécete de comida y agua si es necesario|r << !Rogue !Warrior
    .vendor >>|cffe07cf5Vende tu basura, luego reabastécete de comida si es necesario|r << Rogue/Warrior
    .target Innkeeper Jayka
    .isQuestAvailable 1093
step
    .goto 1442/1,920.88,911.47
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJeeda|r en el segundo piso de la posada
    .vendor >> |cffe07cf5Cómprale|r |T134831:0|t[Pociones de sanación] |cffe07cf5si están disponibles|r << !Warrior
    .vendor >> |cffe07cf5Cómprale|r |T134831:0|t[Pociones de sanación] |cffe07cf5y|r |T134413:0|t[Vidarraíz] |cffe07cf5si están disponibles|r << Warrior
    .target Jeeda
    .isQuestAvailable 1093
step
    .goto 1442/1,940.9,925.14
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMaggran|r
	.turnin 6284 >> Entrega la misión Aracnofobia
    .target Maggran Earthbinder
	.isQuestComplete 6284
step
    #label SRRFP
    .goto 1442/1,1041.99,967.80
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTharm|r
    .fp Sun Rock Retreat >> Consigue la ruta de vuelo del Refugio Roca del Sol
    .target Tharm
    .subzoneskip 460,1
step
    #completewith next
    .goto 1442/1,365.16,878.250,15 >> Viaja hacia |cff5cf05cZiz|r
step
    .goto 1442/1,365.16,878.250
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZiz|r
    .turnin -1483 >> Entrega la misión Ziz Fizziks
    .accept 1093 >> Acepta la misión Súper Segadora 6000
    .target Ziz Fizziks
step
    #completewith Windshear
    >>Despoja los |cffe07cf5Huevos de araña|r cerca de los árboles
    >>|cffff9a3c¡Ten cuidado! Las|r Proles de Musgondo|cffff5a4a tienen probabilidad de invocar a una|r |cffff9a3cMatriarca Musgondo |r |cffff5a4ade nivel 22|r
    .complete 1069,1 --Collect Deepmoss Egg (x15)
step
    #loop
    .goto 1442/1,352.46,912.44,0
    .goto 1442/1,352.46,912.44,50,0
    .goto 1442/1,297.77,959.660,50,0
    .goto 1442/1,250.40,990.59,50,0
    .goto 1442/1,259.68,1032.93,50,0
    .goto 1442/1,246.98,1068.09,50,0
    .goto 1442/1,207.91,1010.13,50,0
    .goto 1442/1,163.47,962.27,50,0
    .goto 1442/1,86.81,961.94,50,0
    .goto 1442/1,181.05,907.89,50,0
    .goto 1442/1,193.75,867.83,50,0
    .goto 1442/1,194.73,827.78,50,0
    .goto 1442/1,225.49,765.26,50,0
    .goto 1442/1,281.16,763.63,50,0
    .goto 1442/1,268.95,832.99,50,0
    .goto 1442/1,303.63,858.39,50,0
    >>Mata a los |cffff5a4aEscupetósigo Musgondo|r
    >>|cffff9a3cGuarda cualquier|r |T134339:0|t[Glándula de veneno pequeña] |cffff9a3cque despojes|r << Rogue
    .complete 6461,2 --Kill Deepmoss Venomspitter (x7)
    .mob Deepmoss Venomspitter
step << Troll Warrior/Orc Warrior/Tauren Warrior
    .goto 1442/1,402.76,1231.88
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cVeenix|r|cffe07cf5. Compra un|r |T135157:0|t[Bastón largo] |cffe07cf5a este vendedor|r
    .collect 928,1,899,1 --Collect Long Staff (1)
    .money <0.9860
    .target Veenix
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.2
step << Troll Warrior/Orc Warrior/Tauren Warrior
    #optional
    #completewith BluePrints
    +|cffff9a3cEquipa el|r |T135157:0|t[Bastón largo]
    .use 928
    .itemcount 928,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.2
    .xp <20,1
step << Undead Warrior/Skyborne Warrior
    .goto 1442/1,402.76,1231.88
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVeenix|r
    .vendor >>|cffe07cf5Compra una|r |T135329:0|t[Espada de verdugo] |cffe07cf5a este vendedor|r
    >>|cffff9a3cSi no está disponible, compra un|r |T135280:0|t[Dalle dacio] |cffff9a3cen su lugar|r
    .money <1.5024
    .target Veenix
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.8
step << Undead Warrior/Skyborne Warrior
    #optional
    #completewith BluePrints
    +|cffff9a3cEquipa la|r |T135329:0|t[Espada de verdugo]
    .use 4818
    .itemcount 4818,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.8
    .xp <19,1
step << Undead Warrior/Skyborne Warrior
    #optional
    #completewith BluePrints
    +|cffff9a3cEquipa el|r |T135280:0|t[Dalle dacio]
    .use 922
    .itemcount 922,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.8
    .xp <21,1
step << Shaman
    .goto 1442/1,402.76,1231.88
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cVeenix|r|cffe07cf5. Compra un|r |T135157:0|t[Bastón largo] |cffe07cf5a este vendedor|r
    .collect 928,1,899,1 --Collect Long Staff (1)
    .money <0.9860
    .target Veenix
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.2
step << Shaman
    #optional
    #completewith BluePrints
    +|cffff9a3cEquipa el|r |T135157:0|t[Bastón largo]
    .use 928
    .itemcount 928,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.2
    .xp <20,1
step << Rogue
    .goto 1442/1,402.76,1231.88
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cVeenix|r|cffe07cf5. Compra una|r |T135324:0|t[Tizona] |cffe07cf5a este vendedor.|r
    .collect 923,1,899,1 --Collect Longsword (1)
    .money <0.8743
    .target Veenix
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.1
step << Rogue
    #optional
    #completewith BluePrints
    +|cffff9a3cEquipa la|r |T135324:0|t[Tizona]
    .use 923
    .itemcount 923,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.1
    .xp <21,1
step
    #label Windshear
    .subzone 461 >> Viaja al Risco Cortaviento
    .isOnQuest 1093
step
    #completewith next
    >>Mata a los |cffff5a4aMadereros de Ventura y Cía.|r
    .complete 1062,1 --Kill Venture Co. Logger (x15)
    .mob Venture Co. Logger
step
    #label BluePrints
    #loop
    .goto 1442/1,179.10,1168.06,0
    .goto 1442/1,179.10,1168.06,100,0
    .goto 1442/1,232.82,1239.70,100,0
    .goto 1442/1,-16.23,1441.59,100,0
    .goto 1442/1,-255.52,1291.80,100,0
    .goto 1442/1,-382.48,1135.50,100,0
    >>Mata a los |cffff5a4aOperadores de Ventura y Cía.|r. Despójalos para obtener sus |cff4fc3f7Planos|r
    .complete 1093,1 --Collect Super Reaper 6000 Blueprints (x1)
    .mob Venture Co. Operator
step
    #loop
    .goto 1442/1,242.58,1121.82,0
    .goto 1442/1,242.58,1121.82,50,0
    .goto 1442/1,292.39,1122.470,50,0
    .goto 1442/1,325.6,1168.39,50,0
    .goto 1442/1,338.79,1206.48,50,0
    .goto 1442/1,276.77,1248.49,50,0
    .goto 1442/1,215.24,1145.59,50,0
    .goto 1442/1,187.40,1114.33,50,0
    .goto 1442/1,138.57,1144.62,50,0
    .goto 1442/1,51.16,1153.41,50,0
    .goto 1442/1,-17.70,1128.33,50,0
    .goto 1442/1,-106.09,1157.31,50,0
    .goto 1442/1,-165.66,1173.60,50,0
    .goto 1442/1,-189.10,1079.82,50,0
    .goto 1442/1,-69.95,1061.91,50,0
    .goto 1442/1,10.63,1072.33,50,0
    .goto 1442/1,57.51,1056.05,50,0
    .goto 1442/1,107.32,1040.09,50,0
    >>Mata a los |cffff5a4aMadereros de Ventura y Cía.|r
    .complete 1062,1 --Kill Venture Co. Logger (x15)
    .mob Venture Co. Logger
step
    #loop
    .goto 1442/1,246.98,1068.09,0
    .goto 1442/1,352.46,912.44,30,0
    .goto 1442/1,297.77,959.660,30,0
    .goto 1442/1,250.40,990.59,30,0
    .goto 1442/1,259.68,1032.93,30,0
    .goto 1442/1,246.98,1068.09,30,0
    .goto 1442/1,207.91,1010.13,30,0
    .goto 1442/1,163.47,962.27,30,0
    .goto 1442/1,86.81,961.94,30,0
    .goto 1442/1,181.05,907.89,30,0
    .goto 1442/1,193.75,867.83,30,0
    .goto 1442/1,194.73,827.78,30,0
    .goto 1442/1,225.49,765.26,30,0
    .goto 1442/1,281.16,763.63,30,0
    .goto 1442/1,268.95,832.99,30,0
    .goto 1442/1,303.63,858.39,30,0
    >>Despoja los |cffe07cf5Huevos de araña|r cerca de los árboles
    >>|cffff9a3c¡Ten cuidado! Las|r Proles de Musgondo|cffff5a4a tienen probabilidad de invocar a una|r |cffff9a3cMatriarca Musgondo |r |cffff5a4ade nivel 22|r
    .complete 1069,1 --Collect Deepmoss Egg (x15)
step
    .goto 1442/1,365.16,878.250
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZiz|r
    .turnin 1093 >> Entrega la misión Súper Segadora 6000
    .accept 1094 >> Acepta la misión Más instrucciones
    .target Ziz Fizziks
step
    #loop
    .goto 1442/1,362.71,539.28,0
    .goto 1442/1,275.30,577.38,80,0
    .goto 1442/1,362.71,539.28,80,0
    .goto 1442/1,298.25,432.80,80,0
    .goto 1442/1,244.05,262.50,80,0
    .goto 1442/1,74.11,185.32,80,0
    .goto 1442/1,-103.64,40.10,80,0
    .goto 1442/1,362.71,539.28,80,0
    >>Mata a los |cffff5a4aTrepadores Musgondo|r
    >>|cffff9a3cGuarda cualquier|r |T134339:0|t[Glándula de veneno pequeña] |cffff9a3cque despojes|r << Rogue
    .complete 6461,1 --Kill Deepmoss Creeper (x10)
    .mob Deepmoss Creeper
step << Druid
    #completewith DruidTraining2
    .cast 18960 >>|cffff9a3cLanza|r |T135758:0|t[Teletransporte a: Claro de la Luna]
    .zoneskip Moonglade
step << Druid
    .goto 1450/1,-2593.82,7866.90
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLoganaar|r
    .train 1430 >> Aprende tus hechizos de clase
    .target Loganaar
    .xp <18,1
    .xp >20,1
step << Druid
    #label DruidTraining2
    .goto 1450/1,-2593.82,7866.90
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLoganaar|r
    .train 768 >> Aprende tus hechizos de clase
    .target Loganaar
    .xp <20,1
step
    #completewith JornSkyseerTurnin
    .hs >> Usa tu Piedra de hogar para ir al Campamento Taurajo
    .use 6948
    .bindlocation 378,1
    .subzoneskip 378
step
    .goto 1413/1,-1995.86,-2375.71
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Byula|r
	.vendor >>|cffe07cf5Vende la basura y luego reabastécete de comida y agua si es necesario|r << !Rogue !Warrior
    .vendor >>|cffe07cf5Vende tu basura, luego reabastécete de comida si es necesario|r << Rogue/Warrior
    .target Innkeeper Byula
    .isOnQuest 3261
step
    #label JornSkyseerTurnin
    .goto 1413/1,-1921.88,-2383.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJorn Vidente del Cielo|r
    .turnin -3261 >>Entrega la misión Jorn Vidente del Cielo
    .accept 882 >>Acepta la misión Ishamuhale
    .target Jorn Skyseer
step
    #completewith LakotaMani2
    >>Mata a los |cffff5a4aAsaltantes Crines de Acero|r. Despójalos para obtener los |cff4fc3f7Adornos de Olgra|r
    .complete 95774,1 --|4/4 Olgra's Adornments
    .mob Razormane Raider
step
	#completewith Adornments
    >>Mata |cffff5a4aMorrotormentas|r. Despójalos para obtener un |cff4fc3f7Cuerno|r
    .complete 821,3 --Thunder Lizard Horn (1)
    .mob Stormsnout
    .isQuestTurnedIn 819
step
    #completewith Adornments
    >>Mata |cffff5a4aJabaespines Erizapúas|r. Despójalos para obtener sus |cff4fc3f7Colmillos|r. Guarda las |T134128:0|t[|cff4fc3f7Esquirla de sangre|r] que obtengas
	.complete 878,1 --Kill Bristleback Water Seeker (x6)
    .mob +Bristleback Water Seeker
    .complete 878,2 --Kill Bristleback Thornweaver (x12)
    .mob +Bristleback Thornweaver
    .complete 878,3 --Kill Bristleback Geomancer (x12)
    .mob +Bristleback Geomancer
    .complete 899,1 --Collect Bristleback Quilboar Tusk (x60)
    .mob +Bristleback Water Seeker
    .mob +Bristleback Thornweaver
    .mob +Bristleback Geomancer
step
    #label LakotaMani2
    #loop
    .goto 1413/1,-1951.27,-1956.15,0
    .goto 1413/1,-2031.32,-1703.47,0
    .goto 1413/1,-2183.32,-1858.19,0
    .goto 1413/1,-2453.88,-1991.28,0
    .goto 1413/1,-1951.27,-1956.15,80,0
    .goto 1413/1,-2031.32,-1703.47,80,0
    .goto 1413/1,-2183.32,-1858.19,80,0
    .goto 1413/1,-2453.88,-1991.28,80,0
	>>Mata a |cffff5a4aLakota'mani|r. Despójalo para obtener la |T132318:0|t[|cff4fc3f7Pezuña de Lakota'mani|r]
    >>Usa la |T132318:0|t[|cffff9a3cPezuña de Lakota'mani|cff4fc3f7] |rpara iniciar la misión|r
    >>|cffff9a3cTiene 4 puntos de aparición (marcados en el mapa)|r
    >>|cffff9a3cOmite este paso si no puedes encontrarlo|r
	.collect 5099,1,883 --Collect Hoof of Lakota'Mani
	.accept 883 >>Acepta la misión Lakota'mani
    .use 5099
    .unitscan Lakota'mani
step
    #label Adornments
    #loop
    .goto 1413/1,-2241.200,-1988.500,0
    .goto 1413/1,-2241.200,-1988.500,50,0
    .goto 1413/1,-2346.200,-1788.600,50,0
    .goto 1413/1,-2458.300,-1824.400,50,0
    .goto 1413/1,-2381.000,-2061.000,50,0
    >>Mata a los |cffff5a4aAsaltantes Crines de Acero|r. Despójalos para obtener los |cff4fc3f7Adornos de Olgra|r
    .complete 95774,1 --|4/4 Olgra's Adornments
    .mob Razormane Raider
step
    #optional
    #completewith next
    >>Mata |cffff5a4aMorrotormentas|r. Despójalos para obtener un |cff4fc3f7Cuerno|r
    .complete 821,3 --Thunder Lizard Horn (1)
    .mob Stormsnout
    .isQuestTurnedIn 819
step
    #loop
    .goto 1413/1,-2515.7,-2076.41,0
    .goto 1413/1,-2515.7,-2076.41,60,0
    .goto 1413/1,-2518.74,-2125.73,60,0
    .goto 1413/1,-2517.72,-2223.7,60,0
    .goto 1413/1,-2486.31,-2254.1,60,0
    .goto 1413/1,-2494.42,-2282.48,60,0
    .goto 1413/1,-2531.91,-2272.34,60,0
    .goto 1413/1,-2571.43,-2295.31,60,0
    .goto 1413/1,-2620.07,-2285.18,60,0
    .goto 1413/1,-2625.14,-2245.32,60,0
    .goto 1413/1,-2755.86,-2082.49,60,0
    .goto 1413/1,-2813.62,-2054.12,60,0
    .goto 1413/1,-2811.59,-2004.12,60,0
    .goto 1413/1,-2783.22,-1949.39,60,0
    .goto 1413/1,-2747.75,-1889.26,60,0
    .goto 1413/1,-2709.24,-1913.59,60,0
    .goto 1413/1,-2706.2,-1948.72,60,0
    .goto 1413/1,-2687.96,-1973.04,60,0
    .goto 1413/1,-2678.84,-2016.28,60,0
    .goto 1413/1,-2584.6,-2050.74,60,0
    >>Mata |cffff5a4aJabaespines Erizapúas|r. Despójalos para obtener sus |cff4fc3f7Colmillos|r. Guarda las |T134128:0|t[|cff4fc3f7Esquirla de sangre|r] que obtengas
	.complete 878,1 --Kill Bristleback Water Seeker (x6)
    .mob +Bristleback Water Seeker
    .complete 878,2 --Kill Bristleback Thornweaver (x12)
    .mob +Bristleback Thornweaver
    .complete 878,3 --Kill Bristleback Geomancer (x12)
    .mob +Bristleback Geomancer
    .complete 899,1 --Collect Bristleback Quilboar Tusk (x60)
    .mob +Bristleback Water Seeker
    .mob +Bristleback Thornweaver
    .mob +Bristleback Geomancer
step << Warlock/Shaman
    #loop
	.goto 1413/1,-2515.7,-2076.41,60,0
	.goto 1413/1,-2518.74,-2125.73,60,0
	.goto 1413/1,-2517.72,-2223.7,60,0
	.goto 1413/1,-2486.31,-2254.1,60,0
	.goto 1413/1,-2494.42,-2282.48,60,0
	.goto 1413/1,-2531.91,-2272.34,60,0
	.goto 1413/1,-2571.43,-2295.31,60,0
	.goto 1413/1,-2620.07,-2285.18,60,0
	.goto 1413/1,-2625.14,-2245.32,60,0
	.goto 1413/1,-2755.86,-2082.49,60,0
	.goto 1413/1,-2813.62,-2054.12,60,0
	.goto 1413/1,-2811.59,-2004.12,60,0
	.goto 1413/1,-2783.22,-1949.39,60,0
	.goto 1413/1,-2747.75,-1889.26,60,0
	.goto 1413/1,-2709.24,-1913.59,60,0
	.goto 1413/1,-2706.2,-1948.72,60,0
	.goto 1413/1,-2687.96,-1973.04,60,0
	.goto 1413/1,-2678.84,-2016.28,60,0
	.goto 1413/1,-2584.6,-2050.74,60,0
    .xp 19+9500 >> Mata enemigos hasta alcanzar 9500+/21300xp
step
    #loop
    .goto 1413/1,-2532.92,-1965.61,0
    .goto 1413/1,-2532.92,-1965.61,50,0
    .goto 1413/1,-2449.83,-1953.45,50,0
    .goto 1413/1,-2377.88,-2018.31,50,0
    .goto 1413/1,-2397.14,-2108.84,50,0
    .goto 1413/1,-2345.46,-2187.21,50,0
    .goto 1413/1,-2415.38,-2179.78,50,0
    >>Mata |cffff5a4aMorrotormentas|r. Despójalos para obtener un |cff4fc3f7Cuerno|r
    .complete 821,3 --Thunder Lizard Horn (1)
    .mob Stormsnout
    .isQuestTurnedIn 819
step
    #completewith next
    >>Mata |cffff5a4aSegadores Solescama|r. Despójalos para obtener sus |cff4fc3f7Cuernos|r
    >>|cffff9a3cTen cuidado, ya que lanzan|r |T132152:0|t[Vapulear] |cffff9a3c(Carga 2 ataques extra cada 10 segundos)|r
    .complete 865,1 --Intact Raptor Horn (5)
    .mob Sunscale Scytheclaw
step
    #loop
    .goto 1413/1,-2847.06,-1879.13,0
    .goto 1413/1,-2847.06,-1879.13,50,0
    .goto 1413/1,-2859.22,-1804.81,50,0
    .goto 1413/1,-2833.88,-1749.41,50,0
    .goto 1413/1,-2881.51,-1723.74,50,0
    .goto 1413/1,-2932.18,-1698.06,50,0
    .goto 1413/1,-2973.72,-1627.8,50,0
    >>Termina de matar |cffff5a4aZancudos de llanura|r. Despójalos para obtener sus |cff4fc3f7Riñones|r
    .complete 821,2 --Plainstrider Kidney (5)
    .mob Greater Plainstrider
    .isQuestTurnedIn 819
step
    #loop
    .goto 1413/1,-3183.48,-2015.61,0
    .goto 1413/1,-2646.42,-1529.16,0
    .goto 1413/1,-3183.48,-2015.61,90,0
    .goto 1413/1,-2646.42,-1529.16,90,0
    >>Termina de matar |cffff5a4aSegadores Solescama|r. Despójalos para obtener sus |cff4fc3f7Cuernos|r
    >>|cffff9a3cTen cuidado, ya que lanzan|r |T132152:0|t[Vapulear] |cffff9a3c(Carga 2 ataques extra cada 10 segundos)|r
    .complete 865,1 --Intact Raptor Horn (5)
    .mob Sunscale Scytheclaw
step
    #completewith next
    >>Mata cualquier |cffff5a4aZhebra|r. Despójala para obtener un |cff4fc3f7Cadáver reciente de zhebra|r
	.collect 10338,1 --Collect Fresh Zhevra Carcass
    .mob Zhevra Charger
step
    #loop
    .goto 1413/1,-3010.20,-1319.04,0
    .goto 1413/1,-3010.20,-1319.04,40,0
    .goto 1413/1,-2959.54,-1292.69,40,0
    .goto 1413/1,-2953.46,-1239.31,40,0
    .goto 1413/1,-2998.04,-1192.02,40,0
    .goto 1413/1,-3050.74,-1225.13,40,0
    .goto 1413/1,-3066.95,-1260.93,40,0
    .goto 1413/1,-3052.76,-1319.710,40,0
    >>Mata |cffff5a4aQuijafortes de oasis|r en y alrededor del lago. Despójalos para obtener sus |cff4fc3f7Caparazones|r
    .complete 880,1 --Altered Snapjaw Shell (8)
    .mob Oasis Snapjaw
step
    #completewith IshamuhalesFang
    >>Mata a las |cffff5a4aMatriarcas de la sabana|r y a los |cffff5a4aPatriarcas de la sabana|r. Despójalos para obtener sus |cff4fc3f7Cueros|r
    .complete 95494,1 --|6/6 Savannah Lion Hide
    .mob Savannah Matriarch
    .mob Savannah Patriarch
step
    #completewith next
    >>Mata cualquier |cffff5a4aZhebra|r. Despójala para obtener un |cff4fc3f7Cadáver reciente de zhebra|r
	.collect 10338,1 --Collect Fresh Zhevra Carcass
    .mob Zhevra Charger
step
    #label IshamuhalesFang
    .goto 1413/1,-3427.70,-436.67
    .use 10338 >>Usa el |T134368:0|t[|cff4fc3f7Cadáver reciente de zhebra|r] en el árbol muerto para invocar a |cffff5a4aIshamuhale|r. Mata y despójalo para obtener su |cff4fc3f7Colmillo|r
    >>|cffff9a3c¡El cadáver solo tiene una duración de 30 minutos!|r
    .complete 882,1 --Ishamuhale's Fang (1)
    .mob Ishamuhale
step
    #loop
    .goto 1413/1,-3633.200,-600.500,0
    .goto 1413/1,-3633.200,-600.500,50,0
    .goto 1413/1,-3469.100,-495.000,50,0
    .goto 1413/1,-3428.300,-584.300,50,0
    >>Mata a las |cffff5a4aMatriarcas de la sabana|r y a los |cffff5a4aPatriarcas de la sabana|r. Despójalos para obtener sus |cff4fc3f7Cueros|r
    .complete 95494,1 --|6/6 Savannah Lion Hide
    .mob Savannah Matriarch
    .mob Savannah Patriarch
step
    #completewith BootyTurnin
    .subzone 392 >> Viaja a Trinquete
step
    .goto 1413/1,-3767.800,-842.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDesdio|r
    .turnin -2381 >>Entrega la misión Saquear a los saqueadores << Rogue
    .target Wrenix the Wretched
step << Rogue
    #optional
    .goto 1413/1,-3767.800,-842.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDesdio|r
    .turnin -2381 >>Entrega la misión Saquear a los saqueadores
    .target Wrenix the Wretched
step
    #label BootyTurnin
    .goto 1413/1,-3728.66,-835.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGazlowe|r
    .turnin -888 >>Entrega la misión Botín robado
    .target Gazlowe
step
    .goto 1413/1,-3759.06,-902.18
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cPetardol|r
    .turnin 1094 >>Entrega la misión Más instrucciones
    .accept 1095 >>Acepta la misión Nuevas instrucciones
    .target Sputtervalve
step
    .goto 1413/1,-3720.300,-920.000
    >>Haz clic en el |cffe07cf5Cartel de Se busca|r
    .accept 92706 >>Acepta la misión SE BUSCA: Bruuz
    .group << Rogue/Warrior
step
    .goto 1413/1,-3697.24,-929.20
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMebok|r
    .turnin -865 >>Entrega la misión Cuernos de raptor
    .turnin -1069 >>Entrega la misión Huevos de araña musgondo
    .target Mebok Mizzyrix
step
    #optional
    #completewith XroadsHS2
    .destroy 5570 >>|cffff9a3cElimina|r |T132834:0|t[Huevos de Musgondo] |cffff9a3cque tengas|r
step
    .goto 1413/1,-3687.11,-981.22
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDrohn|r
    .turnin 821 >>Entrega la misión El barril vacío de Chen
    .target Brewmaster Drohn
    .isQuestComplete 821
step << Warrior
    .goto 1413/1,-3680.02,-982.58
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGrazlix|r
    .vendor >>Cómprale |T134583:0|t[|cff5cf05cPantalones de anillas poderosos|r] si está disponible
    .target Grazlix
    .money <0.619
    .itemStat 7,ITEM_MOD_ARMOR_SHORT,<155
    .equip 7,4800
    .isQuestTurnedIn 865
step << Rogue/Hunter/Warrior/Shaman/Druid
    .goto 1413/1,-3675.96,-985.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVexeje|r
    .vendor >> Cómprale |T132603:0|t[|cff5cf05cBrazales de lobo|r] si están disponibles
    .target Vexspindle
    .money <0.3515
    .itemStat 9,ITEM_MOD_ARMOR_SHORT,<37
    .equip 9,4794
    .isQuestTurnedIn 865
step << Warrior
    #optional
    #completewith FlytoXroads
    +|cffff9a3cEquipa los|r |T134583:0|t[|cff5cf05cPantalones de anillas poderosos|r]
    .use 4800
    .itemcount 4800,1
    .itemStat 7,ITEM_MOD_ARMOR_SHORT,<155
    .isQuestTurnedIn 865
    .equip 7,4800
step << Rogue/Hunter/Warrior/Shaman/Druid
    #optional
    #completewith FlytoXroads
    +|cffff9a3cEquipa los|r |T132603:0|t[|cff5cf05cBrazales de lobo|r]
    .use 4794
    .itemcount 4794,1
    .itemStat 9,ITEM_MOD_ARMOR_SHORT,<37
    .isQuestTurnedIn 865
    .xp <20,1
    .equip 9,4794
step
    #loop
    .goto 1413/1,-3911.900,-1049.200
    .goto 1413/1,-3951.600,-1093.500
    .goto 1413/1,-4012.800,-1081.800
    .goto 1413/1,-3973.000,-1028.700
    >>Mata a |cffe07cf5Bruuz|r (nivel 20 élite) en el mar cerca de Trinquete
    >>|cffff9a3c¡Esto es difícil! Monta grupo si es posible|r << !Rogue !Warrior
    >>|cffff9a3cIntenta "kitearlo" hasta Trinquete hacia los guardias para que te ayuden, ¡pero asegúrate de infligir al menos el 50% del daño!|r
    .complete 92706,1 --Kill Bruuz
    .mob Bruuz
    .isOnQuest 92706
    .group << Rogue/Warrior
step
    .goto 1413/1,-3728.66,-835.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGazlowe|r
    .turnin 92706 >>Entrega la misión SE BUSCA: Bruuz
    .target Gazlowe
    .group << Rogue/Warrior
    .isQuestComplete 92706
step
    #label FlytoXroads
    #completewith XroadsHS2
    .goto 1413/1,-3770.20,-898.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBragok|r
    .fly Crossroads >>Vuela a El Cruce
    .target Bragok
    .subzoneskip 380
step << Hunter
    .goto 1413/1,-2595.75,-473.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThork|r
    .accept 6541 >>Acepta la misión Preséntate ante Kadrak
    .target Thork
step
    .goto 1413/1,-2607.91,-475.180
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDarsok|r
    >>|cffff9a3cEstá en la cima de la torre|r
    .turnin 875 >>Entrega la misión Las tenientes arpías
    .accept 876 >>Acepta la misión Serena Sangrepluma
    .target Darsok Swiftdagger
    .isQuestComplete 875
step
    #optional
    .goto 1413/1,-2607.91,-475.180
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDarsok|r
    >>|cffff9a3cEstá en la cima de la torre|r
    .accept 876 >>Acepta la misión Serena Sangrepluma
    .target Darsok Swiftdagger
    .isQuestTurnedIn 875
step
    #label XroadsHS2
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMankrik|r y |cff5cf05cTonga|r
    .turnin -899 >>Entrega la misión Consumido por el odio
    .turnin -95774 >>Entrega la misión Su nombre es Olgra
    .target +Mankrik
    .goto 1413/1,-2641.35,-521.12
    .turnin -880 >>Entrega la misión Seres alterados
    .accept 1489 >>Acepta la misión Hamuul Tótem de Runa
    .accept 3301 >>Acepta la misión Mura Tótem de Runa
    .target +Tonga Runetotem
    .goto 1413/1,-2672.76,-544.77
step
    #optional
    #completewith IshamuhaleTurnin
    .destroy 5085 >>|cffff9a3cElimina los|r |T133721:0|t[Colmillos de jabaespín Erizapúas] |cffff9a3csobrantes que aún puedas tener|r
    .itemcount 5085,1
step
    .goto 1413/1,-2555.22,-387.350
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKorran|r
    .accept 868 >> Acepta la misión ¡A cazar huevos!
    .target Korran
step << Shaman
    #completewith next
    .goto 1413/1,-2595.75,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDevrak|r
    .fly Orgrimmar >> Vuela a Orgrimmar
    .zoneskip Orgrimmar
    .target Devrak
step << Shaman
    .goto 1454/1,-4213.03,1920.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSearn|r
	.accept 1528 >> Acepta la misión La llamada del agua
    .target Searn Firewarder
step << Shaman
    .goto 1454/1,-4225.09,1933.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKardris|r
    .train 2645 >> Aprende tus hechizos de clase
    .target Kardris Dreamseeker
step << Warlock
    #completewith next
    .goto 1413/1,-2595.75,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDevrak|r
    .fly Orgrimmar >> Vuela a Orgrimmar
    .zoneskip Orgrimmar
    .target Devrak
step << Warlock
    .goto 1454/1,-4357.36,1850.41
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGan'rul|r
    .trainer >> Aprende tus hechizos de clase
    .accept 1507 >>Acepta la misión Devoradora de almas
    .target Gan'rul Bloodeye
step << Warlock
    .goto 1454/1,-4347.4,1836.57
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKurgul|r y compra |T133738:0|t[Grimorio Tormento (Rango 2)]
    .collect 16346,1,1507,1 --Grimoire of Torment (Rank 2)
    .target Kurgul
step << Warlock
    .goto 1454/1,-4340.53,1839.19
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCazul|r
    .turnin 1507 >>Entrega la misión Devoradora de almas
    .accept 1508 >>Acepta la misión Cazul, el ciego
    .target Cazul
step << Warlock
    .goto 1454/1,-4299.99,1820.67
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cKatis|r|cffe07cf5. Compra una|r |T135139:0|t[Varita ardiente] |cffe07cf5a esta vendedora|r
    .collect 5210,1,1507,1 --Collect Burning Wand (1)
    .money <0.5808
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<17.4
    .target Katis
step << Warlock
    .goto 1454/1,-4199.99,1717.49
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZankaja|r
    .turnin 1508 >>Entrega la misión Cazul, el ciego
    .accept 1509 >>Acepta la misión Noticias de Dogran
    .target Zankaja
step << Warlock
    #completewith TurninDogran
    .goto 1454/1,-4313.60,1676.24
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDoras|r
	.fly Crossroads >> Vuela a El Cruce
    .zoneskip Orgrimmar,1
    .target Doras
step << Warlock
    #label TurninDogran
    .goto 1413/1,-2639.32,-436.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGazrog|r
    .turnin 1509 >>Entrega la misión Noticias de Dogran
    .accept 1510 >>Acepta la misión Noticias de Dogran
    .target Gazrog
step << Shaman
    #completewith CallofWater01
    .goto 1454/1,-4313.60,1676.24
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDoras|r
    .fly Ratchet >> Vuela a Trinquete
    .target Doras
    .zoneskip Orgrimmar,1
step << Shaman
    #label CallofWater01
    .goto 1413/1,-4047.86,-1345.39
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cIslen|r
    .turnin 1528 >>Entrega la misión La llamada del agua
    .accept 1530 >>Acepta la misión La llamada del agua
    .target Islen Waterseer
step << Shaman
    #completewith next
    .goto 1413/1,-3770.20,-898.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBragok|r
    .fly Crossroads >> Vuela a El Cruce
    .target Bragok
    .subzoneskip 380
step
    .goto 1413/1,-2589.67,-424.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHelbrim|r
    >>|cff5cf05cHelbrim|r |cffff9a3cInicia una misión cronometrada de 45 minutos|r
    .accept 853 >> Acepta la misión Boticaria Zamah
    .target Apothecary Helbrim
    .isQuestTurnedIn 848
    .isQuestAvailable 853
step
    #sticky
    #completewith ZamahTurnin
    +|cffff9a3cEstás en una misión cronometrada, no te vayas AFK. Se entregará 20-30 minutos después de aceptarla|r
    .isOnQuest 853
step << Shaman
    #completewith TribesTurnin
    .goto 1413/1,-3770.20,-898.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBragok|r
    .fly Camp Taurajo >> Vuela al Campamento Taurajo
    .target Bragok
    .subzoneskip 380
step
    #completewith TribesTurnin
    .goto 1413/1,-2595.75,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDevrak|r
    .fly Camp Taurajo >> Vuela al Campamento Taurajo
    .target Devrak
    .subzoneskip 380,1
step
    .goto 1413/1,-2515.7,-2076.41
    >>Mata |cffff5a4aJabaespines Erizapúas|r. Despójalos para obtener una |T134128:0|t[|cff4fc3f7Esquirla de sangre|r]
    .collect 5075,1,5052,1 --Blood Shard (1)
    .mob Bristleback Water Seeker
    .mob Bristleback Thornweaver
    .mob Bristleback Geomancer
step
    #label TribesTurnin
    .goto 1413/1,-1891.48,-2391.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cQuebrantadientes|r
    .turnin -878 >>Entrega la misión Tribus en guerra
    .accept 5052 >>Acepta la misión Esquirlas de sangre de Agamaggan
    .turnin 5052 >>Entrega la misión Esquirlas de sangre de Agamaggan
    .target Mangletooth
step
    #completewith IshamuhaleTurnin
    .goto 1413/1,-1891.48,-2391.93,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cQuebrantadientes|r
    +|cffff9a3cUsa tus|r |T134128:0|t[|cff4fc3f7Esquirlas sangrientas|r] |cffff9a3cpara obtener buffs. Guarda al menos 4 de ellas para después|r << Tauren/Shaman/Orc Warrior/Troll Warrior
    +|cffff9a3cUsa tus|r |T134128:0|t[|cff4fc3f7Esquirlas sangrientas|r] |cffff9a3cpara obtener buffs. Guarda al menos 4 de ellas para después|r << !Tauren !Shaman !Warrior/Undead
    +|cffff9a3c¡Asegúrate de desactivar cualquier función de autocompletar de addons como Questie o Leatrix Plus para esto!|r
    .target Mangletooth
step
    .goto 1413/1,-1921.88,-2383.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJorn Vidente del Cielo|r
    .turnin 882 >>Entrega la misión Ishamuhale
    .accept 907 >>Acepta la misión Los truenagartos iracundos
    .turnin 883 >>Entrega la misión Lakota'mani
    .target Jorn Skyseer
    .isOnQuest 883
step
    #label IshamuhaleTurnin
    .goto 1413/1,-1921.88,-2383.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJorn Vidente del Cielo|r
    .turnin 882 >>Entrega la misión Ishamuhale
    .accept 907 >>Acepta la misión Los truenagartos iracundos
    .target Jorn Skyseer
step
    #completewith SleepingBag1
    >>Mata a los |cffff5a4aTruenagartos|r. Despójalos para obtener su |cff4fc3f7Sangre|r
    .complete 907,1 --Thunder Lizard Blood (3)
    .mob Thunderhead
    .mob Stormsnout
step
    #completewith LizardBlood
    .goto 1413/1,-1899.59,-2624.34,0
    .goto 1413/1,-2016.12,-2650.02,0
    .goto 1413/1,-2400.18,-2398.01,0
    .goto 1413/1,-2363.70,-2537.19,0
    >>Mata a |cffff5a4aOwatanka|r. Despójalo para obtener |T133723:0|t[|cff4fc3f7Punta de cola de Owatanka|r]
    >>|cffff9a3cUsa la |T133723:0|t[|cff4fc3f7Punta de cola de Owatanka|r] para iniciar la misión|r
    >>|cffff9a3cTiene 4 puntos de aparición (marcados en el mapa)|r
    .collect 5102,1,884,1 --Collect Owatanka's Tailspike
    .accept 884 >>Acepta la misión Owatanka
    .use 5102
    .unitscan Owatanka
step
    #label SleepingBag1
    .goto 1413/1,-2075.00,-3380.64--c:The Barrens,46.361,73.904
    >>Haz clic en los |cffe07cf5Restos quemados|r en el suelo
    .accept 79007 >> Acepta la misión ... y la nota que encontraste
step
    #label LizardBlood
    #loop
    .goto 1413/1,-1868.18,-2498.00,0
    .goto 1413/1,-1868.18,-2498.00,60,0
    .goto 1413/1,-1861.08,-2561.51,60,0
    .goto 1413/1,-1842.84,-2618.94,60,0
    .goto 1413/1,-1888.44,-2650.690,60,0
    .goto 1413/1,-2004.98,-2683.80,60,0
    .goto 1413/1,-2133.67,-2590.56,60,0
    .goto 1413/1,-2182.31,-2479.76,60,0
    .goto 1413/1,-2232.98,-2478.41,60,0
    .goto 1413/1,-2273.51,-2456.79,60,0
    .goto 1413/1,-2356.60,-2513.54,60,0
    .goto 1413/1,-2428.55,-2517.60,60,0
    .goto 1413/1,-2406.26,-2424.36,60,0
    .goto 1413/1,-2363.70,-2395.98,60,0
    .goto 1413/1,-2253.24,-2345.99,60,0
    >>Mata a los |cffff5a4aTruenagartos|r. Despójalos para obtener su |cff4fc3f7Sangre|r
    .complete 907,1 --Thunder Lizard Blood (3)
    .mob Thunderhead
    .mob Stormsnout
step
    .goto 1413/1,-1921.88,-2383.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJorn|r
    .turnin 884 >>Entrega la misión Owatanka
    .turnin 907 >>Entrega la misión Los truenagartos iracundos
    .accept 913 >>Acepta la misión El chillido del halcón trueno
    .target Jorn Skyseer
    .isOnQuest 884
step
    #label Thunderhawk
    .goto 1413/1,-1921.88,-2383.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJorn|r
    .turnin 907 >>Entrega la misión Los truenagartos iracundos
    .accept 913 >>Acepta la misión El chillido del halcón trueno
    .target Jorn Skyseer
step << Shaman
    #completewith CallofWater2
    .goto 1413/1,-1899.59,-2624.34,0
    .goto 1413/1,-2016.12,-2650.02,0
    .goto 1413/1,-2400.18,-2398.01,0
    .goto 1413/1,-2363.70,-2537.19,0
    .goto 1413/1,-1899.59,-2624.34,80,0
    .goto 1413/1,-2016.12,-2650.02,80,0
    .goto 1413/1,-2363.70,-2537.19,80,0
    .goto 1413/1,-2400.18,-2398.01,80,0
    >>Mata a |cffff5a4aOwatanka|r. Despójalo para obtener |T133723:0|t[|cff4fc3f7Punta de cola de Owatanka|r]
    >>|cffff9a3cUsa la |T133723:0|t[|cff4fc3f7Punta de cola de Owatanka|r] para iniciar la misión|r
    >>|cffff9a3cTiene 4 puntos de aparición (marcados en el mapa)|r
    .collect 5102,1,884,1 --Collect Owatanka's Tailspike
    .accept 884 >>Acepta la misión Owatanka
    .use 5102
    .unitscan Owatanka
step << Shaman
    #completewith CallofWater2
    .goto 1413/1,-1776.98,-3617.51,60>> Viaja al sur hacia |cff5cf05cSalmuera|r
step << Shaman
    #completewith next
    >>Mata a un |cffff5a4aHalcón Trueno|r. Despójalo para obtener sus |cff4fc3f7Alas|r
    .complete 913,1 --Thunderhawk Wings (1)
    .mob Thunderhawk Hatchling
    .mob Thunderhawk Cloudscraper
    .mob Greater Thunderhawk
step << Shaman
    #label CallofWater2
    .goto 1413/1,-1776.98,-3617.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSalmuera|r
    .turnin 1530 >>Entrega la misión La llamada del agua
    .accept 1535 >>Acepta la misión La llamada del agua
    .target Brine
step << Shaman
    .goto 1413/1,-1858.04,-3572.92
    .use 7766 >> |cffff9a3cLlena tu|r |T132825:0|t[Odre de agua marrón vacío] |cffff9a3cen la charca debajo de la cabaña de Salmuera|r
    .complete 1535,1 --Filled Brown Waterskin (1)
step << Shaman
    .goto 1413/1,-1776.98,-3617.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSalmuera|r
    .turnin 1535 >>Entrega la misión La llamada del agua
    .accept 1536 >>Acepta la misión La llamada del agua
    .target Brine
step << Shaman
    #completewith ThunderhawkTurnin
    .subzone 378 >>Viaja de vuelta hacia Campamento Taurajo
step
    #completewith next
    .goto 1413/1,-1899.59,-2624.34,0
    .goto 1413/1,-2016.12,-2650.02,0
    .goto 1413/1,-2400.18,-2398.01,0
    .goto 1413/1,-2363.70,-2537.19,0
    .goto 1413/1,-1899.59,-2624.34,80,0
    .goto 1413/1,-2016.12,-2650.02,80,0
    .goto 1413/1,-2363.70,-2537.19,80,0
    .goto 1413/1,-2400.18,-2398.01,80,0
    >>Mata a |cffff5a4aOwatanka|r. Despójalo para obtener |T133723:0|t[|cff4fc3f7Punta de cola de Owatanka|r]
    >>|cffff9a3cUsa la |T133723:0|t[|cff4fc3f7Punta de cola de Owatanka|r] para iniciar la misión|r
    >>|cffff9a3cTiene 4 puntos de aparición (marcados en el mapa)|r
    .collect 5102,1,884,1 --Collect Owatanka's Tailspike
    .accept 884 >>Acepta la misión Owatanka
    .use 5102
    .unitscan Owatanka
step
    #loop
    .goto 1413/1,-1919.86,-2652.04,0
    .goto 1413/1,-1919.86,-2652.04,60,0
    .goto 1413/1,-2096.18,-2531.11,60,0
    .goto 1413/1,-2341.4,-2352.74,60,0
    .goto 1413/1,-1982.68,-2217.62,60,0
    .goto 1413/1,-1775.96,-2235.86,60,0
    >>Mata a una |cffff5a4aProle de Halcón Trueno|r o a un |cffff5a4aDesechanube Halcón Trueno|r. Despójalo para obtener |cff4fc3f7Alas de halcón trueno|r
    .complete 913,1 --Thunderhawk Wings (1)
    .mob Thunderhawk Hatchling
    .mob Thunderhawk Cloudscraper
step
    .goto 1413/1,-1921.88,-2383.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJorn Vidente del Cielo|r
    .turnin 884 >>Entrega la misión Owatanka
    .turnin 913 >>Entrega la misión El chillido del halcón trueno
    .accept 874 >>Acepta la misión Mahren Vidente del Cielo
    .accept 6382 >>Acepta la misión La Caza de Vallefresno << Hunter
    .target Jorn Skyseer
    .isOnQuest 884
step
    #label ThunderhawkTurnin
    .goto 1413/1,-1921.88,-2383.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJorn Vidente del Cielo|r
    .turnin 913 >>Entrega la misión El chillido del halcón trueno
    .accept 874 >>Acepta la misión Mahren Vidente del Cielo
    .accept 6382 >>Acepta la misión La Caza de Vallefresno << Hunter
    .target Jorn Skyseer
step
    #optional
    .xp 20 >>Mata enemigos hasta subir al nivel 20
step << !Tauren !Skyborne
    .goto 1413/1,-1891.48,-2391.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cQuebrantadientes|r
    .aura 16618 >>|cffff9a3cSi te quedan 10|r |T134128:0|t[|cff4fc3f7Esquirlas de sangre|r] |cffff9a3c, úsalas para obtener|r |T136022:0|t[Espíritu del viento] |cffff9a3cde|r |cff5cf05cQuebrantadientes|r
    >>|cffff9a3cOmite este paso si tienes la ruta de vuelo de Cima del Trueno|r
    .itemcount 5075,10
    .target Mangletooth
    .train 2645,1 << Shaman --skip if ghost wolf trained
    .train 5118,1 << Hunter --skip if cheetah trained
step << !Tauren !Skyborne
    #completewith next
    .goto 1412/1,-1480.52,-2339.56,120,0
    .zone Mulgore >>Viaja a Mulgore
step << !Tauren !Skyborne
    #completewith DeathDUPpickup
    .goto 1456/1,184.96,-1308.69
    .zone Thunder Bluff >>Toma el ascensor hacia Cima del Trueno
    >>|cffff9a3cSi tienes la ruta de vuelo de Cima del Trueno, vuela allí en su lugar|r
step << Tauren/Skyborne
    #completewith DeathDUPpickup
    .goto 1413/1,-1881.35,-2384.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOmusa|r
    .fly Thunder Bluff >>Vuela a Cima del Trueno
    .target Omusa Thunderhorn
    .zoneskip Thunder Bluff
step << Undead Warrior/Orc Warrior/Troll Warrior/Troll Shaman/Orc Shaman
    .goto 1456/1,89.46,-1286.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAnsekhwa|r
    .train 199 >>Aprende el uso de Mazas de dos manos
    .train 227 >>Aprende el uso de Bastones
    .target Ansekhwa
step << Troll Hunter/Orc Hunter/Undead Warrior/Warlock/Priest
    .goto 1456/1,89.46,-1286.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAnsekhwa|r
    .train 227 >>Aprende el uso de Bastones
    .target Ansekhwa
step << Rogue !Skyborne
    .goto 1456/1,89.46,-1286.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAnsekhwa|r
    .train 198 >>Aprende el uso de Mazas
    .target Ansekhwa
step << skip --Rogue
    .goto 1456/1,110.13,-1299.65
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cKuruk|r|cffe07cf5. Compra |r |T135423:0|t[Hacha arrojadiza mortal] |cffe07cf5a este vendedor|r
    .collect 3137,1,6562,1 --Deadly Throwing Axe (200)
    .target Kuruk
step << Rogue
    #optional
    .goto 1456/1,104.500,-1308.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBoarton Totemsombrío|r
    >>|cffff9a3cEstá|r |T132320:0|t[En sigilo]
    .train 6761 >>Aprende tus hechizos de clase
    .target Boarton Shadetotem
    .xp <16,1
    .xp >20,1
step << Rogue
    .goto 1456/1,104.500,-1308.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBoarton Totemsombrío|r
    >>|cffff9a3cEstá|r |T132320:0|t[En sigilo]
    .train 1943 >>Aprende tus hechizos de clase
    .target Boarton Shadetotem
    .xp <20,1
step
    .goto 1456/1,24.85,-1252.75
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cChesmu|r
    .bankdeposit 5075 >> Deposita tus |T134128:0|t[Esquirlas de sangre]
    .bankdeposit 5059 >> Deposita tu |T132938:0|t[Garra de excavación]
    .target Chesmu
    .isOnQuest 868
step
    #optional
    .goto 1456/1,24.85,-1252.75
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cChesmu|r
    .bankdeposit 5075 >> Deposita tus |T134128:0|t[Esquirlas de sangre]
    .target Chesmu
    .isNotOnQuest 868
step
    .goto 1456/1,38.32,-1300.48
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cTabernera Pala|r
    .home >>Establece tu Piedra de hogar en Cima del Trueno
    .target Innkeeper Pala
    .bindlocation 1638
    .isQuestAvailable 6442
step << Hunter
    #completewith HunterTraining2
    .goto 1456/1,-123.26,-1394.49,60 >> Viaja al Alto de los Cazadores
step << Hunter
    .goto 1456/1,-100.50,-1454.75
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cUrek|r
    .train 5118 >> Aprende tus hechizos de clase
    .target Urek Thunderhorn
    .xp <20,1
    .xp >22,1
step << Hunter
    #label HunterTraining2
    #optional
    .goto 1456/1,-100.50,-1454.75
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cUrek|r
    .train 5118 >> Aprende tus hechizos de clase
    .target Urek Thunderhorn
    .xp <22,1
step << Hunter
    .goto 1456/1,-47.69,-1434.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHesuwa|r
    .train 24494 >> Entrena los hechizos de tu mascota
    .target Hesuwa Thunderhorn
step << Warrior
    #completewith next
    .goto 1456/1,-123.26,-1394.49,60 >> Viaja al Alto de los Cazadores
step << Warrior
    .goto 1456/1,-81.09,-1457.74
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTorm|r
    .train 845 >>Aprende tus hechizos de clase
    .accept 1823 >>Acepta la misión Habla con Ruga
    .target Torm Ragetotem
step
    #completewith next
    .goto 1456/1,222.96,-1079.42,40,0
    .goto 1456/1,219.09,-1051.44,10 >> Viaja al Alto de los Espíritus y entra en las pozas de las visiones
step
    #sticky
    #completewith DeathDUPpickup
    .goto 1456/1,218.68,-1028.41
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cClarice|r
    .accept 264 >> Acepta la misión Hasta que la muerte nos separe
    .target Clarice Foster
step
    #optional
    #label ZamahTurnin
    .goto 1456/1,278.48,-995.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZamah|r
    .turnin 853 >> Entrega la misión Boticaria Zamah
    .target Apothecary Zamah
    .isOnQuest 853
step << Priest
    .goto 1456/1,252.49,-956.04
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMiles|r
    .accept 5644 >> Acepta la misión Peste devoradora << Undead Priest
    .accept 5642 >> Acepta la misión Guardia de las Sombras << Troll Priest
    .trainer >> Aprende tus hechizos de clase
    .target Miles Welsh
step << Mage
    .goto 1456/1,279.32,-950.76
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShymm|r
    .train 12051 >> Aprende tus hechizos de clase
    .target Archmage Shymm
    .xp <20,1
    .xp >22,1
step << Mage
    #optional
    .goto 1456/1,279.32,-950.76
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShymm|r
    .train 2138 >> Aprende tus hechizos de clase
    .target Archmage Shymm
    .xp <22,1
step << Paladin
    .goto 1456/1,253.900,-950.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAlodan|r
    .train 1866 >>Aprende tus hechizos de clase
    .target Alodan the Hopeful
    .xp <20,1
    .xp >22,1
step << Paladin
    #optional
    .goto 1456/1,253.900,-950.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAlodan|r
    .train 1026 >>Aprende tus hechizos de clase
    .target Alodan the Hopeful
    .xp <22,1
step
    #optional
    #label DeathDUPpickup
step << Shaman
    .goto 1456/1,269.92,-980.40
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTigor|r |cffff9a3cfuera|r
    .train 2645 >> Aprende tus hechizos de clase
    .target Tigor Skychaser
    .xp <20,1
    .xp >22,1
step << Shaman
    #optional
    .goto 1456/1,269.92,-980.40
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTigor|r |cffff9a3cfuera|r
    .train 8498 >> Aprende tus hechizos de clase
    .target Tigor Skychaser
    .xp <22,1
step
    #completewith next
    .skill firstaid,80 >> |cffff9a3cCrea|r |T133688:0|t[Vendas de lino gruesa] |cffff9a3chasta que tu habilidad sea 80 o superior|r
    .skill firstaid,<1,1
step
    .goto 1456/1,206.88,-997.45
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cPand|r
    >>|cffff9a3cOmite este paso si no tuviste suficiente|r |T132889:0|t[Paño de lino] |cffff9a3cpara llegar a 80 de habilidad|r
    .train 3277 >> Aprende |T133684:0|t[Venda de lana]
    .train 7934 >> Aprende |T134437:0|t[Contraveneno] << Rogue
    .target Pand Stonebinder
    .skill firstaid,<1,1
step << Rogue
    >>|cffff9a3cCrea|r |T134437:0|t[Contraveneno] |cffff9a3csi encontraste alguna|r |T134339:0|t[Glándula de veneno pequeña]
    >>|cffff9a3cGuárdalos para más adelante|r
    .collect 6452,1 --Anti Venom
    .itemcount 1475,1
step
    #completewith next
    .goto 1456/1,-212.71,-1065.010,80 >> Viaja al Alto de los Ancestros
step
    .goto 1456/1,-303.83,-1048.66
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHamuul|r
    .turnin 1489 >> Entrega la misión Hamuul Tótem de Runa
    .accept 1490 >> Acepta la misión Nara Ferocrín
    .target Arch Druid Hamuul Runetotem
step
    .goto 1456/1,-272.93,-1069.67
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cNara|r
    .turnin 1490 >> Entrega la misión Nara Ferocrín
    .target Nara Wildmane
step << Druid
    .goto 1456/1,-281.59,-1039.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTurak|r
    .trainer >>Aprende tus hechizos de clase
    .accept 27 >>Acepta la misión Una lección que aprender
    .accept 98340 >>Acepta la misión El gran espíritu felino
    .target Turak Runetotem
step << Druid
    #completewith next
    .cast 18960 >>|cffff9a3cLanza|r |T135758:0|t[Teletransporte a: Claro de la Luna]
    .zoneskip Moonglade
step << Druid
    .goto 1450/1,-2678.76,8019.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDendrita|r
    .turnin 27 >>Entrega la misión Una lección que aprender
    .accept 28 >>Acepta la misión La prueba del lago
    .turnin 98340 >>Entrega la misión El gran espíritu felino
    .accept 98341 >>Acepta la misión El espíritu del gran felino natoviento << Skyborne
    .accept 98405 >>Acepta la misión El gran espíritu felino << !Skyborne
    .target Dendrite Starblaze
step << Druid
    #completewith next
    .goto 1450/1,-2634.67,7634.43
    .collect 15877,1,28,1 >>Despoja el |cffe07cf5Adorno contenedor|r en el fondo del lago para un |T134125:0|t[Adorno de altar]
    >>|cffff9a3cNO te sumerjas hasta que estés justo encima del Adorno|r
step << Druid
    .goto 1450/1,-2221.48,7844.89
    .cast 19719 >> |cffff9a3cUsa el|r |T134125:0|t[Adorno de altar] |cffff9a3cen el Santuario de Remulos|r
    .complete 28,1 -- Complete the Trial of the Lake
    .use 15877
step << Druid
    .goto 1450/1,-2224.25,7874.290
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTajarri|r
    .turnin 28 >> Entrega la misión La prueba del lago
    .accept 30 >> Acepta la misión La prueba del león marino
    .target Tajarri
step << Druid !Skyborne
    .goto 1450/1,-2640.000,7338.900
     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGran espíritu felino|r
    .turnin 98405 >>Entrega la misión El gran espíritu felino
    .accept 98342 >>Acepta la misión El gran espíritu felino
    .target Great Cat Spirit
step << Druid Skyborne
    .goto 1450/1,-2352.700,7375.600,10,0
    .goto 1450/1,-2394.300,7361.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cAvatar de Saeyleenan::272054|r
    .target Avatar of Saeyleenan::272054
    .turnin 98341 >>Entrega la misión El espíritu del gran felino natoviento
    .accept 98404 >>Acepta la misión El espíritu del gran felino natoviento
step << Druid
    #completewith next
    .goto 1450/1,-3046.700,7534.400
    --aura 1309054?
    .subzone 2363 >> Dirígete al Túmulo de Tempestira
step << Druid
    >>Ve al fondo de la cueva, cruza el puente, busca una estatua de gato dentro de un hueco y haz clic en el pequeño orbe junto a la estatua
    >>Despoja la |cff4fc3f7Reliquia de la garra|r
    .goto 1450/1,-3117.400,7455.300
    .complete 98404,2 << Skyborne --|1/1 Relic of the Claw
    .complete 98342,2 << !Skyborne --|1/1 Relic of the Claw
step << Druid
    >>Haz clic en el pequeño orbe junto a la estatua de gato
    >>Despoja la |cff4fc3f7Reliquia de la sombra silenciosa|r
    .goto 1450/1,-3099.200,7485.700
    .complete 98404,3  << Skyborne --|1/1 Relic of the Silent Shadow
    .complete 98342,3  << !Skyborne --|1/1 Relic of the Silent Shadow
step << Druid
    >>Haz clic en el pequeño orbe junto a la estatua de gato
    >>Despoja la |cff4fc3f7Reliquia del colmillo|r
    .goto 1450/1,-3054.100,7476.800
    .complete 98404,1  << Skyborne --|1/1 Relic of the Fang
    .complete 98342,1  << !Skyborne --|1/1 Relic of the Fang
step << Druid !Skyborne
    .goto 1450/1,-2640.000,7338.900
     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGran espíritu felino|r
    .turnin 98342 >>Entrega la misión El gran espíritu felino
    .accept 98739 >>Acepta la misión Bendiciones del gran espíritu felino
    .target Great Cat Spirit
step << Druid Skyborne
    .goto 1450/1,-2395.400,7361.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cAvatar de Saeyleenan::272054|r
    .target Avatar of Saeyleenan::272054
    .turnin 98404 >>Entrega la misión El espíritu del gran felino natoviento
    .accept 98738 >>Acepta la misión Bendiciones del gran espíritu felino natoviento
step << Druid
    #completewith next
    .cast 18960 >>|cffff9a3cLanza|r |T135758:0|t[Teletransporte a: Claro de la Luna]
    .zoneskip Moonglade
step << Druid
    .goto 1450/1,-2678.200,8021.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDendrita Rafagaestelar::11802|r
    .turnin 98738 >>Entrega la misión Bendiciones del gran espíritu felino natoviento << Skyborne
    .turnin 98739 >>Entrega la misión Bendiciones del gran espíritu felino << !Skyborne
    .accept 98362 >>Acepta la misión Viaje a Cima del Trueno
    .target Dendrite Starblaze::11802
step << Druid
    .hs >> Usa tu Piedra de hogar para ir a Cima del Trueno
    .use 6948
    .cooldown item,6948,>0
    .bindlocation 1638,1
    .zoneskip Thunder Bluff
step << Druid
    #completewith next
    .goto 1450/1,-2403.61,7785.31
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBunthen|r
    .fly Thunder Bluff >> Vuela a Cima del Trueno
    .target Bunthen Plainswind
    .zoneskip Thunder Bluff
    .cooldown item,6948,<0
step << Druid
    .goto 1456/1,-281.59,-1039.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTurak|r
    .turnin 98362 >>Entrega la misión Viaje a Cima del Trueno
    .target Turak Runetotem
step << Rogue
    .goto 1456/1,-36.52,-1244.05
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cKard|r|cffe07cf5. Compra una|r |T135324:0|t[Tizona] |cffe07cf5a este vendedor.|r
    .collect 923,1,493,1 --Collect Longsword (1)
    .money <0.8743
    .target Kard Ragetotem
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.1
step << Rogue
    #optional
    #completewith KayaLives
    +|cffff9a3cEquipa la|r |T135324:0|t[Tizona]
    .use 923
    .itemcount 923,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<12.1
    .xp <21,1
step << Warrior/Shaman
    #optional
    #completewith next
    #ah
    +|cff5cf05cSi es más barato puedes comprar un arma verde de la casa de subastas en su lugar|r
step << Warrior
    .goto 1456/1,-38.71,-1255.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cEtu|r|cffe07cf5. Compra un|r |T135157:0|t[Bastón largo] |cffe07cf5a este vendedor|r
    .collect 928,1,493,1 --Collect Long Staff (1)
    .money <0.9860
    .target Etu Ragetotem
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.2
step << Warrior
    #optional
    #completewith KayaLives
    +|cffff9a3cEquipa el|r |T135157:0|t[Bastón largo]
    .use 928
    .itemcount 928,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.2
    .xp <20,1
step << Shaman
    .goto 1456/1,-38.71,-1255.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cEtu|r|cffe07cf5. Compra un|r |T135157:0|t[Bastón largo] |cffe07cf5a este vendedor|r
    .collect 928,1,493,1 --Collect Long Staff (1)
    .money <0.9860
    .target Etu Ragetotem
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.2
step << Shaman
    #optional
    #completewith KayaLives
    +|cffff9a3cEquipa el|r |T135157:0|t[Bastón largo]
    .use 928
    .itemcount 928,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<15.2
    .xp <21,1
step << Hunter
    .goto 1456/1,26.31,-1167.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cKuna|r|cffe07cf5. Compra un|r |T135489:0|t[Arco corvo pesado] |cffe07cf5a esta vendedora|r
    .collect 3027,1,493,1 --Collect Heavy Recurve Bow (1)
    .money <0.5643
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<9.1
    .target Kuna Thunderhorn
step << Hunter
    #completewith KayaLives
    #optional
    +|cffff9a3cEquipa el|r |T135489:0|t[Arco corvo pesado]
    .use 3027
    .itemcount 3027,1
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<9.1
    .xp <20,1
step << Hunter
    .goto 1456/1,26.31,-1167.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cKuna|r
    >>|cffe07cf5Compra|r |T132382:0|t[Flechas afiladas] |cffe07cf5a esta vendedora|r
    .collect 2515,1600,493,1 << Hunter --Sharp Arrow (1600)
    .target Kuna Thunderhorn
step
    #completewith EnterSTM2
    .goto 1456/1,26.1,-1196.66
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTal|r
    .fly Crossroads >>Vuela a El Cruce
    .target Tal
    .zoneskip The Barrens
    .zoneskip Stonetalon Mountains
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 852 >>Entrega la misión Hezrul Marcasangre
    .target Regthar Deathgate
    .isQuestComplete 852
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 855 >>Entrega la misión Los brazales centauro
    .target Regthar Deathgate
    .isQuestComplete 855
step
    #optional
    #completewith Serena
    .abandon 855 >>Abandona la misión Los brazales centauro
step
    #completewith CounterattackTurnin2
    +|cffff9a3cLa próxima misión es muy difícil y se recomienda formar un grupo. Puedes kitear al |cffff5a4aSeñor de la guerra Krom'zar|r alrededor del edificio donde se encuentra el PNJ que da la misión|r
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .accept 4021 >>Acepta la misión ¡Contraataca!
    .target Regthar Deathgate
    --.timer 183,Warlord Krom'zar Spawn
    .isQuestTurnedIn 852
    --timer is random, generally somewhere between 120-210 seconds
step
    .goto 1413/1,-1884.39,-289.38
    >>Mata al |cffff5a4aSeñor de la Guerra Krom'zar|r una vez que aparece. Despoja el |cffe07cf5Estandarte|r que deja en el suelo
    >>|cffff9a3c¡Ten cuidado! Es un élite fuerte y está custodiado por al menos dos|r |cffff5a4aKolkar|r |cffff9a3cenemigos|r
    >>|cffff9a3cPuede tardar hasta 3 minutos en reaparecer|r
    .link https://www.youtube.com/watch?v=xrm0PWe5wf4 >>|cffff9a3cHaz clic aquí para una guía en video sobre cómo hacer "kiting" al|r |cffff5a4aSeñor de la Guerra Krom'zar|r
    .complete 4021,1 --Piece of Krom'zar's Banner (1)
    .unitscan Warlord Krom'zar
    .isQuestTurnedIn 852
step
    #label CounterattackTurnin2
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 4021 >>Entrega la misión ¡Contraataca!
    .target Regthar Deathgate
    .isQuestComplete 4021
step
    .goto 1413/1,-1972.55,-306.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegthar|r
    .turnin 855 >>Entrega la misión Los brazales centauro
    .target Regthar Deathgate
    .isQuestComplete 855
step
    #label Serena
    .goto 1413/1,-1345.3,790.94
    >>Mata a |cffff5a4aSerena Sangrepluma|r. Despójala para obtener su |cff4fc3f7Cabeza|r
    .complete 876,1 --Serena's Head (1)
    .mob Serena Bloodfeather
    .isQuestTurnedIn 875
step
    #completewith next
    >>Despoja las |cffe07cf5Trampas activadas|r del suelo
    .complete 95507,1 --|8/8 Trapped Game
step
    #loop
    .goto 1413/1,-1848.200,486.900,0
    .goto 1413/1,-1848.200,486.900,50,0
    .goto 1413/1,-1937.500,480.000,50,0
    .goto 1413/1,-1983.100,579.700,50,0
    .goto 1413/1,-1960.600,653.700,50,0
    .goto 1413/1,-1871.600,653.700,50,0
    .goto 1413/1,-1729.700,592.400,50,0
    >>Mata a los |cffff5a4aPatriarcas de la sabana|r. Despójalos para obtener sus |cff4fc3f7Cueros|r
    .complete 95494,1 --|6/6 Savannah Lion Hide
    .mob Savannah Patriarch
step
    #loop
    .goto 1413/1,-1960.600,653.700,0
    .goto 1413/1,-1848.200,486.900,50,0
    .goto 1413/1,-1937.500,480.000,50,0
    .goto 1413/1,-1983.100,579.700,50,0
    .goto 1413/1,-1960.600,653.700,50,0
    .goto 1413/1,-1871.600,653.700,50,0
    .goto 1413/1,-1729.700,592.400,50,0
    >>Despoja las |cffe07cf5Trampas activadas|r del suelo
    .complete 95507,1 --|8/8 Trapped Game
step
    .goto 1413/1,-1812.600,789.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVrang Sangrevaje|r
    .turnin 95494 >>Entrega la misión El orgullo herido y la piel del león
    .turnin -95507 >>Entrega la misión Las presas de Vrang
    .accept 95495 >>Acepta la misión El peletero ermitaño
    .target Vrang Wildgore
    .isQuestComplete 95494
step
    #completewith next
    .goto 1413/1,-1778.100,684.200,25,0
    .goto 1413/1,-1741.700,721.400,25,0
    .goto 1413/1,-1643.900,786.000,25,0
    .goto 1413/1,-1605.300,818.300,20 >>Sube por la montaña
step
    .goto 1413/1,-1635.400,838.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWalton|r
    .turnin 95495 >>Entrega la misión El peletero ermitaño
    .accept 95621 >>Acepta la misión Problemas en el valle
    .target Walton
    .isQuestTurnedIn 95494
step
    .goto 1413/1,-1611.500,549.000
    >>Mata al |cffff5a4aCabo Adamore|r
    >>|cffff9a3c¡Ten cuidado! Podrías llamar la atención (aggro) de 2 o 3 bichos a la vez|r
    .complete 95621,1 --|1/1 Learn why the Kul Tirans are here
    .mob Corporal Adamore
    .isQuestTurnedIn 95494
step
    #completewith next
    .goto 1413/1,-1736.900,650.300,25,0
    .goto 1413/1,-1741.700,721.400,25,0
    .goto 1413/1,-1643.900,786.000,25,0
    .goto 1413/1,-1605.300,818.300,20 >>Sube por la montaña
step
    .goto 1413/1,-1635.500,838.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWalton|r
    .turnin 95621 >>Entrega la misión Problemas en el valle
    .accept 95508 >>Acepta la misión Huéspedes no deseados
    .timer 67,Unwelcome Guests RP
    .target Walton
    .isQuestTurnedIn 95494
step
    .goto 1413/1,-1629.200,835.600
    >>Ponte detrás de la casa mientras esperas a que termine el RP para evitar llamar la atención (aggro) de todos los enemigos a la vez
    >>|cffff9a3cEn realidad no necesitas ayudar a |cff5cf05cWalton|r, sobrevivirá con la ayuda de|r |cff5cf05cVrang Sangrevaje|r
    .complete 95508,1 --|1/1 Assist Walton
    .mob Terry Longdrink
    .isQuestTurnedIn 95494
step
    .goto 1413/1,-1635.400,838.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWalton|r
    .turnin 95508 >>Entrega la misión Huéspedes no deseados
    .target Walton
    .isQuestTurnedIn 95494
step << Hunter
    .goto 1413/1,-2347.48,857.83
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWenikee|r
    .turnin 3921 >> Entrega la misión Wenikee Tuercasmil
    .target Wenikee Boltbucket
    .isOnQuest 3921
step << Hunter
    .goto 1413/1,-2253.24,1246.31
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTorek|r
    .turnin 6541 >> Entrega la misión Preséntate ante Kadrak
    .target Kadrak
step << Hunter
    #optional
    .goto 1413/1,-2253.24,1246.31
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTorek|r
    .accept 3513 >>Acepta la misión El pergamino rúnico
    .turnin 3513 >>Entrega la misión El pergamino rúnico
    .target Kadrak
    .itemcount 10621,1
step << Hunter
    .goto 1440/1,-2240.94,1778.570
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTorek|r para comenzar la escolta
    >>|cff5cf05cTorek|r |cffff9a3ctiene un tiempo de reaparición de 5 minutos|r
    .accept 6544 >> Acepta la misión El asalto de Torek
    .target Torek
step << Hunter
    .goto 1440/1,-2110.61,1809.320,60,0
    .goto 1440/1,-2052.37,1776.27,20,0
    .goto 1440/1,-2006.81,1777.42,10,0
    .goto 1440/1,-2037.38,1777.04
    >>Sigue a |cff5cf05cTorek|r
    >>Deja que |cff5cf05cTorek|r y sus |cff5cf05cAsaltantes del Hachazo|r tanqueen a las |cffff5a4aGuerreras Ala de Plata|r y a las |cffff5a4aCentinelas Ala de Plata|r
    >>|cffff9a3cCuando limpies el edificio, corre hacia el Balcón. Cuando |cffff5a4aDuriel Fuegolunar|r llega, deja que |cff5cf05cTorek|r y sus |cff5cf05cAsaltante del Hachazo|r generen amenaza antes de infligir daño|r
    .complete 6544,1 --Take Silverwing Outpost
    .mob Silverwing Warrior
    .mob Silverwing Sentinel
    .unitscan Duriel Moonfire
step << Hunter
    .goto 1440/1,-2511.97,2271.73
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cErtog|r
    .turnin 6544 >> Entrega la misión El asalto de Torek
    .target Ertog Ragetusk
    .isQuestComplete 6544
step << Hunter
    .goto 1440/1,-2554.65,2310.55
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSenani|r
    .turnin 6382 >> Entrega la misión La Caza de Vallefresno
    .turnin 6383 >> Entrega la misión La Caza de Vallefresno
    .target Senani Thunderheart
step << Hunter
    .goto 1440/1,-2520.05,2305.55
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVhulgra|r
    .fp Splintertree Post >> Consigue la ruta de vuelo del Puesto del Hachazo
    .target Vhulgra
step << Hunter
    #completewith EnterSTM2
    .goto 1440/1,-2520.05,2305.55
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVhulgra|r
    .fly Crossroads >> Vuela a El Cruce
    .target Vhulgra
    .zoneskip The Barrens
step << !Hunter
    #softcore
    #completewith next
    .deathskip >> Muere y reaparece en el |cff5cf05cÁngel de la Resurrección|r
step << !Hunter
    #hardcore
    #completewith next
    .subzone 380 >>Viaja a El Cruce
step
    .goto 1413/1,-2607.91,-474.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDarsok|r
    .turnin 876 >> Entrega la misión Serena Sangrepluma
    .accept 1060 >> Acepta la misión Carta para Jin'Zil
    .target Darsok Swiftdagger
    .isQuestComplete 876
step
    #optional
    .goto 1413/1,-2607.91,-474.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDarsok|r
    .accept 1060 >> Acepta la misión Carta para Jin'Zil
    .target Darsok Swiftdagger
    .isQuestTurnedIn 876
step
    .goto 1413/1,-2555.22,-387.350
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKorran|r
    .accept 868 >> Acepta la misión ¡A cazar huevos!
    .target Korran
step
    #label EnterSTM2
    #completewith STMturnins1
    .zone Stonetalon Mountains >> Viaja a Sierra Espolón
    .zoneskip Stonetalon Mountains
step
    #map Stonetalon Mountains
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSeereth|r y |cff5cf05cMakaba|r
    .turnin -1062 >>Entrega la misión Los invasores goblin
    .timer 4,Goblin Invaders RP
    .accept 1063 >>Acepta la misión La bruja anciana
    .accept 1068 >>Acepta la misión Las sierras XT:4 y XT:9
    .target +Seereth Stonebreak
    .goto 1413/1,-950.10,-271.14
    .turnin 6629 >>Entrega la misión Mata a Grundig Nube Negra
    .turnin 6523 >>Entrega la misión Protege a Kaya
    .accept 6401 >>Acepta la misión Kaya está viva
    .target +Makaba Flathoof
    .goto 1413/1,-943.00,-265.06
    .isQuestComplete 6629
    .isQuestComplete 6523
step
    #optional
    #map Stonetalon Mountains
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSeereth|r y |cff5cf05cMakaba|r
    .turnin -1062 >>Entrega la misión Los invasores goblin
    .timer 4,Goblin Invaders RP
    .accept 1063 >>Acepta la misión La bruja anciana
    .accept 1068 >>Acepta la misión Las sierras XT:4 y XT:9
    .target +Seereth Stonebreak
    .goto 1413/1,-950.10,-271.14
    .turnin 6629 >>Entrega la misión Mata a Grundig Nube Negra
    .target +Makaba Flathoof
    .goto 1413/1,-943.00,-265.06
    .isQuestComplete 6629
step
    #optional
    #map Stonetalon Mountains
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSeereth|r y |cff5cf05cMakaba|r
    .turnin -1062 >>Entrega la misión Los invasores goblin
    .timer 4,Goblin Invaders RP
    .accept 1063 >>Acepta la misión La bruja anciana
    .accept 1068 >>Acepta la misión Las sierras XT:4 y XT:9
    .target +Seereth Stonebreak
    .goto 1413/1,-950.10,-271.14
    .turnin 6523 >>Entrega la misión Protege a Kaya
    .accept 6401 >>Acepta la misión Kaya está viva
    .target +Makaba Flathoof
    .goto 1413/1,-943.00,-265.06
    .isQuestComplete 6523
step
    #label STMturnins1
    #optional
    #map Stonetalon Mountains
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSeereth|r
    .turnin -1062 >>Entrega la misión Los invasores goblin
    .timer 4,Goblin Invaders RP
    .accept 1063 >>Acepta la misión La bruja anciana
    .accept 1068 >>Acepta la misión Las sierras XT:4 y XT:9
    .goto 1413/1,-950.10,-271.14
    .target Seereth Stonebreak
step
    #completewith BloodFeedersTI
    .goto 1442/1,-786.33,-294.97,60,0
    .goto 1442/1,-665.72,-280.97,40,0
    .goto 1442/1,-522.63,-294.32,40 >> Sigue el camino de la izquierda hacia arriba
step
    .goto 1442/1,-394.20,-272.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJin'Zil|r
    .turnin 1060 >> Entrega la misión Carta para Jin'Zil
    .accept 1058 >> Acepta la misión Magia del bosque de Jin'Zil
    .target Witch Doctor Jin'Zil
    .isQuestTurnedIn 876
step
    .goto 1442/1,-394.20,-272.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJin'Zil|r
    .accept 1058 >> Acepta la misión Magia del bosque de Jin'Zil
    .target Witch Doctor Jin'Zil
step << Warlock
    .goto 1442/1,-331.21,-181.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKen'zigla|r
    .turnin 1510 >>Entrega la misión Noticias de Dogran
    .accept 1511 >>Acepta la misión Jarabe de Ken'zigla
    .target Ken'zigla
step
    #label BloodFeedersTI
    .goto 1442/1,-233.54,-177.42
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cXen'Zilla|r
    .turnin 6461 >>Entrega la misión Chupasangres
    .target Xen'Zilla
step << skip
    .goto 1442/1,-401.53,-277.710
    .goto 1456/1,-74.62,-981.93,30 >>|cffff9a3cSalta sobre una de las jaulas. Haz un Logout Skip desconectando y volviendo a entrar|r
    .link https://www.youtube.com/watch?v=cp2YI86AO4Y&ab >> |cffff9a3cHAZ CLIC AQUÍ para ver un ejemplo|r
step << skip
    #completewith ElderCroneTurnin
    .goto 1456/1,-48.84,-1037.94,20,0
    .goto 1456/1,-13.04,-1107.95,40 >> Toma el ascensor hasta Cima del Trueno
step << Hunter
    .goto 1442/1,360.76,451.690
    >>Haz clic en el |cff5cf05cCartel de Se busca|r
    .accept 6284 >>Acepta la misión Aracnofobia
step << Hunter
    #loop
    .goto 1442/1,569.77,573.79,0
    .goto 1442/1,711.87,513.23,50,0
    .goto 1442/1,684.04,582.91,50,0
    .goto 1442/1,569.77,573.79,50,0
    >>Mata a |cffff5a4aBesseleth|r. Despójala para obtener su |cff4fc3f7Colmillo|r
    >>|cffff9a3cDespeja la zona alrededor de|r |cffff5a4aBesseleth|r|cffff9a3c. Ten cuidado, ya que te enreda con telarañas|r
    >>|cffff9a3cEsta misión es opcional. Si no puedes hacerla, omite esta misión|r
    .complete 6284,1 --Collect Besseleth's Fang (x1)
	.unitscan Besseleth
step
    #completewith Tsunaman1
    .subzone 460 >>Viaja al Refugio Roca del Sol
step
    #completewith next
    .goto 1442/1,834.44,908.21,30,0
    .goto 1442/1,856.91,874.67,30,0
    .goto 1442/1,896.46,836.57,30,0
    .goto 1442/1,940.41,831.04,30 >> Sube por el camino hacia la derecha
step
    #label Tsunaman1
    .goto 1442/1,933.09,824.53
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTsunaman|r
    .accept 6562 >>Acepta la misión Problemas en las profundidades
    .accept 6393 >>Acepta la misión Guerra elemental
    .target Tsunaman
step
    .goto 1442/1,940.9,925.14
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMaggran|r
	.turnin 6284 >> Entrega la misión Aracnofobia
    .target Maggran Earthbinder
    .isQuestComplete 6284
step
    .goto 1442/1,927.72,893.56
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cTabernera Jayka|r
    >>|cffff9a3cNO establezcas tu|r |T134414:0|t[Piedra de hogar]
	.vendor >>|cffe07cf5Vende la basura y luego reabastécete de comida y agua si es necesario|r << !Rogue !Warrior
    .vendor >>|cffe07cf5Vende tu basura, luego reabastécete de comida si es necesario|r << Rogue/Warrior
    .vendor >> Vende la Basura
    .target Innkeeper Jayka
    .isOnQuest 1095
step
    .goto 1442/1,925.27,885.42,5,0
    .goto 1442/1,920.88,911.47
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJeeda|r en el segundo piso de la posada
    .vendor 4083 >> |cffe07cf5Cómprale|r |T134831:0|t[Pociones de sanación] |cffe07cf5si están disponibles|r << !Warrior
    .vendor 4083 >> |cffe07cf5Cómprale|r |T134831:0|t[Pociones de sanación] |cffe07cf5y|r |T134413:0|t[Vidarraíz] |cffe07cf5si están disponibles|r << Warrior
    .target Jeeda
    .isOnQuest 1095
step
    #label KayaLives
    .goto 1442/1,928.20,1015.99
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTammra|r
    .turnin 6401 >>Entrega la misión Kaya está viva
    .accept 6301 >>Acepta la misión El ciclo del renacimiento
    .target Tammra Windfield
    .isQuestTurnedIn 6523
step
    .goto 1442/1,365.16,878.250
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZiz|r
    .turnin 1095 >>Entrega la misión Nuevas instrucciones
    .accept 1096 >>Acepta la misión Gerenzo Silbillave
    .target Ziz Fizziks
step
    .line Stonetalon Mountains,70.82,55.25,70.52,56.22,69.76,56.70,68.52,56.04,67.77,55.97,66.94,56.25,66.41,56.31,65.74,57.20,65.14,57.02,64.37,56.47,63.72,56.80,62.99,56.25,62.32,56.11,61.58,55.10,61.10,54.68,60.98,54.06,59.81,53.51,59.66,52.14,60.33,51.68
    .goto 1442/1,265.54,1213.0,80,0
    .goto 1442/1,299.72,1233.84,80,0
    .goto 1442/1,332.44,1218.86,80,0
    .goto 1442/1,325.11,1174.25,80,0
    .goto 1442/1,267.98,1156.34,80,0
    .goto 1442/1,262.12,1136.15,80,0
    .goto 1442/1,238.68,1122.47,80,0
    .goto 1442/1,202.54,1089.58,80,0
    .goto 1442/1,169.82,1085.03,80,0
    .goto 1442/1,134.17,1067.12,80,0
    .goto 1442/1,102.43,1077.86,80,0
    .goto 1442/1,64.83,1059.95,80,0
    .goto 1442/1,35.53,1054.09,80,0
    .goto 1442/1,2.81,1083.07,80,0
    .goto 1442/1,-23.07,1085.03,80,0
    .goto 1442/1,-63.6,1094.14,80,0
    .goto 1442/1,-100.23,1091.86,80,0
    .goto 1442/1,-160.78,1070.37,80,0
    .goto 1442/1,-197.89,1086.0,80,0
    .goto 1442/1,-212.54,1117.59,80,0
    .goto 1442/1,332.44,1218.86,80,0
    .goto 1442/1,-202.900,1088.600
    >>Mata a |cffff5a4aXT:9|r
    >>|cffff9a3cPatrulla por el lado sur del río|r
    >>|cffff9a3cSu punto de aparición está marcado en tu mapa|r
    .complete 1068,2 --XT:9 (1)
    .unitscan XT:9
    .isQuestTurnedIn 1062
step << skip --better to do in stonetalon part 2
    #loop
    .line Stonetalon Mountains,67.18,46.87,66.53,46.95,65.72,45.09,63.73,45.02,63.72,45.92,63.43,46.57,64.43,46.13,64.72,46.63,64.82,47.72,65.11,48.31,65.98,48.67,66.24,49.65,66.65,49.58,66.88,48.95,68.41,49.58,69.45,46.56,70.22,48.62,70.95,48.49,71.41,45.54,71.25,43.45
    .goto 1442/1,-34.79,1390.46,80,0
    .goto 1442/1,-3.05,1387.86,80,0
    .goto 1442/1,36.51,1448.42,80,0
    .goto 1442/1,133.69,1450.7,80,0
    .goto 1442/1,134.17,1421.4,80,0
    .goto 1442/1,148.34,1400.23,80,0
    .goto 1442/1,99.5,1414.56,80,0
    .goto 1442/1,85.34,1398.28,80,0
    .goto 1442/1,80.46,1362.78,80,0
    .goto 1442/1,66.3,1343.57,80,0
    .goto 1442/1,23.81,1331.85,80,0
    .goto 1442/1,11.11,1299.94,80,0
    .goto 1442/1,-8.91,1302.22,80,0
    .goto 1442/1,-20.14,1322.73,80,0
    .goto 1442/1,-94.85,1302.22,80,0
    .goto 1442/1,-145.64,1400.56,80,0
    .goto 1442/1,-183.24,1333.48,80,0
    .goto 1442/1,-218.89,1337.71,80,0
    .goto 1442/1,-241.35,1433.77,80,0
    .goto 1442/1,-233.54,1501.83,80,0
    .goto 1442/1,80.46,1378.74,80,0
    .goto 1442/1,80.46,1378.74,0
    >>Mata a |cffff5a4aXT:4|r
    >>|cffff9a3cPatrulla por el lado norte del río|r
    >>|cffff9a3cOmite este paso si no puedes encontrarlo|r
    .complete 1068,1 --XT:4 (1)
    .unitscan XT:4
    .isQuestTurnedIn 1062
step
    #completewith next
    .goto 1442/1,-357.09,978.55
    .subzone 2160 >> Entra en la Mina Cortaviento
    .group
step
    .goto 1442/1,-263.82,962.92
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cPiznik|r
    >>|cffff9a3cEsta misión dura 5 minutos e invocará 3 oleadas de Kóbolds en tiempos establecidos:|r
    >>|cffff9a3cPrimera oleada a los 15 segundos (3 Kóbolds), segunda oleada a los 2 minutos 15 segundos (4 Kóbolds, 2 hechiceros 2 cuerpo a cuerpo), y la tercera oleada a los 3 minutos 20 segundos (4 Kóbolds). El objetivo se completa a los 5 minutos|r
    .accept 1090 >> Acepta la misión Órdenes de Gerenzo
    .target Piznik
    .group 2
step
    .goto 1442/1,-258.93,956.73
    >>Protege a |cff5cf05cPiznik|r de las |cffff5a4aAlimaña Cortaviento|r que llegan
    >>|cffff9a3cPrimera oleada a los 15 segundos (3 Kóbolds), segunda oleada a los 2 minutos 15 segundos (4 Kóbolds, 2 hechiceros 2 cuerpo a cuerpo), y la tercera oleada a los 3 minutos 20 segundos (4 Kóbolds). El objetivo se completa a los 5 minutos|r
    .complete 1090,1 --Keep Piznik safe while he mines the mysterious ore
    .mob Windshear Vermin
    .group 2
step
    .goto 1442/1,-263.82,962.92
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cPiznik|r
    .turnin 1090 >> Entrega la misión Órdenes de Gerenzo
    .accept 1092 >> Acepta la misión Órdenes de Gerenzo
    .target Piznik
    .group
step << skip
    .goto 1442/1,-261.86,951.85
    .goto 1442/1,434.5,898.12,30 >>|cffff9a3cSalta sobre la rueda de madera. Realiza un Logout Skip desconectando y volviendo a entrar|r
    .link https://www.youtube.com/watch?v=8s1SRza7qFg >> |cffff9a3cHAZ CLIC AQUÍ para ver un ejemplo|r
    .group
step
    #completewith next
    .goto 1442/1,-577.33,1532.43,30 >> Entra en El Paso del Espolón
step << skip
    .goto 1442/1,-606.63,1573.79
    .goto 1440/1,-629.73,2633.42,30 >>|cffff9a3cSalta sobre la piedra blanca a tu derecha. Realiza un Logout Skip desconectando y volviendo a entrar|r
    .link https://www.youtube.com/watch?v=h2s4ZjFBLtg >> |cffff9a3cHAZ CLIC AQUÍ para ver un ejemplo|r
    .zoneskip Ashenvale
step
    .goto 1440/1,-632.700,2311.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVa'xug Firefure|r
    .accept 98251 >>Acepta la misión No pienso volver
    .target Va'xug Firefure
step
    #loop
    .goto 1440/1,-609.900,2140.100,0
    .goto 1440/1,-609.900,2140.100,50,0
    .goto 1440/1,-799.500,2222.000,50,0
    .goto 1440/1,-878.400,2168.400,50,0
    .goto 1440/1,-712.300,2023.900,50,0
    .goto 1440/1,-534.500,2045.100,50,0
    >>Mata a los |cffff5a4aAshenvale Osos|r y a los |cffff5a4aShadowhorn Stags|r
    >>|cffff9a3cTen cuidado con |cffff5a4aUrsangous|r (fuerte, nivel 25) que patrulla por la zona|r
    .complete 98251,2 --|6/6 Ashenvale Bear slain
    .mob +Ashenvale Bear
    .complete 98251,1 --|6/6 Shadowhorn Stag slain
    .mob +Shadowhorn Stag
step
    .goto 1440/1,-632.900,2312.000
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVa'xug Firefure|r
    .turnin 98251 >>Entrega la misión No pienso volver
    .accept 98252 >>Acepta la misión Un camino vacío
    .target Va'xug Firefure
step
    .goto 1440/1,-545.200,2446.600
    >>|cffff9a3cCorre hacia el camino principal mientras el |cff5cf05cOjo de Kilrogg|r te sigue|r
    .complete 98252,1 --|1/1 Eye of Kilrogg guided to the road
    .target Eye of Kilrogg
step
    .goto 1440/1,-545.500,2445.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cOjo de Kilrogg|r
    .turnin 98252 >>Entrega la misión Un camino vacío
    .target Eye of Kilrogg
    .isQuestComplete 98252
step
	#completewith ZoramFP
    .goto 1440/1,-268.74,2612.28,50,0
    .goto 1440/1,637.2,3406.79,50,0
    .goto 1440/1,1010.31,3355.28,80 >>Viaja hacia la Avanzada de Zoram'gar
    >>|cffff9a3cAsegúrate de evitar a los guardias de Astranaar en el camino. Sigue la ruta marcada para mayor seguridad|r
    .unitscan Astranaar Sentinel
step
    #optional
	#loop
	.goto 1440/1,1073.74,3635.49,50,0
	.goto 1440/1,1052.4,3683.92,50,0
	.goto 1440/1,1017.8,3683.15,50,0
	.goto 1440/1,978.59,3746.96,50,0
	.goto 1440/1,882.29,3749.26,50,0
	.goto 1440/1,843.65,3785.78,50,0
	.goto 1440/1,885.17,3874.57,50,0
	.goto 1440/1,850.57,3921.08,50,0
	.goto 1440/1,858.64,3984.89,50,0
	.goto 1440/1,928.42,4042.93,50,0
	.goto 1440/1,914.58,4116.34,50,0
	.goto 1440/1,884.02,4084.44,50,0
	.goto 1440/1,784.25,4080.21,50,0
	.goto 1440/1,811.93,4021.02,50,0
	.goto 1440/1,822.31,3949.91,50,0
	.goto 1440/1,815.97,3874.19,50,0
	.goto 1440/1,815.97,3807.69,50,0
	.goto 1440/1,816.55,3715.82,50,0
	.goto 1440/1,848.84,3691.99,50,0
	.goto 1440/1,856.91,3654.71,50,0
	.goto 1440/1,862.68,3587.06,50,0
	.goto 1440/1,918.62,3544.39,50,0
	.goto 1440/1,984.36,3552.46,50,0
	.goto 1440/1,1052.98,3479.82,50,0
	.goto 1440/1,1101.42,3535.17,50,0
	.goto 1440/1,1065.09,3574.76,50,0
    .xp 21 >> Mata enemigos hasta subir al nivel 21
step
    #label ZoramFP
   .goto 1440/1,994.16,3373.730
   >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAndruk|r
   .fp Zoram'gar Outpost >> Consigue la ruta de vuelo de la Avanzada de Zoram'gar
   .target Andruk
   .isQuestAvailable 6442
step
   >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJe'neu|r, |cff5cf05cKarang|r, |cff5cf05cMitsuwa|r y |cff5cf05cMarukai|r
   .turnin 6562 >> Entrega la misión Problemas en las profundidades
   .target +Je'neu Sancrea
   .goto 1440/1,1033.37,3354.89
   .accept 216 >> Acepta la misión Entre una roca y un Piel de Cardo
   .target +Karang Amakkar
   .goto 1440/1,1013.77,3345.67
   .accept 6462 >> Acepta la misión El talismán trol
   .target +Mitsuwa
   .goto 1440/1,1028.18,3333.37
   .accept 6442 >> Acepta la misión Nagas en la Ensenada de Zoram
   .target +Marukai
   .goto 1440/1,1025.88,3331.450
step
    #ah
    #completewith WrathtailHeads
    +|cffff9a3cGuarda todas las|r |T134332:0|t[Páginas del Manual de instrucciones de trituradora] |cffff9a3cque despojes|r
step
   .goto 1440/1,1004.54,3341.83
   >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMuglash|r
   >>|cffff9a3cEsto iniciará una misión de escolta. Ten cuidado porque es difícil|r
   .accept 6641,1 >> Acepta la misión Vorsha la Azotadora
   .target Muglash
step
    #completewith next
   >>Mata |cffff5a4aNagas Colafuria|r. Despójalos para obtener sus |cff4fc3f7Cabezas|r
   .complete 6442,1 --Wrathtail Head (20)
   .mob Wrathtail Razortail
   .mob Wrathtail Wave Rider
   .mob Wrathtail Sorceress
   .mob Wrathtail Sea Witch
   .mob Wrathtail Priestess
   .mob Wrathtail Myrmidon
   .mob Lady Vespia
step
   .goto 1440/1,1144.67,3610.89
   >>Haz clic en el |cffe07cf5Blandón|r cuando llegues allí
   >>|cffff9a3cHabrá olas de|r |cffff5a4aNaga|r |cffff9a3cque aparecen. Ten cuidado cuando|r |cffff5a4aVorsha|r |cffff9a3csalga, pega muy fuerte|r
   >>|cffff9a3cPuedes dejar que|r |cff5cf05cMuglash|r |cffff9a3cgenere algo de amenaza antes de luchar contra él|r
   .complete 6641,1 --Defeat Vorsha the Lasher
   .mob Vorsha the Lasher
step
    #label WrathtailHeads
	#loop
    .goto 1440/1,1065.09,3574.76,0
	.goto 1440/1,1073.74,3635.49,50,0
	.goto 1440/1,1052.4,3683.92,50,0
	.goto 1440/1,1017.8,3683.15,50,0
	.goto 1440/1,978.59,3746.96,50,0
	.goto 1440/1,882.29,3749.26,50,0
	.goto 1440/1,843.65,3785.78,50,0
	.goto 1440/1,885.17,3874.57,50,0
	.goto 1440/1,850.57,3921.08,50,0
	.goto 1440/1,858.64,3984.89,50,0
	.goto 1440/1,928.42,4042.93,50,0
	.goto 1440/1,914.58,4116.34,50,0
	.goto 1440/1,884.02,4084.44,50,0
	.goto 1440/1,784.25,4080.21,50,0
	.goto 1440/1,811.93,4021.02,50,0
	.goto 1440/1,822.31,3949.91,50,0
	.goto 1440/1,815.97,3874.19,50,0
	.goto 1440/1,815.97,3807.69,50,0
	.goto 1440/1,816.55,3715.82,50,0
	.goto 1440/1,848.84,3691.99,50,0
	.goto 1440/1,856.91,3654.71,50,0
	.goto 1440/1,862.68,3587.06,50,0
	.goto 1440/1,918.62,3544.39,50,0
	.goto 1440/1,984.36,3552.46,50,0
	.goto 1440/1,1052.98,3479.82,50,0
	.goto 1440/1,1101.42,3535.17,50,0
	.goto 1440/1,1065.09,3574.76,50,0
   >>Mata |cffff5a4aNagas Colafuria|r. Despójalos para obtener sus |cff4fc3f7Cabezas|r
   .complete 6442,1 --Wrathtail Head (20)
   .mob Wrathtail Razortail
   .mob Wrathtail Wave Rider
   .mob Wrathtail Sorceress
   .mob Wrathtail Sea Witch
   .mob Wrathtail Priestess
   .mob Wrathtail Myrmidon
   .mob Lady Vespia
step
	#loop
	.goto 1440/1,1073.74,3635.49,50,0
	.goto 1440/1,1052.4,3683.92,50,0
	.goto 1440/1,1017.8,3683.15,50,0
	.goto 1440/1,978.59,3746.96,50,0
	.goto 1440/1,882.29,3749.26,50,0
	.goto 1440/1,843.65,3785.78,50,0
	.goto 1440/1,885.17,3874.57,50,0
	.goto 1440/1,850.57,3921.08,50,0
	.goto 1440/1,858.64,3984.89,50,0
	.goto 1440/1,928.42,4042.93,50,0
	.goto 1440/1,914.58,4116.34,50,0
	.goto 1440/1,884.02,4084.44,50,0
	.goto 1440/1,784.25,4080.21,50,0
	.goto 1440/1,811.93,4021.02,50,0
	.goto 1440/1,822.31,3949.91,50,0
	.goto 1440/1,815.97,3874.19,50,0
	.goto 1440/1,815.97,3807.69,50,0
	.goto 1440/1,816.55,3715.82,50,0
	.goto 1440/1,848.84,3691.99,50,0
	.goto 1440/1,856.91,3654.71,50,0
	.goto 1440/1,862.68,3587.06,50,0
	.goto 1440/1,918.62,3544.39,50,0
	.goto 1440/1,984.36,3552.46,50,0
	.goto 1440/1,1052.98,3479.82,50,0
	.goto 1440/1,1101.42,3535.17,50,0
	.goto 1440/1,1065.09,3574.76,50,0
    .xp 21+21450 >> Mata enemigos hasta alcanzar 21450+/25200 experiencia
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cCorredor Grito de Guerra|r y |cff5cf05cMarukai|r
    .turnin 6641 >> Entrega la misión Vorsha la Azotadora
    .target +Warsong Runner
    .goto 1440/1,995.31,3357.97
    .turnin 6442 >> Entrega la misión Nagas en la Ensenada de Zoram
    .target +Marukai
    .goto 1440/1,1025.88,3331.450
step
    .goto 1440/1,1013.77,3345.67
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKarang|r
    .accept 216 >> Acepta la misión Entre una roca y un Piel de Cardo
    .target Karang Amakkar
step
    #completewith JourneytoTM
    .goto 1440/1,994.16,3373.730
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAndruk|r
    .fly Thunder Bluff >> Vuela a Cima del Trueno
    .zoneskip Thunder Bluff
    .target Andruk
    .cooldown item,6948,<0
step
    #completewith JourneytoTM
    .hs >> Usa tu Piedra de hogar para ir a Cima del Trueno
    .use 6948
    .zoneskip Thunder Bluff
    .bindlocation 1638,1
    .cooldown item,6948,>0
step
    #completewith next
    .goto 1456/1,-212.71,-1065.010,80 >> Viaja al Alto de los Ancestros
step
    .goto 1456/1,-212.71,-1065.010
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMagatha|r
    >>|cffff9a3cEspera a que termine el roleplay|r
    .turnin 1063 >> Entrega la misión La bruja anciana
    .timer 6,The Elder Crone RP
    .accept 1064 >> Acepta la misión Ayuda de los Renegados
    .target Magatha Grimtotem
step
    #completewith next
    .goto 1456/1,219.09,-1051.44,10 >> Viaja al Alto de los Espíritus y entra en las pozas de las visiones
step
    #label JourneytoTM
    .goto 1456/1,278.48,-995.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZamah|r
    .turnin 1064 >> Entrega la misión Ayuda de los Renegados
    .accept 1065 >> Acepta la misión Viaje a Molino Tarren
    .target Apothecary Zamah
step << Paladin
    .goto 1456/1,253.900,-950.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAlodan|r
    .train 1866 >>Aprende tus hechizos de clase
    .target Alodan the Hopeful
    .xp <20,1
    .xp >22,1
step << Paladin
    #optional
    .goto 1456/1,253.900,-950.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAlodan|r
    .train 1026 >>Aprende tus hechizos de clase
    .target Alodan the Hopeful
    .xp <22,1
step
    #ah
    .goto 1456/1,24.85,-1252.75
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cChesmu|r
    .bankdeposit 16645,16646,16647,16648,16649,16650,16651,16652,16653,16654,16655,16656 >>Deposita todas tus |T134332:0|t[Páginas del Manual de instrucciones de trituradora]
    .target Chesmu
step << Warlock
    .goto 1456/1,26.1,-1196.66
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTal|r
    .fly Camp Taurajo >>Vuela al Campamento Taurajo
    .target Tal
    .zoneskip Thunder Bluff,1
step << !Warlock
    .goto 1456/1,26.1,-1196.66
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTal|r
    .fly Orgrimmar >>Vuela a Orgrimmar
    .target Tal
    .zoneskip Thunder Bluff,1
step << Warlock
    #optional
    .goto 1440/1,994.16,3373.730
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAndruk|r
    .fly Camp Taurajo >>Vuela al Campamento Taurajo
    .target Andruk
    .zoneskip Ashenvale,1
step << !Warlock
    #optional
    .goto 1440/1,994.16,3373.730
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAndruk|r
    .fly Orgrimmar >>Vuela a Orgrimmar
    .target Andruk
    .zoneskip Ashenvale,1
step << Warlock
    .goto 1413/1,-1898.58,-2391.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLogmar|r
    .turnin 1511 >>Entrega la misión Jarabe de Ken'zigla
    .accept 1515 >>Acepta la misión El cautiverio de Dogran
    .target Grunt Logmar
step << Warlock
    .goto 1413/1,-1765.83,-1622.39
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDogran|r
    .turnin 1515 >>Entrega la misión El cautiverio de Dogran
    .accept 1512 >>Acepta la misión Un regalo de amor
    .target Grunt Dogran
step << Warlock
    .goto 1413/1,-1881.35,-2384.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOmusa|r
    .fly Orgrimmar >>Vuela a Orgrimmar
    .target Omusa Thunderhorn
    .zoneskip The Barrens,1
step << Warlock
    .goto 1454/1,-4357.36,1850.41
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGan'rul|r
    .turnin 1512 >>Entrega la misión Un regalo de amor
    .accept 1513 >>Acepta la misión El vínculo
    .target Gan'rul Bloodeye
step << Warlock
    #completewith next
    .cast 9224 >>|cffff9a3cUsa el|r |T133290:0|t[Colgante de Dogran] |cffff9a3cen el Círculo de Invocación|r
    .use 6626
step << Warlock
    .goto 1454/1,-4377.13,1804.77
    >>Mata a la |cffff5a4aSúcubo invocado|r
    .complete 1513,1 --Kill Summoned Succubus (1)
    .mob Summoned Succubus
    .use 6626
step << Warlock
    .goto 1454/1,-4357.36,1850.41
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGan'rul|r
    .turnin 1513 >>Entrega la misión El vínculo
    .target Gan'rul Bloodeye
step << Warlock
    .goto 1454/1,-4362.55,1834.70
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMirket|r
    .train 6202 >> Aprende tus hechizos de clase
    .target Mirket
    .xp <22,1
    .xp >24,1
step << Warlock
    #optional
    .goto 1454/1,-4362.55,1834.70
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMirket|r
    .train 6223 >> Aprende tus hechizos de clase
    .target Mirket
    .xp <24,1
step << Rogue
    #completewith next
    .goto 1454/1,-4320.75,1750.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cKareth|r|cffe07cf5. Cómprale una|r |T135640:0|t[Jambiya] |cffe07cf5si no tienes una daga|r
    .collect 2207,1 --Collect Jambiya (1)
    .target Kareth
step << Rogue
    .goto 1454/1,-4284.42,1771.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShenthul|r
    .train 921 >>Aprende |T133644:0|t[Robar]
    .train 8676 >>Aprende |T132282:0|t[Emboscada]
    .train 1943 >>Aprende |T132302:0|t[Ruptura]
    .train 1856 >>Aprende |T132331:0|t[Esfumarse]
    .train 1725 >>Aprende |T132289:0|t[Distraer]
    .train 1785 >>Aprende |T132320:0|t[Sigilo Rango 2]
    .accept 2460 >>Acepta la misión El saludo de los Mano Destrozada
    .target Shenthul
step << Rogue
    .goto 1454/1,-4284.42,1771.28
    >>Después de que |cff5cf05cShenthul|r haga su saludo, escribe /Salute mientras lo tienes seleccionado como objetivo
    .complete 2460,1 --Shattered Salute Performed (1)
    .target Shenthul
step << Rogue
    .goto 1454/1,-4284.42,1771.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShenthul|r
    .turnin 2460 >>Entrega la misión El saludo de los Mano Destrozada
    .accept 2458 >>Acepta la misión Agente encubierto
    .target Shenthul
step << Rogue
    .goto 1454/1,-4271.1,1810.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cRekkul|r|cffe07cf5. Compra |r |T134387:0|t[Pólvora cegadora] |cffe07cf5a este vendedor|r
    .collect 2928,40,2479,1 --Collect Dust of Decay (40)
    .collect 3371,40,2479,1 --Collect Empty Vial (40)
    .collect 5140,20,2479,1 --Collect Flash Powder (20)
    .target Rekkul
step << Priest/Warlock
    .goto 1454/1,-4299.99,1820.67
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cKatis|r|cffe07cf5. Compra una|r |T135139:0|t[Varita ardiente] |cffe07cf5a esta vendedora|r
    .collect 5210,1,1507,1 --Collect Burning Wand (1)
    .money <0.5808
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<17.4
    .target Katis
step << Mage
    .goto 1454/1,-4218.64,1473.72
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cPephredo|r
    .train 2138 >> Aprende tus hechizos de clase
    .target Pephredo
    .xp <22,1
    .xp >24,1
step << Mage
    #optional
    .goto 1454/1,-4218.64,1473.72
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cPephredo|r
    .train 2121 >> Aprende tus hechizos de clase
    .target Pephredo
    .xp <24,1
step << Mage
    .goto 1454/1,-4222.85,1474.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cThuul|r en lo alto de la cabaña
    .train 3567 >> Aprende |T135759:0|t[Teletransporte a: Orgrimmar]
    .target Thuul
step << Troll Priest
    .goto 1454/1,-4179.79,1452.580
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cUr'kyo|r
    .turnin 5642 >> Entrega la misión Guardia de las Sombras
    .trainer >> Aprende tus hechizos de clase
    .target Ur'kyo
step << Undead Priest
    .goto 1454/1,-4179.79,1452.580
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cUr'kyo|r
    .train 8103 >> Aprende tus hechizos de clase
    .target Ur'kyo
    .xp <22,1
    .xp >24,1
step << Undead Priest
    #optional
    .goto 1454/1,-4179.79,1452.580
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cUr'kyo|r
    .train 3747 >> Aprende tus hechizos de clase
    .target Ur'kyo
    .xp <24,1
step << Rogue/Druid
    #completewith MissionProbable
    .goto 1454/1,-4048.36,1697.85,80,0
    .goto 1454/1,-3900.25,1681.48,30,0
    .goto 1454/1,-3933.49,1707.86,50 >> Entra en Los Baldíos a través de la salida occidental
    .zoneskip The Barrens
step << Rogue/Druid
    #completewith MissionProbable
    .goto 1413/1,-3216.92,1107.13,120 >> Viaja hacia el Fangal
step << Druid
    .goto 1413/1,-3119.64,1050.38
    >>Despoja el |cffe07cf5Arcón extraño|r en el agua para obtener la |T133443:0|t[Medio colgante de Agilidad acuática]
    .collect 15883,1,31,1 --Half Pendant of Aquatic Agility (1)
step << Rogue
    #completewith next
    .goto 1413/1,-3021.35,1214.56
	+Selecciona al |cff5cf05cCapataz Fizzule|r, luego usa tu |T134536:0|t[Pistola de bengalas] DOS VECES y escribe /Salute
    >>|cffff9a3c¡Ten cuidado! ¡NO te acerques a él hasta que se vuelva amistoso o te atacará!|r
    .use 8051
    .target Taskmaster Fizzule
step << Rogue
    .goto 1413/1,-2995.0,1236.85
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el|r |cff5cf05cCapataz Fizzule|r
    .turnin 2458 >>Entrega la misión Agente encubierto
    .accept 2478 >>Acepta la misión Misión: Posible, pero no probable
    .target Taskmaster Fizzule
step << Rogue/Druid
    #optional
    #label MissionProbable
step << Rogue
    .goto 1413/1,-2930.15,1209.15
    >>Usa |T133644:0|t[Robar] en el |cffff5a4aSupervisor Silixiz|r para obtener su |cff4fc3f7Llave de la torre|r
    .complete 2478,5 --Silixiz's Tower Key (1)
    .mob Foreman Silixiz
step << Rogue
    #completewith roguetowerq
    +|cffff9a3cCada enemigo aquí recibirá más daño de ciertas habilidades|r
    >>Usa |T132282:0|t[Emboscada] sobre los |cffff5a4aZánganos mutados de Ventura y Cía.|r
    >>Usa |T132302:0|t[Ruptura] sobre las |cffff5a4aPatrullas de Ventura y Cía.|r
    >>Usa |T132292:0|t[Eviscerar] sobre los |cffff5a4aOteadores de Ventura y Cía.|r una vez (1 punto de combo)
step << Rogue
    #label roguetowerq
    .goto 1413/1,-2922.04,1224.69
    >>Corre hacia la Torre del Pícaro y mata a los |cffff5a4aZánganos|r, |cffff5a4aPatrullas|r y |cffff5a4aOteadores|r
    .complete 2478,1 --Mutated Venture Co. Drone (2)
    .mob +Mutated Venture Co. Drone
    .complete 2478,3 --Venture Co. Patroller (2)
    .mob +Venture Co. Patroller
    .complete 2478,2 --Venture Co. Lookout (2)
    .mob +Venture Co. Lookout
step << Rogue
    .goto 1413/1,-2927.11,1236.18
    >>En la cima de la torre encontrarás a |cffff5a4aGallywix|r. Despójalo para obtener su |cff4fc3f7Cabeza|r
    >>|cffff9a3cUsa|r |T132282:0|t[Emboscada] |cffff9a3cpara reducir su vida a la mitad. Usa|r |T132155:0|t[Gubia] |cffff9a3cpara restaurar energía y usa|r |T136205:0|t[Evasión]
	>>|cffff9a3cRecuerda usar una Poción y|r |T132819:0|t[Té de cardo] |cffff9a3csi es necesario|r
    .complete 2478,4 --Gallywix's Head (1)
    .mob Grand Foreman Puzik Gallywix
    --VV Video?
step << Rogue
    .goto 1413/1,-2927.11,1236.18
    >>Usa tu Forzar cerraduras para abrir el |cffe07cf5Arcón de Gallywix|r y despoja la |cff4fc3f7Mezcla|r
    .complete 2478,6 --Cache of Zanzil's Altered Mixture (1)
step << skip --Rogue/Druid
    #hardcore
    #completewith next
    .goto 1413/1,-3591.86,1328.06,120 >>Viaja hacia la Mina Pedrusco
step << skip --Rogue/Druid
    #hardcore
    .goto 1413/1,-3505.72,1358.46
    .goto 1454/1,-4242.34,1637.33,30 >>|cffff9a3cSalta a la viga de madera. Haz un Logout Skip desconectando y volviendo a entrar. Regresa a Orgrimmar si no lo logras|r
    .link https://www.youtube.com/watch?v=U7YfoaO-X8E >> |cffff9a3cHAZ CLIC AQUÍ para ver un ejemplo|r
    .zoneskip Orgrimmar
step << Rogue/Druid
    #softcore
    #completewith next
    .deathskip >> Muere y reaparece en el |cff5cf05cÁngel de la Resurrección|r
step << Rogue/Druid
    #softcore
    .goto 1413/1,-2595.75,-437.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDevrak|r
    .fly Orgrimmar >> Vuela a Orgrimmar
    .zoneskip Orgrimmar
    .target Devrak
step << Rogue/Druid
    #hardcore
    #completewith flytoORG
    .goto 1414/1,-3839.37,1644.65
    .zone Orgrimmar >>Entra en Orgrimmar por la entrada occidental
step << Rogue
    .goto 1454/1,-4284.42,1771.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShenthul|r
    .turnin 2478 >>Entrega la misión Misión: Posible, pero no probable
    .accept 2479 >>Acepta la misión La ayuda de Hinott
    .target Shenthul
step << Rogue
    .goto 1454/1,-4271.1,1810.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cRekkul|r|cffe07cf5. Compra|r |T133849:0|t[Polvo de Decadencia] |cffe07cf5y|r |T132793:0|t[Viales vacíos] |cffe07cf5a este vendedor|r
    .collect 2928,20,2479,1 --Collect Dust of Decay (20)
    .collect 3371,20,2479,1 --Collect Empty Vial (20)
    .target Rekkul
step << Shaman
    .goto 1454/1,-4225.09,1933.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKardris|r
    .train 8498 >> Aprende tus hechizos de clase
    .target Kardris Dreamseeker
    .xp <22,1
    .xp >24,1
step << Shaman
    #optional
    .goto 1454/1,-4225.09,1933.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKardris|r
    .train 905 >> Aprende tus hechizos de clase
    .target Kardris Dreamseeker
    .xp <24,1
step << Troll Warrior/Undead Warrior/Tauren Warrior/Undead Paladin
    .goto 1454/1,-4824.00,2090.540
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHanashi|r
    .train 197 >>Aprende el uso de Hachas de dos manos
    .train 2567 >> Aprende el uso de Arrojadizas << !Paladin
    .target Hanashi
step << Orc Warrior
    .goto 1454/1,-4824.00,2090.540
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHanashi|r
    .train 2567 >> Aprende el uso de Arrojadizas
    .target Hanashi
step << Warrior
    .goto 1454/1,-4801.42,1980.53
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGrezz|r
    .train 6192 >> Aprende tus hechizos de clase
    .target Grezz Ragefist
    .xp <22,1
    .xp >24,1
step << Warrior
    #optional
    .goto 1454/1,-4801.42,1980.53
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGrezz|r
    .train 5308 >> Aprende tus hechizos de clase
    .target Grezz Ragefist
    .xp <24,1
step << Hunter
    .goto 1454/1,-4607.02,2100.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOrmak|r
    .train 14323 >> Aprende tus hechizos de clase
    .target Ormak Grimshot
    .xp <22,1
    .xp >24,1
step << Hunter
    #optional
    .goto 1454/1,-4607.02,2100.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOrmak|r
    .train 14262 >> Aprende tus hechizos de clase
    .target Ormak Grimshot
    .xp <24,1
step << Hunter
    .goto 1454/1,-4611.09,2135.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cXao'tsu|r
    .train 24558 >> Entrena los hechizos de tu mascota
    .target Xao'tsu
    .xp <24,1
step << skip
    .goto 1454/1,-4746.58,2036.37
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cNogg|r
    .accept 2841 >>Acepta la misión Las guerras de la plataforma
    .target Nogg
step
    #completewith next
    .goto 1454/1,-4739.57,2036.84
    .gossipoption 95758 >>Habla con |cff5cf05cSovik|r
    .isNotOnQuest 2842
    .target Sovik
step
    .goto 1454/1,-4739.57,2036.84
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSovik|r
    >>|cffff9a3c¡Presta atención! Necesitas pasar por su diálogo primero, después de lo cual aceptarás la misión automáticamente|r
    .accept 2842 >>Acepta la misión Scooty, ingeniero jefe
    .target Sovik
step << skip --Rogue
    .goto 1454/1,-4355.53,1520.68
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cTrak'gen|r|cffe07cf5. Compra|r |T135423:0|t[Hacha arrojadiza mortal] |cffe07cf5a este vendedor|r
    .collect 3137,1,6544,1 --Deadly Throwing Axe (200)
    .target Trak'gen
step << Rogue
    >>|cffff9a3cSi tienes algún|r |T134437:0|t[Contraveneno]|cffff9a3c, úsalo para curarte del|r |T136230:0|t[Toque de Zanzil]
    .itemcount 6452,1
    .use 6452
    .aura -9991
step << Rogue
    #optional
    .destroy 8051 >> |cffff9a3cBorra la|r |T134536:0|t[Pistola de bengalas] |cffff9a3cde tu inventario, ya que ya no la necesitas|r
    .destroy 8066 >> |cffff9a3cBorra|r |T134374:0|t[Silbato de Fizzule] |cffff9a3cde tu inventario, ya que ya no lo necesitas|r
step
    #optional
    #label flytoORG
step
    #optional
    .abandon 6421 >>Abandona la misión Barranco del Alud
step
    #optional
    .abandon 4021 >>Abandona la misión ¡Contraataca!
step
    #optional
    .abandon 6481 >>Abandona la misión El despertar del terráneo
step
    #optional
    .abandon 6284 >>Abandona la misión Aracnofobia
step
    #optional
    .abandon 6641 >>Abandona la misión Vorsha la Azotadora
step
    #optional
    .abandon 6563 >>Abandona la misión La esencia de Aku'Mai
step
    #optional
    .abandon 97003 >>Abandona la misión Chol'aruk, el Insaciable
step
    .zone Durotar >> Sal de Orgrimmar
    .zoneskip Tirisfal Glades
    .zoneskip Undercity
    .zoneskip Silverpine Forest
    .zoneskip Hillsbrad Foothills
]=], "Horde"}
