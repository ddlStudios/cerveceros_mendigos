-- GENERADO por _suite/herramientas/leveo_rutas.py: no editar a mano.
-- Ruta de subida de RestedXP (RXPGuides), traducida y adaptada a WoW Forever por Brudda FastXP.
-- Licencia de este archivo: CC BY-NC-SA 4.0 (ver LICENCIA_RUTAS.txt).
local _, ns = ...
local R = ns.LeveoRutas or {}
ns.LeveoRutas = R
R[#R + 1] = {[=[
#forever
#disabledungeons
<< Horde
#version 11
#group Guía Forever (H)
#subgroup Guía Speedrun 1-22
#defaultfor Undead
#name 1-6 Claros de Tirisfal
#next 6-12 Claros de Tirisfal

step << !Undead
    #completewith next
    +|cffff9a3cHas seleccionado una guía destinada para No-muertos. Se recomienda elegir la misma zona inicial en la que empiezas|r
step
    #completewith Zombies
	.destroy 6948 >> Destruye la |T134414:0|t[Piedra de hogar] en tu inventario, ya que ya no es necesaria
step
    #completewith next
    .goto 1420/0,1675.90,1645.00,8,0
    .goto 1420/0,1665.51,1645.00,8,0
    .goto 1420/0,1667.77,1679.04,10 >> Sube de la cripta hacia |cff5cf05cMordo|r
step
    .goto 1420/0,1667.77,1679.04
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMordo|r
    .accept 363 >> Acepta la misión Desvelo brutal
    .target Undertaker Mordo
step << Warrior/Warlock/Priest/Mage
    #completewith Vendor
    .goto 1420/0,1646.08,1750.44,0 << Warrior/Warlock
    .goto 1420/0,1681.32,1719.710,40,0
    .goto 1420/0,1646.08,1750.44,40,0
    .goto 1420/0,1714.76,1760.68,40,0 << Priest/Mage
    .goto 1420/0,1718.38,1799.24,40,0 << Priest/Mage
    .goto 1420/0,1669.12,1869.73,40,0 << Priest/Mage
    +|cffff9a3cMata |cffff5a4aCarroñeros jóvenes|r y |cffff5a4aMurciumbríos|r. Despójalos hasta que tengas 60 monedas de cobre en objetos para vender (incluyendo tu armadura)|r << Mage
    +|cffff9a3cMata |cffff5a4aCarroñeros jóvenes|r y |cffff5a4aMurciumbríos|r. Despójalos hasta que tengas 50 monedas de cobre en objetos para vender (incluyendo tu armadura)|r << Priest
    +|cffff9a3cMata |cffff5a4aCarroñeros jóvenes|r y |cffff5a4aMurciumbríos|r. Despójalos hasta que tengas 10 monedas de cobre en objetos para vender (incluyendo tu armadura)|r << Warrior/Warlock
    .mob Young Scavenger
    .mob Duskbat
    .money >0.01
step << Warrior/Priest/Mage
    #completewith Training1
    .goto 1420/0,1577.39,1860.09,8 >> Entra en el edificio
step << Priest/Mage
    #label Vendor
    .goto 1420/0,1574.23,1866.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJoshua|r
    >>|cffe07cf5Compra|r |T132794:0|t[Agua de manantial refrescante] |cffe07cf5a este vendedor|r
    .vendor >> Vende la Basura
	.collect 159,10,383,1 --Collect Refreshing Spring Water (10)
    .target Joshua Kien
step << Warlock/Mage
    #sticky
    #label Piercing
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVenya|r y |cff5cf05cSarvis|r << Warlock
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSarvis|r << Mage
    .accept 1470 >>Acepta la misión Descubrir el misterio << Warlock
    .goto 1420/0,1633.42,1836.9 << Warlock
    .target +Venya Marthand << Warlock
    .turnin 363 >> Entrega la misión Desvelo brutal
    .accept 364 >> Acepta la misión Los autómatas
    .target +Shadow Priest Sarvis
    .goto 1420/0,1639.75,1843.220
step << Warlock/Mage
    .goto 1420/0,1616.71,1842.92,10,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cElreth|r
    .accept 376 >> Acepta la misión Los Malditos
    .goto 1420/0,1638.85,1847.74
    .target Novice Elreth
    .xp <2,1
step << Mage
    #requires Percing
    .goto 1420/0,1635.23,1847.44
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cIsabella|r
    .train 1459 >> Aprende |T135932:0|t[Intelecto Arcano]
    .target Isabella
step << Warlock
    #label Vendor
    .goto 1420/0,1641.11,1836.90
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKayla|r
    .vendor >>Vende la Basura
    .target Kayla Smithe
    .money >0.1
step << Warlock
    .goto 1420/0,1636.59,1839.01
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMaximillion|r
    .train 348 >>Aprende |T135817:0|t[Inmolar]
    .target Maximillion
step << !Warlock !Mage
    .goto 1420/0,1616.71,1842.92,10,0
    .goto 1420/0,1639.75,1843.220
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSarvis|r
    .turnin 363 >> Entrega la misión Desvelo brutal
    .accept 364 >> Acepta la misión Los autómatas
    .target Shadow Priest Sarvis
step << !Warlock !Mage
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cElreth|r
    .accept 376 >> Acepta la misión Los Malditos
    .goto 1420/0,1638.85,1847.74
    .target Novice Elreth
    .xp <2,1
step << Warrior
    #completewith next
    #label Vendor
    .goto 1420/0,1568.35,1859.49
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cArchibald|r
    .vendor >> Vende la Basura
    .target Archibald Kava
    .money >0.1
step << Warrior
    #label Training1
    .goto 1420/0,1556.61,1862.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDannal|r
    .train 6673 >>Aprende |T132333:0|t[Grito de batalla]
    .target Dannal Stern
step << Warlock
    #requires Piercing
    #loop
    .goto 1420/0,1595.47,1985.41,0
    .goto 1420/0,1595.47,1985.41,30,0
    .goto 1420/0,1627.55,2008.61,30,0
    .goto 1420/0,1584.17,2024.88,30,0
    .goto 1420/0,1575.58,2053.8,30,0
    .goto 1420/0,1529.49,2044.16,30,0
    .goto 1420/0,1512.32,2007.1,30,0
    .goto 1420/0,1499.67,1975.47,30,0
    .goto 1420/0,1487.47,1938.12,30,0
    .goto 1420/0,1541.69,1939.32,30,0
    >>Mata |cffff5a4aEsqueletos armadóseos|r. Despójalos para obtener sus |cff4fc3f7Calaveras armadóseas|r
    .complete 1470,1 --Rattlecage Skull (3)
    .mob Rattlecage Skeleton
step << Warlock
    #completewith next
    +|cffff9a3cMata |cffff5a4aZombis descerebrados|r y |cffff5a4aZombis espantosos|r. Despójalos hasta que tengas 25 monedas de cobre en objetos para vender (incluyendo tu armadura)|r
    .mob Mindless Zombie
    .mob Wretched Zombie
    .money >0.0025
step << Warlock
    .goto 1420/0,1576.94,1861.6,8,0
    .goto 1420/0,1574.23,1866.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJoshua|r
    >>|cffe07cf5Compra|r |T132794:0|t[Agua de manantial refrescante] |cffe07cf5a este vendedor|r
	.collect 159,5,383,1 --Collect Refreshing Spring Water (5)
    .target Joshua Kien
    .isOnQuest 1470
step << Warlock
    .goto 1420/0,1616.71,1842.92,10,0
    .goto 1420/0,1633.42,1836.90
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVenya|r
    .turnin 1470 >>Entrega la misión Descubrir el misterio
    .target Venya Marthand
step << Warlock
    #completewith next
    .cast 688 >>|cffff9a3cLanza|r |T136218:0|t[Invocar diablillo]
step << Priest
    #completewith next
    +|cffff9a3cGuarda|r |T132889:0|t[Paño de lino]|cffff9a3c. Esto te permitirá crear una varita más tarde|r
step
    #label Zombies
    #requires Piercing << Warlock/Mage
    #loop
	.goto 1420/0,1599.99,1910.1,0
	.goto 1420/0,1599.99,1910.1,40,0
	.goto 1420/0,1646.53,1913.11,40,0
	.goto 1420/0,1637.04,1963.72,40,0
	.goto 1420/0,1644.72,1979.99,40,0
	.goto 1420/0,1626.19,1987.52,40,0
	.goto 1420/0,1596.37,1974.87,40,0
	.goto 1420/0,1548.92,1939.02,40,0
	.goto 1420/0,1546.66,1923.36,40,0
	.goto 1420/0,1523.62,1937.82,40,0
	.goto 1420/0,1508.26,1943.84,40,0
	.goto 1420/0,1519.1,1914.92,40,0
	.goto 1420/0,1517.29,1892.33,40,0
	.goto 1420/0,1529.04,1880.58,40,0
    >>Mata |cffff5a4aZombis descerebrados|r y |cffff5a4aZombis espantosos|r
    .complete 364,1 --Kill Mindless Zombie (x8)
    .mob +Mindless Zombie
    .complete 364,2 --Kill Wretched Zombie (x8)
    .mob +Wretched Zombie
step << Mage/Warlock/Priest
    #completewith Vendor2
    +|cffff9a3cMata |cffff5a4aZombis descerebrados|r y |cffff5a4aZombis espantosos|r. Despójalos hasta que tengas 33 monedas de cobre en objetos para vender (incluyendo tu armadura)|r
    .mob Mindless Zombie
    .mob Wretched Zombie
    .money >0.0033
step << Mage/Warlock/Priest
    .goto 1420/0,1576.94,1861.6,8,0
    .goto 1420/0,1574.23,1866.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJoshua|r
    >>|cffe07cf5Compra|r |T132794:0|t[Agua de manantial refrescante] |cffe07cf5a este vendedor|r
    .collect 159,10,383,1 --Collect Refreshing Spring Water (10)
    .vendor >> Vende la Basura
    .target Joshua Kien
    .money <0.0050
    .itemcount 159,<10
 step << Mage/Warlock/Priest
    #label Vendor2
    .goto 1420/0,1576.94,1861.6,8,0
    .goto 1420/0,1574.23,1866.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJoshua|r
    >>|cffe07cf5Compra|r |T132794:0|t[Agua de manantial refrescante] |cffe07cf5a este vendedor|r
    .collect 159,5,383,1 --Collect Refreshing Spring Water (5)
    .vendor >> Vende la Basura
    .target Joshua Kien
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSarvis|r y |cff5cf05cElreth|r << !Warlock !Mage !Priest
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSarvis|r, |cff5cf05cElreth|r y |cff5cf05cMaximillion|r << Warlock
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSarvis|r, |cff5cf05cElreth|r e |cff5cf05cIsabella|r << Mage
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSarvis|r, |cff5cf05cElreth|r y |cff5cf05cDuesten|r << Priest
    .turnin 364 >> Entrega la misión Los autómatas
    .accept 3095 >> Acepta la misión Un pergamino simple << Warrior
    .accept 3096 >> Acepta la misión Un pergamino codificado << Rogue
    .accept 3097 >> Acepta la misión Un pergamino sacralizado << Priest
    .accept 3098 >> Acepta la misión Un pergamino glífico << Mage
    .accept 3099 >> Acepta la misión Un pergamino corrupto << Warlock
    .accept 98601 >>Acepta la misión Un camino difícil << Paladin
    .accept 3901 >> Acepta la misión Sacudir esqueletos
    .target +Shadow Priest Sarvis
    .goto 1420/0,1616.71,1842.92,10,0
    .goto 1420/0,1639.75,1843.220
    .accept 376 >> Acepta la misión Los Malditos
    .target +Novice Elreth
    .goto 1420/0,1638.85,1847.74
    .turnin 3099 >> Entrega la misión Un pergamino corrupto << Warlock
    .goto 1420/0,1636.59,1839.01 << Warlock
    .target +Maximillion << Warlock
    .turnin 3098 >> Entrega la misión Un pergamino glífico << Mage
    .goto 1420/0,1635.23,1847.44 << Mage
    .target +Isabella << Mage
    .turnin 3097 >> Entrega la misión Un pergamino sacralizado << Priest
    .target +Dark Cleric Duesten << Priest
    .goto 1420/0,1627.55,1848.65 << Priest
step << Paladin
    .goto 1420/0,1628.400,1837.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAramis Manomartillo|r
    .turnin 98601 >>Entrega la misión Un camino difícil
    .accept 90902 >>Acepta la misión Redescubrimiento de la Luz
    .target Aramis Hammerhand
    --90902 only 85xp, not worth doing
step << Paladin
    #completewith XPcheck
    >>|cffff9a3cLanza|r |T135920:0|t[Luz Sagrada] |cffff9a3csobre los|r |cff5cf05cGuardia de la muerte herida|r
    .complete 90902,1 --|5/5 Injured Deathguard healed
    .target Injured Deathguard
step << Mage/Warlock/Priest
    .goto 1420/0,1576.94,1861.6,8,0
    .goto 1420/0,1574.23,1866.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJoshua|r
    >>|cffe07cf5Compra|r |T132794:0|t[Agua de manantial refrescante] |cffe07cf5a este vendedor|r
    .collect 159,10,383,1 --Collect Refreshing Spring Water (10)
    .target Joshua Kien
    .isOnQuest 364
step
    #completewith next
    >>Mata |cffff5a4aEsqueletos armadóseos|r
    .complete 3901,1 --Kill Rattlecage Skeleton (12)
    .mob Rattlecage Skeleton
step
    #loop
    .goto 1420/0,1482.50,2126.70,0
    .goto 1420/0,1713.41,1828.76,40,0
    .goto 1420/0,1701.21,1858.290,40,0
    .goto 1420/0,1695.78,1908.29,40,0
    .goto 1420/0,1692.62,1927.88,40,0
    .goto 1420/0,1673.64,1984.51,40,0
    .goto 1420/0,1633.88,2040.24,40,0
    .goto 1420/0,1604.96,2073.08,40,0
    .goto 1420/0,1584.17,2098.08,40,0
    .goto 1420/0,1548.92,2079.71,40,0
    .goto 1420/0,1482.50,2126.70,40,0
    >>Mata |cffff5a4aCarroñeros jóvenes|r y |cffff5a4aCarroñeros pulgosos|r. Despójalos para obtener sus |cff4fc3f7Garras de carroñero|r
    >>Mata |cffff5a4aMurciumbríos|r y |cffff5a4aMurciumbríos sarnosos|r. Despójalos para obtener sus |cff4fc3f7Alas de Murciumbrío|r
    >>|cffff9a3cIntenta evitar |cffff5a4aMurciumbríos sarnosos|r si puedes debido a que son mucho más difíciles de matar que los |cffff5a4aMurciumbríos|r|r
    .complete 376,1 --Collect Scavenger Paw (x6)
    .mob +Young Scavenger
    .mob +Ragged Scavenger
    .complete 376,2 --Collect Duskbat Wing (x6)
    .mob +Duskbat
    .mob +Mangy Duskbat
step
    #loop
    .goto 1420/0,1595.47,1985.41,0
    .goto 1420/0,1595.47,1985.41,30,0
    .goto 1420/0,1627.55,2008.61,30,0
    .goto 1420/0,1584.17,2024.88,30,0
    .goto 1420/0,1575.58,2053.8,30,0
    .goto 1420/0,1529.49,2044.16,30,0
    .goto 1420/0,1512.32,2007.1,30,0
    .goto 1420/0,1499.67,1975.47,30,0
    .goto 1420/0,1487.47,1938.12,30,0
    .goto 1420/0,1541.69,1939.32,30,0
    >>Mata |cffff5a4aEsqueletos armadóseos|r
    .complete 3901,1 --Kill Rattlecage Skeleton (12)
    .mob Rattlecage Skeleton
step
    #label XPcheck
    #optional
    #loop
    .goto 1420/0,1595.47,1985.41,30,0
    .goto 1420/0,1627.55,2008.61,30,0
    .goto 1420/0,1584.17,2024.88,30,0
    .goto 1420/0,1575.58,2053.8,30,0
    .goto 1420/0,1529.49,2044.16,30,0
    .goto 1420/0,1512.32,2007.1,30,0
    .goto 1420/0,1499.67,1975.47,30,0
    .goto 1420/0,1487.47,1938.12,30,0
    .goto 1420/0,1541.69,1939.32,30,0
    .xp 3+895 >>Mata enemigos hasta alcanzar 895+/1400xp << Paladin
    .xp 3+940 >>Mata enemigos hasta alcanzar 940+/1400xp << Warrior/Rogue
    .xp 3+980 >>Mata enemigos hasta alcanzar 980+/1400xp << !Warrior !Rogue !Paladin
    .mob Mindless Zombie
    .mob Wretched Zombie
step << Paladin
    .goto 1420/0,1593.500,1876.400
    >>|cffff9a3cLanza|r |T135920:0|t[Luz Sagrada] |cffff9a3csobre los|r |cff5cf05cGuardia de la muerte herida|r
    .complete 90902,1 --|5/5 Injured Deathguard healed
    .target Injured Deathguard
step << Mage/Warlock/Priest/Paladin
    .goto 1420/0,1576.04,1861.60,8,0
    .goto 1420/0,1574.23,1866.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJoshua|r
    >>|cffe07cf5Compra|r |T132794:0|t[Agua de manantial refrescante] |cffe07cf5a este vendedor|r << !Paladin
    >>|cffff9a3cNO dejes que tu dinero baje de 1 moneda de plata|r << Mage/Warlock/Priest
    .vendor >> Vende la Basura
    .target Joshua Kien
    .money >0.1
    .isOnQuest 3901
    .itemcount 159,<20
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSarvis|r y |cff5cf05cElreth|r
    .turnin 3901 >> Entrega la misión Sacudir esqueletos
    .target +Shadow Priest Sarvis
    .goto 1420/0,1616.71,1842.92,10,0
    .goto 1420/0,1639.75,1843.220
    .turnin 376 >> Entrega la misión Los Malditos
    .accept 6395 >> Acepta la misión El último deseo de Marla
    .target +Novice Elreth
    .goto 1420/0,1638.85,1847.74
step << Paladin
    .goto 1420/0,1568.35,1859.49
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cArchibald|r
    .vendor >> Vende la Basura
    .target Archibald Kava
    .money >0.1
    .isOnQuest 90902
step
    .goto 1420/0,1628.300,1837.300
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAramis Manomartillo|r
    .turnin 90902 >>Entrega la misión Redescubrimiento de la Luz << Paladin
    .accept 91208 >>Acepta la misión Aceptar la realidad << Paladin
    .accept 91209 >>Acepta la misión Continúa con tu entrenamiento << Paladin
    .accept 98389 >>Acepta la misión Una luz en la oscuridad
    .target Aramis Hammerhand
step << Paladin
    .goto 1420/0,1628.300,1837.300
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAramis Manomartillo|r
    .train 20271 >>Aprende |T135959:0|t[Sentencia]
    .train 19740 >>Aprende |T135906:0|t[Bendición de poderío]
    .target Aramis Hammerhand
    .money <0.02
step << Paladin
    #optional
    .goto 1420/0,1628.300,1837.300
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAramis Manomartillo|r
    .train 20271 >>Aprende |T135959:0|t[Sentencia]
    .target Aramis Hammerhand
    .money <0.01
step << Priest
    .goto 1420/0,1627.55,1848.65
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDuesten|r
    .train 589 >> Aprende tus hechizos de clase
    .target Dark Cleric Duesten
    .money <0.021
step << Priest
    .goto 1420/0,1627.55,1848.65
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDuesten|r
    .train 2052 >> Aprende |T135929:0|t[Sanación inferior Rango 2]
    .train 589 >> Aprende |T136207:0|t[Palabra de las Sombras: dolor]
    .target Dark Cleric Duesten
    .money <0.021
step << Priest
    .goto 1420/0,1627.55,1848.65
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDuesten|r
    .train 1243 >> Aprende |T135987:0|t[Palabra de poder: entereza]
    .train 589 >> Aprende |T136207:0|t[Palabra de las Sombras: dolor]
    .target Dark Cleric Duesten
    .money <0.011
step << Priest
    #optional
    .goto 1420/0,1627.55,1848.65
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDuesten|r
    .train 589 >> Aprende |T136207:0|t[Palabra de las Sombras: dolor]
    .target Dark Cleric Duesten
    .money <0.01
step << Warlock
    .goto 1420/0,1636.59,1839.01
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMaximillion|r
    .train 172 >> Aprende |T136118:0|t[Corrupción]
    .target Maximillion
step << Mage
    .goto 1420/0,1635.23,1847.44
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cIsabella|r
    .train 116 >> Aprende |T135846:0|t[Descarga de Escarcha]
    .target Isabella
step
    .goto 1420/0,1616.71,1842.92,10,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGuardia de la Muerte Saltain|r y el |cff5cf05cEjecutor Arren|r
    .accept 3902 >> Acepta la misión Hurgar en Camposanto
    .goto 1420/0,1604.96,1860.70
    .target +Deathguard Saltain
    .accept 380 >> Acepta la misión Hoya Nocturácnidas
    .goto 1420/0,1580.56,1848.95
    .target +Executor Arren
step << Rogue/Warrior/Paladin
    .goto 1420/0,1568.35,1859.49
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cArchibald|r
    .vendor >> Vende la Basura
    .target Archibald Kava
    .money >0.1
    .isOnQuest 3095 << Warrior
    .isOnQuest 3096 << Rogue
step << Warrior
    .goto 1420/0,1556.61,1862.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDannal|r
    .turnin 3095 >> Entrega la misión Un pergamino simple
    .train 100 >> Aprende |T132337:0|t[Cargar]
    .train 772 >> Aprende |T132155:0|t[Desgarrar]
    .target Dannal Stern
    .money <0.02
 step << Warrior
    #optional
    #label Training2
    .goto 1420/0,1556.61,1862.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDannal|r
    .turnin 3095 >> Entrega la misión Un pergamino simple
    .train 772 >> Aprende |T132155:0|t[Desgarrar]
    .target Dannal Stern
    .money <0.01
step << Rogue
    #optional
    #label Training2
    .goto 1420/0,1563.38,1859.79
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDavid|r
    .turnin 3096 >> Entrega la misión Un pergamino codificado
    .target David Trias
step << Rogue/Warrior/Paladin
    .goto 1420/0,1577.100,1854.600
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWalter Cantero|r arriba
    >>|cffe07cf5Compra un|r |T134708:0|t[Pico de minero] |cffe07cf5a|r |cffe07cf5este vendedor|r
    .train 2575 >> Aprende |T136248:0|t[Minería]
    .collect 2901,1,792,1 --Mining Pick (1)
    >>|cffff9a3cEsto te permitirá encontrar|r |T135232:0|t|cff4fc3f7[Piedras férreas]|r |cffff9a3cde nodos para fabricar|r |T135248:0|t[Piedras de afilar] |cffff9a3c(+2 Daño con arma durante 30 minutos)|r
    .target Walter Mason
step
    #loop
	.goto 1420/0,1570.61,1898.35,0
	.goto 1420/0,1570.61,1898.35,12,0
	.goto 1420/0,1550.73,1897.75,12,0
	.goto 1420/0,1547.12,1891.42,12,0
	.goto 1420/0,1541.69,1867.93,12,0
	.goto 1420/0,1506.45,1892.33,12,0
	.goto 1420/0,1536.27,1937.21,12,0
	.goto 1420/0,1551.64,1936.31,12,0
	.goto 1420/0,1593.66,1985.11,12,0
	.goto 1420/0,1598.63,1970.95,12,0
	.goto 1420/0,1600.89,1953.78,12,0
	.goto 1420/0,1617.16,1956.49,12,0
    >>Abre las |cffe07cf5Cajas de equipamiento|r en el suelo. Despójalas para obtener las |cff4fc3f7Mercancías extraviadas|r
    .complete 3902,1 --Collect Scavenged Goods (x6)
step << Paladin
    .goto 1420/0,1782.400,1914.700
    >>Habla con la |cff5cf05cPaladín aterrorizada|r, mátala cuando se vuelva hostil
    .complete 91208,1 --|1/1 Offer aid to the Frightened Paladin
    .skipgossip
    .mob Frightened Paladin
step
    #label NightWebStart
    #loop
	.goto 1420/0,1680.42,2110.43,0
	.goto 1420/0,1680.42,2110.43,40,0
	.goto 1420/0,1685.84,2149.6,40,0
	.goto 1420/0,1711.6,2157.43,40,0
	.goto 1420/0,1750.01,2135.14,40,0
	.goto 1420/0,1782.54,2117.36,40,0
	.goto 1420/0,1754.98,2080.91,40,0
	.goto 1420/0,1756.79,2047.77,40,0
	.goto 1420/0,1731.93,2044.16,40,0
	.goto 1420/0,1709.79,2048.07,40,0
	.goto 1420/0,1692.62,2074.28,40,0
    >>Mata |cffff5a4aNocturácnidas jóvenes|r
    .complete 380,1,6 --Kill Young Night Web Spider (10)
    .mob Young Night Web Spider
step
    #loop
	.goto 1420/0,1756.79,2082.12,0
	.goto 1420/0,1756.79,2082.12,25,0
	.goto 1420/0,1749.1,2058.02,25,0
	.goto 1420/0,1774.41,2012.83,25,0
	.goto 1420/0,1805.59,2054.7,25,0
	.goto 1420/0,1799.71,2091.15,25,0
	.goto 1420/0,1815.98,2137.85,25,0
	.goto 1420/0,1790.23,2150.5,25,0
    >>Mata |cffff5a4aNocturácnidas jóvenes|r cerca de la entrada de la cueva
    .complete 380,1 --Kill Young Night Web Spider (10)
    .mob Young Night Web Spider
step
    #completewith next
    .goto 1420/0,1822.31,2048.07,15,0
    .goto 1420/0,1844.45,2042.050,30 >>Entra en la cueva
step
    #completewith next
    >>Ataca al |cffff5a4aRenegado enredado|r
    .complete 98389,1 --|6/6 Webbed Forsaken freed
    .mob Webbed Forsaken
step
    #loop
    .goto 1420/0,1918.11,2043.86,0
    .goto 1420/0,1844.45,2042.050,30,0
    .goto 1420/0,1876.08,2043.56,20,0
    .goto 1420/0,1898.68,2020.06,20,0
    .goto 1420/0,1940.70,2006.80,20,0
    .goto 1420/0,1983.63,2032.71,20,0
    .goto 1420/0,1953.80,2079.40,20,0
    .goto 1420/0,1918.11,2043.86,20,0
    >>Mata |cffff5a4aArañas nocturácnidas|r dentro de la cueva
	.complete 380,2 --Kill Night Web Spider (x8)
    .mob Night Web Spider
step
    .goto 1420/0,1921.500,2046.500
    >>Ataca al |cffff5a4aRenegado enredado|r
    .complete 98389,1 --|6/6 Webbed Forsaken freed
    .mob Webbed Forsaken
step
    #softcore
    #completewith Scavenging
    .deathskip >> Muere y reaparece en el |cff5cf05cÁngel de la Resurrección|r
    .target Spirit Healer
step << Warlock
    #softcore
    #completewith ScarletC
    .cast 688 >>|cffff9a3cLanza|r |T136218:0|t[Invocar diablillo]
step << skip
    #hardcore
    #completewith next
    .goto 1420/0,1857.24,2011.71,-1--c:1420,26.027,60.607
    .goto 1420/0,1925.88,2049.28,-1--c:1420,24.508,59.360
    .goto 1420/0,1968.17,2052.92,-1--c:1420,23.572,59.239
    .goto 1420/0,1628.91,1882.99,30 >>|cffff9a3cRealiza un Logout Skip dentro de la cueva saltando encima de una trituradora, pozo o la tabla de madera clavada en la pared, luego desconecta y vuelve a entrar|r
    >>|cffff9a3cDe lo contrario, corre de vuelta a Camposanto|r
step
    #label Scavenging
    .goto 1420/0,1604.96,1860.70
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSaltain|r
    .turnin 3902 >> Entrega la misión Hurgar en Camposanto
    .target Deathguard Saltain
step
    #label NightWebH
    .goto 1420/0,1580.56,1848.95,0,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cArren|r
    .turnin 380 >> Entrega la misión Hoya Nocturácnidas
    .accept 381 >> Acepta la misión La Cruzada Escarlata
    .target Executor Arren
step
    .goto 1420/0,1628.400,1837.000
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAramis Manomartillo|r
    .turnin 91208 >>Entrega la misión Aceptar la realidad << Paladin
    .turnin 98389 >>Entrega la misión Una luz en la oscuridad
    .target Aramis Hammerhand
step << Rogue/Warrior/Paladin
    .goto 1420/0,1568.35,1859.49
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cArchibald|r
    .vendor >> Vende la Basura
    .target Archibald Kava
    .isOnQuest 6395
step << Warlock/Mage/Priest
    .goto 1420/0,1574.23,1866.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJoshua|r
    >>|cffe07cf5Compra|r |T132794:0|t[Agua de manantial refrescante] |cffe07cf5a este vendedor|r
	.collect 159,15,383,1 << Warlock/Mage/Priest --Collect Refreshing Spring Water (15)
    .vendor >> Vende la Basura
    .target Joshua Kien
    .isOnQuest 6395
    .itemcount 159,<15
step
    #requires NightWebH
    #loop
	.goto 1420/0,1400.71,1766.71,0
	.goto 1420/0,1400.71,1766.71,40,0
	.goto 1420/0,1385.80,1744.11,40,0
	.goto 1420/0,1368.17,1728.15,40,0
	.goto 1420/0,1342.42,1741.40,40,0
	.goto 1420/0,1313.95,1735.08,40,0
	.goto 1420/0,1320.28,1752.25,40,0
	.goto 1420/0,1314.85,1765.80,40,0
	.goto 1420/0,1294.07,1780.56,40,0
	.goto 1420/0,1283.67,1817.02,40,0
	.goto 1420/0,1289.55,1841.72,40,0
	.goto 1420/0,1286.84,1877.27,40,0
	.goto 1420/0,1333.38,1868.53,40,0
	.goto 1420/0,1364.56,1867.93,40,0
	.goto 1420/0,1383.54,1866.72,40,0
	.goto 1420/0,1368.17,1831.48,40,0
	.goto 1420/0,1341.06,1790.51,40,0
	.goto 1420/0,1364.56,1784.18,40,0
    >>Mata |cffff5a4aIniciados Escarlata|r y |cffff5a4aConversos Escarlata|r. Despójalos para obtener sus |cff4fc3f7Bandas Escarlata|r
    >>|cffff9a3cNo mates a |cffff5a4aMeven Korgal|r todavía|r
    >>|cffff9a3cIntenta evitar a los |cffff5a4aIniciados Escarlata|r si puedes ya que tienen|r |T135843:0|t[Armadura de Escarcha] |cffff9a3c(reduce tu velocidad de ataque)|r << Warrior/Rogue
    .complete 381,1 --Collect Scarlet Armband (12)
    .mob Scarlet Initiate
    .mob Scarlet Convert
step
    .goto 1420/0,1375.40,1979.69
    >>Mata a |cffff5a4aSamuel|r. Despoja a Samuel para obtener |cff4fc3f7Restos de Samuel|r
    .collect 16333,1,6395,1 --Collect Samuel's Remains
    .mob Samuel Fipps
step
    #softcore
    #completewith next
    .deathskip >> Muere y reaparece en el |cff5cf05cÁngel de la Resurrección|r
    .target Spirit Healer
step
    .goto 1420/0,1624.84,1876.96
	>>Haz clic en la |cffe07cf5Tumba de Marla|r del suelo
    .complete 6395,1 --Collect Samuel's Remains Buried (1)
 step << Warlock
    #softcore
	#completewith ScarletC
	.cast 688 >>|cffff9a3cLanza|r |T136218:0|t[Invocar diablillo]
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cElreth|r << !Priest
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cElreth|r y |cff5cf05cDuesten|r << Priest
    .turnin 6395 >> Entrega la misión El último deseo de Marla
    .target +Novice Elreth
    .goto 1420/0,1616.71,1842.92,10,0
    .goto 1420/0,1638.85,1847.74
    .accept 5651 >> Acepta la misión Al servicio de la Oscuridad << Priest
    .target +Dark Cleric Duesten << Priest
    .goto 1420/0,1627.55,1848.65 << Priest
step
    #sticky
    #label ScarletC
    .goto 1420/0,1580.56,1848.95,0,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cArren|r
    .turnin 381 >> Entrega la misión La Cruzada Escarlata
    .accept 382 >> Acepta la misión El mensajero rojo
    .target Executor Arren
step
    .goto 1420/0,1568.35,1859.49
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cArchibald|r
    .vendor >> Vende la Basura
    .target Archibald Kava
step
    #requires ScarletC
    .goto 1420/0,1383.99,1764.30
    >>Mata a |cffff5a4aMeven|r. Despójalo para obtener los |cff4fc3f7Documentos de la Cruzada Escarlata|r
    .complete 382,1 --Collect Scarlet Crusade Documents (1)
    .mob Meven Korgal
step
    .goto 1420/0,1580.56,1848.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cArren|r
    .turnin 382 >> Entrega la misión El mensajero rojo
    .accept 383 >> Acepta la misión Información decisiva
    .accept 96656 >> Acepta la misión El aventurero
    .target Executor Arren
step
    #loop
    .goto 1420/0,1493.34,2044.76,50,0
    .goto 1420/0,1436.41,2133.93,50,0
    .goto 1420/0,1369.08,2124.89,50,0
    .goto 1420/0,1327.05,2048.68,50,0
    .goto 1420/0,1338.35,1939.93,50,0
	.goto 1420/0,1400.71,1766.71,50,0
	.goto 1420/0,1385.80,1744.11,50,0
	.goto 1420/0,1368.17,1728.15,50,0
	.goto 1420/0,1342.42,1741.40,50,0
	.goto 1420/0,1313.95,1735.08,50,0
	.goto 1420/0,1320.28,1752.25,50,0
	.goto 1420/0,1314.85,1765.80,50,0
	.goto 1420/0,1294.07,1780.56,50,0
	.goto 1420/0,1283.67,1817.02,50,0
	.goto 1420/0,1289.55,1841.72,50,0
	.goto 1420/0,1286.84,1877.27,50,0
	.goto 1420/0,1333.38,1868.53,50,0
	.goto 1420/0,1364.56,1867.93,50,0
	.goto 1420/0,1383.54,1866.72,50,0
	.goto 1420/0,1368.17,1831.48,50,0
	.goto 1420/0,1341.06,1790.51,50,0
	.goto 1420/0,1364.56,1784.18,50,0
	.goto 1420/0,1400.71,1766.71,50,0
    .xp 5+1940 >>Mata enemigos hasta alcanzar 1940+/2800xp << !Paladin
    .xp 5+1850 >>Mata enemigos hasta alcanzar 1850+/2800xp << Paladin
step
    .goto 1420/0,1305.36,2127.30
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCalvin|r
    .accept 8 >> Acepta la misión Un trato de pícaro
    .target Calvin Montague

]=], "Horde"}
R[#R + 1] = {[=[
#forever
#disabledungeons
<< Horde
#name 6-12 Claros de Tirisfal
#displayname 6-13 Claros de Tirisfal << Paladin
#version 11
#group Guía Forever (H)
#subgroup Guía Speedrun 1-22
#defaultfor Undead
#next 12-14 Bosque de Argénteos; 12-17 Los Baldíos

step
    .goto 1420/0,1184.71,2205.63
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCocer|r
    .accept 365 >>Acepta la misión Campos de pena
    .target Deathguard Simmer
step
    #loop
    .goto 1420/0,496.96,2256.54,0
    .goto 1420/0,1191.04,2198.10,0
    .goto 1420/0,1191.04,2198.10,40,0
    .goto 1420/0,1133.65,2177.31,40,0
    .goto 1420/0,1063.61,2201.710,40,0
    .goto 1420/0,945.22,2127.00,40,0
    .goto 1420/0,824.57,2092.36,40,0
    .goto 1420/0,740.97,2112.24,40,0
    .goto 1420/0,660.09,2196.29,40,0
    .goto 1420/0,571.07,2251.42,40,0
    .goto 1420/0,496.96,2256.54,40,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGordo|r
    >>|cffff9a3cEs una abominación que patrulla por el camino a Rémol|r
    .accept 5481 >>Acepta la misión La tarea de Gordo
    .unitscan Gordo
step << Priest
    .goto 1420/0,656.92,2164.66
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBowen|r
    .train 3908 >> Aprende |T136249:0|t[Sastrería]. Guarda tu |T132889:0|t[Paño de lino]. Esto te permitirá crear una varita más tarde
    .target Bowen Brisboise
step
    #softcore
    #completewith next
    .deathskip >> Muere y resucita en el |cff5cf05cÁngel de la Resurrección|r o corre a Rémol
    .target Spirit Healer
step
    .goto 1420/0,391.400,2289.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGuardia de la Muerte Bartholomew|r
    >>|cffff9a3cPuede estar patrullando alrededor del cementerio|r
    .accept 86784 >>Acepta la misión Leños y huesos
    .target Deathguard Bartholomew
step
    #completewith next
    >>Despoja |cffe07cf5Ramas secas|r del suelo debajo de los árboles cerca de Rémol
    .complete 86784,1 --|6/6 Dry Branch
step
    .goto 1420/0,403.42,2287.57
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDillinger|r
    .accept 404 >>Acepta la misión Una tarea pútrida
    .target Deathguard Dillinger
step
    #loop
    .goto 1420/0,603.600,2268.300,40,0
    .goto 1420/0,539.700,2220.400,40,0
    .goto 1420/0,305.600,2180.100,40,0
    .goto 1420/0,375.600,2246.400,40,0
    .goto 1420/0,442.800,2259.400,40,0
    >>Despoja |cffe07cf5Ramas secas|r del suelo debajo de los árboles cerca de Rémol
    .complete 86784,1 --|6/6 Dry Branch
step
    .goto 1420/0,445.500,2165.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cEleanor Shackleton|r
    .turnin 86784 >>Entrega la misión Leños y huesos
    .turnin -96656 >>Entrega la misión El aventurero
    .accept 96607 >>Acepta la misión Bendita naturaleza
    .target Eleanor Shackleton
step
    .goto 1411/1,-4715.200,140.100
    >>|cffff9a3cEscribe /sit (sentarse) junto a la hoguera y espera un minuto hasta obtener la mejora de "Beneficios del campamento"|r
    .complete 96607,1 --|1/1 Use the /sit emote near the campfire
    .macro Sit,134400 >>/sit
    .timer 59, RP
    .complete 96607,2 --|Gain the Boosted Rest buff
step
    .goto 1420/0,445.400,2166.000
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cEleanor Shackleton|r
    .turnin 96607 >>Entrega la misión Bendita naturaleza
    .target Eleanor Shackleton
    .accept 96658 >>Acepta la misión Campamento básico: Cocina
    --.accept 97959 >>Acepta la misión Campamento básico: minería
step
    .goto 1420/0,346.94,2258.950
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJohaan|r
    .accept 367 >>Acepta la misión Una nueva Peste
    .target Apothecary Johaan
    .xp <6,1
step
    .goto 1420/0,296.600,2278.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cEjecutor Zygand|r
    .turnin -383 >>Entrega la misión Información decisiva
    .accept 427 >>Acepta la misión En guerra con la Cruzada Escarlata
    .accept 99141 >>Acepta la misión Paciencia
    .accept 99134 >>Acepta la misión Disciplina
    .target Executor Zygand
step
    #completewith Claws
    .use 286176 >>|cffff9a3cUsa la|r |T133490:0|t[Motivación del ejecutor] |cffff9a3cen cualquier |cff5cf05cGuardia de la muerte|r en Rémol y sus alrededores|r
    .complete 99134,1 --|5/5 Deathguards motivated
    --too many .mobs, will cause clutter
step << Rogue
    .goto 1420/0,270.12,2253.23
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cSra. Winters|r|cffe07cf5. Compra|r |T135421:0|t[Hacha arrojadiza pesada] |cffe07cf5a esta vendedora|r
    .collect 3131,200,786,1 --Weighted Throwing Axe (200)
    .target Mrs. Winters
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<2.9
    .money <0.07
step << Rogue
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOliver|r
    .vendor >> Vende la basura. Vende tu arma si te da suficiente dinero para un |T135641:0|t[Estilete] (3 platas 81 cobre). Volverás más adelante si aún no tienes suficiente
    .target Oliver Dwor
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.3
step << Rogue
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cOliver|r|cffe07cf5. Compra un|r |T135641:0|t[Estilete] |cffe07cf5a este vendedor|r
    .collect 2494,1,404,1 --Collect Stiletto (1)
    .money <0.0381
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.3
step << Rogue
    #optional
    #completewith Claws
    +|cffff9a3cEquipa el|r |T135421:0|t[Hacha arrojadiza pesada]
    .use 3131
    .itemcount 3131,1
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<2.9
step << Rogue
    #optional
    #completewith Claws
    +|cffff9a3cEquipa el |T135641:0|t[Estilete]|r
    .use 2494
    .itemcount 2494,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.3
step << Warrior
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOliver|r
    .vendor >> Vende la basura. Vende tu arma si te da suficiente dinero para un |T135321:0|t[Gladius] (5 platas 10 cobres). Volverás más tarde si no tienes suficiente dinero
    .target Oliver Dwor
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.7
step << Warrior
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cOliver|r|cffe07cf5. Compra un|r |T135321:0|t[Gladius] |cffe07cf5a este vendedor|r
    .collect 2488,1,404,1 --Collect Gladius (1)
    .money <0.0510
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.7
step << Warrior
    #optional
    #completewith Claws
    +|cffff9a3cEquipa el|r |T135321:0|t[Gladius]
    .use 2488
    .itemcount 2488,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.7
step << Paladin
    .goto 1420/0,311.600,2250.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShari Fontana|r
    .complete 91209,1 --|1/1 Report to Shari Stilwell in Brill
    .turnin -91209 >>Entrega la misión Continúa con tu entrenamiento
    .target Shari Stilwell
step << Paladin
    .goto 1420/0,311.600,2250.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShari Fontana|r
    .train 679 >>Aprende |T626003:0|t[Golpe Sagrado]
    .target Shari Stilwell
    .xp <6,1
step << Paladin
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOliver|r
    .vendor >> Vende la basura. Vende tu arma si te da suficiente dinero para una |T133053:0|t[Marra de madera] (6 platas 66 cobres). Volverás más tarde si aún no tienes suficiente
    .target Oliver Dwor
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<4.9
step << Paladin
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cOliver|r|cffe07cf5. Compra una|r |T133053:0|t[Marra de madera] |cffe07cf5a este vendedor|r
    .collect 2493,1,404,1 --Collect Wooden Mallet (1)
    .money <0.0666
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<4.9
step << Paladin
    #optional
    #completewith Claws
    +|cffff9a3cEquipa la|r |T133053:0|t[Marra de madera]
    .use 2493
    .itemcount 2493,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<4.9
step
    .goto 1420/0,244.81,2269.19
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cTabernera Renee|r
    .turnin -8 >>Entrega la misión Un trato de pícaro
    .home >> Establece tu Piedra de hogar en Rémol
    .target Innkeeper Renee
    .bindlocation 2119
step
    #optional
    .goto 1420/0,244.81,2269.19
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cTabernera Renee|r
    .turnin 8 >>Entrega la misión Un trato de pícaro
    .target Innkeeper Renee
    .isOnQuest 8
step
    .goto 1420/0,243.200,2288.100
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWilliam|r
    .train 2550 >>Aprende Cocina
    .turnin 96658 >>Entrega la misión Campamento básico: Cocina
    .target William Pickman
    .money <0.001
step
    .goto 1420/0,236.68,2249.01
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGretchen|r
    >>|cff5cf05cGretchen|r |cffff9a3cestá en el segundo piso de la posada|r
    .accept 375 >>Acepta la misión El frío de la muerte
    .target Gretchen Dedmar
    .xp <7,1
step << Priest
    .goto 1420/0,251.14,2265.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBeryl|r en el segundo piso
    .turnin -5651 >> Entrega la misión Al servicio de la Oscuridad
    .accept 5650 >> Acepta la misión Las prendas de la Oscuridad
	.train 591 >>Aprende |T135924:0|t[Punición]
    .train 17 >>Aprende |T135940:0|t[Palabra de poder: escudo]
    .train 2052 >>Aprende |T135929:0|t[Sanación inferior Rango 2]
    .target Dark Cleric Beryl
step << Mage
    .goto 1420/0,233.06,2256.84
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCain|r en el segundo piso
    .train 143 >> Aprende |T135812:0|t[Bola de Fuego]
    .train 2136 >>Aprende |T135807:0|t[Explosión de Fuego]
    .target Cain Firesong
step << Warrior
    .goto 1420/0,238.49,2255.03
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAustil|r
    .train 3127 >>Aprende |T132269:0|t[Parar]
    .target Austil de Mon
    .money <0.01
step << Rogue
    .goto 1420/0,243.01,2271.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMarion|r en el segundo piso
    .train 1757 >> Aprende |T136189:0|t[Golpe siniestro]
    .target Marion Call
    .money <0.01
step << Warlock
    .goto 1420/0,251.59,2252.62
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGina Lang|r en el segundo piso
    >>|cffe07cf5Compra el|r |T133738:0|t[Grimorio Pacto de sangre] |cffe07cf5a esta vendedora|r
    .collect 16321,1,404,1 --Grimoire of Blood Pact
    .vendor >>Vende la Basura
    .target Gina Lang
    .train 6307,1 --Blood Pact (Rank 1)
step << Warlock
    .goto 1420/0,250.24,2259.25
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRupert|r
    .train 695 >> Aprende |T136197:0|t[Descarga de las Sombras]
    .train 1454 >> Aprende |T136126:0|t[Transfusión de vida]
    .target Rupert Boch
    .money <0.02
step << Warlock
    .goto 1420/0,250.24,2259.25
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRupert|r
    .train 695 >> Aprende |T136197:0|t[Descarga de las Sombras]
    .target Rupert Boch
step << Priest/Warlock
    .goto 1420/0,242.55,2284.25
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVance|r
    .train 7411 >> Aprende |T136244:0|t[Encantamiento]
    >>|cffff9a3cEsto junto con|r |T136249:0|t[Sastrería] |cffff9a3cte permitirá crear una varita más tarde|r
    .target Vance Undergloom
step
    .goto 1420/0,244.81,2269.19
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cTabernera Renee|r
    .vendor >>|cffe07cf5Cómprale la mayor cantidad de|r |T132815:0|t[Leche fría como el hielo] |cffe07cf5que puedas|r << Mage/Priest/Paladin
    .vendor >>|cffe07cf5Cómprale la mayor cantidad de|r |T134532:0|t[Champiñones con motas rojas] |cffe07cf5que puedas|r << Warrior/Rogue
    .vendor >>|cffe07cf5Cómprale la mayor cantidad de|r |T132815:0|t[Leche fría como el hielo] |cffe07cf5y|r |T134532:0|t[Champiñones con motas rojas] |cffe07cf5que puedas|r << Warlock
    .money <0.0125
    .target Innkeeper Renee
step
    .goto 1420/0,84.900,2023.500
    >>Habla con el |cff5cf05cGuardia de la Muerte Kristof|r
    >>|cffff9a3cSelecciona "Necesito un reporte para el Ejecutor Zygand"|r
    .complete 99141,2 --|1/1 Kristof's Report
    .skipgossipid 142730
    .target Deathguard Kristof
step
    .goto 1420/0,77.200,2026.700
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShelene Rhobart|r
    .accept 97558 >>Acepta la misión Pellejos para los Renegados
    .target Shelene Rhobart
step
    .goto 1420/0,346.94,2258.950
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJohaan|r
    .accept 367 >>Acepta la misión Una nueva Peste
    .target Apothecary Johaan
step << Priest
    .goto 1420/0,359.14,2436.99
    >>Lanza |T135929:0|t[Sanación inferior] y |T135987:0|t[Palabra de poder: entereza] en el |cff5cf05cGuardia de la Muerte Kel|r
    >>|cffff9a3cNecesitas Sanación inferior Rango 2 para esta misión|r
    .complete 5650,1 --Heal and fortify Deathguard Kel (1)
    .target Deathguard Kel
step
    #completewith Gordo2
    >>Despoja la |cffe07cf5Hierba luminiscente|r del suelo
    .complete 5481,1 --Gloom Weed (3)
step
    #completewith Pumkpins
    >>Mata |cffff5a4aCanes oscuros|r. Despójalos para obtener su |cff4fc3f7Sangre|r y |cff4fc3f7Pellejos|r
    .complete 367,1 --Darkhound Blood (5)
    .complete 97558,2 --|6/6 Darkhound Hide
    .mob Decrepit Darkhound
step
    #label Claws
    #loop
    .goto 1420/0,655.12,2120.98,0
    .goto 1420/0,550.28,2315.28,50,0
    .goto 1420/0,622.58,2322.51,50,0
    .goto 1420/0,678.16,2319.80,50,0
    .goto 1420/0,716.12,2282.15,50,0
    .goto 1420/0,682.23,2218.58,50,0
    .goto 1420/0,670.48,2128.81,50,0
    .goto 1420/0,595.47,2134.53,50,0
    .goto 1420/0,613.54,2082.72,50,0
    .goto 1420/0,655.12,2120.98,50,0
    >>Mata |cffff5a4aMuertos en podredumbre|r y |cffff5a4aCuerpos devastados|r. Despójalos para obtener sus |cff4fc3f7Garras|r
    .complete 404,1 --Putrid Claw (7)
    .mob Rotting Dead
    .mob Ravaged Corpse
step
    #label Gordo2
    #loop
    .goto 1420/0,496.96,2256.54,40,0
    .goto 1420/0,571.07,2251.42,40,0
    .goto 1420/0,660.09,2196.29,40,0
    .goto 1420/0,740.97,2112.24,40,0
    .goto 1420/0,824.57,2092.36,40,0
    .goto 1420/0,945.22,2127.00,40,0
    .goto 1420/0,1063.61,2201.710,40,0
    .goto 1420/0,1133.65,2177.31,40,0
    .goto 1420/0,1191.04,2198.10,40,0
    .goto 1420/0,1191.04,2198.10,0
    .goto 1420/0,496.96,2256.54,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGordo|r
    >>|cffff9a3cEs una abominación que patrulla por el camino a Rémol|r
    >>|cffff9a3cSelecciona "Necesito un reporte para el Ejecutor Zygand"|r
    .complete 99141,3 --|1/1 Gordo's Report
    .target Gordo
    --.gossipoption 142737
step
    #label GloomWeed
    #loop
    .goto 1420/0,1246.17,2311.97,0
    .goto 1420/0,1025.65,2110.43,0
    .goto 1420/0,1246.17,2311.97,50,0
    .goto 1420/0,1025.65,2110.43,50,0
    >>Termina de despojar la |cffe07cf5Hierba luminiscente|r del suelo
    .complete 5481,1 --Gloom Weed (3)
step << Priest
    #ah
    #completewith FinishRings
    >>|cffff9a3cComienza a recolectar 3 montones de|r |T132889:0|t[Paño de lino]|cffff9a3c. Esto se usará para crear una|r |T135139:0|t[Varita mágica inferior] |cffff9a3cmás tarde|r
    >>|cffff9a3cSi no quieres hacer esto o prefieres comprarlo de la Casa de Subastas más tarde, omite este paso|r
    .collect 2589,60 --Linen Cloth (60)
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.3
step << Priest
    #ssf
    #completewith FinishRings
    >>|cffff9a3cComienza a recolectar 3 montones de|r |T132889:0|t[Paño de lino]|cffff9a3c. Esto se usará para crear una|r |T135139:0|t[Varita mágica inferior] |cffff9a3cmás tarde|r
    .collect 2589,60 --Linen Cloth (60)
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.3
step
    #label Pumkpins
    #loop
    .goto 1420/0,1378.12,2328.54,0
    .goto 1420/0,1352.36,2265.88,50,0
    .goto 1420/0,1377.66,2328.54,50,0
    .goto 1420/0,1402.06,2359.27,50,0
    .goto 1420/0,1448.16,2336.67,50,0
    .goto 1420/0,1438.21,2303.84,50,0
    .goto 1420/0,1471.20,2283.65,50,0
    .goto 1420/0,1378.12,2328.54,50,0
    >>Despoja las |cff4fc3f7Calabazas|r encontradas en el campo
    .complete 365,1 --Tirisfal Pumpkin (10)
step
    #completewith Tescort
    >>Mata |cffff5a4aGuerreros Escarlata|r
    >>|cffff9a3cTen cuidado ya que tienen un 50% más de parada durante 8 segundos después de hacer su animación de actitud defensiva|r << Rogue/Warrior
    .complete 427,1 --Scarlet Warrior (10)
    .mob Scarlet Warrior
step
    .goto 1420/0,1587.700,2439.700
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBareth Piedra del Alba|r en lo alto de la torre
    >>|cffff9a3cEsto inicia una misión de escolta|r
    >>|cffff9a3c¡Ten cuidado! En lo alto de la torre puedes llamar fácilmente la atención de 3 |cffff5a4aGuerreros Escarlata|r al mismo tiempo|r
    .accept 99144,1 >>Acepta la misión Búsqueda de un refugio
    .target Bareth Dawnstone
step
    #label Tescort
    .goto 1420/0,1268.000,2368.200
    >>Escolta a |cff5cf05cBareth Piedra del Alba|r fuera de la Hacienda Solliden
    .complete 99144,1 --
    .target Bareth Dawnstone
step
    #loop
    .goto 1420/0,1597.27,2290.28,0
    .goto 1420/0,1509.16,2351.13,50,0
    .goto 1420/0,1512.77,2299.02,50,0
    .goto 1420/0,1597.27,2290.28,50,0
    .goto 1420/0,1676.80,2316.79,50,0
    .goto 1420/0,1681.78,2354.14,50,0
    .goto 1420/0,1649.69,2405.66,50,0
    .goto 1420/0,1632.07,2436.690,50,0
    .goto 1420/0,1580.56,2487.00,50,0
    .goto 1420/0,1509.16,2473.14,50,0
    .goto 1420/0,1492.44,2395.11,50,0
    .goto 1420/0,1509.16,2351.13,50,0
    >>Mata |cffff5a4aGuerreros Escarlata|r
    >>|cffff9a3cTen cuidado ya que tienen un 50% más de parada durante 8 segundos después de hacer su animación de actitud defensiva|r << Rogue/Warrior
    .complete 427,1 --Scarlet Warrior (10)
    .mob Scarlet Warrior
step
    #loop
    .goto 1420/0,1238.600,2424.900,0
    .goto 1420/0,1238.600,2424.900,60,0
    .goto 1420/0,1204.800,2543.000,60,0
    .goto 1420/0,1122.600,2396.800 ,60,0
    >>Mata |cffff5a4aCanes oscuros|r. Despójalos para obtener su |cff4fc3f7Sangre|r y |cff4fc3f7Pellejos|r
    .complete 367,1 --Darkhound Blood (5)
    .complete 97558,2 --|6/6 Darkhound Hide
    .mob Decrepit Darkhound
step
    #hardcore
    #completewith BrillTurnin1
    .hs >> Usa tu Piedra de Hogar para ir a Rémol
    .subzoneskip 159
    .bindlocation 1497,1
    .cooldown item,6948,>0,1
step
    #hardcore
    #completewith BrillTurnin1
    .subzone 159 >> Viaja de vuelta a Rémol
    .subzoneskip 159
    .cooldown item,6948,<0
step
    #softcore
    #completewith BrillTurnin1
    .deathskip >> Muere y resucita en el |cff5cf05c Ángel de la Resurrección|r
step
    #softcore
    #loop
    .goto 1420/0,425.56,2362.58,0
    .goto 1420/0,399.35,2337.270,30,0
    .goto 1420/0,425.56,2362.58,30,0
    .goto 1420/0,355.52,2429.76,30,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHolland|r
    >>|cffff9a3cPatrulla alrededor del cementerio|r
    .turnin 5481 >>Entrega la misión La tarea de Gordo
    .accept 5482 >>Acepta la misión Apocalíseas
    .target Junior Apothecary Holland
step
    #optional
    #completewith MetaBook
    .use 286176 >>|cffff9a3cUsa la|r |T133490:0|t[Motivación del ejecutor] |cffff9a3cen cualquier |cff5cf05cGuardia de la muerte|r en Rémol y sus alrededores|r
    .complete 99134,1 --|5/5 Deathguards motivated
step
    .goto 1420/0,403.300,2287.700
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGuardia de la Muerte Dillinger|r
    >>|cffff9a3cSelecciona "Necesito un reporte para el Ejecutor Zygand"|r
    .turnin 404 >>Entrega la misión Una tarea pútrida
    .accept 426 >>Acepta la misión La invasión de los molinos
    .complete 99141,1 --|1/1 Dillinger's Report
    .target Deathguard Dillinger
    .skipgossipid 142723
step
    .goto 1420/0,346.94,2258.950
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJohaan|r
    .turnin 367 >>Entrega la misión Una nueva Peste
    .turnin 365 >>Entrega la misión Campos de pena
    .accept 368 >>Acepta la misión Una nueva Peste
    .accept 407 >>Acepta la misión Campos de pena
    .target +Apothecary Johaan
step
    .goto 1420/0,347.600,2265.100
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCarolai Anís|r
    .accept 95314 >>Acepta la misión Aquel elixir verde de Vallesombra
    .target Carolai Anise
    .xp <7,1
step << Mage
    #label MetaBook
    >>Despoja el |cffe07cf5Libro|r del estante
    .collect 208185,1 --The Apothecary's Metaphysical Primer (x1
step
    #optional
    #loop
    .goto 1420/0,290.400,2272.900,30,0
    .goto 1420/0,257.200,2239.500,30,0
    .goto 1420/0,313.400,2259.400,30,0
    .use 286176 >>|cffff9a3cUsa la|r |T133490:0|t[Motivación del ejecutor] |cffff9a3cen cualquier |cff5cf05cGuardia de la muerte|r en Rémol y sus alrededores|r
    .complete 99134,1 --|5/5 Deathguards motivated
step
    #label BrillTurnin1
    .goto 1420/0,295.87,2277.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZygand|r
    .turnin 427 >>Entrega la misión En guerra con la Cruzada Escarlata
    .accept 370 >>Acepta la misión En guerra con la Cruzada Escarlata
    .turnin 99141 >>Entrega la misión Paciencia
    .turnin 99134 >>Entrega la misión Disciplina
    .target Executor Zygand
step
    #completewith Doomweed
    #optional
    .destroy 286176 >>|cffff9a3cDestruye la|r |T133490:0|t[Motivación del ejecutor] |cffff9a3cya que no lo necesitarás para nada más|r
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBurgess|r, el |cff5cf05cCartel de Se busca|r y |cff5cf05cSevren|r dentro del edificio
    .accept 374 >>Acepta la misión Prueba de defunción
    .target +Deathguard Burgess
    .goto 1420/0,280.06,2270.70
    .accept 398 >>Acepta la misión Se busca: Ojo de cresa
    .goto 1420/0,288.64,2285.46
    .accept 358 >>Acepta la misión Profanadores
    .target +Magistrate Sevren
    .goto 1420/0,265.15,2305.94
step << Paladin
    .goto 1420/0,311.600,2251.000
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShari Fontana|r
    .turnin 99144 >>Entrega la misión Búsqueda de un refugio
    .train 853 >>Aprende tus hechizos de clase
    .target Shari Stilwell
    .xp <8,1
step
    #optional << Paladin
    .goto 1420/0,311.900,2250.700
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShari Fontana|r
    .turnin 99144 >>Entrega la misión Búsqueda de un refugio
    .target Shari Stilwell
step << Priest
    .goto 1420/0,251.14,2265.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBeryl|r en el segundo piso
    .turnin 5650 >>Entrega la misión Las prendas de la Oscuridad
    .train 591 >>Aprende |T135924:0|t[Punición]
    .train 17 >>Aprende |T135940:0|t[Palabra de poder: escudo]
    .target Dark Cleric Beryl
step
    .goto 1420/0,236.68,2249.01
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGretchen|r
    >>|cff5cf05cGretchen|r |cffff9a3cestá en el segundo piso de la posada|r
    .accept 375 >>Acepta la misión El frío de la muerte
    .target Gretchen Dedmar
step << Priest
    .goto 1420/0,251.14,2265.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBeryl|r en el segundo piso
	.train 139 >> Aprende tus hechizos de clase
    .target Dark Cleric Beryl
    .xp <8,1
step << Mage
    .goto 1420/0,233.06,2256.84
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCain|r en el segundo piso
    .train 205 >> Aprende tus hechizos de clase
    .target Cain Firesong
    .xp <8,1
step << Warrior
    .goto 1420/0,238.49,2255.03
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAustil|r
    .train 284 >> Aprende tus hechizos de clase
    .target Austil de Mon
    .xp <8,1
step << Rogue
    .goto 1420/0,243.01,2271.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMarion|r en el segundo piso
    .train 6760 >> Aprende tus hechizos de clase
    .target Marion Call
    .xp <8,1
step << Warlock
    .goto 1420/0,250.24,2259.25
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRupert|r
    .train 980 >> Aprende tus hechizos de clase
    .target Rupert Boch
    .xp <8,1
step << Mage/Priest/Warlock
    .goto 1420/0,244.81,2269.19
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cTabernera Renee|r
    .vendor >>|cffe07cf5Cómprale la mayor cantidad de|r |T132815:0|t[Leche fría como el hielo] |cffe07cf5que puedas|r << Mage/Priest
    .vendor >>|cffe07cf5Cómprale la mayor cantidad de|r |T132815:0|t[Leche fría como el hielo] |cffe07cf5y|r |T134532:0|t[Champiñones con motas rojas] |cffe07cf5que puedas|r << Warlock
    .money <0.0125
    .target Innkeeper Renee
step
    .goto 1420/0,243.200,2288.100
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWilliam|r
    .train 2550 >>Aprende Cocina
    .turnin 96658 >>Entrega la misión Campamento básico: Cocina
    .target William Pickman
step << Rogue/Warrior
    .goto 1420/0,240.29,2246.30
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cNeela|r
    >>|cffff9a3cIntenta hacerlos durante momentos en los que estés esperando cosas, como los Zepelines|r
    .train 3273 >>Aprende |T135966:0|t[Primeros auxilios]
    .target Nurse Neela
step << Rogue
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOliver|r
    .vendor >> Vende la basura. Vende tu arma si te da suficiente dinero para un |T135641:0|t[Estilete] (3 platas 81 cobre). Volverás más adelante si aún no tienes suficiente
    .target Oliver Dwor
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.3
step << Rogue
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cOliver|r|cffe07cf5. Compra un|r |T135641:0|t[Estilete] |cffe07cf5a este vendedor|r
    .collect 2494,1,367,1 --Collect Stiletto (1)
    .money <0.0381
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.3
step << Rogue
    #optional
    #completewith Doomweed
    +|cffff9a3cEquipa el |T135641:0|t[Estilete]|r
    .use 2494
    .itemcount 2494,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.3
step << Warrior
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOliver|r
    .vendor >> Vende la basura. Vende tu arma si te da suficiente dinero para un |T135321:0|t[Gladius] (5 platas 10 cobres). Volverás más tarde si no tienes suficiente dinero
    .target Oliver Dwor
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.7
step << Warrior
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cOliver|r|cffe07cf5. Compra un|r |T135321:0|t[Gladius] |cffe07cf5a este vendedor|r
    .collect 2488,1,367,1 --Collect Gladius (1)
    .money <0.0510
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.7
step << Warrior
    #optional
    #completewith Doomweed
    +|cffff9a3cEquipa el|r |T135321:0|t[Gladius]
    .use 2488
    .itemcount 2488,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.7
step << Paladin
    .goto 1420/0,311.600,2250.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShari Fontana|r
    .train 679 >>Aprende |T626003:0|t[Golpe Sagrado]
    .target Shari Stilwell
    .xp <6,1
step << Paladin
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOliver|r
    .vendor >> Vende la basura. Vende tu arma si te da suficiente dinero para una |T133053:0|t[Marra de madera] (6 platas 66 cobres). Volverás más tarde si aún no tienes suficiente
    .target Oliver Dwor
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<4.9
step << Paladin
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cOliver|r|cffe07cf5. Compra una|r |T133053:0|t[Marra de madera] |cffe07cf5a este vendedor|r
    .collect 2493,1,367,1 --Collect Wooden Mallet (1)
    .money <0.0666
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<4.9
step << Paladin
    #optional
    #completewith Doomweed
    +|cffff9a3cEquipa la|r |T133053:0|t[Marra de madera]
    .use 2493
    .itemcount 2493,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<4.9
step
    .goto 1420/0,270.12,2253.23--c:Tirisfal Glades,61.15,52.59
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cSra. Winters|r
    >>|cffe07cf5Compra una|r |T133634:0|t[Faltriquera marrón pequeña] |cffe07cf5a|r |cff5cf05cesta vendedora|r
    .collect 4496,1,5482,1 --Small Brown Pouch (1)
    .target Mrs. Winters
    .money <0.05
step
    #hardcore
    #loop
    .goto 1420/0,425.56,2362.58,0
    .goto 1420/0,399.35,2337.270,30,0
    .goto 1420/0,425.56,2362.58,30,0
    .goto 1420/0,355.52,2429.76,30,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHolland|r
    >>|cffff9a3cPatrulla alrededor del cementerio|r
    .turnin 5481 >>Entrega la misión La tarea de Gordo
    .accept 5482 >>Acepta la misión Apocalíseas
    .target Junior Apothecary Holland
step << Rogue/Warrior
    #optional
    #loop
    .goto 1420/0,482.50,1951.07,0
    .goto 1420/0,403.42,2085.73,50,0
    .goto 1420/0,413.36,1979.99,50,0
    .goto 1420/0,482.50,1951.07,50,0
    .goto 1420/0,560.22,1901.06,50,0
    .goto 1420/0,645.63,1961.92,50,0
    .goto 1420/0,750.46,1993.55,50,0
    .goto 1420/0,869.76,2003.79,50,0
    .goto 1420/0,950.64,2039.040,50,0
    .goto 1420/0,1068.13,1975.47,50,0
    >>Mata |cffff5a4aMurciumbríos|r. Despójalos para obtener sus |cff4fc3f7Pelambres|r y |cff4fc3f7Membranas de alas|r
    .complete 375,1 --Duskbat Pelt (5)
    .complete 97558,1 --|8/8 Duskbat Wing Membrane
    .disablecheckbox
    .mob Greater Duskbat
    .mob Vampiric Duskbat
    .xp >7+3960,1
step << Rogue/Warrior
    #optional
    #label DuskbatTrophy1
    #loop
    .goto 1420/0,482.50,1951.07,0
    .goto 1420/0,403.42,2085.73,50,0
    .goto 1420/0,413.36,1979.99,50,0
    .goto 1420/0,482.50,1951.07,50,0
    .goto 1420/0,560.22,1901.06,50,0
    .goto 1420/0,645.63,1961.92,50,0
    .goto 1420/0,750.46,1993.55,50,0
    .goto 1420/0,869.76,2003.79,50,0
    .goto 1420/0,950.64,2039.040,50,0
    .goto 1420/0,1068.13,1975.47,50,0
    .xp 7+3260 >> Mata enemigos hasta alcanzar 3260+/4500
--XX 700 (375)+540 (367)
step << Rogue/Warrior
    #optional
    .goto 1420/0,275.54,2260.46
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAbigail|r
    >>|cffe07cf5Compra un|r |T132891:0|t[Hilo burdo] |cffe07cf5a esta vendedora|r
    .complete 375,2 --Coarse Thread (1)
    .target Abigail Shiel
    .itemcount 2876,5 --Duskbat Pelt (5)
    .isQuestAvailable 375
step << Rogue/Warrior
    #optional
    .goto 1420/0,236.68,2249.01
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGretchen|r
    .turnin 375 >>Entrega la misión El frío de la muerte
    .target Gretchen Dedmar
    .isQuestComplete 375
step << Warrior
    .goto 1420/0,238.49,2255.03
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAustil|r
    .train 284 >> Aprende tus hechizos de clase
    .target Austil de Mon
    .xp <8,1
step << Rogue
    .goto 1420/0,243.01,2271.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMarion|r en el segundo piso
    .train 6760 >> Aprende tus hechizos de clase
    .target Marion Call
    .xp <8,1
step << Rogue
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOliver|r
    .vendor >> Vende la basura. Vende tu arma si te da suficiente dinero para un |T135641:0|t[Estilete] (3 platas 81 cobre). Volverás más adelante si aún no tienes suficiente
    .target Oliver Dwor
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.3
step << Rogue
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cOliver|r|cffe07cf5. Compra un|r |T135641:0|t[Estilete] |cffe07cf5a este vendedor|r
    .collect 2494,1,398,1 --Collect Stiletto (1)
    .money <0.0381
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.3
step << Rogue
    #optional
    #completewith Doomweed
    +|cffff9a3cEquipa el |T135641:0|t[Estilete]|r
    .use 2494
    .itemcount 2494,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.3
step << Warrior
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOliver|r
    .vendor >> Vende la basura. Vende tu arma si te da suficiente dinero para un |T135321:0|t[Gladius] (5 platas 10 cobres). Volverás más tarde si no tienes suficiente dinero
    .target Oliver Dwor
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.7
step << Warrior
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cOliver|r|cffe07cf5. Compra un|r |T135321:0|t[Gladius] |cffe07cf5a este vendedor|r
    .collect 2488,1,398,1 --Collect Gladius (1)
    .money <0.0510
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.7
step << Warrior
    #optional
    #completewith Doomweed
    +|cffff9a3cEquipa el|r |T135321:0|t[Gladius]
    .use 2488
    .itemcount 2488,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.7
step
    #completewith next
    >>Despoja las |cffe07cf5Apocalíseas|r del suelo
    >>|cffff9a3cSe encuentran cerca de los árboles en el área Gnoll|r
    .complete 5482,1 --Doom Weed (10)
    .isOnQuest 5482
step
    #loop
    .goto 1420/0,537.18,2555.98,0
    .goto 1420/0,488.83,2642.44,40,0
    .goto 1420/0,561.13,2596.65,40,0
    .goto 1420/0,597.73,2514.11,40,0
    .goto 1420/0,537.18,2555.98,40,0
    .goto 1420/0,483.40,2514.41,40,0
    >>Mata |cffff5a4aAsaltatumbas Putrepellejo|r. Despójalos para obtener su |cff4fc3f7Icor|r
    .complete 358,1 --Rot Hide Graverobber (8)
    .complete 358,3 --Embalming Ichor (8)
    .disablecheckbox
    .mob Rot Hide Graverobber
step
    #completewith next
    >>Mata |cffff5a4aBastardos Putrepellejo|r. Despójalos para obtener su |cff4fc3f7Icor|r
    .complete 358,2 --Rot Hide Mongrel (5)
    .complete 358,3 --Embalming Ichor (8)
    .disablecheckbox
    .mob Rot Hide Mongrel
step
    #label Doomweed
    #loop
    .goto 1420/0,435.96,2754.51,0
    .goto 1420/0,426.92,2802.10,30,0
    .goto 1420/0,437.31,2754.20,30,0
    .goto 1420/0,467.14,2699.08,30,0
    .goto 1420/0,500.57,2669.85,30,0
    .goto 1420/0,543.95,2670.46,30,0
    .goto 1420/0,536.72,2627.68,30,0
    .goto 1420/0,562.48,2568.63,30,0
    .goto 1420/0,534.92,2587.01,30,0
    .goto 1420/0,476.62,2572.55,30,0
    .goto 1420/0,399.35,2544.23,30,0
    .goto 1420/0,374.95,2612.01,30,0
    .goto 1420/0,396.19,2676.18,30,0
    .goto 1420/0,435.96,2754.51,30,0
    >>Despoja las |cffe07cf5Apocalíseas|r del suelo
    >>|cffff9a3cSe encuentran cerca de los árboles en el área Gnoll|r
    .complete 5482,1 --Doom Weed (10)
    .isOnQuest 5482
step
    #completewith MaggotEye
    >>Mata |cffff5a4aBastardos Putrepellejo|r. Despójalos para obtener su |cff4fc3f7Icor|r
    .complete 358,2 --Rot Hide Mongrel (5)
    .complete 358,3 --Embalming Ichor (8)
    .disablecheckbox
    .mob Rot Hide Mongrel
step
    #label MaggotEye
    .goto 1420/0,382.63,2910.55
    >>Mata a |cffff5a4aOjo de cresa|r. Despójalo para obtener su |cff4fc3f7Garra|r
    .complete 398,1 --Maggot Eye's Paw (1)
    .mob Maggot Eye
step
    #loop
    .goto 1420/0,332.48,2862.35,0
    .goto 1420/0,380.38,2768.97,50,0
    .goto 1420/0,332.48,2862.35,50,0
    .goto 1420/0,401.16,2895.19,50,0
    .goto 1420/0,318.47,2696.36,50,0
    >>Mata |cffff5a4aBastardos Putrepellejo|r. Despójalos para obtener su |cff4fc3f7Icor|r
    .complete 358,2 --Rot Hide Mongrel (5)
    .complete 358,3 --Embalming Ichor (8)
    .disablecheckbox
    .mob Rot Hide Mongrel
step
    #loop
    .goto 1420/0,332.48,2862.35,0
    .goto 1420/0,380.38,2768.97,50,0
    .goto 1420/0,332.48,2862.35,50,0
    .goto 1420/0,401.16,2895.19,50,0
    .goto 1420/0,318.47,2696.36,50,0
    >>Mata |cffff5a4aGnolls Putrepellejo|r. Despójalos para obtener su |cff4fc3f7Icor|r
    .complete 358,3 --Embalming Ichor (8)
    .mob Rot Hide Mongrel
    .mob Rot Hide Gnoll
    .mob Rot Hide Graverobber
step
    #label MurlocVins
    #loop
    .goto 1420/0,342.87,2998.22,0
    .goto 1420/0,350.10,2962.37,50,0
    .goto 1420/0,342.87,2998.22,50,0
    .goto 1420/0,293.16,2974.12,50,0
    .goto 1420/0,254.75,2951.820,50,0
    .goto 1420/0,188.33,2950.02,50,0
    .goto 1420/0,65.42,2927.12,50,0
    .goto 1420/0,-15.92,2964.78,50,0
    .goto 1420/0,-49.36,3040.39,50,0
    >>Mata a los |cffff5a4aMúrlocs Anca Vil|r. Despójalos para obtener sus |cff4fc3f7Escamas|r y |cff4fc3f7Piel de Múrloc|r
    >>|cffff5a4aSaltacharcos Anca Vil|r |cffff9a3cno sueltan|r |cff4fc3f7Piel de Múrloc Anca Vil|r
    .complete 368,1 --Vile Fin Scale (5)
    .complete 97558,3 --|3/3 Vile Fin Murloc Skin
    .mob Vile Fin Puddlejumper
    .mob Vile Fin Minor Oracle
    .mob Vile Fin Muckdweller
step
    #loop
    .goto 1420/0,138.300,2829.600,0
    .goto 1420/0,138.300,2829.600,50,0
    .goto 1420/0,121.200,2727.400,50,0
    .goto 1420/0,127.500,2601.800,50,0
    .goto 1420/0,211.400,2545.500,50,0
    .goto 1420/0,146.300,2408.000,50,0
    .goto 1420/0,94.600,2312.100,50,0
    .goto 1420/0,39.900,2248.100,50,0
    .goto 1420/0,-137.100,2206.000,50,0
    .goto 1420/0,-190.800,2387.700,50,0
    >>Mata |cffff5a4aMurciumbríos|r. Despójalos para obtener sus |cff4fc3f7Pelambres|r y |cff4fc3f7Membranas de alas|r
    .complete 375,1 --Duskbat Pelt (5)
    .complete 97558,1 --|8/8 Duskbat Wing Membrane
    .mob Greater Duskbat
    .mob Vampiric Duskbat
step
    #completewith Brill3
    .hs >> Usa tu Piedra de Hogar para ir a Rémol
    .subzoneskip 159
    .bindlocation 1497,1
    .cooldown item,6948,>0,1
step
    #completewith Brill3
    .subzone 159 >> Viaja de vuelta a Rémol
    .subzoneskip 159
    .cooldown item,6948,<0
step << skip
    #softcore
    #completewith Brill3
    .deathskip >> Muere y reaparece en el |cff5cf05cÁngel de la Resurrección|r
step
    .goto 1420/0,244.36,2262.26
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cColeman|r
    .accept 354 >>Acepta la misión Muertes en la familia
    .accept 362 >>Acepta la misión Los molinos fantasma
    .target Coleman Farthing
step
    .goto 1420/0,275.54,2260.46
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAbigail|r
    >>|cffe07cf5Compra un|r |T132891:0|t[Hilo burdo] |cffe07cf5a esta vendedora|r
    .complete 375,2 --Coarse Thread (1)
    .target Abigail Shiel
    .isQuestAvailable 375
step
    .goto 1420/0,295.87,2277.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZygand|r
    .turnin 398 >>Entrega la misión Se busca: Ojo de cresa
    .target Executor Zygand
step
    .goto 1420/0,265.15,2305.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSevren|r
    .turnin 358 >>Entrega la misión Profanadores
    .accept 405 >>Acepta la misión El exánime pródigo << Mage/Warlock
    .accept 359 >>Acepta la misión Las obligaciones de los Renegados
    .target Magistrate Sevren
step
    .goto 1420/0,236.68,2249.01
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGretchen|r
    .turnin 375 >>Entrega la misión El frío de la muerte
    .target Gretchen Dedmar
    .isQuestComplete 375
step << Priest
    .goto 1420/0,251.14,2265.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBeryl|r en el segundo piso
	.train 139 >> Aprende tus hechizos de clase
    .target Dark Cleric Beryl
    .xp <8,1
step << Mage
    .goto 1420/0,233.06,2256.84
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCain|r en el segundo piso
    .train 205 >> Aprende tus hechizos de clase
    .target Cain Firesong
    .xp <8,1
step << Warrior
    .goto 1420/0,238.49,2255.03
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAustil|r
    .train 284 >> Aprende tus hechizos de clase
    .target Austil de Mon
    .xp <8,1
step << Rogue
    .goto 1420/0,243.01,2271.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMarion|r en el segundo piso
    .train 6760 >> Aprende tus hechizos de clase
    .target Marion Call
    .xp <8,1
step << Warlock
    .goto 1420/0,250.24,2259.25
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRupert|r
    .train 980 >> Aprende tus hechizos de clase
    .target Rupert Boch
    .xp <8,1
step << Rogue/Warrior
    .goto 1420/0,240.29,2246.30
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cNeela|r
    >>|cffff9a3cIntenta hacerlos durante momentos en los que estés esperando cosas, como los Zepelines|r
    .train 3273 >>Aprende |T135966:0|t[Primeros auxilios]
    .target Nurse Neela
step
    #label Brill3
    .goto 1420/0,244.81,2269.19
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cTabernera Renee|r
    >>|cffe07cf5Compra|r |T132815:0|t[Leche fría como el hielo] |cffe07cf5a esta vendedora|r << Mage/Priest/Paladin
    >>|cffe07cf5Compra|r |T134532:0|t[Champiñones con motas rojas] |cffe07cf5a esta vendedora|r << Warrior/Rogue
    >>|cffe07cf5Compra|r |T132815:0|t[Leche fría como el hielo] |cffe07cf5y|r |T134532:0|t[Champiñones con motas rojas] |cffe07cf5a esta vendedora|r << Warlock
    .collect 1179,20,426,1 << Mage/Priest/Paladin --Ice Cold Milk (20)
    .collect 4605,20,426,1 << Rogue/Warrior --Red-speckled Mushroom (20)
    .collect 1179,10,426,1 << Warlock --Ice Cold Milk (10)
    .collect 4605,10,426,1 << Warlock --Red-speckled Mushroom (10)
    .money <0.025 << Warrior/Rogue
    .money <0.0375 << Mage/Priest/Warlock/Paladin
    .target Innkeeper Renee
step << Paladin
    .goto 1420/0,311.600,2251.000
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShari Fontana|r
    .train 853 >>Aprende tus hechizos de clase
    .target Shari Stilwell
    .xp <8,1
step << Rogue
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOliver|r
    .vendor >> Vende la basura. Vende tu arma si te da suficiente dinero para un |T135641:0|t[Estilete] (3 platas 81 cobre). Volverás más adelante si aún no tienes suficiente
    .target Oliver Dwor
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.3
step << Rogue
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cOliver|r|cffe07cf5. Compra un|r |T135641:0|t[Estilete] |cffe07cf5a este vendedor|r
    .collect 2494,1,354,1 --Collect Stiletto (1)
    .money <0.0381
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.3
step << Rogue
    #optional
    #completewith MillsOverun
    +|cffff9a3cEquipa el |T135641:0|t[Estilete]|r
    .use 2494
    .itemcount 2494,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.3
step << Warrior
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOliver|r
    .vendor >> Vende la basura. Vende tu arma si te da suficiente dinero para un |T135321:0|t[Gladius] (5 platas 10 cobres). Volverás más tarde si no tienes suficiente dinero
    .target Oliver Dwor
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.7
step << Warrior
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cOliver|r|cffe07cf5. Compra un|r |T135321:0|t[Gladius] |cffe07cf5a este vendedor|r
    .collect 2488,1,354,1 --Collect Gladius (1)
    .money <0.0510
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.7
step << Warrior
    #optional
    #completewith MillsOverun
    +|cffff9a3cEquipa el|r |T135321:0|t[Gladius]
    .use 2488
    .itemcount 2488,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<3.7
step << Paladin
    .goto 1420/0,311.600,2250.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShari Fontana|r
    .train 679 >>Aprende |T626003:0|t[Golpe Sagrado]
    .target Shari Stilwell
    .xp <6,1
step << Paladin
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOliver|r
    .vendor >> Vende la basura. Vende tu arma si te da suficiente dinero para una |T133053:0|t[Marra de madera] (6 platas 66 cobres). Volverás más tarde si aún no tienes suficiente
    .target Oliver Dwor
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<4.9
step << Paladin
    .goto 1420/0,316.66,2227.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cOliver|r|cffe07cf5. Compra una|r |T133053:0|t[Marra de madera] |cffe07cf5a este vendedor|r
    .collect 2493,1,354,1 --Collect Wooden Mallet (1)
    .money <0.0666
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<4.9
step << Paladin
    #optional
    #completewith MillsOverun
    +|cffff9a3cEquipa la|r |T133053:0|t[Marra de madera]
    .use 2493
    .itemcount 2493,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<4.9
step << skip --Rogue/Warrior
    #softcore
    .goto 1420/0,308.08,2246.30
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cEliza Callen|r
    .vendor >>Repara tu arma
    .target Eliza Callen
step
    .goto 1420/0,76.000,2026.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShelene Rhobart|r
    .turnin 97558 >>Entrega la misión Pellejos para los Renegados
    .target Shelene Rhobart
step
    .goto 1420/0,74.00,2022.47
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLinnea|r
    .turnin 359 >>Entrega la misión Las obligaciones de los Renegados
    .accept 360 >>Acepta la misión Regresa junto al magistrado
    .accept 356 >>Acepta la misión Patrulla de la retaguardia
    .target Deathguard Linnea
step
    .goto 1420/0,346.94,2258.950
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJohaan|r
    .turnin 368 >>Entrega la misión Una nueva Peste
    .accept 369 >>Acepta la misión Una nueva Peste
    .target Apothecary Johaan
step
    #label DoomedWeed
    #loop
    .goto 1420/0,425.56,2362.58,0
    .goto 1420/0,399.35,2337.270,30,0
    .goto 1420/0,425.56,2362.58,30,0
    .goto 1420/0,355.52,2429.76,30,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHolland|r
    >>|cffff9a3cPatrulla alrededor del cementerio|r
    .turnin 5482 >>Entrega la misión Apocalíseas
    .accept 99142 >>Acepta la misión Tumbalíseas
    .target Junior Apothecary Holland
step
    #label AgamandStart
    .goto 1420/0,882.41,2511.1,100,0
    .goto 1420/0,892.80,2520.74
    .subzone 157 >> Viaja al norte/oeste hacia los Molinos de Agamand
    .isOnQuest 362
step
    #completewith ThurmanGregor
    >>|T134939:0|t[|cff4fc3f7Carta de Thurman|r] |cffff9a3cpuede caer de estos enemigos. Acepta la misión si lo hace|r
    .collect 2839,1,361 --Collect A Letter to Yvette (1)
    .accept 361 >> Acepta la misión Una carta sin entregar
    .use 2839
step
    #completewith ThurmanGregor
    >>Mata |cffff5a4aSoldados|r y |cffff5a4aTirahuesos|r. Despójalos para obtener sus |cff4fc3f7Costillas|r y |cff4fc3f7Calaveras|r
    .complete 426,1 --Notched Rib (5)
    .mob +Rattlecage Soldier
    .mob +Cracked Skull Soldier
    .complete 426,2 --Blackened Skull (3)
    .mob +Darkeye Bonecaster
step
    #label KillDevlin
    .goto 1420/0,894.16,2609.00
    >>Mata a |cffff5a4aDevlin|r. Despójalo para obtener sus |cff4fc3f7Restos|r
    .complete 362,1 --Devlin's Remains (1)
    .mob Devlin Agamand
step
    .goto 1420/0,803.78,2752.40
    >>Mata a |cffff5a4aNissa|r. Despójala para obtener sus |cff4fc3f7Restos|r. Puede estar dentro del edificio
    .complete 354,2 --Nissa's Remains (1)
    .mob Nissa Agamand
step
    #label ThurmanGregor
    #loop
    .goto 1420/0,996.28,2899.11,0
    .goto 1420/0,1058.19,2775.59,60,0
    .goto 1420/0,998.54,2903.93,60,0
    .goto 1420/0,919.01,2939.770,60,0
    .goto 1420/0,1098.40,2875.61,60,0
    .goto 1420/0,1098.40,2875.61,60,0
    .goto 1420/0,996.28,2899.11,60,0
    >>Mata a |cffff5a4aThurman|r y a |cffff5a4aGregor|r. Despójalos para obtener sus |cff4fc3f7Restos|r
    >>|cffff9a3cPueden patrullar por los alrededores|r
    .complete 354,3 --Thurman's Remains (1)
    .unitscan +Thurman Agamand
    .complete 354,1 --Gregor's Remains (1)
    .unitscan +Gregor Agamand
step
    #label MillsOverun
    #loop
    .goto 1420/0,996.28,2899.11,0
    .goto 1420/0,1058.19,2775.59,60,0
    .goto 1420/0,998.54,2903.93,60,0
    .goto 1420/0,919.01,2939.770,60,0
    .goto 1420/0,1098.40,2875.61,60,0
    .goto 1420/0,1098.40,2875.61,60,0
    .goto 1420/0,996.28,2899.11,60,0
    >>Mata |cffff5a4aSoldados|r y |cffff5a4aTirahuesos|r. Despójalos para obtener sus |cff4fc3f7Costillas|r y |cff4fc3f7Calaveras|r
    .complete 426,1 --Notched Rib (5)
    .mob +Rattlecage Soldier
    .mob +Cracked Skull Soldier
    .complete 426,2 --Blackened Skull (3)
    .mob +Darkeye Bonecaster
step
    #optional
    #loop
    .goto 1420/0,857.56,2793.97,60,0
    .goto 1420/0,880.15,2884.04,60,0
    .goto 1420/0,953.35,2926.22,60,0
    .goto 1420/0,1025.2,2908.44,60,0
    .goto 1420/0,1040.56,2793.07,60,0
    .goto 1420/0,918.56,2780.11,60,0
    .goto 1420/0,953.35,2926.22,60,0
    .xp 9+3840 >> Mata enemigos hasta alcanzar 4320+/6500xp
    .itemcount 2839,<1 --A Letter to Yvette (0)
step
    #optional
    #loop
    .goto 1420/0,857.56,2793.97,60,0
    .goto 1420/0,880.15,2884.04,60,0
    .goto 1420/0,953.35,2926.22,60,0
    .goto 1420/0,1025.2,2908.44,60,0
    .goto 1420/0,1040.56,2793.07,60,0
    .goto 1420/0,918.56,2780.11,60,0
    .goto 1420/0,953.35,2926.22,60,0
    .xp 9+3360 >> Mata enemigos hasta alcanzar 3360+/6500xp
    .itemcount 2839,1 --A Letter to Yvette (1)
step
    #hardcore
    #completewith FoodandWater2
    .subzone 159 >> Viaja de vuelta a Rémol
step
    #softcore
    #completewith FoodandWater2
    .deathskip >> Muere y reaparece en el |cff5cf05cÁngel de la Resurrección|r
    .xp <10,1
step
    #softcore
    #completewith FoodandWater2
    .subzone 159 >> Viaja de vuelta a Rémol
    .xp >10,1
step
    .goto 1420/0,403.42,2287.87
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDillinger|r
    .turnin 426 >>Entrega la misión La invasión de los molinos
    .target Deathguard Dillinger
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cYvette|r y |cff5cf05cColeman|r
    .turnin 361 >>Entrega la misión Una carta sin entregar
    .target +Yvette Farthing
    .goto 1420/0,250.69,2252.920
    .turnin 354 >>Entrega la misión Muertes en la familia
    .turnin 362 >>Entrega la misión Los molinos fantasma
    .accept 355 >>Acepta la misión Habla con Sevren
    .target +Coleman Farthing
    .goto 1420/0,244.36,2262.26
    .isOnQuest 361
step
    .goto 1420/0,244.36,2262.26
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cColeman|r
    .turnin 354 >>Entrega la misión Muertes en la familia
    .turnin 362 >>Entrega la misión Los molinos fantasma
    .accept 355 >>Acepta la misión Habla con Sevren
    .target Coleman Farthing
step
    .goto 1420/0,265.15,2305.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSevren|r
    .turnin 360 >>Entrega la misión Regresa junto al magistrado
    .turnin 355 >>Entrega la misión Habla con Sevren
    .target Magistrate Sevren
    .xp >10,1 --turnin later if lvl 10 already
step << Priest
    .goto 1420/0,251.14,2265.28
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBeryl|r en el segundo piso
	.trainer >> Aprende tus hechizos de clase
    .target Dark Cleric Beryl
step << Warrior
    #optional
    .abandon 1505 >>Abandona la misión Uzzek, el veterano
    .isOnQuest 1505
step << Warrior
    #optional
    .abandon 1498 >>Abandona la misión Camino de defensa
    .isOnQuest 1498
step << Warrior
    .goto 1420/0,238.49,2254.43
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAustil|r
    .trainer >> Aprende tus hechizos de clase
    .accept 1818 >> Acepta la misión Habla con Dillinger
    .target Austil de Mon << Warrior
    .isQuestAvailable 1498
step << Warlock
    .goto 1420/0,248.88,2251.12
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAgeron|r dentro de la posada
    .accept 1478 >> Acepta la misión Las invocaciones de Halgar
    .target Ageron Kargal
step << Warlock
    .goto 1420/0,250.24,2259.25
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRupert|r
    .train 707 >> Aprende tus hechizos de clase
    .target Rupert Boch
step << Rogue
    .goto 1420/0,243.01,2270.70
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMarion|r dentro de la posada
    .trainer >> Aprende tus hechizos de clase
    .accept 1885 >>Acepta la misión Mennet Carkad
    .target Marion Call
step << Mage
    .goto 1420/0,233.52,2256.84
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCain|r dentro de la posada
    .accept 1881 >> Acepta la misión Habla con Anastasia
    .target Cain Firesong
step
    #label FoodandWater2
    .goto 1420/0,244.81,2269.19
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cTabernera Renee|r
    >>|cffe07cf5Compra|r |T132815:0|t[Leche fría como el hielo] |cffe07cf5a esta vendedora|r << Mage/Priest/Shaman
    >>|cffe07cf5Compra|r |T134532:0|t[Champiñones con motas rojas] |cffe07cf5a esta vendedora|r <<Warrior/Rogue
    >>|cffe07cf5Compra|r |T132815:0|t[Leche fría como el hielo] |cffe07cf5y|r |T134532:0|t[Champiñones con motas rojas] |cffe07cf5a esta vendedora|r << Warlock
    .collect 1179,20,370,1 << Mage/Priest/Shaman --Ice Cold Milk (20)
    .collect 4605,20,370,1 << Rogue/Warrior --Red-speckled Mushroom (20)
    .collect 1179,15,370,1 << Warlock --Ice Cold Milk (15)
    .collect 4605,15,370,1 << Warlock --Red-speckled Mushroom (15)
    .money <0.075 << Warlock
    .money <0.05 << !Warlock
    .target Innkeeper Renee
step << Warrior
    .goto 1420/0,403.87,2287.87
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDillinger|r
    .turnin 1818 >> Entrega la misión Habla con Dillinger
    .accept 1819 >> Acepta la misión Ulag el Cuchilla
    .target Deathguard Dillinger
    .isQuestAvailable 1498
step << Warrior
    .goto 1420/0,360.04,2376.14
    >>|cffff9a3cHaz clic en la calavera del suelo. Esto invocará a|r |cffff5a4aUlag.|r |cffff9a3cMátalo|r
    .complete 1819,1 --Ulag the Cleaver (1)
    .mob Ulag the Cleaver
step << Warrior
    .goto 1420/0,403.87,2287.87
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDillinger|r
    .turnin 1819 >> Entrega la misión Ulag el Cuchilla
    .accept 1820 >> Acepta la misión Habla con Coleman
    .target Deathguard Dillinger
step
    .goto 1420/0,254.600,2225.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGuardia de la Muerte Terrence|r
    .accept 96895 >>Acepta la misión El emisario Argenta
    .target Deathguard Terrence
step << Paladin
    .goto 1420/0,311.600,2251.000
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShari Fontana|r
    .accept 91282 >>Acepta la misión Segundo hogar
    .trainer >>Aprende tus hechizos de clase
    .target Shari Stilwell
step << Warlock
    #completewith next
    .goto 1420/0,240.75,1877.57,20 >> Entra en Entrañas
    .zoneskip Undercity
step << Warlock
    #completewith next
    .goto 1458/0,239.14,1749.54,35,0
    .goto 1458/0,255.64,1724.70,35,0
    .goto 1458/0,240.68,1706.97,10,0
    .goto 1458/0,241.06,1660.12,10,0
    .goto 1458/0,257.08,1623.38,10,0
    .goto 1458/0,244.51,1598.73,15 >> Toma el ascensor para bajar a Entrañas
step << Warlock
    .goto 1458/0,57.05,1711.77
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCarendin|r en el Barrio de la Magia
    .turnin 1478 >> Entrega la misión Las invocaciones de Halgar
    .accept 1473 >> Acepta la misión Criatura Abisal
step << Warlock
    .goto 1458/0,66.74,1766.31
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBethor|r en el Barrio de Magia
    .turnin 405 >>Entrega la misión El exánime pródigo
    --.accept 357 >>Acepta la misión La identidad del exánime
    .target Bethor Iceshard
step << Warlock
    .goto 1458/0,419.89,1627.54,50,0
    .goto 1458/0,428.52,1597.20,10,0
    .goto 1458/0,439.17,1626.06,10,0
    .goto 1458/0,476.78,1632.150,10,0
    .goto 1458/0,482.34,1660.63,10,0
    .goto 1458/0,539.33,1665.49,15,0
    .goto 1458/0,610.42,1684.44,35,0
    .goto 1458/0,663.19,1600.46,35,0
    .goto 1420/0,724.25,1682.66,50,0
    .zone Tirisfal Glades >> Abandona Entrañas por las Cloacas
    .zoneskip Tirisfal Glades
step << Warlock
    #completewith next
    .goto 1420/0,726.06,1801.95
    >>Despoja |cffe07cf5Cofre de Perrine|r para obtener |T133733:0|t[Grimorio Egalin]
    .complete 1473,1 --Egalin's Grimoire (1)
step
    #label ScarletCrusade1
    #loop
	.goto 1420/0,770.80,1762.79,40,0
	.goto 1420/0,763.57,1820.93,40,0
	.goto 1420/0,721.54,1857.38,40,0
	.goto 1420/0,694.88,1848.04,40,0
	.goto 1420/0,641.56,1800.45,40,0
	.goto 1420/0,651.05,1748.93,40,0
	.goto 1420/0,685.39,1741.70,40,0
	.goto 1420/0,727.42,1742.31,40,0
    >>Mata al |cffff5a4aCapitán Perrine|r, |cffff5a4aZelotes Escarlata|r y |cffff5a4aMisioneros Escarlata|r. Despójalos para obtener sus |cff4fc3f7Anillos con la insignia Escarlata|r
    .complete 370,1 --Captain Perrine (1)
    .mob +Captain Perrine
    .complete 370,2 --Scarlet Zealot (3)
    .mob +Scarlet Zealot
    .complete 370,3 --Scarlet Missionary (3)
    .mob +Scarlet Missionary
    .complete 374,1 --Scarlet Insignia Ring (10)
    .disablecheckbox
step << Warlock
    .goto 1420/0,726.06,1801.95
    >>Despoja |cffe07cf5Cofre de Perrine|r del suelo para obtener |T133733:0|t[Grimorio Egalin]
    .complete 1473,1 --Egalin's Grimoire (1)
step << !Priest
    #completewith UCHome
    .goto 1458/0,714.8,1604.24,35,0
    .goto 1458/0,652.73,1623.44,35,0
    .goto 1458/0,634.02,1669.66,35,0
    .goto 1458/0,539.52,1665.17,10,0
    .goto 1458/0,481.48,1659.8,10,0
    .goto 1458/0,476.49,1632.15,10,0
    .goto 1458/0,439.08,1627.02,10,0
    .goto 1458/0,435.05,1598.86,10,0
    .zone Undercity >> Entra en Entrañas a través de las cloacas
    .zoneskip Undercity
step << Rogue
    .goto 1458/0,323.57,1668.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cArchibald|r en el Barrio de la Guerra
    .train 201 >>Aprende Espadas de 1 mano
    .target Archibald
step << Warrior/Rogue
    .goto 1458/0,335.37,1638.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBrom|r
    .train 2575 >> Aprende |T136248:0|t[Minería]
    >>|cffff9a3cEsto te permitirá encontrar|r |T135232:0|t|cff4fc3f7[Piedras férreas]|r |cffff9a3cde nodos para fabricar|r |T135248:0|t[Piedras de afilar] |cffff9a3c(+2 Daño con arma durante 30 minutos)|r
    .target Brom Killian
step << Warrior/Rogue
    .goto 1458/0,329.04,1641.62
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSarah|r
    >>|cffe07cf5Compra un|r |T134708:0|t[Pico de minero] |cffe07cf5a|r |cff5cf05cSarah|r
    .collect 2901,1,371,1 --Mining Pick (1)
    .target Sarah Killian
    .train 2575,3 --Mining Trained
 step << Warrior/Rogue
    .goto 1458/0,295.94,1691.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBasil Frye|r
    .train 2018 >> Aprende |T136241:0|t[Herrería]
    .target Basil Frye
    .train 2575,3 --Mining Trained
step << Warlock
    .goto 1458/0,57.05,1711.77
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCarendin|r en el Barrio de la Magia
    .turnin 1473 >> Entrega la misión Criatura Abisal
    .accept 1471 >> Acepta la misión El vínculo
    .target Carendin Halgar
step << Warlock
    #completewith next
    .cast 9221 >>|cffff9a3cUsa las|r |T134416:0|t[Runas de Invocación] |cffff9a3cen el Círculo de Invocación|r
    .use 6284
step << Warlock
    .goto 1458/0,41.99,1704.480
    >>Mata al |cffff5a4aAbisario invocado|r
    .complete 1471,1 --Kill Summoned Voidwalker (1)
    .mob Summoned Voidwalker
    .use 6284
step << Warlock
    .goto 1458/0,57.34,1711.71
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCarendin|r
    .turnin 1471 >>Entrega la misión El vínculo
    .target Carendin Halgar
step << Warrior
    #ssf
    .goto 1458/0,133.71,1561.730
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCharles Seaton|r en el Barrio de los Pícaros
    >>|cffe07cf5Compra un|r |T135350:0|t[Mandoble] |cffe07cf5a este vendedor|r
    .collect 1198,1,371,1 --Collect Claymore (1)
    .money <0.2543
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<9.0
    .target Charles Seaton
step << Warrior
    #ah
    .goto 1458/0,133.71,1561.730
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCharles Seaton|r en el Barrio de los Pícaros
    >>|cffe07cf5Compra un|r |T135350:0|t[Mandoble] |cffe07cf5a este vendedor|r
    >>|cffff9a3cAlternativamente, busca en la Casa de subastas algo mejor o más barato|r
    .collect 1198,1,371,1 --Collect Claymore (1)
    .money <0.2543
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<9.0
    .target Charles Seaton
step << Warrior
    #optional
    #completewith LogoutSkip1
    +|cffff9a3cEquipa el|r |T135350:0|t[Mandoble]
    .use 1198
    .itemcount 1198,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<9.0
step << Rogue
    #ssf
    .goto 1458/0,133.71,1561.730
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCharles Seaton|r en el Barrio de los Pícaros
    >>|cffe07cf5Compra un|r |T135346:0|t[Alfanje] |cffe07cf5a este vendedor|r
    .collect 851,1,371,1 --Collect Cutlass (1)
    .money <0.1922
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<6.8
    .target Charles Seaton
step << Rogue
    #ah
    .goto 1458/0,133.71,1561.730
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCharles Seaton|r en el Barrio de los Pícaros
    >>|cffe07cf5Compra un|r |T135346:0|t[Alfanje] |cffe07cf5a este vendedor|r
    >>|cffff9a3cAlternativamente, busca en la Casa de subastas algo mejor o más barato|r
    .collect 851,1,371,1 --Collect Cutlass (1)
    .money <0.1922
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<6.8
    .target Charles Seaton
step << Rogue
    #optional
    #completewith LogoutSkip1
    +|cffff9a3cEquipa el|r |T135346:0|t[Alfanje]
    .use 851
    .itemcount 851,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<6.8
step << Rogue
    .goto 1458/0,129.68,1560.26
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cNathaniel Mechostín|r en el Barrio de los Pícaros
    >>|cffe07cf5Compra|r |T135425:0|t[Cuchillos arrojadizo cortantes] |cffe07cf5a este vendedor|r
    .collect 3107,200,371,1 --Keen Throwing Knife (200)
    .target Nathaniel Steenwick
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<6.3
    .money <0.03
step << Rogue
    #optional
    #completewith LogoutSkip1
    +|cffff9a3cRecuerda equipar los|r |T135425:0|t[Cuchillos arrojadizos cortantes] |cffff9a3ccuando llegues al nivel 11|r
    .use 3107
    .itemcount 3107,1
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<6.3
    .xp >11,1
step << Rogue
    #optional
    #completewith LogoutSkip1
    +|cffff9a3cEquípate con el|r |T135425:0|t[Cuchillo arrojadizo cortante]
    .use 3107
    .itemcount 3107,1
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<6.3
    .xp <11,1
step << Rogue
    .goto 1458/0,71.92,1435.70
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMennet|r
    .turnin 1885 >>Entrega la misión Mennet Carkad
    .accept 1886 >>Acepta la misión Los mortacechadores
    .target Mennet Carkad
step << Mage
    .goto 1458/0,168.600,1662.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOwen Thadd|r
    .turnin 79095 >>Entrega la misión Manual de metafísica del boticario
    .target Owen Thadd
    .itemcount 208185,1
step << Mage
    #optional
    .abandon 1883 >> Abandona la misión Habla con Un'thuwa, de lo contrario, no podrás aceptar la siguiente misión
    .isOnQuest 1883
step << Mage
    .goto 1458/0,56.57,1813.49
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAnastasia|r en el Barrio de la Magia
    .turnin 1881 >> Entrega la misión Habla con Anastasia
    .accept 1882 >> Acepta la misión La Hacienda Balnir
    .target Anastasia Hartwell
step << Mage
    .goto 1458/0,66.74,1766.31
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBethor|r en el Barrio de Magia
    .turnin 405 >>Entrega la misión El exánime pródigo
    --.accept 357 >>Acepta la misión La identidad del exánime
    .target Bethor Iceshard
step << Paladin
    #label UCHome
    .goto 1458/0,223.31,1634.96
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cNorman|r
    .home >> Establece tu Piedra de hogar en Entrañas
    .target Innkeeper Norman
    .bindlocation 1497
step
    #optional
    #label LogoutSkip1
step << skip
    .goto 1458/0,59.07,1747.75
    .goto 1458/0,221.78,1780.14,30 >>|cffff9a3cHaz un Logout Skip colocando a tu personaje en la parte más alta de la escalera más baja hasta que parezca que flota, luego desconecta y vuelve a entrar|r
    .link https://www.youtube.com/watch?v=-Bi95bCN8dM >> |cffff9a3cHAZ CLIC AQUÍ para ver un ejemplo|r
    >>|cffff9a3cSi no puedes hacer esto, simplemente sal de Entrañas de forma normal|r
step << !Priest
    #completewith AtWarS
    .goto 1420/0,235.32,1883.89
    .zone Tirisfal Glades >> Sal de Entrañas
    .zoneskip Tirisfal Glades
step << Undead Rogue
    #sticky
    #completewith ArriveBalnir
    >>|cffff9a3cSi ves a|r |cff5cf05cAstor|r|cffff9a3c, habla con él y mátalo. Despójalo para obtener la carta. Patrulla el camino entre Rémol y El Sepulcro|r
    .complete 1886,1 --Astor's Letter of Introduction (1)
    .unitscan Astor Hadren
    .isOnQuest 1886
step
    #optional
    .goto 1420/0,280.06,2270.70
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBurgess|r
    .turnin 374 >>Entrega la misión Prueba de defunción
    .target Deathguard Burgess
    .isQuestComplete 374
step
    #label AtWarS
    .goto 1420/0,295.87,2277.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZygand|r
    .turnin 370 >>Entrega la misión En guerra con la Cruzada Escarlata
    .accept 371 >>Acepta la misión En guerra con la Cruzada Escarlata
    .target Executor Zygand
step
    .goto 1420/0,270.12,2253.23
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cSra. Winters|r
    >>|cffe07cf5Compra una|r |T133634:0|t[Faltriquera marrón pequeña] |cffe07cf5a|r |cff5cf05cesta vendedora|r
    .collect 4496,1,356,1 --Small Brown Pouch (1)
    .target Mrs. Winters
    .money <0.05
step << Warrior
    .goto 1420/0,244.36,2262.26
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cColeman|r
    .turnin 1820 >>Entrega la misión Habla con Coleman
    .target Coleman Farthing
step
    #label Brill33
    .goto 1420/0,244.81,2269.19
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cTabernera Renee|r
    >>|cffe07cf5Compra|r |T132815:0|t[Leche fría como el hielo] |cffe07cf5a esta vendedora|r << Mage/Priest/Paladin
    >>|cffe07cf5Compra|r |T134532:0|t[Champiñones con motas rojas] |cffe07cf5a esta vendedora|r << Warrior/Rogue
    >>|cffe07cf5Compra|r |T132815:0|t[Leche fría como el hielo] |cffe07cf5y|r |T134532:0|t[Champiñones con motas rojas] |cffe07cf5a esta vendedora|r << Warlock
    .collect 1179,20,96898,1 << Mage/Priest/Paladin --Ice Cold Milk (20)
    .collect 4605,20,96898,1 << Rogue/Warrior --Red-speckled Mushroom (20)
    .collect 1179,10,96898,1 << Warlock --Ice Cold Milk (10)
    .collect 4605,10,96898,1 << Warlock --Red-speckled Mushroom (10)
    .money <0.025 << Warrior/Rogue
    .money <0.0375 << Mage/Priest/Warlock/Paladin
    .target Innkeeper Renee
step
    .goto 1420/0,54.600,1996.600
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHadric Harlson|r
    .turnin 96895 >>Entrega la misión El emisario Argenta
    .accept 96897 >>Acepta la misión El Culto de los Malditos
    .accept 96898 >>Acepta la misión Los restos de la guerra
    .target Hadric Harlson
step
    .goto 1420/0,-130.500,1907.800
    >>Mata |cffff5a4aDéspotas oscuros|r y |cffff5a4aNeófitos oscuros|r. Despójalos para obtener los |cff4fc3f7Trozos de cristal necrótico|r
    >>|cff4fc3f7Los|r Trozos de cristal necróticos|cffff9a3c también se pueden despojar del suelo|r
    >>|cffff9a3c¡Ten cuidado! Estos enemigos golpean fuerte. Los |cffff5a4aDéspotas oscuros|r también tienen una habilidad de lanzamiento instantáneo de 50-70 de daño|r
    .complete 96897,2 --|8/8 Dark Enforcer slain
    .mob +Dark Enforcer
    .complete 96897,1 --|8/8 Dark Neophyte slain
    .mob +Dark Neophyte
    .complete 96898,1 --|12/12 Necrotic Crystal Fragment
step
    .goto 1420/0,54.500,1996.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHadric Harlson|r
    .turnin 96897 >>Entrega la misión El Culto de los Malditos
    .turnin 96898 >>Entrega la misión Los restos de la guerra
    .accept 96899 >>Acepta la misión Fuerte de Bandarion
    .target Hadric Harlson
step
    #label ArriveBalnir
    .goto 1420/0,-423.96,1976.68
    .subzone 165 >>Viaja a la Hacienda Balnir
    .isOnQuest 356
step
    #completewith HorrorsandSpirits
    >>Despoja la |cffe07cf5Tumbalíseas|r del suelo
    .complete 99142,1 --|5/5 Tomb Weed
step << Mage
    #completewith next
    >>Mata |cffff5a4aHorrores sangrantes|r y |cffff5a4aEspíritus deambulantes|r
    .complete 356,1 --Bleeding Horror (8)
    .mob +Bleeding Horror
    .complete 356,2 --Wandering Spirit (8)
    .mob +Wandering Spirit
step << Mage
    .goto 1420/0,-467.79,1969.75
    >>Despoja cualquiera de las plantas en el suelo para obtener |cffe07cf5Bocas de dragón de Balnir|r
    .complete 1882,1 --Balnir Snapdragons (1)
step
    #label HorrorsandSpirits
    #loop
	.goto 1420/0,-324.55,2000.48,0
	.goto 1420/0,-324.55,2000.48,50,0
	.goto 1420/0,-330.88,2040.84,50,0
	.goto 1420/0,-359.34,2073.38,50,0
	.goto 1420/0,-421.25,2070.07,50,0
	.goto 1420/0,-464.63,2070.37,50,0
	.goto 1420/0,-516.14,2017.05,50,0
	.goto 1420/0,-466.44,1986.02,50,0
	.goto 1420/0,-436.61,1951.670,50,0
	.goto 1420/0,-355.28,1970.35,50,0
    >>Mata |cffff5a4aHorrores sangrantes|r y |cffff5a4aEspíritus deambulantes|r
    .complete 356,1 --Bleeding Horror (8)
    .mob +Bleeding Horror
    .complete 356,2 --Wandering Spirit (8)
    .mob +Wandering Spirit
step
    .goto 1420/0,-354.800,2049.000
    >>Despoja la |cffe07cf5Tumbalíseas|r del suelo
    .complete 99142,1 --|5/5 Tomb Weed
step << Paladin
    #completewith ViciousVenom
    >>|cffff9a3cGuarda 10|r |T132889:0|t[Paño de lino] |cffff9a3cpara una misión después. Asegúrate de no venderlo|r
    .collect 2589,10 --Linen Cloth (10)
step
    #sticky
    #label Friars
    #loop
    #optional
    .goto 1420/0,-624.59,2114.05,0
    .goto 1420/0,-452.43,2183.03,0
    .goto 1420/0,-573.53,2138.450,0
    .goto 1420/0,-624.59,2114.05,40,0
    .goto 1420/0,-654.87,2185.44,40,0
    .goto 1420/0,-652.16,2238.77,40,0
    .goto 1420/0,-550.49,2173.09,40,0
    .goto 1420/0,-452.43,2183.03,40,0
    .goto 1420/0,-407.69,2171.590,40,0
    .goto 1420/0,-406.34,2113.75,40,0
    .goto 1420/0,-453.33,2127.91,40,0
    .goto 1420/0,-573.53,2138.450,40,0
    >>Mata |cffff5a4aFrailes Escarlata|r y |cffff5a4aZelotes Escarlata|r. Despójalos para obtener sus |cff4fc3f7Anillos con la insignia Escarlata|r
    .complete 371,2 --Scarlet Friar (5)
    .complete 374,1 --Scarlet Insignia Ring (10)
    .mob Scarlet Friar
    .mob Scarlet Zealot
    .isOnQuest 374
step
    #loop
    #sticky
    #requires Friars
    #label Friars2
    .goto 1420/0,-624.59,2114.05,0
    .goto 1420/0,-452.43,2183.03,0
    .goto 1420/0,-573.53,2138.450,0
    .goto 1420/0,-624.59,2114.05,40,0
    .goto 1420/0,-654.87,2185.44,40,0
    .goto 1420/0,-652.16,2238.77,40,0
    .goto 1420/0,-550.49,2173.09,40,0
    .goto 1420/0,-452.43,2183.03,40,0
    .goto 1420/0,-407.69,2171.590,40,0
    .goto 1420/0,-406.34,2113.75,40,0
    .goto 1420/0,-453.33,2127.91,40,0
    .goto 1420/0,-573.53,2138.450,40,0
    >>Mata a los |cffff5a4aFrailes Escarlata|r
    .complete 371,2 --Scarlet Friar (5)
    .mob Scarlet Friar
    .isQuestTurnedIn 374
step
    .goto 1420/0,-528.35,2146.28
    >>Mata al |cffff5a4aCapitán Vachon|r dentro de la torre
    .complete 371,1 --Captain Vachon (1)
    .mob Captain Vachon
step
    #label ViciousVenom
    #requires Friars2
    #loop
    .goto 1420/0,-808.96,2189.06,0
    .goto 1420/0,-739.82,2163.75,30,0
    .goto 1420/0,-808.96,2189.06,30,0
    .goto 1420/0,-878.10,2195.39,30,0
    .goto 1420/0,-945.88,2180.93,30,0
    .goto 1420/0,-985.64,2224.00,30,0
    .goto 1420/0,-1019.99,2274.61,30,0
    .goto 1420/0,-1075.11,2314.38,30,0
    .goto 1420/0,-1072.85,2381.56,30,0
    .goto 1420/0,-1027.67,2432.17,30,0
    .goto 1420/0,-809.41,2431.26,30,0
    .goto 1420/0,-785.91,2352.64,30,0
    .goto 1420/0,-738.02,2268.29,30,0
    >>Mata |cffff5a4aNocturácnidas sañosas|r. Despójalas para obtener su |cff4fc3f7Veneno|r
    .complete 369,1 --Vicious Night Web Spider Venom (4)
    .mob Vicious Night Web Spider
step << skip
    .goto 1420/0,-38.06,2569.54
    >>Despoja |cffe07cf5Libros de Gunther|r para obtener |cff4fc3f7El libro de hechizos del Exánime|r en la isla en el Lago Aguasclaras
    .complete 357,1 --The Lich's Spellbook (1)
step
    --#hardcore
    #completewith ANewPlagueFinal
    .subzone 159 >> Viaja de vuelta a Rémol
    .subzoneskip 159
step << skip
    #softcore
    #completewith ANewPlagueFinal
    .goto 1420/0,23.85,2483.38
    .deathskip >> Muere |cffff9a3cEN LA ISLA MÁS PEQUEÑA|r y resucita en el |cff5cf05cÁngel de la Resurrección|r
step
    .goto 1420/0,346.94,2259.25
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJohaan|r
    .turnin 369 >>Entrega la misión Una nueva Peste
    .accept 492 >>Acepta la misión Una nueva Peste
    .accept 445 >>Acepta la misión Entrega a Bosque de Argénteos
    .target Apothecary Johaan
step
    .goto 1420/0,295.87,2277.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZygand|r
    .turnin 371 >>Entrega la misión En guerra con la Cruzada Escarlata
    --.accept 372 >>Acepta la misión En guerra con la Cruzada Escarlata
    .target Executor Zygand
step
    .goto 1420/0,265.15,2305.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSevren|r
    .turnin 360 >>Entrega la misión Regresa junto al magistrado
    .turnin 355 >>Entrega la misión Habla con Sevren
    .target Magistrate Sevren
step
    .goto 1420/0,280.06,2270.70
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBurgess|r
    .turnin 374 >>Entrega la misión Prueba de defunción
    .target Deathguard Burgess
step
    .goto 1420/0,244.81,2269.19
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cTabernera Renee|r
	.vendor >>|cffe07cf5Vende la basura y luego reabastécete de comida y agua si es necesario|r << !Rogue !Warrior
    .vendor >>|cffe07cf5Vende tu basura, luego reabastécete de comida si es necesario|r << Rogue/Warrior
    .target Innkeeper Renee
step
    #label ANewPlagueFinal
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cZelote Escarlata capturado|r y con el |cff5cf05cMontaraz capturado|r abajo en la parte de atrás de la posada
    .turnin 407 >>Entrega la misión Campos de pena
    .goto 1420/0,233.06,2292.39
    .target +Captured Scarlet Zealot
    .turnin 492 >> Entrega la misión Una nueva Peste
    .goto 1420/0,234.42,2289.070
    .target +Captured Mountaineer
step << Priest
    .goto 1420/0,251.14,2265.28--c:Tirisfal Glades,61.57,52.19
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBeryl|r en el segundo piso
	.trainer >> Aprende tus hechizos de clase
    .target Dark Cleric Beryl
    .xp <12,1
step << Warrior
    .goto 1420/0,238.49,2255.03--c:Tirisfal Glades,61.85,52.53
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAustil|r
    .train 7384 >>Aprende tus hechizos de clase
    .target Austil de Mon
    .xp <12,1
step << Warlock
    .goto 1420/0,250.24,2259.25--c:Tirisfal Glades,61.59,52.39
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRupert|r
    .train 755 >> Aprende tus hechizos de clase
    .target Rupert Boch
    .xp <12,1
step << Rogue
    .goto 1420/0,243.01,2270.70--c:Tirisfal Glades,61.75,52.01
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMarion|r
    .train 1766 >> Aprende tus hechizos de clase
    .target Marion Call
    .xp <12,1
step << Mage
    .goto 1420/0,233.52,2256.84--c:Tirisfal Glades,61.96,52.47
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCain|r dentro de la posada
    .train 145 >> Aprende tus hechizos de clase
    .target Cain Firesong
    .xp <12,1
step << Paladin
    .goto 1420/0,311.600,2251.000
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShari Fontana|r
    .train 678 >> Aprende tus hechizos de clase
    .target Shari Stilwell
    .xp <12,1
step
    #loop
    .goto 1420/0,425.56,2362.58,0
    .goto 1420/0,399.35,2337.270,30,0
    .goto 1420/0,425.56,2362.58,30,0
    .goto 1420/0,355.52,2429.76,30,0
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHolland|r
    >>|cffff9a3cPatrulla alrededor del cementerio|r
    .turnin 99142 >>Entrega la misión Tumbalíseas
    .target Junior Apothecary Holland

    --Bandarion Keep section

step << !Paladin
    #optional
    .maxlevel 11,BandarionKeepSkip
step
    #completewith next
    .goto 1420/0,1732.500,2437.900,50,0
    .goto 1420/0,1834.300,2424.000,50,0
    .goto 1420/0,1963.100,2340.600,50,0
    .goto 1420/0,2041.000,2352.500,50,0
    .goto 1420/0,2049.900,2463.200,50 >>Viaja al Fuerte de Bandarion
step << Paladin
    .goto 1420/0,2045.900,2475.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBreton Samuels|r
    .turnin 91282 >>Entrega la misión Segundo hogar
    .accept 91285 >>Acepta la misión Múrlocs al acecho
    .target Breton Samuels
step
    .goto 1420/0,2038.000,2490.100
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLeonid Barthalomew el Venerado|r arriba
    .turnin 96899 >>Entrega la misión Fuerte de Bandarion
    .accept 96896 >>Acepta la misión Una causa justa
    .target Leonid Barthalomew the Revered
step
    .goto 1420/0,2038.000,2490.100
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLeonid Barthalomew el Venerado|r arriba
    .turnin 96896 >>Entrega la misión Una causa justa
    .accept 98545 >>Acepta la misión Carta de Leónidas
    .target Leonid Barthalomew the Revered
step
    .goto 1420/0,2041.200,2416.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHilda, la Ultrajadora|r fuera
    .accept 99152 >>Acepta la misión Sea abajo como arriba
    .target Hilda the Breaker
step
    .goto 1420/0,2122.100,2436.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cEphram Bárbaro|r fuera
    .accept 99153 >>Acepta la misión Aquel que partió
    .target Ephram Barbaro
step << Paladin
    #loop
    .goto 1420/0,2424.200,2151.900,0
    .goto 1420/0,2212.000,2022.600,0
    .goto 1420/0,2424.200,2151.900,50,0
    .goto 1420/0,2212.000,2022.600,50,0
    >>Mata |cffff5a4aVidentes Anca Vil|r y |cffff5a4aAtacantes Anca Vil|r
    .complete 91285,2 --|8/8 Vile Fin Seer slain
    .mob +Vile Fin Seer
    .complete 91285,1 --|8/8 Vile Fin Attacker slain
    .mob +Vile Fin Attacker
step << Paladin
    .goto 1420/0,2045.800,2475.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBreton Samuels|r
    .turnin 91285 >>Entrega la misión Múrlocs al acecho
    .accept 91294 >>Acepta la misión Recorrido por las tierras
    .target Breton Samuels
    --very good weapon upgrade 8.9 dps (Wooden Mallet 5.0 dps)
step << Paladin -- paladin trainer outside
    .goto 1420/0,2038.800,2415.900
    >>Habla con |cff5cf05cHilda, la Ultrajadora|r
    .complete 91294,1 --|1/1 Speak with Hilda the Breaker
    .target Hilda the Breaker
step << Paladin --patrols the road
    .goto 1420/0,1961.100,2334.600
    >>Habla con |cff5cf05cAnder Solliden|r
    >>|cffff9a3cPatrulla el camino|r
    .complete 91294,3 --|1/1 Speak with Ander Solliden
    .target Ander Solliden
    --TODO: Patrol path
step << Paladin --inside keep
    .goto 1420/0,2007.900,2491.200
    >>Habla con |cff5cf05cJorin Croge|r
    .complete 91294,2 --|1/1 Speak with Jorin Croge
    .target Jorin Croge
step << Paladin --upstairs in keep
    .goto 1420/0,2035.100,2492.200
    >>Habla con |cff5cf05cDanitha Morr|r
    .complete 91294,4 --|1/1 Speak with Danitha Morr
    .target Danitha Morr
step << Paladin
    .goto 1420/0,2035.100,2492.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDanitha Morr|r
    .turnin 91294 >>Entrega la misión Recorrido por las tierras
    .accept 91317 >>Acepta la misión El Deslustrado
    .target Danitha Morr
step << Paladin
    .goto 1420/0,2007.800,2491.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJorin Croge|r
    .accept 91316 >>Acepta la misión Haciendo arreglos
    .target Jorin Croge
step << Paladin
    #completewith next
    >>Mata |cffff5a4aZelotes mancillados|r y |cffff5a4aEsclavos mancillados|r
    .complete 91317,3 --|6/6 Tarnished Zealot slain
    .mob +Tarnished Zealot
    .complete 91317,2 --|8/8 Tarnished Drudge slain
    .mob +Tarnished Drudge
step << Paladin
    .goto 1420/0,2514.600,1903.600
    >>Mata a |cffff5a4aRudolph Gelhardt|r arriba. Despójalo para obtener su |cff4fc3f7Cabeza|r
    .complete 91317,1 --|1/1 Rudolph Gelhardt's Head
    .mob Rudolph Gelhardt
step << Paladin
    .goto 1420/0,2487.700,1910.000
    >>Mata |cffff5a4aZelotes mancillados|r y |cffff5a4aEsclavos mancillados|r
    .complete 91317,3 --|6/6 Tarnished Zealot slain
    .mob +Tarnished Zealot
    .complete 91317,2 --|8/8 Tarnished Drudge slain
    .mob +Tarnished Drudge
step
    #label ShadowValeCrypt
    .goto 1420/0,2449.500,1857.600,10 >>Entra en la Cripta de Vallesombra
    .isOnQuest 99152,95314,99153
step
    #requires ShadowValeCrypt
    #completewith GlowingFragment
    >>Mata |cffff5a4aMerodeadores vallesombra|r y |cffff5a4aMísticos vallesombra|r. Despójalos para obtener sus |cff4fc3f7Huesos con resplandor tenue|r
    .complete 99152,1 --|6/6 Faintly Glowing Bone
    .mob Shadowvale Lurcher
    .mob Shadowvale Mystic
step
    #requires ShadowValeCrypt
    #completewith GlowingBones
    >>Despoja los |cffe07cf5Montones de madera|r del suelo << Paladin
    >>Despoja las |cffe07cf5Botellas de elixir susurrante|r en el suelo y en las paredes
    .complete 91316,1 << Paladin--|12/12 Sturdy Lumber
    .complete 95314,1 --|8/8 Bottle of Whispering Elixir
step
    .goto 1420/0,2648.100,2027.200
    .use 268812 >>Mata al |cffff5a4aHorror susurrante|r (élite). Despójalo para obtener |T134438:0|t[|cff4fc3f7Residuo de horror susurrante|r]
    >>|cffff9a3c¡Esto es difícil! Únete a un grupo si es posible. Tiene 700 de salud, pero su daño es manejable. Omite este paso si no puedes matarlo|r
    .collect 268812,1,95328 --Whispering Horror Residue (x1)
    .accept 95328 >>Acepta la misión Residuo de horror susurrante
    .mob Whispering Horror
step
    #requires ShadowValeCrypt
    #label GlowingFragment
    .goto 1420/0,2592.400,1748.400
    >>Despoja el |cffe07cf5Fragmento de cristal resplandeciente|r del suelo
    .complete 99153,1 --|1/1 Glowing Crystal Fragment
step
    #requires ShadowValeCrypt
    #label GlowingBones
    .goto 1420/0,2556.100,1868.800
    >>Mata |cffff5a4aMerodeadores vallesombra|r y |cffff5a4aMísticos vallesombra|r. Despójalos para obtener sus |cff4fc3f7Huesos con resplandor tenue|r
    .complete 99152,1 --|6/6 Faintly Glowing Bone
    .mob Shadowvale Lurcher
    .mob Shadowvale Mystic
step
    #requires ShadowValeCrypt
    .goto 1420/0,2647.800,1815.500
    >>Despoja los |cffe07cf5Montones de madera|r del suelo << Paladin
    >>Despoja las |cffe07cf5Botellas de elixir susurrante|r en el suelo y en las paredes
    .complete 91316,1 << Paladin--|12/12 Sturdy Lumber
    .complete 95314,1 --|8/8 Bottle of Whispering Elixir
step << skip
    #softcore
    #completewith next
    .deathskip >> Muere y reaparece en el |cff5cf05cÁngel de la Resurrección|r
step
    .goto 1420/0,2037.100,2416.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHilda, la Ultrajadora|r
    .turnin 99152 >>Entrega la misión Sea abajo como arriba
    .target Hilda the Breaker
step
    .goto 1420/0,2122.500,2436.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cEphram Bárbaro|r
    .turnin 99153 >>Entrega la misión Aquel que partió
    .target Ephram Barbaro
step << Paladin
    .goto 1420/0,2008.000,2491.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJorin Croge|r
    .turnin 91316 >>Entrega la misión Haciendo arreglos
    .target Jorin Croge
step << Paladin
    .goto 1420/0,2035.100,2492.000
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDanitha Morr|r
    .turnin 91317 >>Entrega la misión El Deslustrado
    .accept 95803 >>Acepta la misión Una muestra de buena fe
    .accept 94427 >>Acepta la misión Una lección de divinidad
    .target Danitha Morr
step << !Paladin
    #completewith BrillTurnin2
    .hs >> Usa tu Piedra de Hogar para ir a Rémol
    .subzoneskip 159
    .bindlocation 1497,1
    .cooldown item,6948,>0,1
step << !Paladin
    #completewith BrillTurnin2
    .subzone 159 >> Viaja de vuelta a Rémol
    .subzoneskip 159
    .cooldown item,6948,<0
step << Priest
    .goto 1420/0,251.14,2265.28--c:Tirisfal Glades,61.57,52.19
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBeryl|r en el segundo piso
	.trainer >> Aprende tus hechizos de clase
    .target Dark Cleric Beryl
    .xp <12,1
step << Warrior
    .goto 1420/0,238.49,2255.03--c:Tirisfal Glades,61.85,52.53
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAustil|r
    .train 7384 >>Aprende tus hechizos de clase
    .target Austil de Mon
    .xp <12,1
step << Warlock
    .goto 1420/0,250.24,2259.25--c:Tirisfal Glades,61.59,52.39
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRupert|r
    .train 755 >> Aprende tus hechizos de clase
    .target Rupert Boch
    .xp <12,1
step << Rogue
    .goto 1420/0,243.01,2270.70--c:Tirisfal Glades,61.75,52.01
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMarion|r
    .train 1766 >> Aprende tus hechizos de clase
    .target Marion Call
    .xp <12,1
step << Mage
    .goto 1420/0,233.52,2256.84--c:Tirisfal Glades,61.96,52.47
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCain|r dentro de la posada
    .train 145 >> Aprende tus hechizos de clase
    .target Cain Firesong
    .xp <12,1
step << !Paladin
    .goto 1420/0,347.600,2265.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCarolai Anís|r
    .turnin 95314 >>Entrega la misión Aquel elixir verde de Vallesombra
    .target Carolai Anise
step << Priest
    #optional
    .goto 1420/0,251.14,2265.28--c:Tirisfal Glades,61.57,52.19
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBeryl|r en el segundo piso
	.trainer >> Aprende tus hechizos de clase
    .target Dark Cleric Beryl
    .xp <12,1
step << Warrior
    #optional
    .goto 1420/0,238.49,2255.03--c:Tirisfal Glades,61.85,52.53
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAustil|r
    .train 7384 >>Aprende tus hechizos de clase
    .target Austil de Mon
    .xp <12,1
step << Warlock
    #optional
    .goto 1420/0,250.24,2259.25--c:Tirisfal Glades,61.59,52.39
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRupert|r
    .train 755 >> Aprende tus hechizos de clase
    .target Rupert Boch
    .xp <12,1
step << Rogue
    #optional
    .goto 1420/0,243.01,2270.70--c:Tirisfal Glades,61.75,52.01
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMarion|r
    .train 1766 >> Aprende tus hechizos de clase
    .target Marion Call
    .xp <12,1
step << Mage
    #optional
    .goto 1420/0,233.52,2256.84--c:Tirisfal Glades,61.96,52.47
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCain|r dentro de la posada
    .train 145 >> Aprende tus hechizos de clase
    .target Cain Firesong
    .xp <12,1
step
    #optional
    #label BandarionKeepSkip
step << Rogue
    #completewith EnterUC2
    >>|cffff9a3cSi ves a|r |cff5cf05cAstor|r|cffff9a3c, habla con él y mátalo. Despójalo para obtener la carta. Patrulla el camino entre Rémol y El Sepulcro|r
    .complete 1886,1 --Astor's Letter of Introduction (1)
    .unitscan Astor Hadren
    .isOnQuest 1886
step << !Paladin
    #label BrillTurnin2
    .goto 1420/0,74.00,2022.47
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLinnea|r
    .turnin 356 >>Entrega la misión Patrulla de la retaguardia
    .target Deathguard Linnea
step << !Paladin
    .goto 1420/0,73.800,2022.300
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cGuardia de la Muerte Linnea::1495|r
    >>|cffff9a3cEsta es una misión previa para "La furia de Rath'mael"|r
    .turnin 356 >>Entrega la misión Patrulla de la retaguardia
    .target Deathguard Linnea::1495
    .accept 99156 >>Acepta la misión Patrulla de la retaguardia
    .dungeon ROL
step << !Paladin
    .goto 1420/0,-765.200,2518.700
    >>Mata al |cffff5a4aRasgallanto|r |cffff9a3c(nivel 13 élite)|r. Despójalo para obtener |T134339:0|t[|cff4fc3f7Riptear's Corazón|r]
    >>|cffff9a3cEsta es una misión previa para "La furia de Rath'mael"|r
    .complete 99156,1 --|1/1 Riptear's Heart
    .mob Riptear
    .dungeon ROL
step << !Paladin
    .goto 1420/0,74.200,2022.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cGuardia de la Muerte Linnea::1495|r
    >>|cffff9a3cEsta es una misión previa para "La furia de Rath'mael"|r
    .turnin 99156 >>Entrega la misión Patrulla de la retaguardia
    .target Deathguard Linnea::1495
    .dungeon ROL
step << !Paladin
    #label EnterUC2
    #completewith Glix
    .goto 1420/0,240.75,1877.57,20 >> Entra en Entrañas
    .zoneskip Undercity
step << !Paladin
    #completewith Glix
    .goto 1458/0,239.14,1749.54,35,0
    .goto 1458/0,255.64,1724.70,35,0
    .goto 1458/0,240.68,1706.97,10,0
    .goto 1458/0,241.06,1660.12,10,0
    .goto 1458/0,257.08,1623.38,10,0
    .goto 1458/0,244.51,1598.73,15 >> Toma el ascensor para bajar a Entrañas
step << !Paladin
    .goto 1458/0,223.31,1634.96
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cNorman|r
    .home >> Establece tu Piedra de hogar en Entrañas
    .target Innkeeper Norman
    .bindlocation 1497
step << Paladin
    #completewith Glix
    .hs >> Usa tu Piedra de hogar para ir a Entrañas
    .cooldown item,6948,>0,1
    .bindlocation 1497,1
    .zoneskip Undercity
step << Paladin --trade quarter
    .goto 1458/0,245.300,1637.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTanis Alisero|r
    >>|cffff9a3cAsegúrate de tener 10|r |T132889:0|t[Paño de lino] |cffff9a3cen tu bolsa|r
    .turnin 94427 >>Entrega la misión Una lección de divinidad
    .accept 94434 >>Acepta la misión Una lección de divinidad
    .turnin 94434 >>Entrega la misión Una lección de divinidad
    .accept 94435 >>Acepta la misión Una lección de divinidad
    .target Tanis Alderwood
step
    #label Glix
    .goto 1458/0,201.400,1575.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGlix Xizzix|r
    .turnin 98545 >>Entrega la misión Carta de Leónidas
    .target Glix Xizzix
    .isOnQuest 98545
step << Rogue
    #ssf
    .goto 1458/0,133.71,1561.730
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCharles Seaton|r en el Barrio de los Pícaros
    >>|cffe07cf5Compra un|r |T135346:0|t[Alfanje] |cffe07cf5a este vendedor|r
    .collect 851,1,372,1 --Collect Cutlass (1)
    .money <0.1922
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<6.8
    .target Charles Seaton
step << Rogue
    #ah
    .goto 1458/0,133.71,1561.730
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCharles Seaton|r en el Barrio de los Pícaros
    >>|cffe07cf5Compra un|r |T135346:0|t[Alfanje] |cffe07cf5a este vendedor|r
    >>|cffff9a3cAlternativamente, busca en la Casa de subastas algo mejor o más barato|r
    .collect 851,1,372,1 --Collect Cutlass (1)
    .money <0.1922
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<6.8
    .target Charles Seaton
step << Rogue
    #optional
    #completewith CaptainMelrache
    +|cffff9a3cEquipa el|r |T135346:0|t[Alfanje]
    .use 851
    .itemcount 851,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<6.8
step << Warrior
    #ssf
    .goto 1458/0,133.71,1561.730
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCharles Seaton|r en el Barrio de los Pícaros
    >>|cffe07cf5Compra un|r |T135350:0|t[Mandoble] |cffe07cf5a este vendedor|r
    .collect 1198,1,372,1 --Collect Claymore (1)
    .money <0.2543
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<9.0
    .target Charles Seaton
step << Warrior
    #ah
    .goto 1458/0,133.71,1561.730
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCharles Seaton|r en el Barrio de los Pícaros
    >>|cffe07cf5Compra un|r |T135350:0|t[Mandoble] |cffe07cf5a este vendedor|r
    >>|cffff9a3cAlternativamente, busca en la Casa de subastas algo mejor o más barato|r
    .collect 1198,1,372,1 --Collect Claymore (1)
    .money <0.2543
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<9.0
    .target Charles Seaton
step << Warrior
    #optional
    #completewith CaptainMelrache
    +|cffff9a3cEquipa el|r |T135350:0|t[Mandoble]
    .use 1198
    .itemcount 1198,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<9.0
step
    #ah
    .goto 1458/0,224.300,1648.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cSubastador Cain|r
    >>|cffe07cf5Compra tres|r |T133884:0|t[Ojos de múrloc] |cffe07cf5en la Casa de subastas|r
    >>|cffff9a3cOmitir esto si quieres, es solo un pequeño ahorro de tiempo|r
    .collect 730,3,91920,1 --Collect Murloc Eyes (x3)
    .target Auctioneer Cain
step << Mage
    .goto 1458/0,56.57,1813.49
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAnastasia|r en el Barrio de la Magia
    .turnin 1882 >>Entrega la misión La Hacienda Balnir
    .target Anastasia Hartwell
step << Rogue
    .goto 1458/0,71.92,1435.630
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMennet|r
    .turnin 1886 >>Entrega la misión Los mortacechadores
    .target Mennet Carkad
    .isQuestComplete 1886
step << Rogue
    .goto 1458/0,71.92,1435.630
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMennet|r
    .accept 1898 >>Acepta la misión Los mortacechadores
    .target Mennet Carkad
    .isQuestTurnedIn 1886
step << Rogue
    .goto 1458/0,347.07,1389.48
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAndron|r
    .turnin 1898 >>Entrega la misión Los mortacechadores
    .accept 1899 >>Acepta la misión Los mortacechadores
    .target Andron Gant
    .isQuestTurnedIn 1886
step << Rogue
    .goto 1458/0,341.41,1385.90
    >>Despoja la |cffe07cf5Estantería de Andron|r detrás de |cff5cf05cAndron|r
    .complete 1899,1 --Andron's Ledger (1)
    .isQuestTurnedIn 1886
step << Rogue
    .goto 1458/0,71.83,1435.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMennet|r
    .turnin 1899 >>Entrega la misión Los mortacechadores
    .accept 1978 >>Acepta la misión Los mortacechadores
    .target Mennet Carkad
    .isQuestTurnedIn 1886
step << Rogue
    .goto 1420/0,373.60,1464.85,40,0
    .goto 1420/0,333.38,1287.72
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVarimathras|r
    .turnin 1978 >>Entrega la misión Los mortacechadores
    .target Varimathras
    .isQuestTurnedIn 1886
step
    .goto 1458/0,399.800,1776.600
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cPadre Lankester|r
    .turnin 95328 >>Entrega la misión Residuo de horror susurrante
    .target Father Lankester
    .isOnQuest 95328
step << Priest
    #ah
    .goto 1458/0,257.27,1560.450
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cSubastadora Rhyker|r
    >>|cffe07cf5Compra una|r |T135139:0|t[Varita mágica inferior] |cffe07cf5de la Casa de Subastas|r
    >>|cffff9a3cSi haces esto y estabas reuniendo|r |T132889:0|t[Paño de lino] |cffff9a3cantes, puedes vender tu|r |T132889:0|t[Paño de lino] |cffff9a3cen la Casa de Subastas|r
    >>|cffff9a3cSi no quieres o no puedes hacer esto, omite este paso|r
    .collect 11287,1,435,1 --Lesser Magic Wand (1)
    .target Auctioneer Rhyker
    .itemStat 18,QUALITY,<7 << Priest/Mage/Warlock
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.3 << Priest/Mage/Warlock
step << Priest
    #optional
    .goto 1458/0,403.29,1760.61
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAelthalyste|r
    .turnin 5658 >> Entrega la misión Toque de debilidad
    .target Aelthalyste
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.3
    .train 2652,1 --Touch of Weakness not trained
step << Priest
    #optional
    .goto 1458/0,201.05,1686.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVictor|r
    .train 3908 >> Aprende |T136249:0|t[Sastrería]
    .target Victor Ward
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.3
step << Priest
    #optional
    .goto 1458/0,194.34,1681.63
    >>|cffff9a3cConvierte todos tus|r |T132889:0|t[Paño de lino] |cffff9a3cen|r |T132890:0|t[Madeja de paño de lino]
    .collect 2996,30,435,1 --Bolt of Linen Cloth (30)
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.3
step << Priest
    #optional
    .goto 1458/0,201.05,1686.94
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVictor|r
    .train 7623 >> Aprende |T132662:0|t[Toga de lino marrón]
    .target Victor Ward
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.3
step << Priest
    #optional
    .goto 1458/0,196.16,1684.83
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMillie|r
    >>|cffe07cf5Compra|r |T132891:0|t[Hilo burdo] |cffe07cf5a esta vendedora|r
    .collect 2320,30,435,1 --Coarse Thread (30)
    .target Millie Gregorian
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.3
step << Priest
    #optional
    >>|cffff9a3cCrea tantas|r |T132662:0|t[Togas de lino marrón] |cffff9a3ccomo puedas|r
    .collect 6238,9,398,1 --Brown Linen Robe(9)
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.3
step << Priest
    #optional
    .goto 1458/0,273.87,1482.360
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLavinia|r
    .train 7411 >> Aprende |T136244:0|t[Encantamiento]
    .target Lavinia Crowe
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.3
step << Priest
    #optional
    .goto 1458/0,275.02,1487.55
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|t|cffe07cf5Habla con|r |cff5cf05cThaddeus|r|cffe07cf5. Compra una|r |T133942:0|t[Vara de cobre] |cffe07cf5y|r |T135435:0|t[Madera simple] |cffe07cf5a este vendedor|r
    >>|cffff9a3cDesencanta todas las|r |T132662:0|t[Togas de lino marrón] |cffff9a3cque hiciste y crea una|r |T135225:0|t[Vara rúnica de cobre]
    >>|cffff9a3cSi no obtuviste una|r |T132867:0|t[Esencia mágica inferior] |cffff9a3centonces compra una de|r |cff5cf05cThaddeus|r |cffff9a3csi hay una disponible. De lo contrario termina este paso más tarde|r
    .collect 6218,1,435,1 --Runed Copper Rod (1)
    .collect 4470,1,435,1 --Simple Wood (1)
    .target Thaddeus Webb
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.3
step << Priest
    #optional
    .goto 1458/0,273.2,1491.71
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMalcomb|r
    .train 14293 >> Aprende |T135139:0|t[Varita mágica inferior]
    .target Malcomb Wynn
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.3
step << Priest
    #optional
    #label LesserMagicWand
    >>|cffff9a3cCrea una|r |T135139:0|t[Varita mágica inferior]
    >>|cffff9a3cSi no obtuviste una|r |T132867:0|t[Esencia mágica inferior] |cffff9a3centonces compra una de|r |cff5cf05cThaddeus|r |cffff9a3csi hay una disponible. De lo contrario termina este paso más tarde|r
    .collect 11287,1,435,1 --Lesser Magic Wand (1)
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.3
step << Priest
    #optional
    #completewith Entersilverpine
    +|cffff9a3cEquipa la|r |T135139:0|t[Varita mágica inferior]
    .use 11287
    .itemcount 11287,1
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<11.3
step << Paladin
    #completewith next
    .goto 1458/0,374.41,1464.82,10,0--c:Undercity,51.99,64.54
    .goto 1458/0,429.48,1409.26,10,0--c:Undercity,46.25,73.22
    .goto 1458/0,438.40,1376.62,10,0--c:Undercity,45.32,78.32
    .goto 1458/0,429.39,1340.83,10,0--c:Undercity,46.26,83.91
    .goto 1458/0,402.81,1315.17,10,0--c:Undercity,49.03,87.92
    .goto 1458/0,365.30,1304.41,10 >>Entra en el Barrio Real--c:Undercity,52.94,89.60
step << Paladin
    .goto 1458/0,316.200,1290.600
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLady Sylvanas Brisaveloz|r
    .turnin 95803 >>Entrega la misión Una muestra de buena fe
    .target Lady Sylvanas Windrunner

    --Paladin Ressurrect chain route

step << Paladin
    #completewith
    .goto 1420/0,235.32,1883.89
    .zone Tirisfal Glades >> Sal de Entrañas
    .zoneskip Tirisfal Glades
step << Paladin
    .goto 1420/0,74.00,2022.47
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLinnea|r
    .turnin 356 >>Entrega la misión Patrulla de la retaguardia
    .target Deathguard Linnea
step << Paladin
    .goto 1420/0,73.800,2022.300
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cGuardia de la Muerte Linnea::1495|r
    >>|cffff9a3cEsta es una misión previa para "La furia de Rath'mael"|r
    .turnin 356 >>Entrega la misión Patrulla de la retaguardia
    .target Deathguard Linnea::1495
    .accept 99156 >>Acepta la misión Patrulla de la retaguardia
    .dungeon ROL
step << Paladin
    .goto 1420/0,-765.200,2518.700
    >>Mata al |cffff5a4aRasgallanto|r |cffff9a3c(nivel 13 élite)|r. Despójalo para obtener |T134339:0|t[|cff4fc3f7Riptear's Corazón|r]
    >>|cffff9a3cEsta es una misión previa para "La furia de Rath'mael"|r
    .complete 99156,1 --|1/1 Riptear's Heart
    .mob Riptear
    .dungeon ROL
step << Paladin
    .goto 1420/0,74.200,2022.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cGuardia de la Muerte Linnea::1495|r
    >>|cffff9a3cEsta es una misión previa para "La furia de Rath'mael"|r
    .turnin 99156 >>Entrega la misión Patrulla de la retaguardia
    .target Deathguard Linnea::1495
    .dungeon ROL
step << Paladin
    .goto 1420/0,311.600,2251.000
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShari Fontana|r
    .train 678 >> Aprende tus hechizos de clase
    .target Shari Stilwell
    .xp <12,1
step << Paladin
    .goto 1420/0,347.600,2265.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCarolai Anís|r
    .turnin 95314 >>Entrega la misión Aquel elixir verde de Vallesombra
    .target Carolai Anise
step << Paladin
    #completewith RessComplete
    +|cffff9a3cAhora realizarás la cadena de misiones para tu habilidad|r |T135955:0|t[Redención] |cffff9a3c. Esto llevará ~15 minutos y no dará mucha experiencia|r
    >>|cffff9a3cPuedes omitir esto por ahora y volver más tarde si lo deseas|r
step << Paladin
    #completewith next
    .goto 1420/0,1732.500,2437.900,50,0
    .goto 1420/0,1834.300,2424.000,50,0
    .goto 1420/0,1963.100,2340.600,50,0
    .goto 1420/0,2041.000,2352.500,50,0
    .goto 1420/0,2049.900,2463.200,50 >>Viaja al Fuerte de Bandarion
step << Paladin
    .goto 1420/0,2035.100,2492.100
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDanitha Morr|r
    .turnin 94435 >>Entrega la misión Una lección de divinidad
    .accept 94436 >>Acepta la misión Una lección de divinidad
    .target Danitha Morr
step << Paladin
    .goto 1420/0,2043.400,2497.300
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGuardia de la Muerte Billmuth|r
    .turnin 94436 >>Entrega la misión Una lección de divinidad
    .accept 94438 >>Acepta la misión Una lección de divinidad
    .target Deathguard Billmuth
    .isOnQuest 94436
step << Paladin
    #optional
    .goto 1420/0,2043.400,2497.300
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGuardia de la Muerte Billmuth|r
    .accept 94438 >>Acepta la misión Una lección de divinidad
    .target Deathguard Billmuth
    .isQuestTurnedIn 94436

    --East Tirisfal south of SM

step << Paladin
    #completewith next
    .goto 1420/0,-885.200,2399.800,50 >>Viaja al este de Claros de Tirisfal
step << Paladin
    #completewith next
    .cast 8593 >>|cffff9a3cUsa el|r |T133439:0|t[Símbolo de la vida] |cffff9a3cen el|r |cff5cf05cGuardia de la Muerte Falgan|r
    .use 6866
    .target Deathguard Falgan
step << Paladin
    .goto 1420/0,-885.200,2399.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGuardia de la Muerte Falgan|r
    .turnin 94438 >>Entrega la misión Una lección de divinidad
    .accept 94440 >>Acepta la misión Una lección de divinidad
    .target Deathguard Falgan
    .isQuestTurnedIn 94436
step << Paladin
    .goto 1420/0,-889.700,2531.400
    >>Mata |cffff5a4aFrailes Escarlata|r y |cffff5a4aZelotes Escarlata|r. Despójalos para obtener los |cff4fc3f7Planes de ataque de la Cruzada Escarlata|r
    .complete 94440,1 --|1/1 Scarlet Crusade Attack Plans
    .mob Scarlet Friar
    .mob Scarlet Zealot
    .isQuestTurnedIn 94436

    --Back to Bandarion Keep

step << Paladin
    #completewith next
    .goto 1420/0,1732.500,2437.900,50,0
    .goto 1420/0,1834.300,2424.000,50,0
    .goto 1420/0,1963.100,2340.600,50,0
    .goto 1420/0,2041.000,2352.500,50,0
    .goto 1420/0,2049.900,2463.200,50 >>Viaja al Fuerte de Bandarion
step << Paladin
    .goto 1420/0,2043.500,2497.300
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGuardia de la Muerte Billmuth|r
    .turnin 94440 >>Entrega la misión Una lección de divinidad
    .accept 94441 >>Acepta la misión Una lección de divinidad
    .target Deathguard Billmuth
    .isQuestTurnedIn 94436
step << Paladin
    #label RessComplete
    .goto 1420/0,2034.900,2492.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDanitha Morr|r
    .turnin 94441 >>Entrega la misión Una lección de divinidad
    .target Danitha Morr
    .isQuestTurnedIn 94436
step << !Paladin
    #completewith Entersilverpine
    #optional
    .abandon 96899 >>Abandona la misión Fuerte de Bandarion
step << !Paladin
    #completewith Entersilverpine
    #optional
    .abandon 95314 >>Abandona la misión Aquel elixir verde de Vallesombra
step << !Paladin
    #completewith next
    .goto 1458/0,419.89,1627.54,50,0
    .goto 1458/0,428.52,1597.20,10,0
    .goto 1458/0,439.17,1626.06,10,0
    .goto 1458/0,476.78,1632.150,10,0
    .goto 1458/0,482.34,1660.63,10,0
    .goto 1458/0,539.33,1665.49,15,0
    .goto 1458/0,610.42,1684.44,35,0
    .goto 1458/0,663.19,1600.46,35,0
    .goto 1420/0,724.25,1682.66,50,0
    .zone Tirisfal Glades >> Abandona Entrañas por las Cloacas
step
    #label Entersilverpine
    .goto 1420/0,629.36,1553.42
    .zone Silverpine Forest >> Viaja al Bosque de Argénteos
]=], "Horde"}
R[#R + 1] = {[=[
#group Guía Forever (H)
#subgroup Guía Speedrun 1-22
<< Horde
#version 11
#defaultfor !Hunter !Shaman !Tauren
#forever
#disabledungeons
#name 12-14 Bosque de Argénteos
#displayname 13-15 Bosque de Argénteos << Paladin
#next 12-17 Los Baldíos

step << Undead Rogue
    #sticky
    #completewith RotHideCluesTurnIn
    >>|cffff9a3cSi ves a|r |cff5cf05cAstor|r|cffff9a3c, habla con él y mátalo. Despójalo para obtener la carta. Patrulla el camino entre Rémol y El Sepulcro|r
    .complete 1886,1 --Astor's Letter of Introduction (1)
    .unitscan Astor Hadren
step
    .goto 1421/0,1090.44,1409.63
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cMortacechador Erland|r para comenzar la escolta
    >>|cffff9a3cSi no está allí, omite esta misión por ahora|r
    .accept 435,1 >>Acepta la misión Escolta a Erland
    .target Deathstalker Erland
step
    .goto 1421/0,1087.50,1379.11,30,0
    .goto 1421/0,1087.50,1346.63,30,0
    .goto 1421/0,1090.86,1313.31,30,0
    .goto 1421/0,1204.68,1290.07
    >>Escolta a |cff5cf05cErland|r de forma segura hasta |cff5cf05cRane Yorick|r
    >>|cffff5a4aHuargos|r |cffff9a3cpueden aparecer uno encima del otro, come y bebe siempre que puedas|r
    .complete 435,1 --Erland must reach Rane Yorick (1)
    .mob Worg
    .isOnQuest 435
step
    .goto 1421/0,1204.68,1290.07
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRane Yorick|r
    .turnin 435 >>Entrega la misión Escolta a Erland
    .accept 429 >>Acepta la misión Corazones salvajes
    .accept 449 >>Acepta la misión El informe de los Mortacechadores
    .target Rane Yorick
    .isQuestComplete 435
step
    #optional
    .goto 1421/0,1204.68,1290.07
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRane Yorick|r
    .accept 429 >>Acepta la misión Corazones salvajes
    .target Rane Yorick
step
    #completewith Escort2
    >>Mata |cffff5a4aHuargos|r. Despójalos para obtener sus |cff4fc3f7Corazones|r
    .collect 3164,3,429,1 --Collect Discolored Worg Heart (x6)
    .mob Worg
    .mob Mottled Worg
    .unitscan Gorefang
step
    #loop
    .goto 1421/0,941.300,1210.400,0
    .goto 1421/0,706.700,1317.400,0
    .goto 1421/0,941.300,1210.400,50,0
    .goto 1421/0,830.000,1309.400,50,0
    .goto 1421/0,706.700,1317.400,50,0
    >>Mata |cffff5a4aMúrlocs Anca Vil|r. Despójalos para obtener sus |T133884:0|t[|cff4fc3f7Ojos de múrloc|r]
    .collect 730,3,91920,1 --Collect Murloc Eyes (x3)
    .mob Vile Vin Shredder
    .mob Vile Vin Tidehunter
step
    .goto 1421/0,1090.44,1409.63
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cMortacechador Erland|r para comenzar la escolta
    .accept 435,1 >>Acepta la misión Escolta a Erland
    .target Deathstalker Erland
step
    #label Escort2
    .goto 1421/0,1087.50,1379.11,30,0
    .goto 1421/0,1087.50,1346.63,30,0
    .goto 1421/0,1090.86,1313.31,30,0
    .goto 1421/0,1204.68,1290.07
    >>Escolta a |cff5cf05cErland|r de forma segura hasta |cff5cf05cRane Yorick|r
    >>|cffff5a4aHuargos|r |cffff9a3cpueden aparecer uno encima del otro, come y bebe siempre que puedas|r
    .complete 435,1 --Erland must reach Rane Yorick (1)
    .mob Worg
    .isOnQuest 435
step
    #loop
    .goto 1421/0,1025.76,1384.71,0
    .goto 1421/0,1099.68,1213.63,50,0
    .goto 1421/0,998.46,1230.99,50,0
    .goto 1421/0,955.2,1286.43,50,0
    .goto 1421/0,925.38,1372.39,50,0
    .goto 1421/0,1025.76,1384.71,50,0
    >>Mata |cffff5a4aHuargos|r. Despójalos para obtener sus |cff4fc3f7Corazones|r
    .collect 3164,3,429,1 --Collect Discolored Worg Heart (x6)
    .mob Worg
    .mob Mottled Worg
    .unitscan Gorefang
step
    .goto 1421/0,1204.68,1290.07
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRane Yorick|r
    .turnin 435 >>Entrega la misión Escolta a Erland
    .accept 449 >>Acepta la misión El informe de los Mortacechadores
    .target Rane Yorick
step << skip
    #softcore
    #completewith ProveyourWorth
    .deathskip >> Muere y reaparece en el |cff5cf05cÁngel de la Resurrección|r
step
    --#hardcore
    #completewith next
    .goto 1421/0,1359.66,864.19,50,0
    .goto 1421/0,1359.66,741.27,50,0
    .goto 1421/0,1365.12,607.15,100,0
    .goto 1421/0,1538.58,511.39,100 >> Viaja a El Sepulcro
    .subzoneskip 228
step
    #label ProveyourWorth
    .goto 1421/0,1593.6,554.23
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDalar|r
    .accept 421 >>Acepta la misión Demuestra tu valía
    .target Dalar Dawnweaver
step << !Mage !Priest
    .goto 1421/0,1599.90,552.83
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGwyn|r
    .vendor >> |cffe07cf5Compra|r |T134532:0|t[Champiñón con motas rojas] |cffe07cf5a este vendedor|r
    >>|cffff9a3cNO vendas tus|r |T133884:0|t[|cff4fc3f7Ojos de múrloc|r]
    .collect 4605,20,421,1 --Red-speckled Mushroom (20)
    .target Gwyn Farrow
    .money <0.05
step
    .goto 1421/0,1602.84,549.75
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cEdwin|r
    >>|cffe07cf5Compra|r |T132815:0|t[Leche fría como el hielo] |cffe07cf5a este vendedor|r << Mage/Warlock/Priest/Shaman/Druid
    .vendor >> |cffe07cf5Cómprale|r |T134830:0|t[Pociones menores de sanación] |cffe07cf5si están disponibles|r
    >>|cffff9a3cNO vendas tus|r |T133884:0|t[|cff4fc3f7Ojos de múrloc|r]
    .collect 1179,20,421,1 << Mage/Warlock/Priest/Shaman/Druid --Ice Cold Milk (20)
    .target Edwin Harly
    .money <0.05 << Mage/Warlock/Priest/Shaman/Druid
step << Undead
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAllister|r y |cff5cf05cPodrig|r
    .accept 477 >>Acepta la misión Pasa la frontera
    .target +Shadow Priest Allister
    .goto 1421/0,1602.84,520.63
    .accept 6321 >>Acepta la misión Suministros para El Sepulcro
    .target +Deathguard Podrig
    .goto 1421/0,1625.94,499.91
step
    #label BorderCrossings
    .goto 1421/0,1602.84,520.63
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAllister|r
    .accept 477 >>Acepta la misión Pasa la frontera
    .target Shadow Priest Allister
step
    #completewith next
    .goto 1421/0,1640.22,509.43,8,0
    .goto 1421/0,1654.50,510.270,8,0
    .goto 1421/0,1654.08,521.470,8,0
    .goto 1421/0,1625.94,522.31,2 >> Entra en la cripta
step
    .goto 1421/0,1625.94,522.31
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHadrec|r en la cripta
    .turnin 449 >>Entrega la misión El informe de los Mortacechadores
    .accept 3221 >>Acepta la misión Habla con Renferrel
    .accept 437 >>Acepta la misión El Campo Muerto
    .target High Executor Hadrec
step << Mage/Priest/Warlock
    .goto 1421/0,1626.100,511.500
    >>Despoja el |cffe07cf5Libro Luminoso|r en el suelo
    .collect 210177,1,79096,1 --Ataeric: On Arcane Curiosities
    --Other classes won't be nearby turnin in UC, probably not worth since it's only 160xp
step
    .goto 1421/0,1652.82,522.31
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRenferrel|r
    .turnin 429 >>Entrega la misión Corazones salvajes
    .turnin 445 >>Entrega la misión Entrega a Bosque de Argénteos
    .turnin 3221 >>Entrega la misión Habla con Renferrel
    .accept 1359 >>Acepta la misión Una entrega de Zinge
    .accept 447 >>Acepta la misión Una fórmula mortal
    .accept 430 >>Acepta la misión Regresa junto a Quinn
    .target Apothecary Renferrel
    .addquestitem 3164,429
    .isOnQuest 445
step
    #optional
    .goto 1421/0,1652.82,522.31
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRenferrel|r
    .turnin 429 >>Entrega la misión Corazones salvajes
    .turnin 3221 >>Entrega la misión Habla con Renferrel
    .accept 1359 >>Acepta la misión Una entrega de Zinge
    .accept 447 >>Acepta la misión Una fórmula mortal
    .accept 430 >>Acepta la misión Regresa junto a Quinn
    .target Apothecary Renferrel
    .addquestitem 3164,429
step
    #completewith next
    >>Mata |cffff5a4aOsos|r. Despójalos para obtener sus|cff4fc3f7Corazones|r
    .complete 447,1 --Grizzled Bear Heart (6)
    .mob Ferocious Grizzled Bear
step
    #loop
    .goto 1421/0,1386.96,638.51,0
    .goto 1421/0,1336.56,568.51,50,0
    .goto 1421/0,1271.88,502.99,50,0
    .goto 1421/0,1285.74,460.99,50,0
    .goto 1421/0,1281.96,410.87,50,0
    .goto 1421/0,1274.4,361.87,50,0
    .goto 1421/0,1315.14,329.95,50,0
    .goto 1421/0,1386.96,638.51,50,0
    >>Mata |cffff5a4aCanosos Furia Lunar|r
    .complete 421,1 --Moonrage Whitescalp (5)
    .mob Moonrage Whitescalp
    .unitscan Son of Arugal
step
    .goto 1421/0,1593.6,554.23
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDalar|r
    .target Dalar Dawnweaver
    .turnin 421 >>Entrega la misión Demuestra tu valía
    .accept 422 >>Acepta la misión La locura de Arugal
step
    #completewith Remedy
    .goto 1421/0,1234.92,891.070,80 >> Viaja al Campo de Valgan
step
    #label Remedy
    .goto 1421/0,1234.92,891.070,8,0
    .goto 1421/0,1218.54,884.91,8,0
    .goto 1421/0,1226.52,886.03,8,0
    .goto 1421/0,1231.14,866.99
    >>Entra en la casa y ve al segundo piso. Despoja los |cffe07cf5Libros de hechizos polvorientos|r del suelo
    .complete 422,1 --Remedy of Arugal (1)
step
    #completewith next
    >>Mata |cffff5a4aOsos|r. Despójalos para obtener sus|cff4fc3f7Corazones|r
    .complete 447,1 --Grizzled Bear Heart (6)
    .mob Ferocious Grizzled Bear
step
    #completewith next
    .goto 1421/0,1207.62,1293.71,80,0
    .subzone 239 >>Viaja a Los Dominios de Ivar
step
    #label QuinnYorick
    .goto 1421/0,1207.62,1293.71,8,0
    .goto 1421/0,1220.64,1299.59,8,0
    .goto 1421/0,1212.66,1298.19,8,0
    .goto 1421/0,1205.94,1314.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cQuinn Yorick|r en el segundo piso de la casa
    .turnin 430 >>Entrega la misión Regresa junto a Quinn
    .accept 91920 >>Acepta la misión Mirada salvaje
    .target Quinn Yorick
step
    #loop
    .goto 1421/0,941.300,1210.400,0
    .goto 1421/0,706.700,1317.400,0
    .goto 1421/0,941.300,1210.400,50,0
    .goto 1421/0,830.000,1309.400,50,0
    .goto 1421/0,706.700,1317.400,50,0
    >>Mata |cffff5a4aMúrlocs Anca Vil|r. Despójalos para obtener sus |T133884:0|t[|cff4fc3f7Ojos de múrloc|r]
    .collect 730,3,91920,1 --Collect Murloc Eyes (x3)
    .mob Vile Vin Shredder
    .mob Vile Vin Tidehunter
step
    #completewith ArugalTurnin
    +|cffff9a3c¡Ten cuidado! ¡Puede haber un|r |cffff5a4aHijo de Arugal|r |cffff9a3cen la zona! Este es un élite nivel 25, ¡aléjate de él!|r
    .unitscan Son of Arugal
step
    #completewith Nightlash
    >>Mata |cffff5a4aOsos|r. Despójalos para obtener sus|cff4fc3f7Corazones|r
    .complete 447,1 --Grizzled Bear Heart (6)
    .mob Ferocious Grizzled Bear
    .mob Giant Grizzled Bear
    .unitscan Old VIcejaw
step
    #label Nightlash
    .goto 1421/0,1541.52,1078.39
    >>Mata |cffff5a4aGnolls Putrepellejo|r alrededor de El Campo Muerto hasta que aparezca |cffff5a4aLatipesadilla|r. Mátala y despójala para obtener su |cff4fc3f7Esencia|r
    >>|cffff9a3c¡Son inmunes al miedo!|r << Priest/Warlock
    .complete 437,1 --Enter the Dead Fields (1)
    .complete 437,2 --Essence of Nightlash (1)
    .unitscan Nightlash
    .mob Rot Hide Gladerunner
    .mob Rot Hide Mystic
step
    #completewith KillianVendor
    >>Mata |cffff5a4aOsos|r. Despójalos para obtener sus|cff4fc3f7Corazones|r
    .complete 447,1 --Grizzled Bear Heart (6)
    .mob Ferocious Grizzled Bear
    .mob Giant Grizzled Bear
    .unitscan Old VIcejaw
    .unitscan Son of Arugal
step
    #completewith next
    >>Mata |cffff5a4aArañas|r. Despójalas para obtener su |cff4fc3f7Sangre|r
    >>|cffff9a3c¡Ten cuidado con|r |cffff5a4aKrethis Tejeumbra|r |cffff9a3cya que es increíblemente difícil matarla!|r << !Mage !Warlock
    >>|cffff9a3cTen cuidado con|r |cffff5a4aKrethis Tejeumbra|r |cffff9a3ces difícil pero se puede hacer. Tiene un escudo de 130 de daño cada 15s de enfriamiento y una habilidad de choque instantáneo de 110 de daño|r << Mage/Warlock
    .complete 447,2 --Skittering Blood (6)
    .mob Moss Stalker
    .unitscan Krethis Shadowspinner
    .unitscan Son of Arugal
step
    #label KillianVendor
    .goto 1421/0,2064.0,1167.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKillian|r
    .vendor >> Vende la basura
    .target Killian Sanatha
    .isOnQuest 447
step
    #loop
	.goto 1421/0,1924.14,1269.070,0
	.goto 1421/0,1885.50,1218.95,50,0
	.goto 1421/0,1951.86,1218.39,50,0
	.goto 1421/0,1981.68,1209.15,50,0
	.goto 1421/0,2022.42,1183.95,50,0
	.goto 1421/0,2016.12,1239.39,50,0
	.goto 1421/0,1977.48,1260.670,50,0
	.goto 1421/0,1944.30,1279.43,50,0
	.goto 1421/0,1924.14,1269.070,50,0
    >>Mata |cffff5a4aArañas|r. Despójalas para obtener su |cff4fc3f7Sangre|r
    >>|cffff9a3c¡Ten cuidado con|r |cffff5a4aKrethis Tejeumbra|r |cffff9a3cya que es increíblemente difícil matarla!|r << !Mage !Warlock
    >>|cffff9a3cTen cuidado con|r |cffff5a4aKrethis Tejeumbra|r |cffff9a3ces difícil pero se puede hacer. Tiene un escudo de 130 de daño cada 15s de enfriamiento y una habilidad de choque instantáneo de 110 de daño|r << Mage/Warlock
    .complete 447,2 --Skittering Blood (6)
    .mob Moss Stalker
    .unitscan Krethis Shadowspi
step
    #loop
    .goto 1421/0,1702.8,1060.47,0
    .goto 1421/0,1712.46,1116.75,50,0
    .goto 1421/0,1702.8,1060.47,50,0
    .goto 1421/0,1670.88,1001.11,50,0
    .goto 1421/0,1573.86,971.15,50,0
    .goto 1421/0,1514.64,921.31,50,0
    >>Termina de matar a los |cffff5a4aOsos|r. Despójalos para obtener sus |cff4fc3f7Corazones|r
    .complete 447,1 --Grizzled Bear Heart (6)
    .mob Ferocious Grizzled Bear
    .mob Giant Grizzled Bear
    .unitscan Old VIcejaw
    .unitscan Son of Arugal
step << skip
    #softcore
    #completewith ArugalTurnin
    .deathskip >> Muere y reaparece en el |cff5cf05cÁngel de la Resurrección|r
step
    --#hardcore
    #completewith next
    .goto 1421/0,1538.58,511.39,100,0
    .subzone 228 >>Viaja de regreso a El Sepulcro
step
    .goto 1421/0,1593.6,554.23
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDalar|r
    .turnin 422 >> Entrega la misión La locura de Arugal
    .accept 423 >> Acepta la misión La locura de Arugal
    .target Dalar Dawnweaver
step
    #optional
    #label ArugalTurnin
step
    #completewith next
    .goto 1421/0,1640.22,509.43,8,0
    .goto 1421/0,1654.50,510.270,8,0
    .goto 1421/0,1654.08,521.470,8,0
    .goto 1421/0,1625.94,522.31,2 >> Entra en la cripta
step
    .goto 1421/0,1625.94,522.31
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHadrec|r en la cripta
    .turnin 437 >> Entrega la misión El Campo Muerto
    .accept 438 >> Acepta la misión El Viejo Embarcadero
    .target High Executor Hadrec
step
    .goto 1421/0,1652.600,522.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cBoticario Renferrel|r
    .turnin 91920 >>Entrega la misión Mirada salvaje
    .accept 91921 >>Acepta la misión Regresa junto a Quinn (otra vez)
    .target Apothecary Renferrel
step << !Mage !Priest
    .goto 1421/0,1599.90,552.83
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGwyn|r
    >>|cffe07cf5Compra|r |T134532:0|t[Champiñones con motas rojas] |cffe07cf5a esta vendedora|r
    .vendor >> Vende la basura
    .collect 4605,20,423,1 --Red-speckled Mushroom (20)
    .target Gwyn Farrow
step
    .goto 1421/0,1602.84,549.75
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cEdwin|r
    >>|cffe07cf5Compra|r |T132815:0|t[Leche fría como el hielo] |cffe07cf5a este vendedor|r << Warlock/Priest/Shaman/Druid
    .vendor >> |cffe07cf5Cómprale|r |T134830:0|t[Pociones menores de sanación] |cffe07cf5si están disponibles|r
    .collect 1179,20,423,1 << Warlock/Priest/Shaman/Druid --Ice Cold Milk (20)
    .target Edwin Harly
step << Warlock/Mage/Priest
    .goto 1421/0,1568.4,567.95
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAndrea|r
    .vendor >> Cómprale el |T132491:0|t[|cff5cf05cCinturón de hombre sabio|r] si está disponible
    .target Andrea Boynton
    .money <0.1400
step << Rogue
    .goto 1421/0,1576.38,571.59
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAlexandre|r
    .vendor >> Cómprale las |T132539:0|t[|cff5cf05cBotas de agilidad|r] si están disponibles
    .target Alexandre Lefevre
    .money <0.2633
step << Warlock/Mage/Priest
    #optional
    #completewith Shackles
    +|cffff9a3cEquipa el|r |T132491:0|t[|cff5cf05cCinturón de hombre sabio|r]
    .use 4786
    .itemcount 4786,1
    .xp <15,1
    .equip 6,4786
step << Rogue
    #optional
    #completewith Shackles
    +|cffff9a3cEquipa las|r |T132539:0|t[|cff5cf05cBotas de agilidad|r]
    .use 4788
    .itemcount 4788,1
    .xp <15,1
    .equip 8,4788
step
    #completewith Shackles
    .goto 1421/0,1593.60,597.91,15,0--c:Silverpine Forest,44.20,38.17
    .goto 1421/0,1582.68,640.47,15,0--c:Silverpine Forest,44.46,36.65
    .goto 1421/0,1563.78,738.75,30 >> Baja por la colina--c:Silverpine Forest,44.91,33.14
step
    #completewith Yorick3
    +|cffff9a3c¡Ten cuidado! ¡Puede haber un|r |cffff5a4aHijo de Arugal|r |cffff9a3cen la zona! Este es un élite nivel 25, ¡aléjate de él!|r
    .unitscan Son of Arugal
step
    #label Shackles
    #completewith Yorick3
    .goto 1421/0,1609.1399,798.6667,50,0,0
    .goto 1421/0,1609.1399,798.6667,50,0
    .goto 1421/0,1592.7599,783.2667,50,0
    .goto 1421/0,1622.5799,760.0267,50,0
    .goto 1421/0,1660.3799,795.3067,50,0
    .goto 1421/0,1716.2399,819.6667,50,0
    .goto 1421/0,1782.5999,819.9467,50,0
    .goto 1421/0,1813.6799,850.4667,50,0
    .goto 1421/0,1842.2399,907.8667,50,0
    .goto 1421/0,1870.7999,990.1867,50,0
    .goto 1421/0,1851.0599,1019.0267,50,0
    .goto 1421/0,1830.4799,1052.6267,50,0
    .goto 1421/0,1781.3399,1015.3867,50,0
    .goto 1421/0,1707.4199,1008.3867,50,0
    .goto 1421/0,1722.1199,952.6667,50,0
    .goto 1421/0,1720.8599,875.3867,50,0
    .goto 1421/0,1685.5799,847.1067,50,0
    .goto 1421/0,1609.1399,798.6667,50,0
    >>Mata |cffff5a4aGlotones Furia Lunar|r y |cffff5a4aAlmanegras Furia Lunar|r. Despójalos para obtener sus |cff4fc3f7Grilletes|r
    >>|cffff9a3c¡Ten cuidado! Los|r |cffff5a4aAlmanegras Furia Lunar|r |cffff9a3cse enfurecen cuando están por debajo del 25% de salud. Mátalos rápidamente cuando están débiles|r
    .complete 423,1 --Glutton Shackle (6)
    .mob +Moonrage Glutton
    .complete 423,2 --Darksoul Shackle (3)
    .mob +Moonrage Darksoul
    .unitscan Son of Arugal
step
    #label Yorick3
    .goto 1421/0,1207.62,1293.71,8,0
    .goto 1421/0,1220.64,1299.59,8,0
    .goto 1421/0,1212.66,1298.19,8,0
    .goto 1421/0,1205.94,1314.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cQuinn Yorick|r en el segundo piso de la casa
    .turnin 91921 >>Entrega la misión Regresa junto a Quinn (otra vez)
    .target Quinn Yorick
step
    .goto 1421/0,1204.68,1290.07
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRane Yorick|r fuera
    .accept 425 >>Acepta la misión Ivar el Hediondo
    .target Rane Yorick
step
    .goto 1421/0,1265.58,1274.11,6,0
    .goto 1421/0,1270.62,1279.71,6,0
    .goto 1421/0,1285.32,1277.19
    >>Mata a |cffff5a4aIvar el Hediondo|r. Despójalo para obtener su |cff4fc3f7Cabeza|r
    >>|cffff9a3cIvar está protegido por dos|r |cffff5a4aEsclavos Corvozarpa|r |cffff9a3cdentro del granero. Puedes atraer a uno de ellos cuando patrulle hacia adelante|r
    >>|cffff9a3c¡Son inmunes al miedo!|r << Priest/Warlock
    .complete 425,1 --Ivar's Head (1)
    .target Ivar the Foul
    .mob Ravenclaw Slave
step
    .goto 1421/0,1204.68,1290.07
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRane Yorick|r
    .turnin 425 >>Entrega la misión Ivar el Hediondo
    .target Rane Yorick
step
    #label DecrepitFerry
    .goto 1421/0,997.62,692.55
    >>Haz clic en el |cffe07cf5Bote|r al lado de los muelles
    .turnin 438 >>Entrega la misión El Viejo Embarcadero
    .accept 439 >>Acepta la misión Pistas de Putrepellejos
step
    #loop
    .goto 1421/0,1079.000,375.000,0
    .goto 1421/0,1079.000,375.000,30,0
    .goto 1421/0,1015.900,417.200,20,0
    .goto 1421/0,1134.400,301.200,40,0
    >>Mata |cffff5a4aGlotones Furia Lunar|r y |cffff5a4aAlmanegras Furia Lunar|r. Despójalos para obtener sus |cff4fc3f7Grilletes|r
    >>|cffff9a3c¡Ten cuidado! Los|r |cffff5a4aAlmanegras Furia Lunar|r |cffff9a3cse enfurecen cuando están por debajo del 25% de salud. Mátalos rápidamente cuando están débiles|r
    .complete 423,1 --Glutton Shackle (6)
    .mob +Moonrage Glutton
    .complete 423,2 --Darksoul Shackle (3)
    .mob +Moonrage Darksoul
    .unitscan Son of Arugal
step
    #completewith next
    .goto 1421/0,1538.58,511.39,100 >> Viaja de regreso a El Sepulcro
    .subzoneskip 228
step
    .goto 1421/0,1593.6,554.23
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDalar|r
    .turnin 423 >>Entrega la misión La locura de Arugal
    .accept 424 >>Acepta la misión La locura de Arugal
    .target Dalar Dawnweaver
step
    #completewith next
    .goto 1421/0,1640.22,509.43,8,0
    .goto 1421/0,1654.50,510.270,8,0
    .goto 1421/0,1654.08,521.470,8,0
    .goto 1421/0,1625.94,522.31,2 >> Entra en la cripta
step
    .goto 1421/0,1625.94,522.31
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHadrec|r en la cripta
    .turnin 439 >>Entrega la misión Pistas de Putrepellejos
    .accept 440 >>Acepta la misión El anillo grabado
    .target High Executor Hadrec
step
    #completewith next
    .goto 1421/0,1077.84,380.35,10 >> Entra en la Mina--c:Silverpine Forest,56.48,45.94
step
    #label GrimsonthePale
    .goto 1421/0,990.48,410.87--c:Silverpine Forest,58.56,44.85
    >>Mata a |cffff5a4aGrimson el Pálido|r. Despójalo para obtener su |cff4fc3f7Cabeza|r
    .complete 424,1 --Head of Grimson (1)
    .target Grimson the Pale
step
    #hardcore
    .goto 1421/0,1354.62,-22.57
    >>Haz clic en el |cffe07cf5Cajón|r en el campamento
    >>|cffff9a3c¡Ten cuidado! Estos enemigos lanzan|r |T135846:0|t[Descarga de Escarcha] |cffff9a3cy huyen con poca salud. Atráelos hacia atrás y mátalos uno a uno hasta que puedas hacer clic en el cajón de forma segura|r
    .turnin 477 >>Entrega la misión Pasa la frontera
    .accept 478 >>Acepta la misión Mapas y runas
    .mob Dalaran Apprentice
step
    #label BorderCrossings
    #softcore
    .goto 1421/0,1354.62,-22.57
    >>Haz clic en el |cffe07cf5Cajón|r en el campamento
    >>|cffff9a3cTen cuidado, estos enemigos lanzan|r |T135846:0|t[Descarga de Escarcha]|r
    .turnin 477 >>Entrega la misión Pasa la frontera
    .accept 478 >>Acepta la misión Mapas y runas
    .mob Dalaran Apprentice
step
    #completewith next
    #hardcore
    .goto 1421/0,1538.58,511.39,100 >> Viaja de regreso a El Sepulcro--c:Silverpine Forest,45.51,41.26
    .subzoneskip 228
step
    #softcore
    #completewith next
    .deathskip >> Muere y reaparece en el |cff5cf05cÁngel de la Resurrección|r
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAllister|r y |cff5cf05cDalar|r
    .turnin 478 >>Entrega la misión Mapas y runas
    .accept 481 >>Acepta la misión El análisis de Dalar
    .target +Shadow Priest Allister
    .goto 1421/0,1602.84,520.63
    .turnin 424 >>Entrega la misión La locura de Arugal
    .turnin 481 >>Entrega la misión El análisis de Dalar
    .accept 482 >>Acepta la misión Las intenciones de los Dalaran
    .target +Dalar Dawnweaver
    .goto 1421/0,1593.6,554.23
step
    .goto 1421/0,1602.84,520.63
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAllister|r
    .turnin 482 >>Entrega la misión Las intenciones de los Dalaran
    .target Shadow Priest Allister
step
    .goto 1421/0,1579.600,461.700
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTabitha Tejecorazones::250686|r
    .accept 92401 >>Acepta la misión Una pregunta con miedo
    .target Tabitha Heartweaver::250686
    .xp <15,1
    .dungeon ROL
step
    .goto 1421/0,1533.96,474.43
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKaros|r
    .turnin 6321 >>Entrega la misión Suministros para El Sepulcro << Undead
    .accept 6323 >>Acepta la misión Vuela a Entrañas << Undead
    .fp Sepulcher >> Consigue la ruta de vuelo de El Sepulcro << !Undead
    .fly Undercity >> Vuela a Entrañas << !Undead
    .target Karos Razok
    .zoneskip Undercity
step << Undead
    .hs >> Usa tu Piedra de hogar para ir a Entrañas
    .use 6948
    .zoneskip Undercity
    .bindlocation 1497,1
step << Undead
    .goto 1458/0,283.37,1610.32
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGordon|r
    .turnin 6323 >> Entrega la misión Vuela a Entrañas
    .accept 6322 >> Acepta la misión Michael Garrett
    .target Gordon Wendham
step << Rogue
    #ssf
    .goto 1458/0,286.53,1616.21
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLouis Warren|r en el Barrio del Comercio
    >>|cffe07cf5Compra una|r |T135343:0|t[Cimitarra] |cffe07cf5a este vendedor|r
    .collect 2027,1 --Collect Scimitar (1)
    .money <0.3815
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.6
    .target Louis Warren
step << Rogue
    #ah
    .goto 1458/0,286.53,1616.21
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLouis Warren|r en el Barrio del Comercio
    >>|cffe07cf5Compra una|r |T135343:0|t[Cimitarra] |cffe07cf5a este vendedor|r
    >>|cffff9a3cAlternativamente, busca en la Casa de subastas algo mejor o más barato|r
    .collect 2027,1 --Collect Scimitar (1)
    .money <0.3815
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.6
    .target Louis Warren
step << Rogue
    #optional
    #completewith Conscript
    +|cffff9a3cEquipa la|r |T135343:0|t[Cimitarra]
    .use 2027
    .itemcount 2027,1
    .itemStat 16,QUALITY,<7
    .itemStat 16,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.6
step << Undead
    .goto 1458/0,266.20,1567.17
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMichael|r
    .turnin 6322 >>Entrega la misión Michael Garrett
    .target Michael Garrett
step << Rogue/Warrior
    .goto 1458/0,171.03,1524.80
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cMary|r en el Barrio de los Pícaros
    .train 3273 >>Aprende |T135966:0|t[Primeros auxilios]
    .target Mary Edras
step << Rogue/Warrior
    #optional
    .goto 1458/0,171.03,1524.80
    .skill firstaid,40 >> Crea |T133685:0|t[Vendas de lino] hasta que tu habilidad sea 40 o superior
    .itemcount 2589,1 --Linen Cloth (1+)
step << Rogue/Warrior
    #optional
    .goto 1458/0,171.03,1524.80
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cMary|r en el Barrio de los Pícaros
    .train 3276 >> Aprende |T133688:0|t[Venda de lino gruesa]
    .target Mary Edras
    .skill firstaid,<40,1
step << Rogue/Warrior
    #optional
    .goto 1458/0,171.03,1524.80
    .skill firstaid,50 >> Crea |T133688:0|t[Vendas de lino gruesas] hasta que tu habilidad sea 50 o superior
    .itemcount 2589,2 --Linen Cloth (2+)
step << Rogue/Warrior
    .goto 1458/0,171.03,1524.80
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cMary|r en el Barrio de los Pícaros
    .train 3274 >> Aprende Oficial de primeros auxilios
    .target Mary Edras
    .skill firstaid,<50,1
step << Undead Rogue
    .goto 1458/0,71.92,1435.630
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMennet|r
    .turnin 1886 >>Entrega la misión Los mortacechadores
    .accept 1898 >>Acepta la misión Los mortacechadores
    .target Mennet Carkad
    .isQuestComplete 1886
step << Undead Rogue
    .goto 1458/0,71.92,1435.630
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMennet|r
    .accept 1898 >>Acepta la misión Los mortacechadores
    .target Mennet Carkad
    .isQuestTurnedIn 1886
step << Undead Rogue
    #optional
    .goto 1458/0,68.66,1416.69
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCarolyn|r
    .train 1758 >> Aprende tus hechizos de clase
    .target Carolyn Ward
    .xp <14,1
    .xp >16,1
    .isOnQuest 1898 << Undead
--XX Only train if you were directed here for class quest as an Undead
step << Undead Rogue
    #optional
    .goto 1458/0,68.66,1416.69
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCarolyn|r
    .train 6761 >> Aprende tus hechizos de clase
    .target Carolyn Ward
    .xp <16,1
    .isOnQuest 1898 << Undead
step << Undead Rogue
    .goto 1458/0,347.07,1389.48
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAndron|r
    .turnin 1898 >>Entrega la misión Los mortacechadores
    .accept 1899 >>Acepta la misión Los mortacechadores
    .target Andron Gant
    .isQuestTurnedIn 1886
step << Undead Rogue
    .goto 1458/0,341.41,1385.90
    >>Despoja la |cffe07cf5Estantería de Andron|r detrás de |cff5cf05cAndron|r
    .complete 1899,1 --Andron's Ledger (1)
    .isQuestTurnedIn 1886
step
    .goto 1458/0,310.900,1528.100
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAlessandro Luca|r
    .accept 97891 >>Acepta la misión Presto portador de la poción
    .target Alessandro Luca
step
    #completewith next
    #optional
    .goto 1458/0,351.46,1410.58,50,0 << !Undead/!Rogue--c:1458,54.383,73.014
    .goto 1458/0,366.29,1380.42,20,0--c:1458,52.837,77.725
    .goto 1458/0,371.68,1370.64,15,0--c:1458,52.275,79.254
    .goto 1458/0,381.23,1366.35,15,0--c:1458,51.279,79.923
    .goto 1458/0,396.45,1372.88,15,0--c:1458,49.693,78.903
    .goto 1458/0,413.16,1390.37,15 >>Viaja a El Apothecarium--c:1458,47.951,76.171
step
    .goto 1458/0,426.100,1403.600
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cDoctor Martin Felben|r
    .complete 97891,1 --|1/1 Speak to Doctor Martin Felben
    .turnin 97891 >>Entrega la misión Presto portador de la poción
    .target Doctor Martin Felben
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cFaranell|r y |cff5cf05cZinge|r en El Apothecarium
    .turnin 447 >>Entrega la misión Una fórmula mortal
    .target +Master Apothecary Faranell
    .goto 1458/0,404.63,1434.67
    .turnin 1359 >> Entrega la misión Una entrega de Zinge
    .accept 1358 >> Acepta la misión Muestra para Helbrim
    .target +Apothecary Zinge
    .goto 1458/0,391.97,1442.87
    .dungeon !ROL
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cFaranell|r y |cff5cf05cZinge|r en El Apothecarium
    .turnin 447 >>Entrega la misión Una fórmula mortal
    .accept 450 >>Acepta la misión Una fórmula mortal
    .target +Master Apothecary Faranell
    .goto 1458/0,404.63,1434.67
    .turnin 1359 >> Entrega la misión Una entrega de Zinge
    .accept 1358 >> Acepta la misión Muestra para Helbrim
    .target +Apothecary Zinge
    .goto 1458/0,391.97,1442.87
    .dungeon ROL
step
    .goto 1458/0,334.02,1262.17--c:Undercity,56.2,96.2
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVarimathras|r
    .accept 5725 >>Acepta la misión Poder destructivo
    .target Varimathras
    .dungeon RFC
step << Undead Rogue
    .goto 1458/0,71.83,1435.51
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMennet|r
    .turnin 1899 >>Entrega la misión Los mortacechadores
    .accept 1978 >>Acepta la misión Los mortacechadores
    .target Mennet Carkad
    .isQuestTurnedIn 1886
step << Undead Rogue
    .goto 1420/0,373.60,1464.85,40,0
    .goto 1420/0,333.38,1287.72
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVarimathras|r
    .turnin 1978 >>Entrega la misión Los mortacechadores
    .target Varimathras
    .isQuestTurnedIn 1886
step << !Rogue !Warrior
    #optional
    .goto 1458/0,171.03,1524.80
    .skill firstaid,40 >> Crea |T133685:0|t[Vendas de lino] hasta que tu habilidad sea 40 o superior
    .itemcount 2589,1 --Linen Cloth (1+)
step << !Rogue !Warrior
    #optional
    .goto 1458/0,171.03,1524.80
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cMary|r en el Barrio de los Pícaros
    .train 3276 >> Aprende |T133688:0|t[Venda de lino gruesa]
    .target Mary Edras
    .skill firstaid,<40,1
step << !Rogue !Warrior
    #optional
    .goto 1458/0,171.03,1524.80
    .skill firstaid,50 >> Crea |T133688:0|t[Vendas de lino gruesas] hasta que tu habilidad sea 50 o superior
    .itemcount 2589,2 --Linen Cloth (2+)
step << !Rogue !Warrior
    #optional
    .goto 1458/0,171.03,1524.80
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con|r |cff5cf05cMary|r en el Barrio de los Pícaros
    .train 3274 >> Aprende Oficial de primeros auxilios
    .target Mary Edras
    .skill firstaid,<50,1
step << Mage
    .goto 1458/0,56.38,1813.81
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAnastasia|r
    .train 2137 >> Aprende tus hechizos de clase
    .target Anastasia Hartwell
    .xp <14,1
    .xp >16,1
--XX no dungeon RFC due to close proximity
step << Mage
    #optional
    .goto 1458/0,56.38,1813.81
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAnastasia|r
    .train 2120 >> Aprende tus hechizos de clase
    .target Anastasia Hartwell
    .xp <16,1
step << Undead Warlock
    .goto 1458/0,20.02,1776.42
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRichard|r
    .train 6222 >> Aprende tus hechizos de clase
    .target Richard Kerwin
    .xp <14,1
    .xp >16,1
--XX no dungeon RFC due to close proximity
step << Undead Warlock
    #optional
    .goto 1458/0,20.02,1776.42
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRichard|r
    .train 1455 >> Aprende tus hechizos de clase
    .target Richard Kerwin
    .xp <16,1
step << Paladin
    .goto 1458/0,418.500,1782.600
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGaren|r
    .train 647 >>Aprende tus hechizos de clase
    .target Garen Largo
    .xp <14,1
    .xp >16,1
step << Paladin
    #optional
    .goto 1458/0,418.500,1782.600
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGaren|r
    .train 7294 >>Aprende tus hechizos de clase
    .target Garen Largo
    .xp <16,1
step << Priest/Mage/Warlock
    .goto 1458/0,168.200,1663.100
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOwen Thadd::211022|r
    .target Owen Thadd::211022
    .turnin 79096 >>Entrega la misión Ataeric: Tratado de curiosidades arcanas
    .itemcount 210177,1
step << Priest/Mage/Warlock
    #ssf
    .goto 1458/0,206.04,1705.57
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZane Bradford|r en el Barrio de Magia
    >>|cffe07cf5Compra una|r |T135468:0|t[Varita humeante] |cffe07cf5a este vendedor|r
    .collect 5208,1 --Smoldering Wand (1)
    .money <0.3515
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<13.4
	.target Zane Bradford
step << Priest/Mage/Warlock
    #ah
    .goto 1458/0,206.04,1705.57
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cZane Bradford|r en el Barrio de Magia
    >>|cffe07cf5Compra una|r |T135468:0|t[Varita humeante] |cffe07cf5a este vendedor|r
    >>|cffff9a3cAlternativamente, busca en la Casa de subastas algo mejor o más barato|r
    .collect 5208,1 --Smoldering Wand (1)
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<13.4
	.target Zane Bradford
step << Priest/Mage/Warlock
    #optional
    #completewith Conscript
    +|cffff9a3cEquipa la|r |T135468:0|t[Varita humeante] |cffff9a3ccuando seas nivel 15|r
    .use 5208
    .itemcount 5208,1
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<13.4
    .xp >15,1
step << Priest/Mage/Warlock
    #optional
    #completewith Conscript
    +|cffff9a3cEquipa la|r |T135468:0|t[Varita humeante]
    .use 5208
    .itemcount 5208,1
    .itemStat 18,QUALITY,<7
    .itemStat 18,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<13.4
    .xp <15,1
step << Undead Rogue
    #optional
    #completewith Conscript
    >>Abandona la misión Los mortacechadores, ya no hay oportunidad de hacerlo
    .abandon 1886 >> Abandona la misión Los mortacechadores
    .isOnQuest 1886
step << Undead
    #completewith next
    .goto 1420/0,235.32,1883.89,50,0
    .zone Tirisfal Glades >> Sal de Entrañas
    .zoneskip Tirisfal Glades
step << Undead
    #label ZeptoDurotar
    .goto 1420/0,278.70,2071.27,12,0
    .goto 1420/0,253.85,2059.82,10,0
    .goto 1420/0,264.70,2053.50,8,0
    .goto 1420/0,271.02,2064.94,8,0
    .goto 1420/0,259.72,2068.86,8,0
    .goto 1420/0,261.53,2055.00,8,0
    .goto 1420/0,299.04,2069.46,-1
    .goto 1420/0,279.61,2441.21,-1
    .zone Durotar >>Toma el zepelín hacia Durotar
    >>Haz piedras de afilar/vendas mientras esperas << Warrior/Rogue
    >>Conjura comida/agua mientras esperas << Mage
    .zoneskip Durotar
step << Druid
    #completewith DruidTraining1
    .cast 18960 >>|cffff9a3cLanza|r |T135758:0|t[Teletransporte a: Claro de la Luna]
    .zoneskip Moonglade
step << Skyborne Druid
    .goto 1450/1,-2678.76,8019.94--c:Moonglade,56.21,30.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDendrita|r
    .turnin -94913 >>Entrega la misión Claro de la Luna
    .target Dendrite Starblaze
step << Druid
    .goto 1450/1,-2593.82,7866.90
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLoganaar|r
    .train 5178 >> Aprende tus hechizos de clase
    .target Loganaar
    .xp <14,1
    .xp >16,1
step << Druid
    #label DruidTraining1
    .goto 1450/1,-2593.82,7866.90
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLoganaar|r
    .train 8925 >> Aprende tus hechizos de clase
    .target Loganaar
    .xp <16,1
step << Skyborne
    .hs >> Usa tu Piedra de hogar para ir a Orgrimmar
    .use 6948
    .zoneskip Orgrimmar
    .bindlocation 1637,1
step << Undead
    #completewith HiddenEnemiesPickup
    .goto 1454/1,-4367.46,1405.44,50,0
    .zone Orgrimmar >> Viaja a Orgrimmar
    .dungeon RFC
step << Undead
    .goto 1454/1,-4313.60,1676.24
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDoras|r
    >>|cffff9a3c¡No vueles a ningún lado!|r
    .fp Orgrimmar >> Consigue la ruta de vuelo de Orgrimmar
    .target Doras
    .dungeon RFC
step << Undead/Skyborne
    .goto 1454/1,-4125.79,1920.10
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThrall|r
    .accept 5726 >>Acepta la misión Enemigos ocultos
    .target Thrall
    .dungeon RFC
step << Undead/Skyborne
    #completewith Gazzuz
    .goto 1454/1,-4367.46,1405.44,50,0
    .zone Durotar >> Sal de Orgrimmar
    .dungeon RFC
step << Undead/Skyborne
    #completewith Gazzuz
    >>Mata a los |cffff5a4aOrcos Filo Ardiente|r. Despójalos para obtener una |cff4fc3f7Insignia de Teniente|r
    >>|cffff9a3cEsta misión es un prerrequisito para Sima Ígnea. Tiene una baja probabilidad de caída|r
    .complete 5726,1 --Lieutenant's Insignia (1)
    .mob Burning Blade Fanatic
    .mob Burning Blade Apprentice
    .dungeon RFC
step << Undead/Skyborne
    #label Gazzuz
    .goto 1411/1,-4701.42,1455.83
    >>Mata a |cffff5a4aGazz'uz|r. Despójalo para obtener su |T134085:0|t[|cff4fc3f7Ojo de la Sombra ardiente|r]
    >>|cffff9a3cUsa el |T134085:0|t[|cff4fc3f7Ojo de la Sombra ardiente|r] para empezar la misión|r
    >>|cffff9a3cCorta la línea de visión (LoS) para evitar las Descargas de las Sombras de |cffff5a4aGazz'uz|r|r
    >>|cffff9a3cPuedes correr hacia las zonas de agua que hay dentro de la cueva para evadir al|r |cffff5a4aAbisario|r |cffff9a3cdespués de matar a|r |cffff5a4aGazz'uz|r
    >>|cffff9a3cTen cuidado, ya que es difícil. Puedes saltarte esta misión si lo necesitas|r
    .collect 4903,1,832,1 --Collect Eye of Burning Shadow
    .accept 832 >>Acepta la misión Sombras Ardientes
    .use 4903
	.unitscan Gazz'uz
    .dungeon RFC
step << Undead/Skyborne
    #loop
    .goto 1411/1,-4805.59,1495.67,0
    .goto 1411/1,-4855.82,1498.84,15,0
    .goto 1411/1,-4833.08,1494.96,15,0
    .goto 1411/1,-4805.59,1495.67,15,0
    .goto 1411/1,-4784.44,1535.85,15,0
    .goto 1411/1,-4750.60,1531.62,15,0
    .goto 1411/1,-4734.21,1505.54,15,0
    .goto 1411/1,-4693.49,1519.64,15,0
    .goto 1411/1,-4679.75,1501.31,15,0
    .goto 1411/1,-4684.50,1466.06,15,0
    .goto 1411/1,-4805.59,1495.67,15,0
    >>Mata a los |cffff5a4aOrcos Filo Ardiente|r. Despójalos para obtener una |cff4fc3f7Insignia de Teniente|r
    >>|cffff9a3cEsta misión es un prerrequisito para Sima Ígnea. Tiene una baja probabilidad de caída|r
    .complete 5726,1 --Lieutenant's Insignia (1)
    .mob Burning Blade Fanatic
    .mob Burning Blade Apprentice
    .dungeon RFC
step << Undead/Skyborne
    #completewith Conscript
    .subzone 362 >> Viaja a Cerrotajo
step << !Undead !Skyborne
    .hs >> Usa tu Piedra de hogar para ir a Cerrotajo
    .use 6948
    .subzoneskip 362
    .bindlocation 362,1
step << Rogue
    #optional << Undead
    .goto 1411/1,-4710.94,268.26
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKaplak|r
    .train 1758 >> Aprende tus hechizos de clase
    .target Kaplak
    .xp <14,1
    .xp >16,1
step << Rogue
    #optional << Undead
    .goto 1411/1,-4710.94,268.26
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKaplak|r
    .train 6761 >> Aprende tus hechizos de clase
    .target Kaplak
    .xp <16,1
step << Priest
    #optional << Undead
    .goto 1411/1,-4831.5,295.05
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTai'jin|r
	.train 8122 >>Aprende tus hechizos de clase
    .target Tai'jin
    .xp <14,1
    .xp >16,1
step << Priest
    #optional << Undead
    .goto 1411/1,-4831.5,295.05
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTai'jin|r
	.train 8102 >>Aprende tus hechizos de clase
    .target Tai'jin
    .xp <16,1
step << Warrior
    #optional << Undead
    .goto 1411/1,-4827.27,311.62
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTarshaw|r
    .train 285 >>Aprende tus hechizos de clase
    .target Tarshaw Jaggedscar
    .xp <16,1
step << Warlock
    #optional << Undead
    .goto 1411/1,-4837.31,356.030
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDhugru|r
    .train 6222 >> Aprende tus hechizos de clase
    .target Dhugru Gorelust
    .xp <14,1
    .xp >16,1
step << Warlock
    #optional << Undead
    .goto 1411/1,-4837.31,356.030
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDhugru|r
    .train 1455 >> Aprende tus hechizos de clase
    .target Dhugru Gorelust
    .xp <16,1
step
    #label Conscript
    .goto 1411/1,-4648.55,271.43
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTakrin|r
    .accept 840 >>Acepta la misión Nuevo recluta de la Horda
    .target Takrin Pathseeker
step
    #completewith next
    .subzone 379 >> Viaja a la Avanzada del Puente
step
    .goto 1413/1,-3687.11,303.14
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKargal|r
    .turnin 840 >>Entrega la misión Nuevo recluta de la Horda
    .accept 842 >>Acepta la misión Servicio militar en El Cruce
    .target Kargal Battlescar
step << !Undead !Skyborne
    .goto 1413/1,-3694.2,256.52
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAk'Zeloth|r
    .turnin -809 >>Entrega la misión Ak'Zeloth
    .accept 924 >>Acepta la misión La Semilla del Demonio
    .target Ak'Zeloth
    .isQuestTurnedIn 829
step << !Undead !Skyborne
    .goto 1413/1,-3694.2,259.22
    >>|cffff9a3cDespoja la|r |T134095:0|t[Piedra de energía con imperfecciones] |cffff9a3cjunto a|r |cff5cf05cAk'Zeloth|r|cffff9a3c. Este objeto tiene un temporizador de 30 minutos, así que date prisa|r
    .turnin 926 >>Entrega la misión La piedra de energía con imperfecciones
    .isOnQuest 924

]=], "Horde"}
