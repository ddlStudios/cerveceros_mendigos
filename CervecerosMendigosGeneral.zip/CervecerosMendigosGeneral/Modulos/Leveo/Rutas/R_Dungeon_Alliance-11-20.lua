-- GENERADO por _suite/herramientas/leveo_rutas.py: no editar a mano.
-- Ruta de subida de RestedXP (RXPGuides), traducida y adaptada a WoW Forever por Brudda FastXP.
-- Licencia de este archivo: CC BY-NC-SA 4.0 (ver LICENCIA_RUTAS.txt).
local _, ns = ...
local R = ns.LeveoRutas or {}
ns.LeveoRutas = R
R[#R + 1] = {[=[
#forever
#version 1
<< Alliance NightElf
#name 11-16 Costa Oscura/Loch Modan
#group Forever Guía de Mazmorras (A)
#subgroup Mazmorras 1-20
#next 17-18 Salón de Señores Feudales

step
    #include Guía Forever (A)\14-16 Costa Oscura@WashedA-DarkshoreEndNE
step
    #include Guía Forever (A)\15-16 Loch Modan@SWBoat-IFExit
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cTabernero Brebefuego|r
    .goto 1455/0,-856.69,-4841.490
    .home >> Establece tu Piedra de hogar en Forjaz
    .target Innkeeper Firebrew
step
    #completewith next
    .zone Dun Morogh >> Viaja a Dun Morogh
step
    .goto 1426/0,-1147.9916,-5502.3333,30,0
    .goto 1426/0,-1212.0166,-5426.8167,15,0
    .goto 1426/0,-1256.3416,-5430.1000,20 >>Sube corriendo por la rampa hacia |cffff5a4aVagash|r
step
    #completewith next
    +"Kitea" a |cffff5a4aVagash|r hacia |cff5cf05cRudra Semperámbar|r
    >>|cffff9a3cIntenta evitar acercarte a él o lanzará|r |T135848:16|t[Rugido glacial] |cffff9a3clo que te aturdirá durante 3 segundos|r
    .mob Vagash
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:16|tHabla con |cff5cf05cRudra Semperámbar|r
    .goto 1426/0,-1304.71,-5513.86
    .target Rudra Amberstill
    .accept 314 >>Acepta la misión La protección del rebaño
step
    >>"Kitea" a |cffff5a4aVagash|r hacia el |cff5cf05cMontaraz de Dun Morogh|r
    >>|cffff9a3cAsegúrate de causarle al menos 50% de daño|r
    .goto 1426/0,-1290.8166,-5669.7833,10,0
    .mob Vagash
    .target Dun Morogh Mountaineer
    .complete 314, 1
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:16|tHabla con |cff5cf05cRudra Semperámbar|r
    .goto 1426/0,-1304.71,-5513.86
    .target Rudra Amberstill
    .turnin 314 >>Entrega la misión La protección del rebaño
step
    #label QuarryStart
    .goto 1426/0,-1394.24,-5797.83
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVidenterra Farsen|r
    .accept 96392 >> Acepta la misión La vigilancia de Farsen
    .target Earthseer Farsen
step
    .isOnQuest 96392
    .goto 1426/0,-1394.24,-5797.83
    .gossipoption 139831 >> Habla con |cff5cf05cVidenterra Farsen|r para ver su vista lejana
    >>|cffff9a3cPuedes cancelar la Vista lejana cuando se completa el objetivo|r
    .target Earthseer Farsen
step
    .isOnQuest 96392
    .aura -1293681 >> |cffff9a3cPresiona ESC para cancelar la Vista lejana|r
step << skip
    .goto 1426/0,-1394.24,-5797.83
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVidenterra Farsen|r
    >>|cffff9a3cPuedes cancelar la Vista lejana cuando se completa el objetivo|r
    .complete 96392,1 -- Use Farsen's Farsight
    .skipgossip
    .target Earthseer Farsen
step
    .goto 1426/0,-1394.24,-5797.83
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVidenterra Farsen|r
    >>|cffff9a3cPresiona ESC para cancelar la Vista lejana|r
    .turnin 96392 >> Entrega la misión La vigilancia de Farsen
    --.accept 96390 >> Acepta la misión Párteles el coco
    .target Earthseer Farsen
step
    .goto 1426/0,-2009.87,-5860.22,40,0
    .goto 1426/0,-2034.49,-5922.60
    >>Mata |cffff5a4aEspías Hierro Negro|r. Despójalos para obtener el |T237385:0|t[|cff4fc3f7Mapa de Hierro Negro|r]
    .use 274268 >>|cffff9a3cUsa el|r |T237385:0|t[|cff4fc3f7Mapa de Hierro Negro|r] |cffff9a3cpara iniciar la misión|r
    -->>|cffff9a3cYou can skip killing |cffff5a4aDark Iron Spies|r for the other quest because they are low level once you find the|r |T237385:0|t[|cff4fc3f7Mapa de Hierro Negro|r]
    --.complete 96390,1 -- Dark Iron Spy slain 10/10
    --.disablecheckbox
    .collect 274268,1,96391,1 -- Dark Iron Map (1)
    .accept 96391 >> Acepta la misión Mapa subterráneo
    .mob Dark Iron Spy
step
    .goto 1426/0,-1394.24,-5797.83
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVidenterra Farsen|r
    .turnin 96391 >> Entrega la misión Mapa subterráneo
    .accept 96393 >> Acepta la misión Incursión a Antigua Forjaz
    .target Earthseer Farsen
step
    #optional
    .isQuestComplete 96390
    .goto 1426/0,-1394.24,-5797.83
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVidenterra Farsen|r
    .turnin 96390 >> Entrega la misión Párteles el coco
    .target Earthseer Farsen
step
    #include Guía Forever (A)\15-16 Loch Modan@LochEnter-LochEnd
step << NightElf Druid
    #completewith next
	.cast 18960 >> Lanza Teletransporte a: Claro de la Luna
	.zoneskip Moonglade
step << Druid
	.goto 1450/1,-2400.33,7795.33--c:Moonglade,44.148,45.229
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSilva Fil'naveth|r
	.fly Teldrassil >>Vuela a la Aldea Rut'theran
	.target Silva Fil'naveth
step << Druid
    #completewith next
    .goto 1438/1,965.7958,8780.9475
    .zone Darnassus >> Toma el portal morado a Darnassus
step << Druid
	.goto 1457/1,2563.92,10179.040
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMathrengyl Garroso|r
	.accept 26 >>Acepta la misión Una lección que aprender
	.trainer >> Aprende tus hechizos de clase
	.target Mathrengyl Bearwalker
step << Druid
	#completewith next
	.cast 18960 >> Lanza Teletransporte a: Claro de la Luna
	.zoneskip Moonglade
step << Druid
    .goto 1450/1,-2676.22,8019.01
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDendrita Rafagaestelar|r
    .turnin 26 >> Entrega la misión Una lección que aprender
    .accept 29 >> Acepta la misión La prueba del lago
    .target Dendrite Starblaze
step << Druid
    .goto 1450/1,-2595.43,7697.24
    >>Nada al Lago Elune'ara
    >>Abre el |cffe07cf5Adorno contenedor|r. Despójalo para obtener un |T134125:0|t[Adorno de altar]
    >>|cffff9a3cPuede aparecer en diferentes ubicaciones bajo el agua|r
    .collect 15877,1,29,1 -- Shrine Bauble (1)
step << Druid
    #optional
    #completewith next
    .cast 18960 >> Lanza Teletransporte a: Claro de la Luna
    .itemcount 15877,1 -- Shrine Bauble (1)
step << Druid
    .goto 1450/1,-2212.85,7854.68
    >>|cffff9a3cUsa el|r |T134125:0|t[Adorno de altar] |cffff9a3cen el árbol del Santuario de Remulos|r
    .complete 29,1 --Complete the Trial of the Lake.
    .use 15877
step << Druid
    #label TotL
    .goto 1450/1,-2224.18,7874.23
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTajarri|r
    .turnin 29 >> Entrega la misión La prueba del lago
    .accept 272 >> Acepta la misión La prueba del león marino
    .target Tajarri
step << NightElf
    .hs >>Usa tu Piedra de hogar para ir a Forjaz
    .zoneskip Ironforge
step << NightElf Priest/NightElf Druid
    #ah
    #label OilWandFood
    #completewith AHCheck
    .goto 1455/0,-917.57,-4967.58,-1--c:Ironforge,25.800,75.500
    .goto 1455/0,-904.92,-4962.83,-1--c:Ironforge,24.200,74.600
    .goto 1455/0,-901.76,-4948.06,-1--c:Ironforge,23.800,71.800
    >>|cffff9a3cCompra lo siguiente si te lo puedes permitir:|r
    >>|T134711:0|t[Aceite de zahorí menor] |cffff9a3cy|r |T133906:0|t[Sabiola ahumada]
    >>|cffff9a3cComprueba también si hay mejoras de|r |T132317:0|t[Varita] |cffff9a3cde alto DPS que puedas usar ahora o pronto|r << Priest
    >>|cffff9a3cTe proporcionarán un gran aumento de DPS en los niveles iniciales. Si no quieres o no puedes hacer esto, omite este paso|r
    .collect 20744,1 -- Minor Wizard Oil (1)
    .collect 21072,20 -- Smoked Sagefish (20)
    .target Auctioneer Lympkin
    .target Auctioneer Redmuse
    .target Auctioneer Buckler
step << NightElf Hunter
    .goto 1455/0,-1266.100,-5006.700
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBelia Tronagranito|r
    .trainer >> Aprende tus hechizos de clase
    .target Regnus Thundergranite
step << NightElf Priest
    .goto 1455/0,-897.200,-4607.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cSumo sacerdote Rohan|r  
    .trainer >> Aprende tus hechizos de clase
    .target High Priest Rohan
step << NightElf Rogue
    .goto 1455/0,-1120.72,-4650.120
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cFenthwick|r
    .trainer >> Aprende tus hechizos de clase
    .target Fenthwick
step << NightElf Warrior
    .goto 1455/0,-1234.65,-5035.67
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBilban Cálculo|r
    .trainer >> Aprende tus hechizos de clase
    .target Bilban Tosslespanner
step << NightElf
    .goto 1455/0,-1303.75,-4631.19
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cProspector Pico Tormenta|r
    .turnin 301 >> Entrega la misión Informe a Forjaz
    .target Prospector Stormpike










-- step
--     .goto 1453/0,673.58,-8867.76
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cTabernera Allison|r
--     .home >> Set your Hearthstone to Stormwind City
--     .target Innkeeper Allison
--     .bindlocation 16509
-- step
--     #ah
--     .goto 1453/0,660.28,-8814.55
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cSubastadora Jaxon|r
--     >>|cffe07cf5Buy the following items for faster turn ins at Westfall shortly:|r
--     >>|cffff9a3cIf you don't want to or can't do this, skip this step|r
--     >>|T133972:0|t[Carne fibrosa de buitre]
--     >>|T133884:0|t[Ojo de múrloc]
--     >>|T135997:0|t[Morro de dentosangre]
--     >>|T134185:0|t[Okra]
--     >>|T134341:0|t[Hígado de Dentosangre]
--     >>|T4548890:0|t[Isorresorte de gólem]
--     >>|T132995:0|t[Giroestabilizador de cosechador]
--     .collect 729,3,38,1 -- Stringy Vulture Meat (3)
--     .collect 730,3,38,1 -- Murloc Eye (3)
--     .collect 731,3,38,1 -- Goretusk Snout (3)
--     .collect 732,3,38,1 -- Okra (3)
--     .collect 723,8,22,1 -- Goretusk Liver (8)
--     .collect 255007,14,92909,1 -- Golem Isospring (14)
--     .collect 255010,5,92909,1 -- Harvester Gyrostabilizer (5)
--     .target Auctioneer Jaxon
-- step
--     .goto 1453/0,484.200,-8832.500
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cDungar Tragolargo|r
--     .fp Stormwind >> Get the Stormwind Flight Path
--     .target Dungar Longdrink
-- step
--     #completewith SaldeanVendor
--     #optional
--     .goto 1429/0,875.96,-9814.400
--     .zone Westfall >> Travel to Westfall
-- step
--     .goto 1436/0,918.42,-9851.50
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cGranjero Cejade|r
--     .accept 64 >> Acepta la misión La reliquia olvidada
--     .target Farmer Furlbrow
-- step
--     .goto 1436/0,919.47,-9853.13
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cVerna Cejade|r
--     .accept 36 >> Acepta la misión Estofado de los Páramos de Poniente
--     .accept 151 >> Acepta la misión La pobre y vieja Blanchy
--     .target Verna Furlbrow
-- step
--     #completewith SalmaS
--     .goto 1436/0,1055.27,-10128.70,65 >> Travel to Saldean's Farm
-- step
--     .goto 1436/0,1055.27,-10128.70
--     .target Farmer Saldean
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cGranjero Saldean|r
--     .accept 109 >>Acepta la misión Habla con Gryan Mantorrecio
-- step
--     #label SalmaS
--     .goto 1436/0,1042.67,-10111.670
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cSalma Saldean|r
--     .turnin 36 >> Entrega la misión Estofado de los Páramos de Poniente
--     .target Salma Saldean
--     .accept 38 >> Acepta la misión Estofado de los Páramos de Poniente
-- step << Gnome/Dwarf/NightElf
--     #completewith next
--     .goto 1436/0,1045.12,-10508.80
--     .target Gryan Stoutmantle
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cGryan Mantorrecio|r
--     .turnin 109 >> Entrega la misión Habla con Gryan Mantorrecio
--     .isOnQuest 109
-- step
--     .goto 1436/0,1045.12,-10508.80
--     .target Gryan Stoutmantle
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cGryan Mantorrecio|r
--     .accept 12 >> Acepta la misión La Milicia Popular
-- step
--     .goto 1436/0,1041.97,-10511.13
--     .target Captain Danuvin
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cCapitán Danuvin|r
--     .accept 102 >> Acepta la misión En patrulla por los Páramos de Poniente
-- step
-- 	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cExplorador Galiaan|r
--     .target Scout Galiaan
--     .goto 1436/0,1126.67,-10636.670
--     .accept 153 >> Acepta la misión Pañuelos rojos de cuero
-- step
--     .goto 1436/0,1166.57,-10653.23
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cTabernera Heather|r
--     .vendor >>|cffe07cf5Buy food/water if needed|r
-- 	.target Innkeeper Heather
-- step
--     .goto 1436/0,1179.800,-10635.601
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cAlba Lunaclara::253092|r
--     .target Alba Fairmoon::253092
--     .accept 92742 >>Acepta la misión Pruebas en los pozos
--     .accept 92744 >>Acepta la misión Branquias de múrloc
-- step
-- 	#completewith GnollPaws
--     >>Open the |cffe07cf5Sacks of Oats|r on the ground. Loot them for the |cff4fc3f7Puñado de avena|r
--     >>|cffff9a3cYou can usually find them near Farm Fences or Buildings|r
--     .complete 151,1 --Handful of Oats (8)
-- step
--     #completewith TravelCompass
--     >>Kill |cffff5a4aYoung Goretusks|r and |cffff5a4aYoung Fleshrippers|r. Loot them for their |cff4fc3f7Vulture Meat|r, |cff4fc3f7Snouts|r and |cff4fc3f7Livers|r
--     .collect 729,3,38,1 --Stringy Vulture Meat (3)
--     .mob +Young Fleshripper
--     .mob +Fleshripper
--     .collect 731,3,38,1 --Goretusk Snout (3)
--     .mob +Young Goretusk
--     .mob +Goretusk
-- step
--     #completewith TravelCompass
--     >>Kill |cffff5a4aDefias Trappers|r and |cffff5a4aDefias Smugglers|r. Loot them for their |T133694:0|t|cff4fc3f7Red Leather Bandanas|r
--     .complete 12,1 -- Defias Trapper slain (15)
--     .mob +Defias Trapper
--     .complete 12,2 -- Defias Smuggler slain (15)
--     .mob +Defias Smuggler
--     .complete 153,1 -- Red Leather Bandana (15)
--     .mob +Defias Trapper
--     .mob +Defias Smuggler
-- step
--     #label TravelCompass
--     .isOnQuest 399
--     .goto 1436/0,1602.67,-10629.67,75 >> Travel to the Alexston's Farmstead
--     >>|cffff9a3cWork on completing the other quest objectives as you move there|r
-- step
--     #sticky
--     #completewith bennytime
--     >>Kill |cffff5a4aHarvest Watchers|r located on any of the fields as you run by them
--     >>Loot them for their |cff4fc3f7Okra|r and |cff4fc3f7Flasks of Oil|r
--     .mob Harvest Watcher
--     .collect 732,3,38,1 --Okra (3)
--     .collect 814,5,103,1 --Flask of Oil (5)
-- step
--     .goto 1436/0,1748.27,-10672.13
--     >>Open |cffe07cf5Alexston's Chest|r. Loot it for |cff4fc3f7Una sencilla brújula|r
--     .complete 399,1 --A Simple Compass (1)
--     .isOnQuest 399
-- step
--     .goto 1436/0,1404.200,-10290.900
--     .use 254545 >>|cffff9a3cUse the|r |T236996:0|t[Kit de muestra de agua de pozo] |cffff9a3cat the Molsen Farm well|r
--     .complete 92742,2 --|1/1 Molsen Farm Water Sample
-- step
--     #completewith bennytime
--     >>Kill |cffff5a4aYoung Goretusks|r and |cffff5a4aYoung Fleshrippers|r. Loot them for their |cff4fc3f7Vulture Meat|r, |cff4fc3f7Snouts|r and |cff4fc3f7Livers|r
--     .collect 729,3,38,1 --Stringy Vulture Meat (3)
--     .mob +Young Fleshripper
--     .mob +Fleshripper
--     .collect 731,3,38,1 --Goretusk Snout (3)
--     .mob +Young Goretusk
--     .mob +Goretusk
-- step
--     #completewith bennytime
--     >>Kill |cffff5a4aDefias Trappers|r and |cffff5a4aDefias Smugglers|r. Loot them for their |T133694:0|t|cff4fc3f7Red Leather Bandanas|r
--     .complete 12,1 -- Defias Trapper slain (15)
--     .mob +Defias Trapper
--     .complete 12,2 -- Defias Smuggler slain (15)
--     .mob +Defias Smuggler
--     .complete 153,1 -- Red Leather Bandana (15)
--     .mob +Defias Trapper
--     .mob +Defias Smuggler
-- step
--     .goto 1436/0,1266.67,-9927.33,75 >> Travel to the Jansen Stead, |cffff9a3cwork on the other quest objectives as you move there|r
-- step
-- 	#label bennytime
--     .goto 1436/0,1289.77,-9849.63
--     >>Open |cffe07cf5Furlbrow's Wardrobe|r. Loot it for |cff4fc3f7Reloj de bolsillo de Cejade|r
--     >>|cffff9a3cYou can loot |cffe07cf5Furlbrow's Wardrobe|r from outside if you angle your camera correctly|r
-- 	>>|cffff9a3cBe aware of |cffff5a4aBenny Blanco|r. He hits hard|r
--     .complete 64,1 --Furlbrow's Pocket Watch
-- step
--     .goto 1436/0,1192.12,-9641.73,60,0
--     .goto 1436/0,1042.67,-9619.33,60,0
--     .goto 1436/0,1192.12,-9641.73,60,0
--     .goto 1436/0,1042.67,-9619.33,60,0
--     .goto 1436/0,1192.12,-9641.73
--     .goto 1436/0,1042.67,-9619.33,0
--     >>Kill |cffff5a4aMurloc Raiders|r and |cffff5a4aMurloc Coastrunners|r. Loot them for their |cff4fc3f7Eyes|r and |cff4fc3f7Gills|r
--     .collect 730,3,38,1 --Murloc Eye (3)
--     .complete 92744,1 -- Longshore Murloc Gills 7/7
--     .mob Murloc Raider
--     .mob Murloc Coastrunner
-- step
--     .goto 1436/0,1035.300,-9835.101
--     .use 254545 >>|cffff9a3cUse the|r |T236996:0|t[Kit de muestra de agua de pozo] |cffff9a3cat the Jansen Stead well|r
--     .complete 92742,1 --|1/1 Jansen Stead Water Sample
-- step
--     .goto 1436/0,1004.87,-9716.87,60,0
--     .goto 1436/0,1013.62,-9861.53,60,0
--     .goto 1436/0,1192.12,-10175.13,60,0
--     .goto 1436/0,1019.57,-10204.30,60,0
--     .goto 1436/0,1013.62,-9861.53
--     >>Open the |cffe07cf5Sacks of Oats|r on the ground. Loot them for the |cff4fc3f7Puñado de avena|r
-- 	>>|cffff9a3cYou can usually find them near Farm Fences or Buildings|r
-- 	.complete 151,1 --Handful of Oats (8)
-- step
--     #label FurlbrowFarm
-- 	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cGranjero Cejade|r and |cff5cf05cVerna Cejade|r
--     .turnin 64 >> Entrega la misión La reliquia olvidada
--     .target +Farmer Furlbrow
--     .goto 1436/0,918.42,-9851.50
--     .turnin 151 >> Entrega la misión La pobre y vieja Blanchy
--     .target +Verna Furlbrow
--     .goto 1436/0,919.47,-9853.13
-- step
--     #completewith SaldeanVendor
-- 	.goto 1436/0,1055.27,-10128.70
-- 	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cGranjero Saldean|r
--     .vendor >> |cffe07cf5Vendor trash|r
--     >>|cffff9a3cDo NOT sell|r |T133884:0|t[Murloc Eyes], |T135997:0|t[Goretusk Snouts], |T134341:0|t[Goretusk Livers] |cffff9a3cor|r |T133972:0|t[Carne fibrosa de buitre]
-- 	.target Farmer Saldean
-- step
--     #optional
-- 	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cSalma Saldean|r
--     .goto 1436/0,1042.67,-10111.670
--     .turnin 38 >> Entrega la misión Estofado de los Páramos de Poniente
--     .isQuestComplete 38
--     .target Salma Saldean
-- step
--     #optional
--     .goto 1436/0,1213.400,-10153.800
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cOzwin Piñón de Hierro::253395|r
--     .target Ozwin Ironsprocket::253395
--     .accept 92909 >>Acepta la misión Cosechar a los cosechadores
--     .turnin 92909 >>Entrega la misión Cosechar a los cosechadores
--     .itemcount 255007,14 -- Golem Isospring (14)
--     .itemcount 255010,5 -- Harvester Gyrostabilizer (5)
-- step
--     #optional
-- 	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cSalma Saldean|r
--     .goto 1436/0,1042.67,-10111.670
--     .turnin 38 >> Entrega la misión Estofado de los Páramos de Poniente
--     .isQuestComplete 38
--     .target Salma Saldean
-- step
--     .isQuestAvailable 38
--     .goto 1436/0,1132.27,-10146.67,60,0
--     .goto 1436/0,1238.67,-9907.73,80,0
--     .goto 1436/0,1460.22,-10224.83,80,0
--     .goto 1436/0,1132.27,-10146.67,80,0
--     .goto 1436/0,1238.67,-9907.73,80,0
--     .goto 1436/0,1460.22,-10224.83,80,0
--     .goto 1436/0,1132.27,-10146.67,60,0
--     .goto 1436/0,1460.22,-10224.83,60,0
--     .goto 1436/0,1238.67,-9907.73
--     >>Kill |cffff5a4aHarvest Watchers|r. Loot them for their |cff4fc3f7Okra|r and |cff4fc3f7Flasks of Oil|r
--     .collect 732,3,38,1 --Okra (3)
--     .collect 814,5,103,1 --Flask of Oil (5)
-- step
--     .isQuestTurnedIn 38
--     #label HarvestW
--     .goto 1436/0,1132.27,-10146.67,60,0
--     .goto 1436/0,1238.67,-9907.73,80,0
--     .goto 1436/0,1460.22,-10224.83,80,0
--     .goto 1436/0,1132.27,-10146.67,80,0
--     .goto 1436/0,1238.67,-9907.73,80,0
--     .goto 1436/0,1460.22,-10224.83,80,0
--     .goto 1436/0,1132.27,-10146.67,60,0
--     .goto 1436/0,1460.22,-10224.83,60,0
--     .goto 1436/0,1238.67,-9907.73
--     >>Kill |cffff5a4aHarvest Watchers|r. Loot them for their |cff4fc3f7Flasks of Oil|r
--     .collect 814,5,103,1 --Flask of Oil (5)
-- step
--     #optional
--     .goto 1436/0,1213.400,-10153.800
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cOzwin Piñón de Hierro::253395|r
--     .target Ozwin Ironsprocket::253395
--     .accept 92909 >>Acepta la misión Cosechar a los cosechadores
--     .turnin 92909 >>Entrega la misión Cosechar a los cosechadores
--     .itemcount 255007,14 -- Golem Isospring (14)
--     .itemcount 255010,5 -- Harvester Gyrostabilizer (5)
-- step
--     .goto 1436/0,1179.52,-10382.57,75,0
--     .goto 1436/0,1138.22,-10474.97,75,0
--     .goto 1436/0,860.67,-10462.83,75,0
--     .goto 1436/0,904.07,-10038.87,75,0
--     .goto 1436/0,1104.62,-9848.000,75,0
--     .goto 1436/0,1298.52,-10028.13,75,0
--     .goto 1436/0,1340.52,-10401.93,75,0
--     .goto 1436/0,1111.97,-10342.20
--     >>Kill |cffff5a4aYoung Goretusks|r and |cffff5a4aYoung Fleshrippers|r. Loot them for their |cff4fc3f7Vulture Meat|r, |cff4fc3f7Snouts|r and |cff4fc3f7Livers|r
--     .collect 729,3,38,1 --Stringy Vulture Meat (3)
--     .mob +Young Fleshripper
--     .mob +Fleshripper
--     .collect 731,3,38,1 --Goretusk Snout (3)
--     .mob +Young Goretusk
--     .mob +Goretusk
--     .collect 723,8,22,1 --Goretusk Liver (8)
--     .mob +Young Goretusk
--     .mob +Goretusk
-- step
--     #label SaldeanVendor
-- 	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cSalma Saldean|r
-- 	.target Salma Saldean
--     .goto 1436/0,1042.67,-10111.670
--     .turnin 38 >> Entrega la misión Estofado de los Páramos de Poniente
-- step
--     #optional
--     .goto 1436/0,1213.400,-10153.800
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cOzwin Piñón de Hierro::253395|r
--     .target Ozwin Ironsprocket::253395
--     .accept 92909 >>Acepta la misión Cosechar a los cosechadores
--     .turnin 92909 >>Entrega la misión Cosechar a los cosechadores
--     .itemcount 255007,14 -- Golem Isospring (14)
--     .itemcount 255010,5 -- Harvester Gyrostabilizer (5)
-- step
--     #completewith next
--     >>Kill |cffff5a4aDefias Trappers|r and |cffff5a4aDefias Smugglers|r. Loot them for their |T133694:0|t|cff4fc3f7Red Leather Bandanas|r
--     >>|cffff9a3cIt is a dynamic respawn area meaning if you kill enough they will keep respawning|r
--     .complete 12,1 -- Defias Trapper slain (15)
--     .mob +Defias Trapper
--     .complete 12,2 -- Defias Smuggler slain (15)
--     .mob +Defias Smuggler
--     .complete 153,1 -- Red Leather Bandana (15)
--     .mob +Defias Trapper
--     .mob +Defias Smuggler
-- step
--     .goto 1436/0,1324.200,-10490.400
--     >>Kill |cffff5a4aDefias Trappers|r and |cffff5a4aDefias Smugglers|r. Loot them for their |T133694:0|t|cff4fc3f7Red Leather Bandanas|r
--     >>|cffff9a3cIt is a dynamic respawn area meaning if you kill enough they will keep respawning|r
--     .complete 12,1 -- Defias Trapper slain (15)
--     .mob +Defias Trapper
--     .complete 12,2 -- Defias Smuggler slain (15)
--     .mob +Defias Smuggler
--     .complete 153,1 -- Red Leather Bandana (15)
--     .mob +Defias Trapper
--     .mob +Defias Smuggler
-- step
-- 	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cGryan Mantorrecio|r
-- 	.target Gryan Stoutmantle
--     .goto 1436/0,1045.12,-10508.80
--     .turnin 12 >> Entrega la misión La Milicia Popular
-- step
-- 	.xp <14,1
-- 	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cGryan Mantorrecio|r
-- 	.target Gryan Stoutmantle
--     .goto 1436/0,1045.12,-10508.80
--     .accept 65 >> Acepta la misión La hermandad de los Defias
-- step
-- 	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cExplorador Galiaan|r
-- 	.target Scout Galiaan
--     .goto 1436/0,1126.67,-10636.670
--     .turnin 153 >> Entrega la misión Pañuelos rojos de cuero
-- step
--     .goto 1436/0,1179.800,-10635.601
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cAlba Lunaclara::253092|r
--     .target Alba Fairmoon::253092
--     .turnin 92742 >>Entrega la misión Pruebas en los pozos
--     .turnin 92744 >>Entrega la misión Branquias de múrloc
-- step
--     .hs >> Hearth to Stormwind
--     .bindlocation 16509,1
--     .cooldown item,6948,>2,1
--     .zoneskip Stormwind City
--     .zoneskip Darkshore
-- step
--     #completewith DeeprunEnter
--     .goto 1436/0,1037.42,-10628.27
-- 	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cThor|r
--     .fly Stormwind >> Fly to Stormwind
--     .target Thor
--     .zoneskip Stormwind City
--     .zoneskip Darkshore

-- step << Rogue
--     #ah
--     .goto 1453/0,609.63,-8787.71
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cMarda Weller|r
--     .vendor 1287 >>|cffe07cf5Buy a|r |T135343:0|t[Cimitarra] |cffe07cf5from her or something better from the Auction House and equip it your off-hand|r
--     .money <0.3815
--     .itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.7
--     .target Marda Weller
-- step << Rogue
--     #ssf
--     .goto 1453/0,609.63,-8787.71
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cMarda Weller|r
--     .vendor 1287 >>|cffe07cf5Buy a|r |T135343:0|t[Cimitarra] |cffe07cf5from her|r
--     .money <0.3815
--     .itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.7
--     .target Marda Weller
-- step << Rogue
--     .goto 1453/0,377.47,-8752.39
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cOsborne|r
--     .train 1758,1
--     .trainer >> Train your class spells
--     .target Osborne the Night Man
--     .xp <16,1
-- step << Warrior
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cWu|r or |cff5cf05cIlsa|r
--     .goto 1453/0,358.25,-8728.28,15,0
--     .goto 1453/0,302.6,-8685.53,15,0
-- 	.goto 1453/0,323.3,-8689.29
--     .train 1160,1
--     .trainer >> Train your class spells
--     .target Wu Shen
--     .target Ilsa Corbin
--     .xp <16,1
-- step << Hunter
--     .goto 1453/0,552.78,-8415.71
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cEinris Lanza Reluciente|r inside
--     .trainer >> Train your class spells
--     .target Einris Brightspear
--     .xp <16,1
-- step << Druid
--     .goto 1453/0,1347.6192,-8591.2168
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cTheridran|r
--     .trainer >>Train your class spells
-- 	.target Theridran
--     .xp <16,1
-- step
--     .goto 1453/0,719.67,-8550.30
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cBaros Alexston|r
--     .turnin 399 >> Entrega la misión Principios humildes
--     .target Baros Alexston
--     .isQuestComplete 399
-- step << Priest
--     #optional
--     #completewith next
--     .goto 1453/0,809.52,-8579.22,20 >> Travel to the Stormwind Cathedral
-- step << Priest
--     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTalk to |cff5cf05cHermano Joshua|r
--     .goto 1453/0,862.89,-8519.61
--     .trainer >> Train your class spells
--     .train 8122,1
--     .target Brother Joshua
--     .xp <16,1
-- step
--     #optional
--     #label endOfTheGuide
-- step
--     #label DeeprunEnter
--     #completewith next
--     .goto 1453/0,562.300,-8385.300,20,0
--     .goto 1453/0,522.000,-8352.101
--     .subzone 2257 >>Enter the Deeprun Tram
--     .zoneskip Ironforge
--     .zoneskip Loch Modan
--     .zoneskip Dun Morogh
-- step
--     .zone Ironforge >> Take the tram to Ironforge
--     .zoneskip Loch Modan
--     .zoneskip Dun Morogh


]=], "Alliance"}
R[#R + 1] = {[=[
#forever
#version 1
<< Alliance !NightElf
#name 13-15 Páramos de Poniente 
#displayname 14-15 Páramos de Poniente << Gnome/Dwarf !Hunter
#group Forever Guía de Mazmorras (A)
#subgroup Mazmorras 1-20
#next 15-17 Costa Oscura

step
    #optional
    .maxlevel 14,endOfTheGuide

step
    .goto 1453/0,673.58,-8867.76
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cTabernera Allison|r
    .home >> Establece tu Piedra de hogar en la ciudad de Ventormenta
    .target Innkeeper Allison
    .bindlocation 16509
step
    #ah
    .goto 1453/0,660.28,-8814.55
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cSubastadora Jaxon|r
    >>|cffe07cf5Compra los siguientes objetos para entregar las misiones más rápido en Páramos de Poniente pronto:|r
    >>|cffff9a3cSi no quieres o no puedes hacer esto, omite este paso|r
    >>|T133972:0|t[Carne fibrosa de buitre]
    >>|T133884:0|t[Ojo de múrloc]
    >>|T135997:0|t[Morro de dentosangre]
    >>|T134185:0|t[Okra]
    >>|T134341:0|t[Hígado de Dentosangre]
    >>|T4548890:0|t[Isorresorte de gólem]
    -->>|T132995:0|t[Giroestabilizador de cosechador]
    .collect 729,3,38,1 -- Stringy Vulture Meat (3)
    .collect 730,3,38,1 -- Murloc Eye (3)
    .collect 731,3,38,1 -- Goretusk Snout (3)
    .collect 732,3,38,1 -- Okra (3)
    .collect 723,8,22,1 -- Goretusk Liver (8)
    .collect 255007,14,92909,1 -- Golem Isospring (14)
    --.collect 255010,5,92909,1 -- Harvester Gyrostabilizer (5)
    .target Auctioneer Jaxon

step << Human
    .goto 1453/0,484.200,-8832.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDungar Tragolargo|r
    .turnin 6261 >> Entrega la misión Dungar Tragolargo
    .accept 6285 >> Acepta la misión Regresa junto a Lewis
    .target Dungar Longdrink

step << !Skyborne
    .goto 1453/0,484.200,-8832.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDungar Tragolargo|r
    .fly Westfall >> Vuela a Páramos de Poniente << !NightElf !Dwarf/!Hunter
    .fp Stormwind >> Consigue la Ruta de Vuelo de Ventormenta << NightElf/Dwarf Hunter
    .target Dungar Longdrink
step
    #completewith SaldeanVendor
    #optional
    .goto 1429/0,875.96,-9814.400
    .zone Westfall >> Viaja a Páramos de Poniente
step
    .goto 1436/0,918.42,-9851.50
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGranjero Cejade|r
    .accept 64 >> Acepta la misión La reliquia olvidada
    .target Farmer Furlbrow
step
    .goto 1436/0,919.47,-9853.13
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVerna Cejade|r
    .accept 36 >> Acepta la misión Estofado de los Páramos de Poniente
    .accept 151 >> Acepta la misión La pobre y vieja Blanchy
    .target Verna Furlbrow
step
    #completewith SalmaS
    .goto 1436/0,1055.27,-10128.70,65 >> Viaja a la Finca de Saldean
step
    .goto 1436/0,1055.27,-10128.70
    .target Farmer Saldean
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGranjero Saldean|r
    .accept 9 >> Acepta la misión Campos de la muerte
    .accept 109 >>Acepta la misión Habla con Gryan Mantorrecio << !Human
step
    #label SalmaS
    .goto 1436/0,1042.67,-10111.670
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSalma Saldean|r
    .turnin 36 >> Entrega la misión Estofado de los Páramos de Poniente
    .target Salma Saldean
    .accept 38 >> Acepta la misión Estofado de los Páramos de Poniente
    .accept 22 >> Acepta la misión Pastel de hígado de dentosangre
step << Human
    #label Lewis
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cIntendente Lewis|r
    .target Quartermaster Lewis
    .goto 1436/0,1021.67,-10500.63
    .turnin 6285 >> Entrega la misión Regresa junto a Lewis
step << !Human
    #completewith next
    .goto 1436/0,1045.12,-10508.80
    .target Gryan Stoutmantle
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGryan Mantorrecio|r
    .turnin 109 >> Entrega la misión Habla con Gryan Mantorrecio
    .isOnQuest 109
step
    .goto 1436/0,1045.12,-10508.80
    .target Gryan Stoutmantle
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGryan Mantorrecio|r
    .accept 12 >> Acepta la misión La Milicia Popular
step << skip
    .goto 1436/0,1041.97,-10511.13
    .target Captain Danuvin
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cCapitán Danuvin|r
    .accept 102 >> Acepta la misión En patrulla por los Páramos de Poniente
step << Human
    #requires Lewis
    .goto 1436/0,1126.67,-10636.670
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cExplorador Galiaan|r
    .target Scout Galiaan
    .accept 153 >> Acepta la misión Pañuelos rojos de cuero
step << !Human
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cExplorador Galiaan|r
    .target Scout Galiaan
    .goto 1436/0,1126.67,-10636.670
    .accept 153 >> Acepta la misión Pañuelos rojos de cuero
step
    .goto 1436/0,1166.57,-10653.23
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cTabernera Heather|r
    .vendor >>|cffe07cf5Compra comida/agua si es necesario|r
	.target Innkeeper Heather
step
    .goto 1436/0,1179.800,-10635.601
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAlba Lunaclara::253092|r
    .target Alba Fairmoon::253092
    .accept 92742 >>Acepta la misión Pruebas en los pozos
    .accept 92744 >>Acepta la misión Branquias de múrloc
step
    #optional
    .abandon 102 >> Abandona la misión En patrulla por los Páramos de Poniente
    >>|cffff9a3cNo completarás esta misión en esta guía|r
step
	#completewith MurlocEyeGills
    >>Abre los |cffe07cf5Sacos de avena|r del suelo. Despójalos para obtener el |cff4fc3f7Puñado de avena|r
    >>|cffff9a3cGeneralmente puedes encontrarlos cerca de las vallas de las granjas o de los edificios|r
    .complete 151,1 --Handful of Oats (8)
step
    #completewith TravelCompass
    >>Mata |cffff5a4aDentosangre jóvenes|r y |cffff5a4aDesgarradores jóvenes|r. Despójalos para obtener su |cff4fc3f7Carne de buitre|r, |cff4fc3f7Morros|r e |cff4fc3f7Hígados|r
    .collect 729,3,38,1 --Stringy Vulture Meat (3)
    .mob +Young Fleshripper
    .mob +Fleshripper
    .collect 731,3,38,1 --Goretusk Snout (3)
    .mob +Young Goretusk
    .mob +Goretusk
    .collect 723,8,22,1 --Goretusk Liver (8)
    .mob +Young Goretusk
    .mob +Goretusk
step
    #completewith TravelCompass
    >>Mata |cffff5a4aTramperos Defias|r y |cffff5a4aContrabandistas Defias|r. Despójalos para obtener sus |T133694:0|t|cff4fc3f7Pañuelos rojos de cuero|r
    .complete 12,1 -- Defias Trapper slain (15)
    .mob +Defias Trapper
    .complete 12,2 -- Defias Smuggler slain (15)
    .mob +Defias Smuggler
    .complete 153,1 -- Red Leather Bandana (15)
    .mob +Defias Trapper
    .mob +Defias Smuggler
step
    #label TravelCompass
    .isOnQuest 399
    .goto 1436/0,1602.67,-10629.67,75 >> Viaja a la Hacienda de Alexston
    >>|cffff9a3cVe completando los otros objetivos de misión mientras te diriges hacia allí|r
step
    #optional
    .itemcount 255007,10 -- only accepting this quest if they bought a bunch of isosprings from AH
    .goto 1436/0,1213.400,-10153.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOzwin Piñón de Hierro::253395|r en el granero
    .target Ozwin Ironsprocket::253395
    .accept 92909 >>Acepta la misión Cosechar a los cosechadores
step
    .isNotOnQuest 92909
    #completewith bennytime
    >>Mata |cffff5a4aVigilantes de la cosecha|r ubicados en cualquiera de los campos mientras corres cerca de ellos
    >>Despójalos para obtener su |cff4fc3f7Okra|r y sus |cff4fc3f7Frascos de aceite|r
    .mob Harvest Watcher
    .complete 9,1 --Havest Watcher slain (20)
    .collect 732,3,38,1 --Okra (3)
    .collect 814,5,103,1,1 --Flask of Oil (5)
step
    #optional
    .isOnQuest 92909
    #completewith bennytime
    >>Mata |cffff5a4aVigilantes de la cosecha|r ubicados en cualquiera de los campos mientras corres cerca de ellos
    >>Despójalos por sus |cff4fc3f7Okra|r, |cff4fc3f7Flasks of Oil|r, |cff4fc3f7Golem Isosprings|r y |cff4fc3f7Harvester Gyrostabilizers|r
    .mob Harvest Watcher
    .complete 9,1 --Havest Watcher slain (20)
    .collect 732,3,38,1 --Okra (3)
    .collect 814,5,103,1,1 --Flask of Oil (5)
    .complete 92909,1 -- Golem Isosprings (14)
    .complete 92909,2 -- Harvester Gyrostabilizer (5)
step
    .goto 1436/0,1748.27,-10672.13
    >>Abre el |cffe07cf5Cofre de Alexston|r. Despójalo para obtener |cff4fc3f7Una sencilla brújula|r
    >>|cffff9a3cEvita a los enemigos frente al edificio quemado. Despoja esto desde atrás, junto a la chimenea. Usa la chimenea para evadir los hechizos de |cffff5a4aSaqueadores|r si es necesario|r
    .complete 399,1 --A Simple Compass (1)
    .isOnQuest 399
step
    #completewith bennytime
    >>Mata |cffff5a4aDentosangre jóvenes|r y |cffff5a4aDesgarradores jóvenes|r. Despójalos para obtener su |cff4fc3f7Carne de buitre|r, |cff4fc3f7Morros|r e |cff4fc3f7Hígados|r
    .collect 729,3,38,1 --Stringy Vulture Meat (3)
    .mob +Young Fleshripper
    .mob +Fleshripper
    .collect 731,3,38,1 --Goretusk Snout (3)
    .mob +Young Goretusk
    .mob +Goretusk
    .collect 723,8,22,1 --Goretusk Liver (8)
    .mob +Young Goretusk
    .mob +Goretusk
step
    #completewith bennytime
    >>Mata |cffff5a4aTramperos Defias|r y |cffff5a4aContrabandistas Defias|r. Despójalos para obtener sus |T133694:0|t|cff4fc3f7Pañuelos rojos de cuero|r
    .complete 12,1 -- Defias Trapper slain (15)
    .mob +Defias Trapper
    .complete 12,2 -- Defias Smuggler slain (15)
    .mob +Defias Smuggler
    .complete 153,1 -- Red Leather Bandana (15)
    .mob +Defias Trapper
    .mob +Defias Smuggler
step
    .goto 1436/0,1266.67,-9927.33,75 >> Viaja a la Finca de Jansen, |cffff9a3ctrabaja en los otros objetivos de misión mientras te mueves hacia allí|r
step
	#label bennytime
    .goto 1436/0,1289.77,-9849.63
    >>Abre el |cffe07cf5Guardarropa de Cejade|r. Despoja el |cff4fc3f7Reloj de bolsillo de Cejade|r
    >>|cffff9a3cPuedes despojar el |cffe07cf5Guardarropa de Cejade|r desde fuera si orientas bien la cámara|r
	>>|cffff9a3cCuidado con |cffff5a4aBenny Blaanco|r. Pega fuerte|r
    .complete 64,1 --Furlbrow's Pocket Watch
step << skip
    #completewith next
    >>Mata |cffff5a4aGnolls Zarparrío|r y |cffff5a4aExploradores Zarparrío|r. Despójalos para obtener sus |T134297:0|t|cff4fc3f7Garras gnoll|r
    .complete 102,1 --Gnoll Paw (8)
    .mob Riverpaw Gnoll
    .mob Riverpaw Scout
step
    .goto 1436/0,1035.300,-9835.101
    .use 254545 >>|cffff9a3cUsa el|r |T236996:0|t[Kit de muestra de agua de pozo] |cffff9a3cen el pozo de la Finca de Jansen|r
    .complete 92742,1 --|1/1 Jansen Stead Water Sample
step
    #label MurlocEyeGills
    .goto 1436/0,1192.12,-9641.73,60,0
    .goto 1436/0,1042.67,-9619.33,60,0
    .goto 1436/0,1192.12,-9641.73,60,0
    .goto 1436/0,1042.67,-9619.33,60,0
    .goto 1436/0,1192.12,-9641.73
    .goto 1436/0,1042.67,-9619.33,0
    >>Mata a los |cffff5a4aAsaltantes múrloc|r y a los |cffff5a4aCorrecostas múrloc|r. Despójalos para obtener sus |cff4fc3f7Ojos|r y |cff4fc3f7Branquias|r
    >>|cffff9a3cSi no tienes muchas |cff4fc3f7Branquias|r para cuando hayas terminado con los |cff4fc3f7Ojos|r, omite este paso|r
    .collect 730,3,38,1 --Murloc Eye (3)
    .complete 92744,1 -- Longshore Murloc Gills 7/7
    .mob Murloc Raider
    .mob Murloc Coastrunner
step << skip
    #label GnollPaws
    .goto 1436/0,1042.67,-9715.0,60,0
    .goto 1436/0,1517.97,-9743.000,60,0
    .goto 1436/0,1412.62,-9720.83,60,0
    .goto 1436/0,1184.07,-9745.80,60,0
    .goto 1436/0,1026.57,-9715.70,60,0
    .goto 1436/0,1026.57,-9715.70,60,0
    .goto 1436/0,1517.97,-9743.000,60,0
    .goto 1436/0,1184.07,-9745.80,60,0
    .goto 1436/0,1412.62,-9720.83
    .goto 1436/0,1517.97,-9743.000,0
    .goto 1436/0,1184.07,-9745.80,0
    .goto 1436/0,1028.32,-9710.330,0
    >>Mata |cffff5a4aGnolls Zarparrío|r y |cffff5a4aExploradores Zarparrío|r. Despójalos para obtener sus |T134297:0|t|cff4fc3f7Garras gnoll|r
    .complete 102,1 --Gnoll Paw (8)
    .mob Riverpaw Gnoll
    .mob Riverpaw Scout
step
    .goto 1436/0,1004.87,-9716.87,60,0
    .goto 1436/0,1013.62,-9861.53,60,0
    .goto 1436/0,1192.12,-10175.13,60,0
    .goto 1436/0,1019.57,-10204.30,60,0
    .goto 1436/0,1013.62,-9861.53
    >>Abre los |cffe07cf5Sacos de avena|r del suelo. Despójalos para obtener el |cff4fc3f7Puñado de avena|r
	>>|cffff9a3cGeneralmente puedes encontrarlos cerca de las vallas de las granjas o de los edificios|r
	.complete 151,1 --Handful of Oats (8)
step << Human Warlock
    #label FurlbrowFarm
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGranjero Cejade|r y |cff5cf05cVerna Cejade|r
    .turnin 64 >> Entrega la misión La reliquia olvidada
    .turnin 184 >> Entrega la misión Las escrituras de Cejade
    .target +Farmer Furlbrow
    .goto 1436/0,918.42,-9851.50
    .turnin 151 >> Entrega la misión La pobre y vieja Blanchy
    .goto 1436/0,919.47,-9853.13
	.target +Verna Furlbrow
    .isOnQuest 184
step
    #optional << Human Warlock
    #label FurlbrowFarm << !Human/!Warlock
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGranjero Cejade|r y |cff5cf05cVerna Cejade|r
    .turnin 64 >> Entrega la misión La reliquia olvidada
    .target +Farmer Furlbrow
    .goto 1436/0,918.42,-9851.50
    .turnin 151 >> Entrega la misión La pobre y vieja Blanchy
    .target +Verna Furlbrow
    .goto 1436/0,919.47,-9853.13
step
    #completewith SaldeanVendor
	.goto 1436/0,1055.27,-10128.70
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGranjero Saldean|r
    .vendor >> |cffe07cf5Vende la basura|r
    >>|cffff9a3cNO vendas|r |T133884:0|t[Ojo de múrloc], |T135997:0|t[Morros de dentosangre], |T134341:0|t[Hígados de Dentosangre] |cffff9a3co|r |T133972:0|t[Carne fibrosa de buitre]
	.target Farmer Saldean
step
    #optional
    .isQuestComplete 9
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGranjero Saldean|r
	.target Farmer Saldean
    .goto 1436/0,1055.27,-10128.70
    .turnin 9 >> Entrega la misión Campos de la muerte
step
    #optional
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSalma Saldean|r
    .goto 1436/0,1042.67,-10111.670
    .turnin 22 >> Entrega la misión Pastel de hígado de dentosangre
    .turnin 38 >> Entrega la misión Estofado de los Páramos de Poniente
    .isQuestComplete 22
    .isQuestComplete 38
    .target Salma Saldean
step
    #optional
    .goto 1436/0,1213.400,-10153.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOzwin Piñón de Hierro::253395|r
    .target Ozwin Ironsprocket::253395
    .turnin 92909 >>Entrega la misión Cosechar a los cosechadores
    .itemcount 255007,14 -- Golem Isospring (14)
    .itemcount 255010,5 -- Harvester Gyrostabilizer (5)
step
    #optional
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSalma Saldean|r
    .goto 1436/0,1042.67,-10111.670
    .turnin 22 >> Entrega la misión Pastel de hígado de dentosangre
    .isQuestComplete 22
    .target Salma Saldean
step
    #optional
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSalma Saldean|r
    .goto 1436/0,1042.67,-10111.670
    .turnin 38 >> Entrega la misión Estofado de los Páramos de Poniente
    .isQuestComplete 38
    .target Salma Saldean
step
    #optional
    #completewith HarvestW
    .isOnQuest 92909
    >>Despoja a los |cffff5a4aHarvest Watchers|r para obtener |cff4fc3f7Golem Isosprings|r y |cff4fc3f7Harvester Gyrostabilizers|r
    .complete 92909,1 -- Golem Isosprings (14)
    .complete 92909,2 -- Harvester Gyrostabilizer (5)
step
    .isQuestAvailable 38
    .goto 1436/0,1132.27,-10146.67,60,0
    .goto 1436/0,1238.67,-9907.73,80,0
    .goto 1436/0,1460.22,-10224.83,80,0
    .goto 1436/0,1132.27,-10146.67,80,0
    .goto 1436/0,1238.67,-9907.73,80,0
    .goto 1436/0,1460.22,-10224.83,80,0
    .goto 1436/0,1132.27,-10146.67,60,0
    .goto 1436/0,1460.22,-10224.83,60,0
    .goto 1436/0,1238.67,-9907.73
    >>Mata a los |cffff5a4aVigías de la cosecha|r. Despójalos para obtener su |cff4fc3f7Okra|r y sus |cff4fc3f7Frascos de aceite|r
    .complete 9,1 --Harvest Watcher (20)
    .mob Harvest Watcher
    .collect 732,3,38,1 --Okra (3)
    .collect 814,5,103,1,1 --Flask of Oil (5)
step
    .isQuestTurnedIn 38
    #label HarvestW
    .goto 1436/0,1132.27,-10146.67,60,0
    .goto 1436/0,1238.67,-9907.73,80,0
    .goto 1436/0,1460.22,-10224.83,80,0
    .goto 1436/0,1132.27,-10146.67,80,0
    .goto 1436/0,1238.67,-9907.73,80,0
    .goto 1436/0,1460.22,-10224.83,80,0
    .goto 1436/0,1132.27,-10146.67,60,0
    .goto 1436/0,1460.22,-10224.83,60,0
    .goto 1436/0,1238.67,-9907.73
    >>Mata a los |cffff5a4aVigías de la cosecha|r. Despójalos para obtener sus |cff4fc3f7Frascos de aceite|r
    .complete 9,1 --Harvest Watcher (20)
    .mob Harvest Watcher
    .collect 814,5,103,1,1 --Flask of Oil (5)
step
    .isOnQuest 92909
    #optional
    .goto 1436/0,1132.27,-10146.67,60,0
    .goto 1436/0,1238.67,-9907.73,80,0
    .goto 1436/0,1460.22,-10224.83,80,0
    .goto 1436/0,1132.27,-10146.67,80,0
    .goto 1436/0,1238.67,-9907.73,80,0
    .goto 1436/0,1460.22,-10224.83,80,0
    .goto 1436/0,1132.27,-10146.67,60,0
    .goto 1436/0,1460.22,-10224.83,60,0
    .goto 1436/0,1238.67,-9907.73
    >>Mata a los |cffff5a4aHarvest Watchers|r. Despójalos por sus |cff4fc3f7Golem Isosprings|r y |cff4fc3f7Harvester Gyrostabilizers|r
    .complete 92909,1 -- Golem Isosprings (14)
    .complete 92909,2 -- Harvester Gyrostabilizer (5)
    .mob Harvest Watcher
step
    #optional
    .isQuestComplete 9
    .subzoneskip 107,1 -- forces early turnin if already at same farm
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGranjero Saldean|r
	.target Farmer Saldean
    .goto 1436/0,1055.27,-10128.70
    .turnin 9 >> Entrega la misión Campos de la muerte
step
    .goto 1436/0,1179.52,-10382.57,75,0
    .goto 1436/0,1138.22,-10474.97,75,0
    .goto 1436/0,860.67,-10462.83,75,0
    .goto 1436/0,904.07,-10038.87,75,0
    .goto 1436/0,1104.62,-9848.000,75,0
    .goto 1436/0,1298.52,-10028.13,75,0
    .goto 1436/0,1340.52,-10401.93,75,0
    .goto 1436/0,1111.97,-10342.20
    >>Mata |cffff5a4aDentosangre jóvenes|r y |cffff5a4aDesgarradores jóvenes|r. Despójalos para obtener su |cff4fc3f7Carne de buitre|r, |cff4fc3f7Morros|r e |cff4fc3f7Hígados|r
    .collect 729,3,38,1 --Stringy Vulture Meat (3)
    .mob +Young Fleshripper
    .mob +Fleshripper
    .collect 731,3,38,1 --Goretusk Snout (3)
    .mob +Young Goretusk
    .mob +Goretusk
    .collect 723,8,22,1 --Goretusk Liver (8)
    .mob +Young Goretusk
    .mob +Goretusk
step
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGranjero Saldean|r
	.target Farmer Saldean
    .goto 1436/0,1055.27,-10128.70
    .turnin 9 >> Entrega la misión Campos de la muerte
step
    #label SaldeanVendor
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSalma Saldean|r
	.target Salma Saldean
    .goto 1436/0,1042.67,-10111.670
    .turnin 38 >> Entrega la misión Estofado de los Páramos de Poniente
    .turnin 22 >> Entrega la misión Pastel de hígado de dentosangre
step
    #optional
    .goto 1436/0,1213.400,-10153.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOzwin Piñón de Hierro::253395|r
    .target Ozwin Ironsprocket::253395
    .turnin 92909 >>Entrega la misión Cosechar a los cosechadores
    .itemcount 255007,14 -- Golem Isospring (14)
    .itemcount 255010,5 -- Harvester Gyrostabilizer (5)
step
    #completewith next
    >>Mata |cffff5a4aTramperos Defias|r y |cffff5a4aContrabandistas Defias|r. Despójalos para obtener sus |T133694:0|t|cff4fc3f7Pañuelos rojos de cuero|r
    >>|cffff9a3cEs un área de reaparición dinámica, lo que significa que si matas a suficientes enemigos, seguirán reapareciendo|r
    .complete 12,1 -- Defias Trapper slain (15)
    .mob +Defias Trapper
    .complete 12,2 -- Defias Smuggler slain (15)
    .mob +Defias Smuggler
    .complete 153,1 -- Red Leather Bandana (15)
    .mob +Defias Trapper
    .mob +Defias Smuggler
step
    .goto 1436/0,1404.200,-10290.900
    .use 254545 >>|cffff9a3cUsa el|r |T236996:0|t[Kit de muestra de agua de pozo] |cffff9a3cen el pozo de la Granja de Molsen|r
    .complete 92742,2 --|1/1 Molsen Farm Water Sample
step
    .isOnQuest 153
    .goto 1436/0,1324.200,-10490.400
    >>Mata |cffff5a4aTramperos Defias|r y |cffff5a4aContrabandistas Defias|r. Despójalos para obtener sus |T133694:0|t|cff4fc3f7Pañuelos rojos de cuero|r
    >>|cffff9a3cEs un área de reaparición dinámica, lo que significa que si matas a suficientes enemigos, seguirán reapareciendo|r
    >>|cffff9a3cSi aún estás muy rezagado con los |T133694:0|t|cff4fc3f7Pañuelos de cuero rojo|r y has matado a todos los |cffff5a4aDefias|r requeridos, abandona la misión|r [Pañuelos rojos de cuero]
    .complete 12,1 -- Defias Trapper slain (15)
    .mob +Defias Trapper
    .complete 12,2 -- Defias Smuggler slain (15)
    .mob +Defias Smuggler
    .complete 153,1 -- Red Leather Bandana (15)
    .mob +Defias Trapper
    .mob +Defias Smuggler
step
    #optional
    .goto 1436/0,1324.200,-10490.400
    >>Mata |cffff5a4aTramperos Defias|r y |cffff5a4aContrabandistas Defias|r. Despójalos para obtener sus |T133694:0|t|cff4fc3f7Pañuelos rojos de cuero|r
    >>|cffff9a3cEs un área de reaparición dinámica, lo que significa que si matas a suficientes enemigos, seguirán reapareciendo|r
    .complete 12,1 -- Defias Trapper slain (15)
    .mob +Defias Trapper
    .complete 12,2 -- Defias Smuggler slain (15)
    .mob +Defias Smuggler
step
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGryan Mantorrecio|r
	.target Gryan Stoutmantle
    .goto 1436/0,1045.12,-10508.80
    .turnin 12 >> Entrega la misión La Milicia Popular
step
	.xp <14,1
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGryan Mantorrecio|r
	.target Gryan Stoutmantle
    .goto 1436/0,1045.12,-10508.80
    .accept 65 >> Acepta la misión La hermandad de los Defias
step << Skyborne
    .goto 1436/0,1037.42,-10628.27
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThor|r
    .fp Westfall >> Consigue la ruta de vuelo de Páramos de Poniente
    .target Thor
step
    #optional
    .isQuestComplete 102
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cCapitán Danuvin|r
	.target Captain Danuvin
    .goto 1436/0,1041.97,-10511.13
    .turnin 102 >> Entrega la misión En patrulla por los Páramos de Poniente
step
    .isQuestComplete 153
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cExplorador Galiaan|r
	.target Scout Galiaan
    .goto 1436/0,1126.67,-10636.670
    .turnin 153 >> Entrega la misión Pañuelos rojos de cuero
step
    .goto 1436/0,1179.800,-10635.601
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAlba Lunaclara::253092|r
    .target Alba Fairmoon::253092
    .turnin 92742 >>Entrega la misión Pruebas en los pozos
    .turnin 92744 >>Entrega la misión Branquias de múrloc
    .isQuestComplete 92744
step
    .goto 1436/0,1179.800,-10635.601
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAlba Lunaclara::253092|r
    .target Alba Fairmoon::253092
    .turnin 92742 >>Entrega la misión Pruebas en los pozos
step
    .hs >> Usa tu Piedra de hogar para ir a Ventormenta
    .bindlocation 16509,1
    .cooldown item,6948,>2,1
    .zoneskip Stormwind City
    .zoneskip Darkshore
step
    #completewith DeeprunEnter
    .goto 1436/0,1037.42,-10628.27
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThor|r
    .fly Stormwind >> Vuela a Ventormenta
    .target Thor
    .zoneskip Stormwind City
    .zoneskip Darkshore

step << Human Rogue
    #ah
    .goto 1453/0,609.63,-8787.71
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMarda Weller|r
    .vendor 1287 >>|cffe07cf5Cómprale una|r |T135343:0|t[Cimitarra] |cffe07cf5o algo mejor de la Casa de Subastas y equípalo en tu mano izquierda|r
    .money <0.3815
    .itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.7
    .target Marda Weller
step << Human Rogue
    #ssf
    .goto 1453/0,609.63,-8787.71
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMarda Weller|r
    .vendor 1287 >>|cffe07cf5Compra una|r |T135343:0|t[Cimitarra] |cffe07cf5a esta vendedora|r
    .money <0.3815
    .itemStat 17,ITEM_MOD_DAMAGE_PER_SECOND_SHORT,<8.7
    .target Marda Weller
step << Rogue
    .goto 1453/0,377.47,-8752.39
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOsborne|r
    .train 1758,1
    .trainer >> Aprende tus hechizos de clase
    .target Osborne the Night Man
step << Warrior
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWu|r o |cff5cf05cIlsa|r
    .goto 1453/0,358.25,-8728.28,15,0
    .goto 1453/0,302.6,-8685.53,15,0
	.goto 1453/0,323.3,-8689.29
    .train 1160,1
    .trainer >> Aprende tus hechizos de clase
    .target Wu Shen
    .target Ilsa Corbin
step
    .goto 1453/0,765.700,-8804.000
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCatherine Leland|r
    >>|cffe07cf5Cómprale un|r |T134335:0|t[Adorno lustroso] |cffe07cf5y tres|r |T134324:0|t[Reptadores nocturnos] |cffe07cf5. Esto es para una misión de 900xp|r
    .collect 6529,1,95065,1 --|1/1 Shiny Bauble
    .collect 6530,3,95065,1 --|3/3 Nightcrawlers
    .target Catherine Leland
step << Hunter
    .goto 1453/0,552.78,-8415.71
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cEinris Lanza Reluciente|r dentro
    >>|cffff9a3cSi acabas de aprender habilidades antes, omite este paso|r
    .trainer >> Aprende tus hechizos de clase
    .target Einris Brightspear
step
    .goto 1453/0,719.67,-8550.30
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBaros Alexston|r
    .turnin 399 >> Entrega la misión Principios humildes
    .target Baros Alexston
    .isQuestComplete 399
step << NightElf Druid
    .goto 1453/0,1347.6192,-8591.2168
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTheridran|r
    .trainer >>Aprende tus hechizos de clase
	.target Theridran
step << Warlock
    #optional
    #completewith next
    .goto 1453/0,988.44,-8942.15,20,0
    .goto 1453/0,1015.33,-8978.9,15 >> Viaja a El Cordero Degollad y baja las escaleras
step << Warlock
    .goto 1453/0,1029.89,-8971.06
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cUrsula Deline|r
    .trainer >> Aprende tus hechizos de clase
    .train 6222,1
    .target Ursula Deline
step << Mage
    #optional
    #completewith next
    .goto 1453/0,874.32,-9014.67,10 >> Viaja a la Torre de los Magos
step << Mage
    .goto 1453/0,885.34,-9006.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cElsharin|r
    .train 2137,1
    .trainer >> Aprende tus hechizos de clase
    .target Elsharin
step << Priest/Paladin
    #optional
    #completewith train19742 << Paladin
    #completewith next << Priest
    .goto 1453/0,809.52,-8579.22,20 >> Viaja a la Catedral de Ventormenta
step << Human Paladin
    .isOnQuest 1780
    .goto 1453/0,845.800,-8545.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDuthorian Rall|r
    .turnin 1780 >>Entrega la misión Escrito sobre divinidad
    .target Duthorian Rall
step << Paladin
    #label train19742
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cArthur el Leal|r
    .goto 1453/0,859.13,-8559.14,10,0
    .goto 1453/0,861.14,-8573.03
    .trainer >> Aprende tus hechizos de clase
    .train 19742,1
    .target Arthur the Faithful
step
    #optional
    #sticky
    .abandon 153 >> Abandona la misión Pañuelos rojos de cuero
step
    #optional
    #sticky
    .abandon 92744 >> Abandona la misión Branquias de múrloc
step
    #optional
    #label endOfTheGuide

step
    .goto 1453/0,673.58,-8867.76
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cTabernera Allison|r
    .home >> Establece tu Piedra de hogar en la ciudad de Ventormenta
    .target Innkeeper Allison
    .bindlocation 16509
step
    #ah
    .goto 1453/0,660.28,-8814.55
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cSubastadora Jaxon|r
    >>|cffe07cf5Compra|r |T133970:0|t|cff4fc3f7[Trozos de carne de jabalí]|r |cffe07cf5y/o|r |T133970:0|t|cff4fc3f7[Carne de lobo fibrosa]|r |cffe07cf5para subir tu|r |T133971:0|t[Cocina] |cffe07cf5más tarde|r
    >>|cffff9a3cTu habilidad de|r |T133971:0|t[Cocina] |cffff9a3cdebe ser 10 para la entrega en Costa Oscura de|r |T133972:0|t[Carne de zancudo]
    >>|cffff9a3cSi no quieres o no puedes hacer esto, omite este paso|r
    >>|cffe07cf5Compra los siguientes objetos para entregas más rápidas en Costa Oscura pronto:|r
    >>|T133972:0|t[Carne de zancudo]
    >>|T133912:0|t[Mero de Costa Oscura]
    >>|T133970:0|t|cff4fc3f7[Trozos de carne de jabalí]|r
    >>|T133970:0|t|cff4fc3f7[Carne de lobo fibrosa]|r
    .collect 5469,5,2178,1 -- Strider Meat (5)
    .collect 12238,6,1141,1 -- Darkshore Grouper (6)
    .collect 769,50,2178,1,0x20,cooking --Chunk of Boar Meat (1-50)
    .disablecheckbox
    .collect 2672,50,2178,1,0x20,cooking --Stringy Wolf Meat (1-50)
    .disablecheckbox
    .target Auctioneer Jaxon
    .skill cooking,<1,1 -- step only displays if skill is 1 or higher
step
    #ah
    #optional
    .goto 1453/0,660.28,-8814.55
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cSubastadora Jaxon|r
    >>|cffff9a3cSi no quieres o no puedes hacer esto, omite este paso|r
    >>|cffe07cf5Compra los siguientes objetos para entregas más rápidas en Costa Oscura pronto:|r
    >>|T133912:0|t[Mero de Costa Oscura]
    .collect 12238,6,1141,1 -- Darkshore Grouper (6)
    .target Auctioneer Jaxon
step
    .goto 1453/0,1193.100,-8328.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cManifestación de dependiente Philmor::268511|r 
    .target Manifest Clerk Philmor::268511
    .accept 97220 >>Acepta la misión Favor de Philmor
step
    .goto 1453/0,1269.100,-8540.601
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGilbert Gray::267118|r
    .target Gilbert Gray::267118
    .accept 95065 >>Acepta la misión Hora de la pesca
    .turnin 95065 >>Entrega la misión Hora de la pesca
step
    #optional
    #requires DockTravel
    #label DarkshoreCook1
    #completewith DarkshoreBoat
    >>|cffff9a3cMientras esperas el barco en el muelle:|r
    .cast 818 >>|cffff9a3cCrea una|r |T135805:0|t[Hoguera básica] |cffff9a3c(en tu Libro de Profesiones)|r
    .usespell 818
    .zoneskip Darkshore
    .itemcount 769,1 --Chunk of Boar Meat (1+)
    .itemcount 2672,1 --Stringy Wolf Meat (1+)
    .itemcount 4470,1 --Simple Wood (1+)
    .itemcount 4471,1 --Flint and Tinder (1)
    .skill cooking,50,1 --XX Shows if cooking skill is <50
step
    #optional
    #requires DarkshoreCook1
    #label DarkshoreCook2
    #completewith DarkshoreBoat
    >>|cffff9a3cMientras esperas el barco en el muelle:|r
    .cast 818 >>|cffff9a3cCrea una|r |T135805:0|t[Hoguera básica] |cffff9a3c(en tu Libro de Profesiones)|r
    .usespell 818
    .zoneskip Darkshore
    .itemcount 769,<1 --Chunk of Boar Meat (<1)
    .itemcount 2672,1 --Stringy Wolf Meat (1+)
    .itemcount 4470,1 --Simple Wood (1+)
    .itemcount 4471,1 --Flint and Tinder (1)
    .skill cooking,50,1 --XX Shows if cooking skill is <50
step
    #optional
    #requires DarkshoreCook2
    #label DarkshoreCook3
    #completewith DarkshoreBoat
    >>|cffff9a3cMientras esperas el barco en el muelle:|r
    .cast 818 >>|cffff9a3cCrea una|r |T135805:0|t[Hoguera básica] |cffff9a3c(en tu Libro de Profesiones)|r
    .usespell 818
    .zoneskip Darkshore
    .itemcount 769,1 --Chunk of Boar Meat (1+)
    .itemcount 2672,<1 --Stringy Wolf Meat (<1)
    .itemcount 4470,1 --Simple Wood (1+)
    .itemcount 4471,1 --Flint and Tinder (1)
    .skill cooking,50,1 --XX Shows if cooking skill is <50
step
    #optional
    #requires DarkshoreCook3
    #label DarkshoreCook4
    #completewith DarkshoreBoat
    >>|cffff9a3cNecesitas 50 de|r |T133971:0|t[Cocina] |cffff9a3cpara una misión en Bosque del Ocaso más adelante|r
    >>|T133971:0|t[Cocina] |cffff9a3clos siguientes objetos:|r
    >>|T133971:0|t[Cocina] |cffff9a3cel|r |T133970:0|t|cff4fc3f7[Trozo de carne de jabalí]|r |cffff9a3cen|r |T133974:0|t[Carne de jabalí asada]
    >>|T133971:0|t[Cocina] |cffff9a3cla|r |T133970:0|t|cff4fc3f7[Carne de lobo fibrosa]|r |cffff9a3cen|r |T133974:0|t[Carne de lobo carbonizada]
    .usespell 2550
    .zoneskip Darkshore
    .itemcount 769,1 --Chunk of Boar Meat (1+)
    .itemcount 2672,1 --Stringy Wolf Meat (1+)
    .itemcount 4471,1 --Flint and Tinder (1)
    .skill cooking,50,1
step
    #optional
    #requires DarkshoreCook4
    #label DarkshoreCook5
    #completewith DarkshoreBoat
    >>|cffff9a3cNecesitas 50 de|r |T133971:0|t[Cocina] |cffff9a3cpara una misión en Bosque del Ocaso más adelante|r
    >>|T133971:0|t[Cocina] |cffff9a3cla|r |T133970:0|t|cff4fc3f7[Carne de lobo fibrosa]|r |cffff9a3cen|r |T133974:0|t[Carne de lobo carbonizada]
    .usespell 2550
    .zoneskip Darkshore
    .itemcount 769,<1 --Chunk of Boar Meat (<1)
    .itemcount 2672,1 --Stringy Wolf Meat (1)
    .itemcount 4471,1 --Flint and Tinder (1)
    .skill cooking,50,1
step
    #optional
    #requires DarkshoreCook5
    #label DarkshoreCook6
    #completewith DarkshoreBoat
    >>|cffff9a3cNecesitas 50 de|r |T133971:0|t[Cocina] |cffff9a3cpara una misión en Bosque del Ocaso más adelante|r
    >>|T133971:0|t[Cocina] |cffff9a3cel|r |T133970:0|t|cff4fc3f7[Trozo de carne de jabalí]|r |cffff9a3cen|r |T133974:0|t[Carne de jabalí asada]
    .usespell 2550
    .zoneskip Darkshore
    .itemcount 769,1 --Chunk of Boar Meat (1)
    .itemcount 2672,<1 --Stringy Wolf Meat (<1)
    .itemcount 4471,1 --Flint and Tinder (1)
    .skill cooking,50,1
step
    #optional
    .goto 1453/0,1330.100,-8645.400
    >>|cffff9a3cSube tu nivel de|r |T135966:0|t[Primeros auxilios] |cffff9a3cmientras esperas el barco a Costa Oscura si es necesario|r
    .zone Darkshore >> Toma el barco hacia Costa Oscura
    .skill firstaid,<1,1 -- shows if firstaid is >1
step
    #label DarkshoreBoat
    .goto 1453/0,1330.100,-8645.400
    .zone Darkshore >> Toma el barco hacia Costa Oscura
]=], "Alliance"}
R[#R + 1] = {[=[
#forever
#version 1
<< Alliance !NightElf
#name 15-17 Costa Oscura
#group Forever Guía de Mazmorras (A)
#subgroup Mazmorras 1-20
#next 17-18 Salón de Señores Feudales

step
    .goto 1439/1,600.50,6424.66--c:1439,35.743,43.710
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCerellean Zarpablanca|r
    .accept 963 >> Acepta la misión Un amor eterno
    .target Cerellean Whiteclaw
step
    #optional
    #completewith next
    .goto 1439/1,525.800,6414.800,8 >> Sube por las rampa hacia |cff5cf05cManiveo Zumbang|r
step
    .goto 1439/1,519.74,6406.10--c:1439,36.976,44.135
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cManiveo Zumbang|r arriba
    .accept 983 >> Acepta la misión La caja mecánica 827
    .target Wizbang Cranktoggle
step
    .goto 1439/1,497.08,6427.72--c:1439,37.322,43.640
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBarithras Sombra Lunar|r
    .accept 947 >> Acepta la misión La cueva de las setas
    .target Barithras Moonshade
step
    .goto 1439/1,472.12,6438.51--c:1439,37.703,43.393
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cCentinela Glynda Nal'Shea|r
    .accept 4811 >> Acepta la misión El cristal rojo
    .target Sentinel Glynda Nal'Shea
step
    .goto 1439/1,397.45,6437.50--c:1439,38.843,43.416
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTharnariun Espinarbolado|r
    .accept 2118 >> Acepta la misión Tierras apestadas
    .target Tharnariun Treetender
step
    .goto 1439/1,362.74,6434.58--c:1439,39.373,43.483
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTerenthis|r
    .accept 984 >> Acepta la misión La extensión de la amenaza
    .target Terenthis
step
    .goto 1439/1,503.100,6402.100
    >>Haz clic en el |cffe07cf5Cartel de Se busca|r
    .accept 98025 >>Acepta la misión SE BUSCA: Jai'vhanel
step
    #optional
    .goto 1439/1,577.38,6371.35
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGubber Blump|r
    .accept 1141 >> Acepta la misión La familia y la caña de pescar
    .turnin 1141 >> Entrega la misión La familia y la caña de pescar
    .itemcount 12238,6 -- Darkshore Grouper (6)
    .target Gubber Blump
step
    #label WashedA
    .goto 1439/1,537.75,6363.01,8,0--c:1439,36.701,45.122
    .goto 1439/1,542.99,6342.31--c:1439,36.621,45.596
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGwennyth Bly'Leggonde|r
    .accept 3524 >> Acepta la misión Varado
    .target Gwennyth Bly'Leggonde
step
    .goto 1439/1,561.66,6343.27
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCaylais Plumalunar|r
    .fp Auberdine >> Consigue la ruta de vuelo de Auberdine
    .target Caylais Moonfeather
step << Dwarf Hunter/Human Hunter/Skyborne Hunter
    #optional
    #completewith RabidThistle
    #loop
    .goto 1439/1,272.54,5255.27,0
    .goto 1439/1,271.23,4902.88,0
    .goto 1439/1,438.91,5131.69,0
    .goto 1439/1,272.54,5255.27,40,0
    .goto 1439/1,271.23,4902.88,40,0
    .goto 1439/1,438.91,5131.69,40,0
    >>|cffff9a3cEnvía tu mascota a atacar al |cffff5a4aOso cardo|r. Una vez que tu mascota sea aturdida por el |cffff5a4aOso cardo|r, abandona tu mascota y empieza a domesticarla|r
    .train 16828 >>|cffff9a3cLanza|r |T132164:0|t[Domesticar bestia] |cffff9a3cen un |cffff5a4aOso cardo|r para domesticarlo|r
    .target Thistle Bear
    .train 17255,1 --skips if they also already know bite r2
step
    #sticky
    #label BuzzBox1
    #loop
    .goto 1439/1,580.33,6378.94,0--c:1439,36.051,44.757
    .goto 1439/1,565.33,6146.90,0--c:1439,36.280,50.071
    .goto 1439/1,631.15,5998.74,0--c:1439,35.275,53.464
    .waypoint 1439/1,577.71,6084.46,60,0--c:1439,36.091,51.501
    .waypoint 1439/1,510.63,6046.60,60,0--c:1439,37.115,52.368
    .waypoint 1439/1,509.65,5990.05,60,0--c:1439,37.130,53.663
    .waypoint 1439/1,535.20,5922.02,60,0--c:1439,36.740,55.221
    .waypoint 1439/1,606.26,5893.59,60,0--c:1439,35.655,55.872
    .waypoint 1439/1,643.40,5927.95,60,0--c:1439,35.088,55.085
    .waypoint 1439/1,631.15,5998.74,60,0--c:1439,35.275,53.464
    .waypoint 1439/1,577.71,6084.46,60,0--c:1439,36.091,51.501
    .waypoint 1439/1,565.33,6146.90,60,0--c:1439,36.280,50.071
    .waypoint 1439/1,549.41,6213.14,60,0--c:1439,36.523,48.554
    .waypoint 1439/1,585.17,6219.52,60,0--c:1439,35.977,48.408
    .waypoint 1439/1,590.09,6274.67,60,0--c:1439,35.902,47.145
    .waypoint 1439/1,599.45,6348.46,60,0--c:1439,35.759,45.455
    .waypoint 1439/1,580.33,6378.94,60,0--c:1439,36.051,44.757
    >>Mata |cffff5a4aReptadores de marea pigmeo|r y |cffff5a4aReptadores de arrecife jóvenes|r. Despójalos para obtener sus |cff4fc3f7Patas de reptador|r
    >>|cffff9a3cPuede que necesites entrar al agua para encontrarlos|r
    >>|cffff9a3cAunque algunas de estas misiones sean grises, complétalas igual, ya que forman parte de una cadena|r
    .complete 983,1 --Crawler Leg (6)
    .mob Pygmy Tide Crawler
    .mob Young Reef Crawler
    .isOnQuest 983
step
    .goto 1439/1,559.37,6109.83--c:1439,36.371,50.920
    >>Abre la |cffe07cf5Criatura marina varada|r. Despójala para obtener los |cff4fc3f7Huesos de criatura marina|r
    .complete 3524,1 --Sea Creature Bones (1)



step << Druid
    #ah
    #optional
    #completewith CliffspringEnd
    #label GatheringQ
    .skill herbalism,15 >>|cffff9a3cSube tu|r |T136065:0|t[Herboristería] |cffff9a3cal 15 para poder recolectar|r |T134187:0|t[Raíz de tierra] |cffff9a3cpara una misión de clase importante en pronto. Puedes desaprenderla después|r
    >>|cffff9a3cSi prefieres comprar 5|r |T134187:0|t[Raíz de tierra] |cffff9a3cde la Casa de Subastas después, omite este paso|r
    .collect 2449,5,6123,1 --Earthroot (5)
    .disablecheckbox
step << Druid
    #ssf
    #optional
    #completewith CliffspringEnd
    #label GatheringQ
    .skill herbalism,15 >>|cffff9a3cSube tu|r |T136065:0|t[Herboristería] |cffff9a3cal 15 para poder recopilar 5|r |T134187:0|t[Raíz de tierra] |cffff9a3cpara una misión de clase importante pronto. Puedes desaprenderla después|r
    .collect 2449,5,6123,1 --Earthroot (5)
    .disablecheckbox
step << Druid
    #optional
    #completewith CliffspringEnd
    #requires GatheringQ
    >>Recoge 5 |T134187:0|t[Raíz de tierra] mediante |T136065:0|t[Herboristería] |cffff9a3cy raramente en los|cffe07cf5 Cofres maltrechos|r para una misión de clase futura|r
    .collect 2449,5,6123,1 --Earthroot (5)
    .skill herbalism,<15,1



step
    #completewith next
    >>|cffff9a3cUsa|r |T134335:0|t[Esperanza de Tharnariun] |cffff9a3cen un|r |cffff5a4aOso cardo rabioso|r --|cffff9a3c. It can be used from any range as long as you're targeting the|r |cffff5a4aBear|r
    -->>|cffff9a3c==DO NOT USE THE QUEST ITEM IF THERES NO |cffff5a4aBEAR|r NEARBY==|r
    >>|cffff9a3c¡Puedes desperdiciar la trampa y hacer que la misión sea imposible de completar! Si eso te sucede, tienes que volver a quien te dio la misión y pedirle otra trampa|r
    .complete 2118,1 --Rabid Thistle Bear Captured (1)
    .unitscan Rabid Thistle Bear
    .use 7586
step
    .goto 1439/1,393.72,5993.24
    >>Corre hacia el borde del Campamento Fúrbolg
    .complete 984,1 -- Find a corrupt furbolg camp
step
    #sticky
    #label RabidThistle
    #loop
    .goto 1439/1,437.86,6028.61,0--c:1439,38.226,52.780
    .goto 1439/1,378.72,5749.31,0--c:1439,39.129,59.176
    .goto 1439/1,437.86,6028.61,50,0--c:1439,38.226,52.780
    .goto 1439/1,418.15,5946.47,50,0--c:1439,38.527,54.661
    .goto 1439/1,450.24,5852.41,50,0--c:1439,38.037,56.815
    .goto 1439/1,446.44,5783.42,50,0--c:1439,38.095,58.395
    .goto 1439/1,407.08,5806.17,50,0--c:1439,38.696,57.874
    .goto 1439/1,378.72,5749.31,50,0--c:1439,39.129,59.176
    >>|cffff9a3cUsa|r |T134335:0|t[Esperanza de Tharnariun] |cffff9a3cen un|r |cffff5a4aOso cardo rabioso|r --|cffff9a3c. It can be used from any range as long as you're targeting the bear|r
    -->>|cffff9a3c==DO NOT USE THE QUEST ITEM IF THERES NO BEAR NEARBY==|r
    >>|cffff9a3c¡Puedes desperdiciar la trampa y hacer que la misión sea imposible de completar! Si eso te sucede, tienes que volver a quien te dio la misión y pedirle otra trampa|r
    .complete 2118,1 --Rabid Thistle Bear Captured (1)
    .unitscan Rabid Thistle Bear
    .use 7586
step
    #label invisThistle
    #optional
    #requires RabidThistle
--XXREQ Placeholder invis step until multiple requires per step
step
    #requires BuzzBox1
    .goto 1439/1,542.14,6313.75--c:1439,36.634,46.250
    >>Haz clic en la |cffe07cf5Caja mecánica 827|r del suelo
    .turnin 983 >> Entrega la misión La caja mecánica 827
    .accept 1001 >> Acepta la misión La caja mecánica 411
step
    .goto 1439/1,537.75,6363.01,8,0--c:1439,36.701,45.122
    .goto 1439/1,542.99,6342.31--c:1439,36.621,45.596
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGwennyth Bly'Leggonde|r
    .turnin 3524 >> Entrega la misión Varado
    .accept 4681 >> Acepta la misión Varado
    .target Gwennyth Bly'Leggonde
step
    #optional
    #completewith next
    .goto 1439/1,530.87,6406.02,8,0--c:1439,36.806,44.137
    .goto 1439/1,600.50,6424.66,12 >> Viaja hacia |cff5cf05cCerellean Zarpablanca|r en el muelle--c:1439,35.743,43.710
step
    .goto 1439/1,600.50,6424.66--c:1439,35.743,43.710
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCerellean Zarpablanca|r
    .accept 963 >> Acepta la misión Un amor eterno
    .target Cerellean Whiteclaw
step
    #optional
    #completewith SeaT1
    .goto 1439/1,817.37,6423.18,15 >> Viaja al final del muelle, luego salta al agua--c:1439,32.432,43.744
step
    #optional
    #completewith washed1
    .goto 1439/1,741.52,6570.95,0
    .goto 1439/1,915.10,6333.84,0
    .goto 1439/1,778.20,6231.66,0
    >>Mata a los |cffff5a4aTrilladores de Costa Oscura|r. Despójalos para obtener sus |cff4fc3f7Ojos de trillador|r
    .complete 1001,1 --Thresher Eye (3)
    .mob Darkshore Thresher
    .isOnQuest 1001
step
    #label SeaT1
    .goto 1439/1,856.08,6311.39--c:1439,31.841,46.304
    >>Abre la |cffe07cf5Tortuga marina esquelética|r. Despójala para obtener los |cff4fc3f7Restos de tortuga marina|r
    .complete 4681,1 --Sea Turtle Remains (1)
step
    #label washed1
    .goto 1439/1,537.75,6363.01,8,0--c:1439,36.701,45.122
    .goto 1439/1,542.99,6342.31--c:1439,36.621,45.596
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGwennyth Bly'Leggonde|r
    .turnin 4681 >> Entrega la misión Varado
    .target Gwennyth Bly'Leggonde
step
    .goto 1439/1,497.08,6427.72--c:1439,37.322,43.640
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBarithras Sombra Lunar|r
    .accept 947 >> Acepta la misión La cueva de las setas
    .target Barithras Moonshade
step
    .goto 1439/1,472.12,6438.51--c:1439,37.703,43.393
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cCentinela Glynda Nal'Shea|r
    .accept 4811 >> Acepta la misión El cristal rojo
    .target Sentinel Glynda Nal'Shea
step
    .goto 1439/1,397.45,6437.50--c:1439,38.843,43.416
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTharnariun Espinarbolado|r
    .turnin 2118 >> Entrega la misión Tierras apestadas
    .accept 2138 >> Acepta la misión La limpieza de la infección
    .target Tharnariun Treetender
step
    .goto 1439/1,362.74,6434.58--c:1439,39.373,43.483
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTerenthis|r
    .turnin 984 >> Entrega la misión La extensión de la amenaza
    .accept 985 >> Acepta la misión La extensión de la amenaza
    .accept 4761 >> Acepta la misión Thundris Tejevientos
    .target Terenthis
step
    .goto 1439/1,445.66,6535.79--c:1439,38.107,41.165
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGorbold Mano de Acero|r
    .accept 982 >> Acepta la misión Profundo océano, mar inmenso
    .target Gorbold Steelhand
step
    #optional
    .goto 1439/1,472.32,6556.100
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAlanndarian Arrullanoche|r
    .accept 2178 >> Acepta la misión Guiso de zancudo
    .turnin 2178 >> Entrega la misión Guiso de zancudo
    .target Alanndarian Nightsong
    .itemcount 5469,5 -- Strider Meat (5)
    .skill cooking,<10,1 -- step only displays if skill is 10 or higher
step
    #optional
    #completewith next
    .goto 1439/1,488.69,6564.830
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDalmond|r dentro
    .vendor 4182 >> |cffe07cf5Compra tantas|r |T133634:0|t[Faltriqueras marrón pequeñas] |cffe07cf5o|r |T133634:0|t[Carteras de cuero marrón] |cffe07cf5como necesites|r
    >>|cffe07cf5Cómprale|r |T132382:0|t[Flechas afiladas] |cffe07cf5o|r |T132384:0|t[Perdigones pesados] |cffe07cf5hasta que tu carcaj/bolsa de proyectiles esté llena|r << Hunter
    .target Dalmond
step
    .goto 1439/1,492.36,6581.08--c:1439,37.394,40.128
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThundris Tejevientos|r
    .turnin 4761 >> Entrega la misión Thundris Tejevientos
    .accept 4762 >> Acepta la misión El Río Fonroca
    .accept 954 >> Acepta la misión Bashal'Aran
    .accept 958 >> Acepta la misión Las herramientas de los Altonato << !sod
    .target Thundris Windweaver
    .xp >16,1
--XX if 16+, skip Tools
step
    #optional
    .goto 1439/1,492.36,6581.08--c:1439,37.394,40.128
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThundris Tejevientos|r
    .turnin 4761 >> Entrega la misión Thundris Tejevientos
    .accept 4762 >> Acepta la misión El Río Fonroca
    .accept 954 >> Acepta la misión Bashal'Aran
    .target Thundris Windweaver
    .xp >18,1
--XX if 18+, skip Bashal
step
    #optional
    .goto 1439/1,492.36,6581.08--c:1439,37.394,40.128
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThundris Tejevientos|r
    .turnin 4761 >> Entrega la misión Thundris Tejevientos
    .accept 4762 >> Acepta la misión El Río Fonroca
step
    #completewith MistVeil
    .goto 1439/1,620.35,6768.76,0
    .goto 1439/1,602.66,6924.21,0
    .goto 1439/1,537.82,7023.33,0
    .goto 1439/1,404.85,7099.75,0
    .goto 1439/1,310.53,7077.48,0
    .goto 1439/1,620.35,6768.76,55,0
    .goto 1439/1,602.66,6924.21,55,0
    >>Mata a los |cffff5a4aTrilladores de Costa Oscura|r. Despójalos para obtener sus |cff4fc3f7Ojos de trillador|r
    .complete 1001,1 --Thresher Eye (3)
    .mob Darkshore Thresher
    .isOnQuest 1001
    .isOnQuest 982
step
    #optional
    #completewith next
    +|cffff9a3cPresiona Escape, luego ve a -> Opciones -> Controles|r
    >>|cffff9a3cActiva "Habilitar tecla de interactuar" y asigna la opción "Interactuar con objetivo" a una tecla|r
step
    .goto 1439/1,438.72,7077.74--c:1439,38.213,28.754
--  .goto 1439,38.234,28.796
    >>|cffff9a3c==¡TEN CUIDADO CON LA BARRA DE RESPIRACIÓN!|==|r
    >>|cffff9a3cNada bajo el agua hacia el exterior de la parte trasera del barco|r
    >>|cffff9a3cEn la ubicación de la flecha, presiona tu atajo de teclado "Interactuar con objetivo" para despojar el |cff4fc3f7Arcón del Amanecer de Plata|r del exterior del barco|r
    >>|cffff9a3cSi no quieres hacer esto, nada bajo el agua al piso inferior del barco y despoja el |cff4fc3f7Arcón del Amanecer de Plata|r dentro|r
    .complete 982,1 --Silver Dawning's Lockbox (1)
    .isOnQuest 982
step
    #label MistVeil
    .goto 1439/1,349.11,7133.07--c:1439,39.581,27.487
--  .goto 1439,39.629,27.462
    >>|cffff9a3c==¡TEN CUIDADO CON LA BARRA DE RESPIRACIÓN!|==|r
    >>|cffff9a3cNada bajo el agua hacia el exterior de la parte trasera del barco|r
    >>|cffff9a3cEn la ubicación de la flecha, presiona tu atajo de teclado "Interactuar con objetivo" para despojar el |cff4fc3f7Arcón del Halo de bruma|r del exterior del barco|r
    >>|cffff9a3cSi no quieres hacer esto, nada bajo el agua al piso inferior del barco y despoja el |cff4fc3f7Arcón del Halo de bruma|r dentro|r
    .complete 982,2 --Mist Veil Lockbox (1)
    .isOnQuest 982
step
    #loop
    .goto 1439/1,310.53,7077.48,0
    .goto 1439/1,404.85,7099.75,0
    .goto 1439/1,537.82,7023.33,0
    .goto 1439/1,310.53,7077.48,55,0
    .goto 1439/1,404.85,7099.75,55,0
    .goto 1439/1,537.82,7023.33,55,0
    .goto 1439/1,602.66,6924.21,55,0
    .goto 1439/1,620.35,6768.76,55,0
    .goto 1439/1,602.66,6924.21,55,0
    .goto 1439/1,620.35,6768.76,55,0
    >>Mata a los |cffff5a4aTrilladores de Costa Oscura|r. Despójalos para obtener sus |cff4fc3f7Ojos de trillador|r
    .complete 1001,1 --Thresher Eye (3)
    .mob Darkshore Thresher
    .isOnQuest 1001
step
    .goto 1439/1,197.15,6964.86--c:1439,41.901,31.339
    >>Haz clic en la |cffe07cf5Criatura marina varada|r
    .accept 4723 >> Acepta la misión Criatura marina varada
step
    .goto 1439/1,193.29,7083.77--c:1439,41.960,28.616
    >>Haz clic en la |cffe07cf5Caja mecánica 411|r del suelo
    .turnin 1001 >> Entrega la misión La caja mecánica 411
    .isQuestComplete 1001
step
    #optional
    #completewith Bashal1
    .goto 1439/1,18.47,6747.53,20,0--c:1439,44.629,36.316
    .goto 1439/1,48.66,6748.71,15 >> Viaja hacia |cff5cf05cAsterion|r--c:1439,44.168,36.289
step
    .goto 1439/1,48.66,6748.71--c:1439,44.168,36.289
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAsterion|r
    >>|cffff9a3cEvita matar a los |cffff5a4aGrells salvajes|r y a los |cffff5a4aDuendes vil|r por el camino|r
    .turnin 954 >> Entrega la misión Bashal'Aran
    .accept 955 >> Acepta la misión Bashal'Aran
    .target Asterion
    .isOnQuest 954
    .xp >16,1
--XX skip Bashal Aran qline if 16+
step
    #optional
    #label Bashal1
    .goto 1439/1,48.66,6748.71--c:1439,44.168,36.289
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAsterion|r
    >>|cffff9a3cEvita matar a los |cffff5a4aGrells salvajes|r y a los |cffff5a4aDuendes vil|r por el camino|r
    .turnin 954 >> Entrega la misión Bashal'Aran
    .target Asterion
    .isOnQuest 954
--XX Turn in Breadcrumb if you picked it up earlier before 18
step
    #loop
    .goto 1439/1,25.08,6735.70,0--c:1439,44.528,36.587
    .goto 1439/1,-27.71,6613.17,0--c:1439,45.334,39.393
    .goto 1439/1,-77.62,6737.71,0--c:1439,46.096,36.541
    .goto 1439/1,25.08,6735.70,50,0--c:1439,44.528,36.587
    .goto 1439/1,31.17,6700.03,50,0--c:1439,44.435,37.404
    .goto 1439/1,30.65,6665.18,50,0--c:1439,44.443,38.202
    .goto 1439/1,27.38,6629.98,50,0--c:1439,44.493,39.008
    .goto 1439/1,5.89,6599.29,50,0--c:1439,44.821,39.711
    .goto 1439/1,-27.71,6613.17,50,0--c:1439,45.334,39.393
    .goto 1439/1,-16.77,6645.53,50,0--c:1439,45.167,38.652
    .goto 1439/1,-11.79,6679.89,50,0--c:1439,45.091,37.865
    .goto 1439/1,-38.26,6716.84,50,0--c:1439,45.495,37.019
    .goto 1439/1,-60.26,6726.84,50,0--c:1439,45.831,36.790
    .goto 1439/1,-77.62,6737.71,50,0--c:1439,46.096,36.541
    .goto 1439/1,-130.68,6753.87,50,0--c:1439,46.906,36.171
    .goto 1439/1,-165.06,6754.74,50,0--c:1439,47.431,36.151
    .goto 1439/1,-138.27,6714.04,50,0--c:1439,47.022,37.083
    .goto 1439/1,-147.71,6692.34,50,0--c:1439,47.166,37.580
    .goto 1439/1,-60.00,6725.88,50,0--c:1439,45.827,36.812
    >>Mata a los |cffff5a4aGrells salvaje|r y a los |cffff5a4aDuendes vil|r. Despójalos para obtener sus |cff4fc3f7Pendientes grell|r
    >>|cffff9a3cEvita matar a los |cffff5a4aSátiros Deth'ryll|r por ahora|r
    .complete 955,1 --Grell Earring (8)
    .mob Wild Grell
    .mob Vile Sprite
    .isOnQuest 955
step
    .goto 1439/1,48.66,6748.71--c:1439,44.168,36.289
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAsterion|r
    .turnin 955 >> Entrega la misión Bashal'Aran
    .accept 956 >> Acepta la misión Bashal'Aran
    .target Asterion
    .isQuestComplete 955
step
    #optional
    .goto 1439/1,48.66,6748.71--c:1439,44.168,36.289
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAsterion|r
    .accept 956 >> Acepta la misión Bashal'Aran
    .target Asterion
    .isQuestTurnedIn 955
step
    #optional
    .abandon 955 >> Abandona la misión Bashal'Aran
step
    #loop
    .goto 1439/1,-31.57,6740.72,0--c:1439,45.393,36.472
    .goto 1439/1,-33.93,6596.58,0--c:1439,45.429,39.773
    .goto 1439/1,-160.94,6727.54,0--c:1439,47.368,36.774
    .goto 1439/1,-31.57,6740.72,45,0--c:1439,45.393,36.472
    .goto 1439/1,-67.27,6682.73,45,0--c:1439,45.938,37.800
    .goto 1439/1,-67.27,6672.25,45,0--c:1439,45.938,38.040
    .goto 1439/1,-106.11,6624.48,45,0--c:1439,46.531,39.134
    .goto 1439/1,-33.93,6596.58,45,0--c:1439,45.429,39.773
    .goto 1439/1,-153.99,6688.24,45,0--c:1439,47.262,37.674
    .goto 1439/1,-197.09,6707.71,45,0--c:1439,47.920,37.228
    .goto 1439/1,-160.94,6727.54,45,0--c:1439,47.368,36.774
    >>Mata |cffff5a4aSátiros Deth'ryll|r. Despójalos para obtener el |cff4fc3f7Sello de piedra lunar antiguo|r
    >>|cffff9a3cTen en cuenta que no tienen reapariciones dinámicas|r
    .complete 956,1 --Ancient Moonstone Seal (1)
    .mob Deth'ryll Satyr
    .isQuestTurnedIn 955
step
    .goto 1439/1,48.66,6748.71--c:1439,44.168,36.289
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAsterion|r
    .turnin 956 >> Entrega la misión Bashal'Aran
    .accept 957 >> Acepta la misión Bashal'Aran
    .target Asterion
    .isQuestComplete 956
step
    .goto 1439/1,48.66,6748.71--c:1439,44.168,36.289
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAsterion|r
    .accept 957 >> Acepta la misión Bashal'Aran
    .target Asterion
    .isQuestTurnedIn 956
step
    .goto 1439/1,-157.40,6207.81--c:1439,47.314,48.676
    >>Viaja hasta el |cffe07cf5Cristal rojo misterioso|r
    >>|cffff9a3cTen cuidado con los dos grupos de 2 |cffff5a4aLechúcicos lunares enfurecidos|r al oeste del |cffe07cf5Cristal rojo misterioso|r ya que las parejas más cercanas entre sí están vinculadas por agro|r
    .complete 4811,1 --Locate the large, red crystal on Darkshore's eastern mountain range
step
    #sticky
    #label Anaya
    .goto 1439/1,189.55,5762.85,0 --NE spawn--c:1439,42.017,58.866
    .goto 1439/1,110.63,5726.74,0 --NE spawn--c:1439,43.222,59.693
    .goto 1439/1,120.65,5606.44,0 --SE spawn--c:1439,43.069,62.448
    .goto 1439/1,158.64,5683.77,0 --Middle spawn--c:1439,42.489,60.677
    .waypoint 1439/1,189.55,5762.85,50,0 --NE spawn--c:1439,42.017,58.866
    .waypoint 1439/1,170.30,5772.50,50,0--c:1439,42.311,58.645
    .waypoint 1439/1,161.32,5790.36,50,0--c:1439,42.448,58.236
    .waypoint 1439/1,110.63,5726.74,50,0 --NE spawn--c:1439,43.222,59.693
    .waypoint 1439/1,95.89,5707.61,50,0--c:1439,43.447,60.131
    .waypoint 1439/1,74.08,5701.32,50,0--c:1439,43.780,60.275
    .waypoint 1439/1,120.65,5606.44,50,0 --SE spawn--c:1439,43.069,62.448
    .waypoint 1439/1,118.35,5601.42,50,0--c:1439,43.104,62.563
    .waypoint 1439/1,138.66,5618.75,50,0--c:1439,42.794,62.166
    .waypoint 1439/1,158.64,5683.77,50,0 --Middle spawn--c:1439,42.489,60.677
    >>Mata a |cffff5a4aAnaia Correalba|r. Despójala para obtener su |cff4fc3f7Colgante|r
    -->>|cffff9a3cBe aware that she has a 7-8 minute spawn time and 4 different spawnpoints across Ameth'Aran|r
    -->>|cffff9a3cYou may want to group with others nearby if you can't find her. Ask in General Chat (/1) to group with anyone else that is also looking for her|r
    -->>|cffff9a3cIf you can't find her and want to try again later at the cost of potentially grinding more mobs soon, skip this step|r
    --much faster spawn time now on forever
    .complete 963,1 --Anaya's Pendant (1)
    .unitscan Anaya Dawnrunner
step
    #sticky
    #label Relics
    .goto 1439/1,146.78,5827.30,0--c:1439,42.670,57.390
    .goto 1439/1,191.58,5605.83,0--c:1439,41.986,62.462
    .goto 1439/1,54.95,5691.19,0--c:1439,44.072,60.507
    .waypoint 1439/1,146.78,5827.30,55,0--c:1439,42.670,57.390
    .waypoint 1439/1,209.79,5805.56,55,0--c:1439,41.708,57.888
    .waypoint 1439/1,217.06,5723.59,55,0--c:1439,41.597,59.765
    .waypoint 1439/1,186.87,5660.98,55,0--c:1439,42.058,61.199
    .waypoint 1439/1,191.58,5605.83,55,0--c:1439,41.986,62.462
    .waypoint 1439/1,140.04,5563.99,55,0--c:1439,42.773,63.420
    .waypoint 1439/1,108.60,5569.80,55,0--c:1439,43.253,63.287
    .waypoint 1439/1,63.27,5617.79,55,0--c:1439,43.945,62.188
    .waypoint 1439/1,54.95,5691.19,55,0--c:1439,44.072,60.507
    .waypoint 1439/1,98.31,5722.77,55,0--c:1439,43.410,59.784
    .waypoint 1439/1,73.62,5758.79,55,0--c:1439,43.787,58.959
    >>Mata a los |cffff5a4aAltonatos malditos|r, a los |cffff5a4aAltonatos en pena|r y a los |cffff5a4aAltonatos gemebunda|r. Despójalos para obtener sus |cff4fc3f7Reliquias|r
    .complete 958,1 --Highborne Relic (7)
    .mob Cursed Highborne
    .mob Writhing Highborne
    .mob Wailing Highborne
    .isOnQuest 958
step
    .goto 1439/1,301.89,5725.08--c:1439,40.302,59.731
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cCentinela Tysha Filoluna|r
    .accept 953 >> Acepta la misión La caída de Ameth'Aran
    .target Sentinel Tysha Moonblade
    .xp >17,1
step
    .goto 1439/1,147.96,5576.00--c:1439,42.652,63.145
    >>Haz clic en la |cffe07cf5La caída de Ameth'Aran|r
    .complete 953,2 --Read The Fall of Ameth'Aran (1)
    .isOnQuest 953
step << !sod/Warrior/Rogue/Priest
    .goto 1439/1,166.24,5634.08--c:1439,42.373,61.815
    >>Haz clic en la |cffe07cf5Llama antigua|r
    .complete 957,1 --Destroy the seal at the ancient flame (1)
    .isOnQuest 957
step
    #label TheLay
    .goto 1439/1,105.52,5770.100
    >>Haz clic en |cffe07cf5La instauración de Ameth'Aran|r
    .complete 953,1 --Read The Lay of Ameth'Aran (1)
    .isOnQuest 953
step
    .isOnQuest 98025
    .waypoint 1439/1,-18.100,5779.800
    >>Mata a |cffff5a4aJai'vhanel|r. Despójalo para obtener la |cff4fc3f7Pluma de Jai'vhanel|r
    .complete 98025,1 --|1/1 Feather of Jai'vhanel
    .mob Jai'vhanel
step
    #optional
    #requires Relics
--XXREQ Placeholder invis step until multiple requires per step
step
    #optional
    #requires Anaya
--XXREQ Placeholder invis step until multiple requires per step
step
    .isQuestComplete 953
    .goto 1439/1,301.89,5725.08--c:1439,40.302,59.731
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cCentinela Tysha Filoluna|r
    .turnin 953 >> Entrega la misión La caída de Ameth'Aran
    .target Sentinel Tysha Moonblade
step
    #optional
    #completewith FurbolgGrind
    >>Mata a los |cffff5a4aOsos cardo rabiosos|r
    >>|cffff9a3cTen cuidado ya que lanzan|r |T135914:0|t[Rabia animal] |cffff9a3csi no los matas lo suficientemente rápido (Golpe instantáneo Cuerpo a cuerpo: Reduce TODA la regeneración de vida un 50% durante 10 minutos)|r
    .complete 2138,1 -- Rabid Thistle Bear slain (20)
    .mob Rabid Thistle Bear
step
    .goto 1439/1,511.29,5618.71--c:1439,37.105,62.167
    >>Haz clic en la |cffe07cf5Tortuga marina varada|r
    .accept 4722 >> Acepta la misión Tortuga marina varada
step
    #loop
    #label FurbolgGrind
    .goto 1439/1,328.28,5942.80,0--c:1439,39.899,54.745
    .goto 1439/1,309.81,5878.00,0--c:1439,40.181,56.229
    .goto 1439/1,369.68,6014.98,50,0--c:1439,39.267,53.092
    .goto 1439/1,337.78,5999.61,50,0--c:1439,39.754,53.444
    .goto 1439/1,306.34,5961.14,50,0--c:1439,40.234,54.325
    .goto 1439/1,328.28,5942.80,50,0--c:1439,39.899,54.745
    .goto 1439/1,309.81,5878.00,50,0--c:1439,40.181,56.229
    .goto 1439/1,361.75,5858.70,50,0--c:1439,39.388,56.671
    .goto 1439/1,374.66,5871.32,50,0--c:1439,39.191,56.382
    .goto 1439/1,324.48,5918.57,50,0--c:1439,39.957,55.300
    .goto 1439/1,365.42,5971.88,50,0--c:1439,39.332,54.079
    >>Mata |cffff5a4aAbrecaminos Bosque Negro|r y |cffff5a4aSoplavientos Bosque Negro|r
    .complete 985,1 -- Blackwood Pathfinder (8)
    .mob +Blackwood Pathfinder
    .complete 985,2 -- Blackwood Windtalker (5)
    .mob +Blackwood Windtalker
step
    #completewith TOTH
    .goto 1439/1,537.75,6363.01--c:1439,36.701,45.122
    .subzone 442 >> Regresa a Auberdine
step
    .goto 1439/1,537.75,6363.01,8,0--c:1439,36.701,45.122
    .goto 1439/1,542.99,6342.31--c:1439,36.621,45.596
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGwennyth Bly'Leggonde|r
    .turnin 4722 >> Entrega la misión Tortuga marina varada
    .turnin 4723 >> Entrega la misión Criatura marina varada
    .target Gwennyth Bly'Leggonde
step
    #optional
    #completewith next
    .goto 1439/1,530.87,6406.02,8,0--c:1439,36.806,44.137
    .goto 1439/1,600.50,6424.66,12 >> Regresa a |cff5cf05cCerellean Zarpablanca|r en el muelle--c:1439,35.743,43.710
step
    #optional
    .goto 1439/1,600.50,6424.66--c:1439,35.743,43.710
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cCerellean Zarpablanca|r
    .turnin 963 >> Entrega la misión Un amor eterno
    .target Cerellean Whiteclaw
    .isQuestComplete 963
step
    .isOnQuest 98025
    .goto 1439/1,472.900,6439.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cCentinela Glynda Nal'Shea::2930|r
    .target Sentinel Glynda Nal'Shea::2930
    .turnin 98025 >>Entrega la misión SE BUSCA: Jai'vhanel
step
    .goto 1439/1,472.12,6438.51--c:1439,37.703,43.393
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cCentinela Glynda Nal'Shea|r
    .turnin 4811 >> Entrega la misión El cristal rojo
    .accept 4812 >> Acepta la misión Agua en cascada
    .target Sentinel Glynda Nal'Shea
step
    .goto 1439/1,467.93,6411.96--c:1439,37.767,44.001
    >>|cffff9a3cUsa el|r |T134865:0|t[Tubo de agua vacío] |cffff9a3cen la Poza de la Luna de Auberdine|r
    .complete 4812,1 --Moonwell Water Tube (1)
    .use 14338
step
    #optional
    .goto 1439/1,445.66,6535.79--c:1439,38.107,41.165
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGorbold Mano de Acero|r
    .turnin 982 >> Entrega la misión Profundo océano, mar inmenso
    .target Gorbold Steelhand
    .isQuestComplete 982
step
    #optional
    .goto 1439/1,472.32,6556.100
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAlanndarian Arrullanoche|r
    .accept 2178 >> Acepta la misión Guiso de zancudo
    .turnin 2178 >> Entrega la misión Guiso de zancudo
    .target Alanndarian Nightsong
    .itemcount 5469,5 -- Strider Meat (5)
    .skill cooking,<10,1 -- step only displays if skill is 10 or higher
step
    #label TOTH
    .goto 1439/1,492.36,6581.08--c:1439,37.394,40.128
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThundris Tejevientos|r
    .turnin 958 >> Entrega la misión Las herramientas de los Altonato
    .target Thundris Windweaver
    .isQuestComplete 958
step
    #optional
    .goto 1439/1,397.45,6437.50--c:1439,38.843,43.416
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTharnariun Espinarbolado|r
    .turnin 2138 >> Entrega la misión La limpieza de la infección
    .accept 2139 >> Acepta la misión La esperanza de Tharnariun
    .target Tharnariun Treetender
    .isQuestComplete 2138
step
    #optional
    .goto 1439/1,397.45,6437.50--c:1439,38.843,43.416
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTharnariun Espinarbolado|r
    .accept 2139 >> Acepta la misión La esperanza de Tharnariun
    .target Tharnariun Treetender
    .isQuestTurnedIn 2138
step
    .goto 1439/1,362.74,6434.58--c:1439,39.373,43.483
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTerenthis|r
    .turnin 985 >> Entrega la misión La extensión de la amenaza
    .target Terenthis
step
    #optional
    #completewith next
    .goto 1439/1,368.83,6450.38,6,0--c:1439,39.280,43.121
    .goto 1439/1,376.56,6447.20,6 >> Sube las escaleras--c:1439,39.162,43.194
step
    .goto 1439/1,384.35,6431.43--c:1439,39.043,43.555
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cCentinela Elissa Brisa Estelar|r arriba
    .accept 965 >> Acepta la misión La Torre de Althalaxx
    .target Sentinel Elissa Starbreeze
step
    .goto 1439/1,-157.40,6207.81--c:1439,47.314,48.676
    >>Haz clic en el |cffe07cf5Cristal rojo misterioso|r
    >>|cffff9a3cTen cuidado con los 2 grupos de 2 |cffff5a4aLechúcicos lunares enfurecidos|r al oeste del |cffe07cf5Cristal rojo misterioso|r ya que las parejas más cercanas entre sí están vinculadas por agro|r
    .turnin 4812 >> Entrega la misión Agua en cascada
    .accept 4813 >> Acepta la misión Los trozos del interior
step
    .goto 1439/1,48.66,6748.71--c:1439,44.168,36.289
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAsterion|r
    .turnin 957 >> Entrega la misión Bashal'Aran
    .isOnQuest 957
    .target Asterion
step
    #optional
    #completewith CrabTurtle
    >>Mata a los |cffff5a4aOsos cardo rabiosos|r
    >>|cffff9a3cTen cuidado ya que lanzan|r |T135914:0|t[Rabia animal] |cffff9a3csi no los matas lo suficientemente rápido (Golpe instantáneo Cuerpo a cuerpo: Reduce TODA la regeneración de vida un 50% durante 10 minutos)|r
    .complete 2138,1 -- Rabid Thistle Bear slain (20)
    .mob Rabid Thistle Bear
step
    #label CrabTurtle
    .goto 1439/1,47.88,7433.800
    >>Haz clic en la |cffe07cf5Tortuga marina varada|r
    .accept 4725 >> Acepta la misión Tortuga marina varada
step
    .goto 1439/1,-386.39,7219.830
    >>|cffff9a3cUsa el|r |T134865:0|t[Tubo de ensayo vacío] |cffff9a3cen la base del Río Fonroca|r
    .complete 4762,1 --Cliffspring River Sample (1)
    .use 12350
step
    #loop
    .goto 1439/1,-571.03,7195.64,0--c:1439,53.629,26.054
    .goto 1439/1,-608.70,7002.59,0--c:1439,54.204,30.475
    .goto 1439/1,-318.60,7008.01,0--c:1439,49.775,30.351
    .goto 1439/1,-260.89,7175.56,0--c:1439,48.894,26.514
    .goto 1439/1,-203.77,7145.64,60,0--c:1439,48.022,27.199
    .goto 1439/1,-260.89,7175.56,60,0--c:1439,48.894,26.514
    .goto 1439/1,-304.38,7194.20,60,0--c:1439,49.558,26.087
    .goto 1439/1,-326.91,7132.02,60,0--c:1439,49.902,27.511
    .goto 1439/1,-318.66,7093.51,60,0--c:1439,49.776,28.393
    .goto 1439/1,-318.60,7008.01,60,0--c:1439,49.775,30.351
    .goto 1439/1,-386.91,7002.11,60,0--c:1439,50.818,30.486
    .goto 1439/1,-378.46,6935.96,60,0--c:1439,50.689,32.001
    .goto 1439/1,-416.32,6922.07,60,0--c:1439,51.267,32.319
    .goto 1439/1,-608.70,7002.59,60,0--c:1439,54.204,30.475
    .goto 1439/1,-588.72,7082.81,60,0--c:1439,53.899,28.638
    .goto 1439/1,-533.04,7111.41,60,0--c:1439,53.049,27.983
    .goto 1439/1,-514.38,7184.38,60,0--c:1439,52.764,26.312
    .goto 1439/1,-571.03,7195.64,60,0--c:1439,53.629,26.054
    >>Mata a los |cffff5a4aOsos cardo rabiosos|r
    >>|cffff9a3cTen cuidado ya que lanzan|r |T135914:0|t[Rabia animal] |cffff9a3csi no los matas lo suficientemente rápido (Golpe instantáneo Cuerpo a cuerpo: Reduce TODA la regeneración de vida un 50% durante 10 minutos)|r
    .complete 2138,1 -- Rabid Thistle Bear slain (20)
    .mob Rabid Thistle Bear
step
    #optional
    #completewith next
    .goto 1439/1,-656.51,6904.52,20,0--c:1439,54.934,32.721
    .goto 1439/1,-667.91,6866.13,40 >> Viaja a la Cueva del Río Fonroca--c:1439,55.108,33.600
step << Druid
    .goto 1439/1,-660.18,6874.43
    >>|cffff9a3cUsa la|r |T134776:0|t[Muestra vacía de Salto de Fonroca] |cffff9a3cen el agua en la entrada de la Cueva del Río Fonroca|r
    .complete 6122,1 --Filled Cliffspring Falls Sampler (1)
    .isOnQuest 6122
step
    .goto 1439/1,-690.31,6751.29,12,0
    .goto 1439/1,-706.68,6748.23,12,0
    .goto 1439/1,-719.13,6787.530,12,0
    >>Despoja los |cff4fc3f7Boletos rudos|r y una |cff4fc3f7Oronja verde|r del suelo
    >>|cffff9a3cQuédate en la sección superior. Si no hay una |cff4fc3f7Oronja verde|r al final del lado superior, baja y consigue uno de la sala del sur abajo|r
    >>|cffff9a3cTen cuidado ya que los |cffff5a4aJinetes de olas Escama Tormentosa|r lanzan|r |T135836:0|t[Aspersión] |cffff9a3c(Ataque a distancia instantáneo: Causa daño a los enemigos cercanos y los lanza hacia atrás) - asegúrate de no estar en una posición donde te puedan tirar del nivel superior de la cueva|r
    .complete 947,1 --Scaber Stalk (5)
    .goto 1439/1,-663.45,6877.49,8,0
    .goto 1439/1,-679.17,6848.67,8,0
    .goto 1439/1,-666.73,6819.41,8,0
    .goto 1439/1,-680.48,6779.67,8,0
    .goto 1439/1,-663.45,6877.49,8,0
    .goto 1439/1,-679.17,6848.67,8,0
    .goto 1439/1,-666.73,6819.41,8,0
    .goto 1439/1,-680.48,6779.67,8,0
    .goto 1439/1,-663.45,6877.49
    .complete 947,2 --Death Cap (1)
    .goto 1439/1,-685.72,6746.49
step
    .deathskip >> Muere y resucita en el cementerio de Auberdine
    .target Spirit Healer
step
    #optional
    #label CavetoAuber
    #completewith CliffspringEnd
    .subzone 442 >> Viaja a Auberdine
step
    #label CliffspringEnd
    .goto 1439/1,492.36,6581.08--c:1439,37.394,40.128
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThundris Tejevientos|r
    .turnin 4762 >> Entrega la misión El Río Fonroca
    .target Thundris Windweaver
step
    .goto 1439/1,472.32,6556.100
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAlanndarian Arrullanoche|r
    .accept 2178 >> Acepta la misión Guiso de zancudo
    .turnin 2178 >> Entrega la misión Guiso de zancudo
    .target Alanndarian Nightsong
    .skill cooking,<10,1 -- step only displays if skill is 10 or higher
    .itemcount 5469,5 -- strider meat (5)

step << Druid
    #optional
    .isOnQuest 6122
    .goto 1439/1,472.32,6556.100
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAlanndarian Arrullanoche|r
    .turnin 6122 >> Entrega la misión La fuente del envenenamiento
    .accept 6123 >> Acepta la misión Reunir los ingredientes del remedio
    .target Alanndarian Nightsong
step << Druid
    #optional
    .isQuestTurnedIn 6123
    .goto 1439/1,472.32,6556.100
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAlanndarian Arrullanoche|r
    .accept 6123 >> Acepta la misión Reunir los ingredientes del remedio
    .target Alanndarian Nightsong
step << !Druid
    .goto 1439/1,489.41,6506.36--c:1439,37.439,41.839
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cArqueóloga Hollee|r
    .accept 729 >> Acepta la misión El prospector despistado
    .target Archaeologist Hollee
step
    .goto 1439/1,397.45,6437.50--c:1439,38.843,43.416
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTharnariun Espinarbolado|r
    .turnin 2138 >> Entrega la misión La limpieza de la infección
    .accept 2139 >> Acepta la misión La esperanza de Tharnariun
    .target Tharnariun Treetender
step
    .goto 1439/1,472.32,6438.64
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cCentinela Glynda Nal'Shea|r
    >>|cffff9a3cElige la|r |T135641:0|t[Daga de madera curva] |cffff9a3cya que deberías intentar guardar una|r |T135641:0|t[Daga] |cffff9a3cpara tu misión de|r |T132290:0|t[Venenos] |cffff9a3cmás adelante|r << Rogue
    .turnin 4813 >> Entrega la misión Los trozos del interior
    .target Sentinel Glynda Nal'Shea
step
    .goto 1439/1,497.08,6427.72--c:1439,37.322,43.640
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBarithras Sombra Lunar|r
    .turnin 947 >> Entrega la misión La cueva de las setas
    .accept 948 >> Acepta la misión Onus
    .target Barithras Moonshade
step
    .goto 1439/1,504.41,6402.39
    >>Haz clic en el |cffe07cf5Cartel de Se busca|r
    .accept 4740 >> Acepta la misión SE BUSCA: ¡Viscoso!
step
    .goto 1439/1,537.75,6363.01,8,0--c:1439,36.701,45.122
    .goto 1439/1,542.99,6342.31--c:1439,36.621,45.596
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGwennyth Bly'Leggonde|r
    .turnin 4725 >> Entrega la misión Tortuga marina varada
    .target Gwennyth Bly'Leggonde

----Start of Druid Quest section----
step << Druid
    #completewith TotL
    .goto 1439/1,766.22,6591.78--c:1439,33.213,39.883
    .zone Teldrassil >> Toma el barco hacia Darnassus
    .zoneskip Darnassus
step << Druid
    #optional
    #label DruidLesson
    #completewith TotL
    .goto 1438/1,965.80,8780.95
    .zone Darnassus >> Toma el portal morado a Darnassus
step << Druid
    .goto 1457/1,2563.98,10179.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMathrengyl Garroso|r
    .accept 26 >> Acepta la misión Una lección que aprender
    .trainer >> Aprende tus hechizos de clase
    .target Mathrengyl Bearwalker
step << Druid
    #optional
    #completewith next
    .abandon 729 >> Abandona la misión El prospector despistado para aceptar la misión ¿Problemas en Costa Oscura?
step << Druid
    #optional
	#completewith TotL
	.cast 18960 >> Lanza Teletransporte a: Claro de la Luna
	.zoneskip Moonglade
step << Druid
    .goto 1450/1,-2676.22,8019.01
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDendrita Rafagaestelar|r
    .turnin 26 >> Entrega la misión Una lección que aprender
    .accept 29 >> Acepta la misión La prueba del lago
    .target Dendrite Starblaze
step << Druid
    .goto 1450/1,-2595.43,7697.24
    >>Nada al Lago Elune'ara
    >>Abre el |cffe07cf5Adorno contenedor|r. Despójalo para obtener un |T134125:0|t[Adorno de altar]
    >>|cffff9a3cPuede aparecer en diferentes ubicaciones bajo el agua|r
    .collect 15877,1,29,1 -- Shrine Bauble (1)
step << Druid
    #optional
    #completewith next
    .cast 18960 >> Lanza Teletransporte a: Claro de la Luna
    .itemcount 15877,1 -- Shrine Bauble (1)
step << Druid
    .goto 1450/1,-2212.85,7854.68
    >>|cffff9a3cUsa el|r |T134125:0|t[Adorno de altar] |cffff9a3cen el árbol del Santuario de Remulos|r
    .complete 29,1 --Complete the Trial of the Lake.
    .use 15877
step << Druid
    #label TotL
    .goto 1450/1,-2224.18,7874.23
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTajarri|r
    .turnin 29 >> Entrega la misión La prueba del lago
    .accept 272 >> Acepta la misión La prueba del león marino
    .target Tajarri
step
    .hs >> Usa tu Piedra de hogar para ir a Ventormenta
    .zoneskip Stormwind City
    .zoneskip Ironforge
step
    .goto 1453/0,566.600,-8845.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cElaine Trias::483|r
    .target Elaine Trias::483
    .turnin 97220 >>Entrega la misión Favor de Philmor
    .accept 97222 >>Acepta la misión Víveres de entrada
step
    .goto 1453/0,568.300,-8862.200
    .use 277198 >> |cffff9a3cUsa el|r |T132762:0|t[Cargamento de entrada] |cffff9a3cfrente a la |cffe07cf5Entrada|r arriba|r
    .complete 97222,1 --|1/1 Gatehouse Shipment delivered
step
    #label Gatehouse
    .goto 1453/0,566.600,-8845.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cElaine Trias::483|r
    .target Elaine Trias::483
    .turnin 97222 >>Entrega la misión Víveres de entrada
step << Druid
    .goto 1453/0,1095.500,-8741.700
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTheridran|r
    .trainer >>Aprende tus hechizos de clase
	.target Theridran
    .zoneskip Dun Morogh
    .zoneskip Ironforge
step << Warlock
    #optional
    #completewith next
    .goto 1453/0,988.44,-8942.15,20,0
    .goto 1453/0,1015.33,-8978.9,15 >> Viaja a El Cordero Degollad y baja las escaleras
    .zoneskip Dun Morogh
    .zoneskip Ironforge
step << Warlock
    .goto 1453/0,1029.89,-8971.06
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cUrsula Deline|r
    .trainer >> Aprende tus hechizos de clase
    .target Ursula Deline
    .zoneskip Dun Morogh
    .zoneskip Ironforge
step << Mage
    #optional
    #completewith next
    .goto 1453/0,874.32,-9014.67,10 >> Viaja a la Torre de los Magos
    .zoneskip Dun Morogh
    .zoneskip Ironforge
step << Mage
    .goto 1453/0,885.34,-9006.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cElsharin|r
    .trainer >> Aprende tus hechizos de clase
    .target Elsharin
    .zoneskip Dun Morogh
    .zoneskip Ironforge
step << Priest/Paladin
    #optional
    #completewith next
    .goto 1453/0,809.52,-8579.22,20 >> Viaja a la Catedral de Ventormenta
    .zoneskip Dun Morogh
    .zoneskip Ironforge
step << Paladin
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cArthur el Leal|r
    .goto 1453/0,859.13,-8559.14,10,0
    .goto 1453/0,861.14,-8573.03
    .trainer >> Aprende tus hechizos de clase
    .target Arthur the Faithful
    .zoneskip Dun Morogh
    .zoneskip Ironforge
step << Priest
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cHermano Joshua|r
    .goto 1453/0,862.89,-8519.61
    .trainer >> Aprende tus hechizos de clase
    .target Brother Joshua
    .zoneskip Dun Morogh
    .zoneskip Ironforge
step << Hunter
    .goto 1453/0,552.78,-8415.71
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cEinris Lanza Reluciente|r
    .trainer >> Aprende tus hechizos de clase
    .target Einris Brightspear
    .zoneskip Dun Morogh
    .zoneskip Ironforge
step << Rogue
    .goto 1453/0,377.47,-8752.39
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOsborne|r
    .trainer >> Aprende tus hechizos de clase
    .target Osborne the Night Man
    .zoneskip Dun Morogh
    .zoneskip Ironforge
step << Warrior
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWu|r o |cff5cf05cIlsa|r
    .goto 1453/0,358.25,-8728.28,15,0
    .goto 1453/0,302.6,-8685.53,15,0
	.goto 1453/0,323.3,-8689.29
    .trainer >> Aprende tus hechizos de clase
    .target Wu Shen
    .target Ilsa Corbin
    .zoneskip Dun Morogh
    .zoneskip Ironforge
step
    .goto 1453/0,501.200,-8468.601
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWilder Cardortiga|r
    .accept 167 >> Acepta la misión Oh, hermano...
    .accept 168 >> Acepta la misión Recolección de recuerdos
    .target Wilder Thistlenettle
    .zoneskip Dun Morogh
    .zoneskip Ironforge
step << Hunter
    .goto 1453/0,553.22,-8422.23
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKarrina Mekenda|r
    .trainer >> Entrena los hechizos de tu mascota
    .target Karrina Mekenda
    .zoneskip Dun Morogh
    .zoneskip Ironforge
step
    .goto 1453/0,634.700,-8390.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShoni la Shilenshiosha|r
    .accept 2040 >> Acepta la misión Asalto subterráneo
    .target Shoni the Shilent
    .zoneskip Dun Morogh
    .zoneskip Ironforge
step
    #completewith TramIF
    .goto 1453/0,562.300,-8385.300,20,0
    .goto 1453/0,522.000,-8352.101
    .subzone 2257 >>Entra en el Tranvía Subterráneo
    .zoneskip Ironforge
    .zoneskip Dun Morogh
step
    >>|cffff9a3cToma el Tranvía Subterráneo hacia el lado de Forjaz|r
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMonty|r en el andén central del lado de Forjaz del Tranvía Subterráneo
    >>|cffff9a3cOmite este paso si eres nivel 18 o superior|r
    .accept 6661 >> Acepta la misión A por las ratas del tranvía subterráneo
    .target Monty
    .xp >17,1
step
    .isOnQuest 6661
    >>|cffff9a3cUsa la|r |T133942:0|t[Flauta cazarratas] |cffff9a3cen las |cffff5a4aRata del subterráneo|r dentro del Tranvía Subterráneo|r
    .complete 6661,1 --Rats Captured (x5)
    .use 17117
    .mob Deeprun Rat
step
    .isQuestComplete 6661
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMonty|r dentro del Tranvía Subterráneo
    .turnin 6661 >> Entrega la misión A por las ratas del tranvía subterráneo
    .target Monty
step
    #label TramIF
    .zone Ironforge >> Toma el tranvía y entra a Forjaz
    .zoneskip Dun Morogh
]=], "Alliance"}
R[#R + 1] = {[=[
#forever
#version 1
<< Alliance
#group Forever Guía de Mazmorras (A)
#subgroup Mazmorras 1-20
#name 17-18 Salón de Señores Feudales
#next 18-19 Ruinas de Lordaeron
#displayname 16-17 Salón de Señores Feudales << NightElf

step << Skyborne
    .goto 1455/0,-1152.40,-4821.13
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGryth Thurden|r
    .fp Ironforge >> Consigue la ruta de vuelo de Forjaz
    .target Gryth Thurden
step << !NightElf
    #completewith OII
    +|cffff9a3cAhora completarás una misión previa para El Salón de Señores Feudales y luego harás la mazmorra|r
step << !NightElf
    #completewith OII
    .zone Dun Morogh >> Viaja a Dun Morogh
step << !NightElf
    #label QuarryStart
    .goto 1426/0,-1394.24,-5797.83
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVidenterra Farsen|r
    .accept 96392 >> Acepta la misión La vigilancia de Farsen
    .target Earthseer Farsen
step << !NightElf
    .isOnQuest 96392
    .goto 1426/0,-1394.24,-5797.83
    .gossipoption 139831 >> Habla con |cff5cf05cVidenterra Farsen|r para ver su vista lejana
    >>|cffff9a3cPuedes cancelar la Vista lejana cuando se completa el objetivo|r
    .target Earthseer Farsen
step << !NightElf
    .isOnQuest 96392
    .aura -1293681 >> |cffff9a3cPresiona ESC para cancelar la Vista lejana|r
step << skip
    .goto 1426/0,-1394.24,-5797.83
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVidenterra Farsen|r
    >>|cffff9a3cPuedes cancelar la Vista lejana cuando se completa el objetivo|r
    .complete 96392,1 -- Use Farsen's Farsight
    .skipgossip
    .target Earthseer Farsen
step << !NightElf
    .goto 1426/0,-1394.24,-5797.83
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVidenterra Farsen|r
    >>|cffff9a3cPresiona ESC para cancelar la Vista lejana|r
    .turnin 96392 >> Entrega la misión La vigilancia de Farsen
    --.accept 96390 >> Acepta la misión Párteles el coco
    .target Earthseer Farsen
step << !NightElf
    .goto 1426/0,-2009.87,-5860.22,40,0
    .goto 1426/0,-2034.49,-5922.60
    >>Mata |cffff5a4aEspías Hierro Negro|r. Despójalos para obtener el |T237385:0|t[|cff4fc3f7Mapa de Hierro Negro|r]
    .use 274268 >>|cffff9a3cUsa el|r |T237385:0|t[|cff4fc3f7Mapa de Hierro Negro|r] |cffff9a3cpara iniciar la misión|r
    -->>|cffff9a3cYou can skip killing |cffff5a4aDark Iron Spies|r for the other quest because they are low level once you find the|r |T237385:0|t[|cff4fc3f7Mapa de Hierro Negro|r]
    --.complete 96390,1 -- Dark Iron Spy slain 10/10
    --.disablecheckbox
    .collect 274268,1,96391,1 -- Dark Iron Map (1)
    .accept 96391 >> Acepta la misión Mapa subterráneo
    .mob Dark Iron Spy
step << !NightElf
    #label OII
    .goto 1426/0,-1394.24,-5797.83
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVidenterra Farsen|r
    .turnin 96391 >> Entrega la misión Mapa subterráneo
    .accept 96393 >> Acepta la misión Incursión a Antigua Forjaz
    .target Earthseer Farsen
step << !NightElf
    #optional
    .isQuestComplete 96390
    .goto 1426/0,-1394.24,-5797.83
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVidenterra Farsen|r
    .turnin 96390 >> Entrega la misión Párteles el coco
    .target Earthseer Farsen

step
    #completewith EnterHoT
    +|cffff9a3cEmpieza a buscar un grupo para Salón de Señores Feudales|r
step
    #optional
    #label InIronforge
    #completewith EnterHoT
    .zone Ironforge >> Viaja a Forjaz
step
    #requires InIronforge
    #completewith EnterHoT
    .goto 1455/0,-1054.300,-4843.200,10,0
    .goto 1455/0,-1081.900,-4850.100,10,0
    .goto 1455/0,-1082.800,-4886.000,10,0
    .goto 1455/0,-1087.700,-4821.900,10,0
    .goto 1455/0,-1010.300,-4850.900,10 >> Baja a Antigua Forjaz a través de la sala del |cff5cf05cRey Magni|r
step
    .goto 1455/0,-971.800,-4820.700
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAfadra Muropardo|r
    .accept 96394 >> Acepta la misión Los muertos sin descanso
    .target Afadra Dunwall
step
    #completewith EnterHoT
    .goto 1455/0,-996.100,-4821.200,10,0
    .goto 1455/0,-972.000,-4803.000,10,0
    .goto 1455/0,-988.900,-4854.400,10 >> |cffff9a3cDéjate caer en la rampa de abajo|r
step
    .goto 1455/0,-968.200,-4803.700
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThom Birla|r
    .accept 96403 >> Acepta la misión Reliquias importantes
    .target Thom Filch
step
    #label EnterHoT
    .enabledungeon HOT
    .goto 1455/0,-933.200,-4821.900
    .subzone 16919 >> Entra en El Salón de Señores Feudales

step
    #completewith FaldrimAnvilmar
    >>Despoja las |cffe07cf5Reliquias de los enanos|r del suelo a lo largo de El Salón de Señores Feudales
    >>|cffff9a3cPuedes recoger muchas de estas al final de la mazmorra también|r
    .complete 96403,1 -- Dwarven Heirloom (8)
step
    #completewith FaldrimAnvilmar
    >>Mata |cffff5a4aAparecidos iracundos|r y |cffff5a4aAlmas atormentadas|r
    .complete 96394,1 -- Enraged Apparition slain (15)
    .mob +Enraged Apparition slain (15)
    .complete 96394,2 -- Tormented Soul slain (10)
    .mob +Tormented Soul slain (10)
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cAsistente fantasmal|r
    .accept 96395 >> Acepta la misión Un agravio antiguo
    .target Ghostly Attendant
step
    #label FaldrimAnvilmar
    >>Mata a |cffff5a4aFaldrim Yunquemar|r
    .complete 96395,1 -- Faldrim Anvilmar slain (1)
    .mob Faldrim Anvilmar
step
    #completewith next
    +|cffff9a3cRegresa con el|r |cff5cf05cAsistente fantasmal|r
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cAsistente fantasmal|r
    .turnin 96395 >> Entrega la misión Un agravio antiguo
    .target Ghostly Attendant
step
    >>Mata |cffff5a4aAparecidos iracundos|r y |cffff5a4aAlmas atormentadas|r
    >>|cffff9a3cCompleta esto ahora porque quizás no tengas la oportunidad de terminarla después|r
    .complete 96394,1 -- Enraged Apparition slain (15)
    .mob +Enraged Apparition slain (15)
    .complete 96394,2 -- Tormented Soul slain (10)
    .mob +Tormented Soul slain (10)
step
    #completewith ToU
    >>Despoja las |cffe07cf5Reliquias de los enanos|r del suelo a lo largo de El Salón de Señores Feudales
    >>|cffff9a3cPuedes recoger muchas de estas al final de la mazmorra también|r
    .complete 96403,1 -- Dwarven Heirloom (8)
step
    >>Mata a |cffff5a4aDurgen Martillo de Endecha|r. Despójalo para obtener la |cff4fc3f7Cabeza de Durgen Martillo de Endecha|r
    .complete 96393,1 -- Durgen Dirgehammer's Head
    .mob Durgen Dirgehammer
step
    #label ToU
    >>Haz clic en el |cffe07cf5Tratado del entendimiento|r
    .accept 98423 >> Acepta la misión El Tratado del entendimiento
step
    >>Despoja las |cffe07cf5Reliquias de los enanos|r del suelo a lo largo de El Salón de Señores Feudales
    .complete 96403,1 -- Dwarven Heirloom (8)
step
    .zone Ironforge >> |cffff9a3cSal del Salón de Señores Feudales. La forma más rápida es correr en línea recta por el pasillo desde la sala del jefe final|r
    .subzoneskip 16919,1

step
    .goto 1455/0,-968.200,-4803.700
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThom Birla|r
    .turnin 96403 >> Entrega la misión Reliquias importantes
    .target Thom Filch
step
    #completewith next
    .goto 1455/0,-1006.600,-4841.600,10,0
    .goto 1455/0,-969.700,-4841.500,10,0
    .goto 1455/0,-964.300,-4807.500,10,0
    .goto 1455/0,-993.500,-4817.600,10,0
    .goto 1455/0,-983.700,-4847.800,10,0
    .goto 1455/0,-1022.000,-4842.100,10,0
    .goto 1455/0,-994.000,-4843.100,10 >> Regresa con |cff5cf05cAfadra Muropardo|r subiendo la rampa
step
    .goto 1455/0,-971.800,-4820.700
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAfadra Muropardo|r
    .turnin 96394 >> Entrega la misión Los muertos sin descanso
    .target Afadra Dunwall
step
    #completewith next
    .goto 1455/0,-1030.200,-4831.000,10,0
    .goto 1455/0,-1090.900,-4830.400,10,0
    .goto 1455/0,-1079.600,-4884.100,10,0
    .goto 1455/0,-1058.000,-4842.500,10 >> Sube la rampa hacia |cff5cf05cRey Magni Barbabronce|r
step
    .goto 1455/0,-1022.600,-4865.700
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cRey Magni Barbabronce|r
    .turnin 96393 >> Entrega la misión Incursión a Antigua Forjaz
    .turnin 98423 >> Entrega la misión El Tratado del entendimiento
    .target King Magni Bronzebeard

step << Shaman
    .goto 1455/0,-1086.500,-4642.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cEldrun Rompetormentas::258098|r
    .target Eldrun Stormbreaker::258098
    .trainer >> Aprende tus hechizos de clase
step << Priest/Paladin/Mage
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cToldren Acerhondo|r << Priest
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBrandur Martiyerro|r << Paladin
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDink|r << Mage
    .goto 1455/0,-928.48,-4614.620 << Mage
    .goto 1455/0,-912.88,-4625.99 << Priest
    .goto 1455/0,-896.55,-4601.68 << Paladin
    .trainer >> Aprende tus hechizos de clase
    .target Toldren Deepiron << Priest
    .target Brandur Ironhammer << Paladin
    .target Dink << Mage
step << Warlock/Rogue
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBrezospina|r << Warlock
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cFenthwick|r << Rogue
    .goto 1455/0,-1117.60,-4615.14,15,0 << Warlock
    .goto 1455/0,-1111.62,-4599.09 << Warlock
    .goto 1455/0,-1120.72,-4650.120 << Rogue
    .trainer >> Aprende tus hechizos de clase
    .target Briarthorn << Warlock
    .target Fenthwick << Rogue
step << Warlock
    .goto 1455/0,-1134.20,-4610.39,15,0
    .goto 1455/0,-1130.26,-4601.270
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cJubahl Buscador de cadáveres|r
    .vendor >> |cffe07cf5Compra|r |T133738:0|t[Grimorio de sacrificio (Rango 1)]
    .target Jubahl Corpseseeker
    .train 20381,1
step << Warrior/Hunter
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRegnus Tronagranito|r << Hunter
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBilban Cálculo|r << Warrior
    .goto 1455/0,-1266.02,-5006.570 << Hunter
    .goto 1455/0,-1234.65,-5035.67 << Warrior
    .trainer >> Aprende tus hechizos de clase
    .target Regnus Thundergranite << Hunter
    .target Bilban Tosslespanner << Warrior
step << Hunter/Druid
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBuliwyf Petramano|r
    .train 266 >> Aprende Armas de Fuego << Hunter
    .train 199 >> Aprende Mazas de 2 manos << Druid
    .goto 1455/0,-1197.27,-5041.49
    .target Buliwyf Stonehand
]=], "Alliance"}
R[#R + 1] = {[=[
#forever
#version 1
<< Alliance
#group Forever Guía de Mazmorras (A)
#subgroup Mazmorras 1-20
#name 18-19 Ruinas de Lordaeron
#next 19-20 Minas de la Muerte
#displayname 17-18 Ruinas de Lordaeron << NightElf

step
    #completewith EnterRoL
    +|cffff9a3cAhora harás Ruinas de Lordaeron|r
    >>|cffff9a3cTodas las misiones se aceptan dentro de la mazmorra|r
step
    .goto 1455/0,-1152.400,-4821.100
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGryth Thurden|r
    >>|cffff9a3cSi no tienes la ruta de vuelo hacia Los Humedales, omite este paso|r
    .fly Wetlands >> Vuela a Los Humedales
    .target Gryth Thurden
    .zoneskip Ironforge,1

step
    .goto 1426/0,-826.400,-5027.100,30,0
    .goto 1426/0,-721.900,-5078.900,30,0
    .goto 1426/0,-426.500,-5181.000,70,0
    .goto 1426/0,-230.400,-5154.600,80,0
    .goto 1426/0,-65.000,-5115.000,100 >> |cffff9a3cSal de Forjaz. Ve a la ubicación del atajo (deathskip) de Dun Morogh -> Los Humedales|r
    .zoneskip Wetlands
    .zoneskip Hillsbrad Foothills
    .subzoneskip 150 -- menethil
    .subzoneskip 16611 -- ruins of lordaeron
step
    .goto 1426/0,288.09,-5002.25,15,0--c:1426,30.741,34.269
    .goto 1426/0,284.59,-4978.58,15,0--c:1426,30.812,33.548
    .goto 1426/0,272.38,-4945.58,15,0--c:1426,31.060,32.543
    .goto 1426/0,253.71,-4939.44,15,0--c:1426,31.439,32.356
    .goto 1426/0,242.09,-4850.13,15,0--c:1426,31.675,29.636
    .goto 1426/0,215.79,-4821.93,15,0--c:1426,32.209,28.777
    .goto 1426/0,194.32,-4787.88,15,0--c:1426,32.645,27.740
    .goto 1415/0,191.72,-4741.19,15,0--c:1415,44.910,52.022
    .goto 1415/0,191.72,-4743.07--c:1415,44.910,52.030
    .subzone 207 >>|cffff9a3cSube la montaña y luego baja pasando el patrón irregular hasta que tu zona cambie a Los Humedales|r
    .zoneskip Hillsbrad Foothills
    .subzoneskip 150 -- menethil
    .subzoneskip 16611 -- ruins of lordaeron
step
    .goto 1415/0,254.0285,-4708.3416,-1
    .goto 1437/0,-874.700,-3341.400,-1
    >>|cffff9a3cSalta de la montaña hacia el norte o noroeste|r
    .deathskip >> Muere y resucita en el |cff5cf05cÁngel de la Resurrección|r de la Bahía de Baradin
    .target Spirit Healer
    .zoneskip Hillsbrad Foothills
    .subzoneskip 150 -- menethil
    .subzoneskip 16611 -- ruins of lordaeron
step
    #completewith next
    .goto 1437/0,-839.800,-3657.900
    .subzone 150 >> Nada hacia el Puerto de Menethil
    .zoneskip Hillsbrad Foothills
    .subzoneskip 16611 -- ruins of lordaeron
step
    .goto 1437/0,-782.000,-3793.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShellei Brondir|r
    .fp Menethil Harbor >> Consigue la ruta de vuelo de Los Humedales
    .target Shellei Brondir
    .zoneskip Hillsbrad Foothills
    .subzoneskip 16611 -- ruins of lordaeron
step
    .goto 1437/0,-581.800,-3722.400
    .zone Hillsbrad Foothills >> Toma el barco hacia Costasur
    .subzoneskip 16611 -- ruins of lordaeron
step
    .goto 1424/0,-512.15,-715.14
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDarla Harris|r
    .fp Southshore >> Consigue la ruta de vuelo de Costasur
    .target Darla Harris
    .subzoneskip 16611 -- ruins of lordaeron
step
    #completewith next
    .goto 1424/0,-136.700,-535.800,125 >> |cffff9a3cNOTA: Podrías encontrar |cffff5a4aLeones|r y |cffff5a4aOsos|r de nivel superior de camino a Campos de Trabalomas|r
    >>|cffff9a3cTen cuidado con jugadores de la Horda si estás en un servidor PvP|r
    .zoneskip 1424,1 
step
    #label EnterRoL
    .enabledungeon ROL
    .goto 1424/0,-47.400,-249.400,100,0
    .goto 1416/0,68.400,-46.200,130,0
    .goto 1416/0,45.300,257.100,150,0
    .goto 1416/0,-54.700,812.600,100,0
    .goto 1420/0,7.600,1530.500,70,0
    .goto 1420/0,-21.800,1668.600,20,0
    .goto 1420/0,-56.600,1692.000,10,0
    .goto 1420/0,-55.200,1779.600,15,0
    .goto 1420/0,6.300,1791.500,25,0
    .goto 1420/0,4.300,1847.500,10,0
    .goto 1458/0,238.400,1872.200,20,0
    .goto 1458/0,170.700,1804.700,20 >>Viaja a las Ruinas de Lordaeron en Entrañas. Entra en la mazmorra
    >>|cffff9a3cTen cuidado con los |cffff5a4aFelinos|r, |cffff5a4aOsos|r, |cffff5a4aArañas|r o |cffff5a4aMúrlocs|r de mayor nivel mientras vas hacia allí|r
    >>|cffff9a3cEn cuanto entres a Entrañas se te activará automáticamente el JcJ (PVP), pudiendo ser atacado por la|r |cffff5a4aHorda|r
    .link https://www.youtube.com/watch?v=jxmG6_JPFMc >> |cffff9a3cHaz clic aquí para ver una videoguía sobre cómo entrar a la mazmorra de las Ruinas de Lordaeron|r
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cCapitán Truman|r
    .accept 95250 >> Acepta la misión Criaturas abominables
    .target Captain Truman
step
    #sticky
    #label BaronHead
    >>Mata |cffff5a4aEl barón|r. Despójalo para obtener la |cff4fc3f7Cabeza del Barón|r
    .complete 95250,1 -- Head of the Baron (1)
    .mob The Baron
step
    >>Despoja todos los enemigos para obtener la |T133328:0|t[|cff4fc3f7Insignia ensangrentada|r]
    .use 268535 >> |cffff9a3cUsa la|r |T133328:0|t[|cff4fc3f7Insignia ensangrentada|r] |cffff9a3cpara iniciar la misión|r
    .collect 268535,1,95195,1 -- Bloodied Insignia (1)  
    .accept 95195 >> Acepta la misión La insignia ensangrentada
step
    #sticky
    #label BloodiedInsignia
    >>Despoja todos los enemigos para obtener sus |cff4fc3f7Insignias ensangrentadas|r
    .complete 95195,1 -- Bloodied Insignia (10)
step
    #sticky
    #label CrestofLordaeron
    >>Despoja el |T4504543:0|t[|cff4fc3f7Blasón de Lordaeron|r] del suelo o colgado en una pared
    >>|cffff9a3cMantente atento a esto. Puede aparecer en muchas ubicaciones diferentes y puede ser difícil de ver|r
    .use 268579 >> |cffff9a3cUsa el|r |T4504543:0|t[|cff4fc3f7Blasón de Lordaeron|r] |cffff9a3cpara iniciar la misión|r
    .collect 268579,1,95189,1 -- Crest of Lordaeron (1)
    .accept 95189 >> Acepta la misión El blasón de Lordaeron
step
    #sticky
    #label CrumpledPaper
    >>Haz clic en el |cffe07cf5Papel trituradol|r en el suelo cerca de |cffff5a4aRath'mael|r
    >>|cffff9a3cPuedes hacer esto después de haberlo matado|r
    .accept 92415 >> Acepta la misión Recuerda el amor que te tengo
step
    #requires BaronHead
step
    #requires BloodiedInsignia
step
    #requires CrestofLordaeron
step
    #requires CrumpledPaper
step
    #completewith next
    .goto 1458/0,170.700,1804.700,15 >> |cffff9a3cMuere a manos de cualquier enemigo de dentro para volver más rápido al inicio de la instancia. El cementerio está justo fuera del portal de la estancia|r
    >>|cffff9a3c¡NO resucites en el ángel! Regresa como|r |T132331:0|t[Fantasma] |cffff9a3chacia el portal de la instancia|r
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cCapitán Truman|r
    >>|cff5cf05cCapitán Truman|r |cffff9a3cestá de vuelta al principio de la mazmorra|r
    .turnin 95250 >> Entrega la misión Criaturas abominables
    .target Captain Truman
step
    .hs >> Usa tu Piedra de hogar para ir a Ventormenta << !NightElf
    .hs >> Usa tu Piedra de hogar para ir a Forjaz << NightElf
    .zoneskip Ironforge
    .zoneskip Stormwind City
step 
    #optional
    .goto 1455/0,-1319.2893,-4839.7968,10,0
    .zone Stormwind City >> Toma el tranvía a Ventormenta
step << NightElf
    .goto 1453/0,634.700,-8390.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShoni la Shilenshiosha|r
    .accept 2040 >> Acepta la misión Asalto subterráneo
    .target Shoni the Shilent
step << NightElf
    #optional
    .goto 1453/0,600.22,-8426.93
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cFuren Barbalarga|r
    .turnin 1338 >> Entrega la misión Un pedido de Pico Tormenta
    .target Furen Longbeard
    .isOnQuest 1338
step << NightElf
    .goto 1453/0,501.200,-8468.601
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWilder Cardortiga|r
    .accept 167 >> Acepta la misión Oh, hermano...
    .accept 168 >> Acepta la misión Recolección de recuerdos
    .target Wilder Thistlenettle
step << NightElf
    #completewith next
    .goto 1453/0,437.600,-8524.5000,20,0
    .goto 1453/0,408.100,-8478.500,15,0
    .goto 1453/0,502.900,-8358.800,15 >> Viaja a la Biblioteca de Ventormenta
step << NightElf
    .isOnQuest 95189
    .goto 1453/0,531.000,-8322.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLady Dena Kennedy|r
    >>|cffff9a3cElla deambula un poco por la Galería Real|r
    .turnin 95189 >> Entrega la misión El blasón de Lordaeron
    .target Lady Dena Kennedy
step << NightElf
    .isOnQuest 92415
    .goto 1453/0,744.400,-8621.101
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cSupervisora de huérfanos Ruiseñor|r
    .turnin 92415 >> Entrega la misión Recuerda el amor que te tengo
    .accept 95161 >> Acepta la misión Recuerda el amor que te tengo
    .target Orphan Matron Nightingale
step << NightElf
    #optional
    .isQuestTurnedIn 92415
    .goto 1453/0,744.400,-8621.101
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cSupervisora de huérfanos Ruiseñor|r
    .accept 95161 >> Acepta la misión Recuerda el amor que te tengo
    .target Orphan Matron Nightingale
step << NightElf Rogue
    .goto 1453/0,377.61,-8752.30
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOsborne|r
    >>|cffff9a3cAsegúrate de entrenar|r |T136058:0|t[Forzar cerraduras] |cffff9a3cya que lo necesitarás pronto para la misión de clase de pícaro|r
    .train 1804 >> Aprende |T136058:0|t[Forzar cerradura]
    .target Osborne the Night Man
    .xp >20,1
    .xp <18,1
step << NightElf Rogue
    .goto 1453/0,377.61,-8752.30
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOsborne|r
    >>|cffff9a3cAsegúrate de entrenar|r |T136058:0|t[Forzar cerraduras] |cffff9a3cya que lo necesitarás pronto para la misión de clase de pícaro|r
    .train 1804 >> Aprende |T136058:0|t[Forzar cerradura]
    .trainer >> Aprende tus hechizos de clase
    .target Osborne the Night Man
    .xp <20,1
step << NightElf Rogue
    #completewith next
    .goto 1453/0,374.11,-8762.88,20,0
    .goto 1453/0,326.66,-8818.01,20,0
    .goto 1453/0,323.43,-8817.83,5 >> Entra en el cuartel general de IV:7. Sube las escaleras y dirígete hacia |cff5cf05cRenzik "Chafarote"|r
step << NightElf Rogue
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRenzik "Chafarote"|r
    .accept 2281 >> Acepta la misión Cita en Crestagrana
    .goto 1453/0,362.55,-8819.80
    .target Renzik "The Shiv"
step << NightElf
    .goto 1453/0,673.58,-8867.76
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cTabernera Allison|r
    .home >> Establece tu Piedra de hogar en la ciudad de Ventormenta
    .target Innkeeper Allison
    .bindlocation 16509
step << NightElf
    .goto 1453/0,484.200,-8832.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDungar Tragolargo|r
    .fp Stormwind >> Consigue la Ruta de Vuelo de Ventormenta
    .target Dungar Longdrink
step << NightElf
    .isOnQuest 95195
    .goto 1453/0,521.000,-8954.101
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGeneral Marcus Jonathan|r
    .turnin 95195 >> Entrega la misión La insignia ensangrentada
    .target General Marcus Jonathan
step << !NightElf
    .isOnQuest 92415
    .goto 1453/0,744.400,-8621.101
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cSupervisora de huérfanos Ruiseñor|r
    .turnin 92415 >> Entrega la misión Recuerda el amor que te tengo
    .accept 95161 >> Acepta la misión Recuerda el amor que te tengo
    .target Orphan Matron Nightingale
step << !NightElf
    #optional
    .isQuestTurnedIn 92415
    .goto 1453/0,744.400,-8621.101
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cSupervisora de huérfanos Ruiseñor|r
    .accept 95161 >> Acepta la misión Recuerda el amor que te tengo
    .target Orphan Matron Nightingale
step << !NightElf
    .goto 1453/0,634.700,-8390.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShoni la Shilenshiosha|r
    .accept 2040 >> Acepta la misión Asalto subterráneo
    .target Shoni the Shilent
step << !NightElf
    .goto 1453/0,501.200,-8468.601
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWilder Cardortiga|r
    .accept 167 >> Acepta la misión Oh, hermano...
    .accept 168 >> Acepta la misión Recolección de recuerdos
    .target Wilder Thistlenettle
step << !NightElf
    #completewith next
    .goto 1453/0,437.600,-8524.5000,20,0
    .goto 1453/0,408.100,-8478.500,15,0
    .goto 1453/0,502.900,-8358.800,15 >> Viaja a la Biblioteca de Ventormenta
step << !NightElf
    .isOnQuest 95189
    .goto 1453/0,531.000,-8322.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLady Dena Kennedy|r
    >>|cffff9a3cElla deambula un poco por la Galería Real|r
    .turnin 95189 >> Entrega la misión El blasón de Lordaeron
    .target Lady Dena Kennedy
step << !NightElf
    .isOnQuest 95195
    .goto 1453/0,521.000,-8954.101
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGeneral Marcus Jonathan|r
    .turnin 95195 >> Entrega la misión La insignia ensangrentada
    .target General Marcus Jonathan
step << !NightElf Rogue
    .goto 1453/0,377.61,-8752.30
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOsborne|r
    >>|cffff9a3cAsegúrate de entrenar|r |T136058:0|t[Forzar cerraduras] |cffff9a3cya que lo necesitarás pronto para la misión de clase de pícaro|r
    .train 1804 >> Aprende |T136058:0|t[Forzar cerradura]
    .target Osborne the Night Man
    .xp >20,1
    .xp <18,1
step << !NightElf Rogue
    .goto 1453/0,377.61,-8752.30
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOsborne|r
    >>|cffff9a3cAsegúrate de entrenar|r |T136058:0|t[Forzar cerraduras] |cffff9a3cya que lo necesitarás pronto para la misión de clase de pícaro|r
    .train 1804 >> Aprende |T136058:0|t[Forzar cerradura]
    .trainer >> Aprende tus hechizos de clase
    .target Osborne the Night Man
    .xp <20,1
step << !NightElf Rogue
    #completewith next
    .goto 1453/0,374.11,-8762.88,20,0
    .goto 1453/0,326.66,-8818.01,20,0
    .goto 1453/0,323.43,-8817.83,5 >> Entra en el cuartel general de IV:7. Sube las escaleras y dirígete hacia |cff5cf05cRenzik "Chafarote"|r
step << !NightElf Rogue
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRenzik "Chafarote"|r
    .accept 2281 >> Acepta la misión Cita en Crestagrana
    .goto 1453/0,362.55,-8819.80
    .target Renzik "The Shiv"
step << Warrior
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWu|r o |cff5cf05cIlsa|r
    .goto 1453/0,358.25,-8728.28,15,0
    .goto 1453/0,302.6,-8685.53,15,0
	.goto 1453/0,323.3,-8689.29
    .trainer >> Aprende tus hechizos de clase
    .target Wu Shen
    .target Ilsa Corbin
    .xp <20,1
step << Hunter
    .goto 1453/0,552.78,-8415.71
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cEinris Lanza Reluciente|r dentro
    .trainer >> Aprende tus hechizos de clase
    .target Einris Brightspear
    .xp <20,1
step << Druid
    .goto 1453/0,1347.6192,-8591.2168
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTheridran|r
    .trainer >> Aprende tus hechizos de clase
	.target Theridran
    .xp <20,1
step << Warlock
    #optional
    #completewith next
    .goto 1453/0,988.44,-8942.15,20,0
    .goto 1453/0,1015.33,-8978.9,15 >> Viaja a El Cordero Degollad y baja las escaleras
step << Warlock
    .goto 1453/0,1029.89,-8971.06
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cUrsula Deline|r
    .trainer >> Aprende tus hechizos de clase
    .target Ursula Deline
    .xp <20,1
step << Mage
    #optional
    #completewith next
    .goto 1453/0,874.32,-9014.67,10 >> Viaja a la Torre de los Magos
step << Mage
    .goto 1453/0,885.34,-9006.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cElsharin|r
    .trainer >> Aprende tus hechizos de clase
    .target Elsharin
    .xp <20,1
step << Priest/Paladin
    #optional
    #completewith next
    .goto 1453/0,809.52,-8579.22,20 >> Viaja a la Catedral de Ventormenta
step << Paladin
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cArthur el Leal|r
    .goto 1453/0,859.13,-8559.14,10,0
    .goto 1453/0,861.14,-8573.03
    .trainer >> Aprende tus hechizos de clase
    .target Arthur the Faithful
    .xp <20,1
step << Priest
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cHermano Joshua|r
    .goto 1453/0,862.89,-8519.61
    .trainer >> Aprende tus hechizos de clase
    .target Brother Joshua
    .xp <20,1
]=], "Alliance"}
R[#R + 1] = {[=[
#forever
#version 1
<< Alliance
#group Forever Guía de Mazmorras (A)
#subgroup Mazmorras 1-20
#name 19-20 Minas de la Muerte
#displayname 18-20 Minas Muerte/Crestagrana << NightElf
#next 20-21 Costa Oscura/Vallefresno

step
    #optional
    .goto 1453/0,673.58,-8867.76
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cTabernera Allison|r
    .home >> Establece tu Piedra de hogar en la ciudad de Ventormenta
    .target Innkeeper Allison
    .bindlocation 16509
step << !NightElf !Dwarf/!Hunter
    #completewith TDB1
    .goto 1453/0,484.200,-8832.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDungar Tragolargo|r
    .fly Westfall >> Vuela a Páramos de Poniente
    .target Dungar Longdrink
step << Dwarf Hunter/NightElf
    #optional
    #completewith TDB1
    .zone Westfall >> Sal de Ventormenta. Viaja a Páramos de Poniente
step
    #label TDB1
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGryan Mantorrecio|r
	.target Gryan Stoutmantle
    .goto 1436/0,1045.12,-10508.80
    .accept 65 >> Acepta la misión La hermandad de los Defias
step << !Skyborne
    #completewith RRDB
    .goto 1453/0,484.200,-8832.500,-1
    .goto 1436/0,1037.42,-10628.27,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDungar Tragolargo|r o |cff5cf05cThor|r
    .fly Redridge >> Vuela a Montañas Crestagrana << !NightElf !Dwarf/!Hunter
    .fp Westfall >> Consigue la ruta de vuelo de Páramos de Poniente << NightElf/Dwarf Hunter
    .target Dungar Longdrink
    .target Thor
    .zoneskip Redridge Mountains
    .zoneskip Elwynn Forest
step
    .isQuestAvailable 132
    .goto 1433/0,-1906.400,-9606.800
    .zone Redridge Mountains >> Viaja a las Montañas Crestagrana
step << NightElf/Skyborne/Dwarf Hunter
    .goto 1433/0,-1906.400,-9606.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGuardia Parker|r
    .accept 244 >> Acepta la misión Gnolls invasores
    .target Guard Parker
step << NightElf/Skyborne/Dwarf Hunter
    .goto 1433/0,-2237.93,-9443.60
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cAyudante de alguacil Feldon|r
    .turnin 244 >> Entrega la misión Gnolls invasores
    .target Deputy Feldon
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cSupervisor Olento|r
    .goto 1433/0,-2268.32,-9279.12
    .accept 125 >> Acepta la misión Las herramientas perdidas
    .target Foreman Oslow
step
    #label RRDB
    .goto 1433/0,-2164.56,-9213.10,8,0
    .goto 1433/0,-2145.67,-9231.49
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWiley el Negro|r en la planta de arriba
    .turnin 65 >> Entrega la misión La hermandad de los Defias
    .accept 132 >> Acepta la misión La hermandad de los Defias
	.target Wiley the Black
step << Rogue
    .goto 1433/0,-2180.19,-9328.21
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLucius|r
    .turnin 2281 >> Entrega la misión Cita en Crestagrana
    .accept 2282 >> Acepta la misión Molino de Alther
    .target Lucius
step
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShawn|r
	.target Shawn
    .goto 1433/0,-2207.10,-9351.52
    .accept 3741 >> Acepta la misión El collar de Hilary
step
    >>|cffff9a3cSalta al Lago|r
    >>Abre el |cffe07cf5Barro centelleante|r. Despójalo para obtener el |cff4fc3f7Collar de Hilary|r
    >>|cffff9a3cTiene múltiples ubicaciones de aparición en el Lago|r
    .goto 1433/0,-2174.32,-9386.56,0
    .goto 1433/0,-2147.41,-9308.08,0
    .goto 1433/0,-2090.96,-9373.82,0
    .goto 1433/0,-1986.76,-9324.30,0
    .goto 1433/0,-2246.40,-9359.92,0
    .goto 1433/0,-2309.57,-9376.28,0
    .goto 1433/0,-2397.70,-9363.97,0
    .goto 1433/0,-1986.76,-9324.30,70,0
    .goto 1433/0,-2397.70,-9363.97,70,0
    .complete 3741,1 --Hilary's Necklace (1)
step
    >>Abre el |cffe07cf5Cofre sumergido|r. Despójalo para obtener la |cff4fc3f7Caja de herramientas de Olento|r
    .goto 1433/0,-2472.16,-9366.72
    .complete 125,1 --Oslow's Toolbox (1)
step << Rogue
    #completewith next
    .subzone 97 >> Viaja al Molino de Alther
step << Rogue
    .goto 1433/0,-2696.32,-9228.24--c:1433,51.846,45.116
    >>|cffff9a3cDEBES hacer esto para tu misión de|r |T132290:0|t[Venenos] |cffff9a3cmás adelante|r
    >>|cffff9a3cColócate en el punto marcado de la ruta. Posiciona tu cámara y cursor hasta que puedas hacer clic en 3 |cffe07cf5Arcones de prácticas|r de una vez sin tener que mover nada|r
    .skill lockpicking,80 >>|cffff9a3cAbre los |cffe07cf5Arcones de prácticas|r del suelo en Molino de Alther hasta que tu habilidad de|r |T136058:0|t[Forzar cerraduras] sea 80|r
step << Rogue
	.goto 1433/0,-2700.75,-9222.07
    >>Abre el |cffe07cf5Arcón de Lucius|r. Despójalo para obtener la |cff4fc3f7Muestra de robo|r
    .complete 2282,1 --Token of Thievery
    .skill lockpicking,<80,1
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cSupervisor Olento|r
    .goto 1433/0,-2268.32,-9279.12
    .turnin 125 >> Entrega la misión Las herramientas perdidas
    .target Foreman Oslow
step << Rogue
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLucius|r
	.target Lucius
    .goto 1433/0,-2180.19,-9328.21
    .turnin 2282 >> Entrega la misión Molino de Alther
step
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cHilary|r
	.target Hilary
    .goto 1433/0,-2205.58,-9351.52
    .turnin 3741 >> Entrega la misión El collar de Hilary
step << Rogue
    #optional
	#sticky
	.destroy 7907 >> Destruye el |T134328:0|t[Certificado de Ratería]. No lo necesitas
step
    #completewith next
    .goto 1433/0,-2234.900,-9435.300
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAriena Tempespluma|r
    .fly Westfall >> Vuela a Páramos de Poniente
    .target Ariena Stormfeather
step
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGryan Mantorrecio|r
	.target Gryan Stoutmantle
    .goto 1436/0,1045.12,-10508.80
    .turnin 132 >> Entrega la misión La hermandad de los Defias
    .accept 135 >> Acepta la misión La hermandad de los Defias
step
    #completewith SWDB
    .goto 1436/0,1037.42,-10628.27
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThor|r
    .fly Stormwind >> Vuela a Ventormenta
    .target Thor
step
    #optional
    #completewith next
    .goto 1453/0,374.11,-8762.88,20,0
    .goto 1453/0,326.66,-8818.01,20,0
    .goto 1453/0,323.43,-8817.83,10 >> Entra al cuartel general de IV:7. Sube las escaleras hacia el |cff5cf05cMaestro Mathias Shaw|r
step
    #label SWDB
    .goto 1453/0,362.28,-8815.23
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cMaestro Mathias Shaw|r
    .turnin 135 >> Entrega la misión La hermandad de los Defias
    .accept 141 >> Acepta la misión La hermandad de los Defias
    .target Master Mathias Shaw
step << Rogue
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cMaestro Mathias Shaw|r
    .accept 2360 >> Acepta la misión Mathias y los Defias
    .goto 1453/0,362.28,-8815.23
    .target Master Mathias Shaw
    .xp <20,1
step
    #ah
    .goto 1453/0,660.28,-8814.55
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cSubastadora Jaxon|r
    >>|cffe07cf5Compra los siguientes objetos para entregar las misiones más rápido en Páramos de Poniente pronto:|r
    >>|cffff9a3cSi no quieres o no puedes hacer esto, omite este paso|r
    >>|T132794:0|t[Frasco de aceite]
    .collect 814,5,103,1 -- Flask of Oil (5)
    .target Auctioneer Jaxon
step
    #completewith EnterDM
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDungar Tragolargo|r
    .goto 1453/0,484.200,-8832.500
    .fly Westfall >> Vuela a Páramos de Poniente
    .target Dungar Longdrink
step
    .goto 1436/0,1045.29,-10508.78
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGryan Mantorrecio|r
    .turnin 141 >> Entrega la misión La hermandad de los Defias
    .accept 142 >> Acepta la misión La hermandad de los Defias
    .target Gryan Stoutmantle
step << Druid
    .goto 1436/0,1166.500,-10653.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cTabernera Heather|r
    .target Innkeeper Heather
    .home >> Establece tu Piedra de hogar en Páramos de Poniente
step
    #optional
    #completewith next
    .goto 1436/0,1459.17,-11024.47,55 >> Viaja a Arroyo de la Luna
step
    .goto 1436/0,1459.17,-11024.47
    .line Westfall,44.50,69.62,44.50,69.62,45.08,69.40,45.21,69.35,45.63,68.69,45.85,67.73,45.62,66.99,45.52,65.71,45.61,64.95,44.28,63.88,44.26,62.80,43.60,59.89,43.37,58.42,43.26,57.01,43.12,54.24,42.15,52.74,41.74,51.42,41.48,49.89,40.91,48.71,38.93,46.05,38.51,45.46,37.85,45.54,36.60,44.21,36.06,43.86,35.12,43.49,33.92,43.21,32.56,43.05,31.34,44.54,32.56,43.05,33.92,43.21,35.12,43.49,36.06,43.86,36.26,43.77,36.87,42.87,36.95,40.85,37.04,39.79,37.91,36.98,39.06,35.58,40.48,34.31,41.27,32.87,41.76,31.27,42.26,30.26,43.20,28.99,44.29,28.19,44.64,26.85,44.57,24.94,44.64,26.85,44.29,28.19,43.20,28.99,42.26,30.26,41.76,31.27,41.27,32.87,40.48,34.31,39.06,35.58,37.91,36.98,37.04,39.79,36.95,40.85,36.87,42.87,36.26,43.77,36.06,43.86,35.12,43.49,33.92,43.21,32.56,43.05,31.34,44.54,32.56,43.05,33.92,43.21,35.12,43.49,36.06,43.86,36.60,44.21,37.85,45.54,38.51,45.46,38.93,46.05,40.91,48.71,41.48,49.89,41.74,51.42,42.15,52.74,43.12,54.24,43.26,57.01,43.37,58.42,43.60,59.89,44.26,62.80,44.28,63.88,45.61,64.95,45.52,65.71,45.62,66.99,45.85,67.73,45.63,68.69,45.21,69.35,45.08,69.40,44.50,69.62
    >>Mata al |cffff5a4aMensajero Defias|r. Despójalo para obtener |cff4fc3f7Un mensaje misterioso|r
    >>|cffff9a3cEl |cffff5a4aMensajero Defias|r aparece en Arroyo de la Luna. Camina por el camino al norte de Arroyo de la Luna, hacia la Mina de la Costa del Oro y la Mina de Jango. Si no lo ves por el camino, espéralo a que aparezca en Arroyo de la Luna|r
    .complete 142,1 -- A Mysterious Message (1)
    .unitscan Defias Messenger
step
    .goto 1436/0,1045.12,-10508.80
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGryan Mantorrecio|r
    .turnin 142 >> Entrega la misión La hermandad de los Defias
    .target Gryan Stoutmantle
step
    .goto 1436/0,1067.87,-10508.330
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cEl Traidor de los Defias|r
    >>|cffff9a3cEs posible que debas esperar a que |cff5cf05cEl Traidor de los Defias|r aparezca si no está ahí|r
    .accept 155 >> Acepta la misión La hermandad de los Defias
    .target The Defias Traitor
step
    .goto 1436/0,1527.07,-11073.23
    >>Escolta a |cff5cf05cEl Traidor de los Defias|r a Las Minas de la Muerte
    .complete 155,1 -- Escort The Defias Traitor to discover where VanCleef is hiding (1)
    .target The Defias Traitor
step
    .goto 1436/0,1045.12,-10508.80
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGryan Mantorrecio|r
    .turnin 155 >> Entrega la misión La hermandad de los Defias
    .accept 166 >> Acepta la misión La hermandad de los Defias
    .target Gryan Stoutmantle
step
    .goto 1436/0,1033.22,-10504.83
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cExploradora Riell|r en lo alto de la Torre
    .accept 214 >> Acepta la misión Pañuelos rojos de seda
    .target Scout Riell
step
    .goto 1436/0,1040.78,-11032.91,0--c:1436,56.454,69.982
    .goto 1436/0,1041.48,-11134.58,0--c:1436,56.434,74.339
    .goto 1436/0,938.23,-11130.96,0--c:1436,59.384,74.184
    .goto 1436/0,886.18,-11135.11,0--c:1436,60.871,74.362
    .goto 1436/0,885.10,-11211.60,0--c:1436,60.902,77.640
    .goto 1436/0,796.20,-11204.58,0--c:1436,63.442,77.339
    .goto 1436/0,734.56,-11156.67,0--c:1436,65.203,75.286
    .goto 1436/0,790.88,-11100.11,0--c:1436,63.594,72.862
    .goto 1436/0,782.79,-11036.25,0--c:1436,63.825,70.125
    .goto 1436/0,1523.95,-11065.44--c:1436,42.649,71.376
    >>|cffff9a3cGrindea a los |cffff5a4aGnolls|r al sur de Colina Centinela mientras reúnes un grupo para Minas de la Muerte|r
    .subzone 20 >>Una vez que tu grupo esté reunido, viaja a Arroyo de la Luna
step
    .goto 1436/0,1527.42,-11072.77
    .subzone 1581 >> Entra a la Ladronera de los Defias con tu grupo
step
    #completewith EnterDM
    >>Mata a los |cffff5a4aDefias|r. Despójalos para obtener sus |cff4fc3f7Pañuelos de seda rojos|r
    >>|cffff9a3cTambién puedes completar esto dentro de Minas de la Muerte|r
    .complete 214,1 -- Red Silk Bandana (10)
    .isOnQuest 214
step
    #completewith next
    >>Mata a los |cffff5a4aMineros esquelético|r, a los |cffff5a4aDinamitadores no-muertos|r y a los |cffff5a4aExcavadores no-muertos|r. Despójalos para obtener sus |cff4fc3f7Tarjetas|r
    >>|cffff9a3cNOTA: Esta misión NO otorga experiencia extra como otras misiones de mazmorra, y lleva bastante más tiempo completarla. Considera omitir esta misión si tu grupo está de acuerdo|r
    >>|cffff9a3cEsto se completa FUERA de la Mazmorra|r
    .complete 168,1 -- Miners' Union Card (4)
    .mob Skeletal Miner
    .mob Undead Dynamiter
    .mob Undead Excavator
step
    .goto 1415/0,1504.68,-11259.75,25,0--c:1415,41.18,79.80
    .goto 1415/0,1557.48,-11297.29,25,0--c:1415,41.03,79.96
    .goto 1415/0,1596.20,-11318.41,25,0--c:1415,40.92,80.05
    .goto 1415/0,1539.88,-11332.49--c:1415,41.08,80.11
    >>Mata al |cffff5a4aSupervisor Cardortiga|r. Despójalo para obtener su |cff4fc3f7Distintivo|r
    >>|cffff9a3cEsto se completa FUERA de la Mazmorra|r
    .complete 167,1 -- Thistlenettle's Badge (1)
    .unitscan Foreman Thistlenettle
step
    .goto 1415/0,1504.68,-11259.75,25,0--c:1415,41.18,79.80
    .goto 1415/0,1557.48,-11297.29,25,0--c:1415,41.03,79.96
    .goto 1415/0,1596.20,-11318.41,25,0--c:1415,40.92,80.05
    .goto 1415/0,1539.88,-11332.49--c:1415,41.08,80.11
    >>Mata a los |cffff5a4aMineros esquelético|r, a los |cffff5a4aDinamitadores no-muertos|r y a los |cffff5a4aExcavadores no-muertos|r. Despójalos para obtener sus |cff4fc3f7Tarjetas|r
    >>|cffff9a3cNOTA: Esta misión NO otorga experiencia extra como otras misiones de mazmorra, y lleva bastante más tiempo completarla. Considera omitir esta misión si tu grupo está de acuerdo|r
    >>|cffff9a3cEsto se completa FUERA de la Mazmorra|r
    .complete 168,1 -- Miners' Union Card (4)
    .mob Skeletal Miner
    .mob Undead Dynamiter
    .mob Undead Excavator
step
    #label EnterDM
    .enabledungeon DM
    .goto 1415/0,1589.16,-11250.36,25,0--c:1415,40.94,79.76
    .goto 1415/0,1617.32,-11217.51,20,0--c:1415,40.86,79.62
    .goto 1415/0,1681.38,-11207.65--c:1415,40.678,79.578
    .subzone 1581,2 >> Entra a la Mazmorra Las Minas de la Muerte
step
    #completewith DMend
    >>Mata a los |cffff5a4aDefias|r dentro de Las Minas de la Muerte. Despójalos para obtener sus |cff4fc3f7Pañuelos|r
    .complete 214,1 -- Red Silk Bandana (10)
step
    >>Mata a |cffff5a4aSneed|r. Despójalo para obtener la |cff4fc3f7Dentrituradora goblin|r
    .complete 2040,1 -- Gnoam Sprecklesprocket (1)
step
    #label DMend
    >>Mata a |cffff5a4aEdwin VanCleef|r. Despójalo para obtener su |cff4fc3f7Cabeza|r y |T133471:0|t[|cff4fc3f7Una carta sin enviar|r]
    >>|cffff9a3cUsa |T133471:0|t[|cff4fc3f7Una carta sin enviar|r] para iniciar la misión|r
    .collect 2874,1,373 -- An Unsent Letter (1)
    .complete 166,1 -- Head of VanCleef (1)
    .accept 373 >> Acepta la misión La carta sin enviar
    .use 2874 -- An Unsent Letter
step
    #completewith next
    .goto 1436/0,1966.32,-11407.13,40 >> Viaja al Faro de Poniente
step
    .goto 1436/0,1966.32,-11407.13
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cCapitán Grisillo|r
    .accept 104 >> Acepta la misión La amenaza costera
    .accept 103 >> Acepta la misión Guardián de la Llama
    .turnin 103 >> Entrega la misión Guardián de la Llama
    .target Captain Grayson
    .itemcount 814,5 -- Flask of Oil (5)
step
    .goto 1436/0,1966.32,-11407.13
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cCapitán Grisillo|r
    .accept 104 >> Acepta la misión La amenaza costera
    .target Captain Grayson
step
    .goto 1436/0,1811.62,-11358.37
    .line Westfall,34.43,83.93,34.43,83.93,33.88,83.32,33.08,82.86,32.56,82.71,32.08,82.49,31.91,82.36,31.55,81.88,30.86,81.42,30.63,81.16,30.33,80.81,30.02,80.11,29.68,79.22,29.32,78.19,29.29,77.60,29.27,77.31,29.18,76.26,29.07,75.29,28.95,74.14,28.85,73.29,28.79,72.48,28.37,71.94,27.84,71.29,27.44,70.25,27.29,69.47,27.13,68.65,27.09,67.57,27.07,67.01,26.74,66.09,27.07,67.01,27.09,67.57,27.13,68.65,27.29,69.47,27.44,70.25,27.84,71.29,28.37,71.94,28.79,72.48,28.85,73.29,28.95,74.14,29.07,75.29,29.18,76.26,29.27,77.31,29.29,77.60,29.32,78.19,29.68,79.22,30.02,80.11,30.33,80.81,30.63,81.16,30.86,81.42,31.55,81.88,31.91,82.36,32.08,82.49,32.56,82.71,33.08,82.86,33.88,83.32,34.43,83.93
    >>Mata a |cffff5a4aViejo Ojosombrío|r. Despójalo para obtener su |cff4fc3f7Escama|r
    .complete 104,1 -- Scale of Old Murk-Eye (1)
    .unitscan Old Murk-Eye
step
    .goto 1436/0,1966.32,-11407.13
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cCapitán Grisillo|r
    .turnin 104 >> Entrega la misión La amenaza costera
    .target Captain Grayson
    .isQuestComplete 104
step << Druid
    .goto 1436/0,1707.2116,-10583.0227
    >>Haz clic en los |cffe07cf5Restos quemados|r en el suelo
    .accept 79008 >> Acepta la misión ... y la nota que encontraste
step << Druid
    #completewith next
    .goto 1436/0,2389.19,-10172.31,50 >> Nada hacia mar adentro
step << Druid
    .goto 1436/0,2389.19,-10172.31
    >>Abre el |cffe07cf5Arcón extraño|r. Despójalo para obtener el |cff4fc3f7Medio colgante de Resistencia acuática|r
    .collect 15882,1,272,1 --Collect Half Pendant of Aquatic Endurance (x1)
step << Druid
    #completewith next
	.cast 18960 >> Lanza Teletransporte a: Claro de la Luna
step << Druid
    .goto 1450/1,-2593.82,7867.06
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLoganaar|r
    .trainer >> Aprende tus hechizos de clase
    .target Loganaar
step << Druid
    .hs >> Usa la Piedra de hogar para ir a Colina del Centinela
step << !Druid
    .goto 1436/0,1707.2116,-10583.0227
    >>Haz clic en los |cffe07cf5Restos quemados|r en el suelo
    .accept 79008 >> Acepta la misión ... y la nota que encontraste
step
    #completewith RSB
    .goto 1436/0,1045.12,-10508.80,100 >> Viaja a Colina del Centinela
step
    .isQuestComplete 166
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGryan Mantorrecio|r
    .turnin 166 >> Entrega la misión La hermandad de los Defias
    .target Gryan Stoutmantle
    .goto 1436/0,1045.12,-10508.80
step
    #label RSB
    .isQuestComplete 214
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cExploradora Riell|r en lo alto de la Torre
    .turnin 214 >> Entrega la misión Pañuelos rojos de seda
    .goto 1436/0,1033.22,-10504.83
    .target Scout Riell

step
   .maxlevel 19,Level20Check

step
    .goto 1436/0,1037.42,-10628.27
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThor|r
    .fly Redridge >> Vuela a Montañas Crestagrana
    .target Thor
step
    .goto 1433/0,-1906.400,-9606.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGuardia Parker|r
    .accept 244 >> Acepta la misión Gnolls invasores
    .target Guard Parker
step
    .goto 1433/0,-2237.93,-9443.60
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cAyudante de alguacil Feldon|r
    .turnin 244 >> Entrega la misión Gnolls invasores
    .accept 246 >> Acepta la misión Evaluar la amenaza
    .accept 98407 >>Acepta la misión Demostración de fuerza
    .target Deputy Feldon
step
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cAlguacil Marris|r
    .goto 1433/0,-2298.06,-9284.04
    .accept 20 >> Acepta la misión La amenaza de los Roca Negra
    .accept 98387 >>Acepta la misión Bloqueo Roca Negra
    .target Marshal Marris
step
    .group
    .goto 1433/0,-2208.600,-9243.500
    >>Haz clic en el |cffe07cf5Cartel de Se busca|r
    .accept 95999 >>Acepta la misión Se busca: incinerador Gar'im
step
    #loop
    .goto 1433/0,-1913.800,-9490.601,50,0
    .goto 1433/0,-2211.01,-9773.870,45,0
    .goto 1433/0,-2276.79,-9759.11,45,0
    .goto 1433/0,-2508.20,-9620.68,45,0
    .goto 1433/0,-2246.61,-9764.90,45,0
	>>Mata a los |cffff5a4aBastardos de Crestagrana|r y a los |cffff5a4aFurtivos de Crestagrana|r
    >>Mata a los |cffff5a4aDescarnadores de Crestagrana|r. Despójalos para obtener sus |cff4fc3f7Colleras con pinchos|r
    .complete 246,1 --Redridge Mongrel (10)
    .mob +Redridge Mongrel
    .complete 246,2 --Redridge Poacher (6)
	.mob +Redridge Poacher
    .complete 98407,1 --Spiked Collar (5)
	.mob +Redridge Thrasher
step
    .group 4
    .isOnQuest 95999
    #sticky
    #label IncineratorGarim
    .waypoint 1433/0,-3261.400,-9824.700
    >>Mata al |cffff5a4aIncinerador Gar'im|r dentro de la cueva. Despójalo para obtener el |cff4fc3f7Bastón roto del incinerador Gar'im|r
    >>|cffff9a3cOmite este paso si no puedes encontrar un grupo para él|r
    .complete 95999,1 -- Broken Staff of Incinerator Gar'im (1)
    .mob Incinerator Gar'im
step
    #completewith next
    >>Despoja los |cffe07cf5sacos de grano|r y los |cffe07cf5paletadas de carne|r en el suelo para los |cff4fc3f7Suministros robados|r
    >>Despoja los |cffe07cf5Expositores de armas|r y las |cffe07cf5Armas robadas|r del suelo
    .complete 98387,1 -- Stolen Supplies (10)
    .complete 98387,2 -- Stolen Weapon (8)
step
    #label orcs
    #loop
    >>Mata a los |cffff5a4aBrutos Roca Negra|r y a los |cffff5a4aAvanzados Roca Negras|r. Despójalos para obtener sus |cff4fc3f7Hachas|r
	>>|cffff9a3cTen cuidado, los |cffff5a4aAvanzados Roca Negra|r lanzarán |T132149:0|t[Red] sobre ti|r
    .goto 1433/0,-3177.25,-9718.85,60,0
    .goto 1433/0,-3224.57,-9782.42,60,0
    .goto 1433/0,-3259.74,-9566.82,60,0
    .goto 1433/0,-3092.80,-9694.82,60,0
    .goto 1433/0,-3177.25,-9718.85,60,0
    .complete 20,1 --Battleworn Axe (10)
    .mob Blackrock Grunt
	.mob Blackrock Outrunner
step
    #loop
    .goto 1433/0,-3177.25,-9718.85,60,0
    .goto 1433/0,-3224.57,-9782.42,60,0
    .goto 1433/0,-3259.74,-9566.82,60,0
    .goto 1433/0,-3092.80,-9694.82,60,0
    .goto 1433/0,-3177.25,-9718.85,60,0
    >>Despoja los |cffe07cf5sacos de grano|r y los |cffe07cf5paletadas de carne|r en el suelo para los |cff4fc3f7Suministros robados|r
    >>Despoja los |cffe07cf5Expositores de armas|r y las |cffe07cf5Armas robadas|r del suelo
    .complete 98387,1 -- Stolen Supplies (10)
    .complete 98387,2 -- Stolen Weapon (8)
step
    #requires IncineratorGarim
step << Shaman -- most likely not on this quest yet
    #optional
    .isOnQuest 94499
    .goto 1433/0,-3121.100,-9485.000
    .use 265747 >> |cffff9a3cUsa la|r |T132829:0|t[Bota de agua roja sin llenar] |cffff9a3cen Cascadas Petravista|r
    .complete 94499,1 --|1/1 Full Red Waterskin
step
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cAyudante de alguacil Feldon|r
	.target Deputy Feldon
    .goto 1433/0,-2237.93,-9443.60
    .turnin 246 >> Entrega la misión Evaluar la amenaza
    .turnin 98407 >>Entrega la misión Demostración de fuerza
step
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cAlguacil Marris|r
	.target Marshal Marris
    .goto 1433/0,-2298.06,-9284.04
    .turnin 20 >> Entrega la misión La amenaza de los Roca Negra
    .turnin 98387 >>Entrega la misión Bloqueo Roca Negra
step
    .isQuestComplete 95999
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cMagistrado Solomon|r
	.target Magistrate Solomon
    .goto 1433/0,-2207.10,-9231.34,15,0
    .goto 1433/0,-2221.65,-9218.60
    .turnin 95999 >>Entrega la misión Se busca: incinerador Gar'im
step
    #optional
    .xp 20 >> Mata enemigos hasta el nivel 20

step
    #label Level20Check

step << !Druid !Rogue
    .hs >> Usa tu Piedra de hogar para ir a Ventormenta
    .cooldown item,6948,>2,1
    .zoneskip Stormwind City
    .zoneskip Darkshore
step
    #optional
    #completewith DarkshoreBoat
    .goto 1433/0,-2234.900,-9435.300,-1
    .goto 1436/0,1037.42,-10628.27,-1
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAriena Tempespluma|r o |cff5cf05cThor|r
    .fly Stormwind >> Vuela a Ventormenta
    .target Ariena Stormfeather
    .target Thor
    .zoneskip Stormwind City
    .zoneskip Darkshore
step << Rogue
    .isNotOnQuest 2360
    .goto 1453/0,377.47,-8752.39
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOsborne|r
    .trainer >> Aprende tus hechizos de clase
    .target Osborne the Night Man
    .train 1785,1
    .xp <20,1
    .xp >22,1
step << Rogue
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cMaestro Mathias Shaw|r
    .accept 2360 >> Acepta la misión Mathias y los Defias
    .goto 1453/0,362.28,-8815.23
    .target Master Mathias Shaw
step << Rogue
    #completewith RoguePoison
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDungar Tragolargo|r
    .goto 1453/0,484.200,-8832.500
    .fly Westfall >> Vuela a Páramos de Poniente
    .target Dungar Longdrink
step << !Dwarf Rogue
    .goto 1431/0,404.03,-11014.47,60,0
    .goto 1431/0,432.11,-10878.75,50,0
    .goto 1431/0,551.72,-10688.13
    >>Mata |cffff5a4aTelarácnidas venenosa pigmeas|r y |cffff5a4aTelarácnidas venenosas|r. Despójalas para obtener una |cff4fc3f7Glándula de veneno pequeña|r y sus |cff4fc3f7Patas pegajosas de araña|r
    >>|cffff9a3cNecesitas una|cff4fc3f7 Glándula de veneno pequeña|r para hacer un|r |T134437:0|t[Contraveneno] |cffff9a3cmás tarde para quitar el perjuicio|r |T136230:0|t[Toque de Zanzil] |cffff9a3cmás tarde|r
    >>|cffff9a3cGuarda las |cff4fc3f7Patas pegajosas de araña|r para más tarde|r
    >>|cffff9a3cSi tienes un amigo|r |T626003:0|t|cFFF48CBAPaladín|r|cffff9a3c,|r |T625999:0|t|cFFFF7C0ADruida|r |cffff9a3co|r |T626006:0|t|cFF0070DDChamán|r |cffff9a3cpuedes saltarte este paso y pedirle que te lo disipe|r
    .collect 1475,1,2359,1 -- Small Venom Sac (1)
    .collect 2251,6,93,1,1 -- Gooey Spider Legs (6)
    .disablecheckbox
    .mob Pygmy Venom Web Spider
    .mob Venom Web Spider
    .itemcount 6452,<1 --Anti Venom (<1)
step << Rogue
    #optional
    #completewith TowerKey
    +|cffff9a3c==PRESTA ATENCIÓN A LA SIGUIENTE SECCIÓN==|r
    >>|cffff9a3cPresiona Escape, luego ve a -> Opciones -> Controles|r
    >>|cffff9a3cActiva "Habilitar tecla de interactuar" y asigna la opción "Interactuar con objetivo" a una tecla|r
    >>|cffff9a3cAdemás, se recomienda activar las placas de nombre enemigas (tecla predeterminada: V) ya que te permite ver a los enemigos detrás de algunas esquinas dentro de la torre|r
step << Rogue
    .goto 1436/0,619.17,-11035.20
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cAgente Kearnen|r
    >>|cffff9a3cDEBES completar esta misión para desbloquear|r |T132290:0|t[Venenos].
    .turnin 2360 >> Entrega la misión Mathias y los Defias
    .accept 2359 >> Acepta la misión La torre de Klaven
    .target Agent Kearnen
step << Rogue
    #label TowerKey
    #loop
    .goto 1436/0,514.52,-11114.77,0
    .goto 1436/0,531.32,-11166.80,0
    .goto 1436/0,581.37,-11104.97,0
    .goto 1436/0,514.52,-11114.77,30,0
    .goto 1436/0,531.32,-11166.80,30,0
    .goto 1436/0,581.37,-11104.97,30,0
    >>|T133644:0|t[Robar] al |cffff5a4aZángano Defias deforme|r. Despójalo para obtener la |cff4fc3f7Llave de la torre Defias|r
    >>|cffff9a3cDebes estar en|r |T132320:0|t[Sigilo] |cffff9a3cpara usar|r |T133644:0|t[Robar]
    >>|cffff9a3cEl |cffff5a4aZángano Defias deforme|r aparece en la entrada de la torre, luego patrulla alrededor del exterior de ella|r
    >>|cffff9a3cTen cuidado ya que él hace MUCHO daño. Si tu|r |T132320:0|t[Sigilo] |cffff9a3cse rompe, usa rápidamente|r |T132307:0|t[Sprint] |cffff9a3cy huye|r
    .complete 2359,2 --Collect Defias Tower Key (x1)
    .link https://www.youtube.com/watch?v=5sIew15IcG0 >> Haz clic AQUÍ para una guía en vídeo
    .mob Malformed Defias Drone
step << Rogue
    #optional
    #completewith Mortwake
    +|cffff9a3cEquipa la|r |T135641:0|t[Daga de madera curva] |cffff9a3cpara esta misión si no tienes una|r |T135641:0|t[Daga] |cffff9a3cequipada|r
    .use 15396
    .itemcount 15396,1
step << Rogue
    #label Mortwake
    .goto 1436/0,551.93,-11127.39--c:1436,70.421,74.031
    >>|cffff9a3cViaja hasta el 2.º piso de la torre. Mientras estés en|r |T132320:0|t[Sigilo] |cffff9a3cy los |cffff5a4aAvizores de torre Defias|r no estén cerca de ti, Salta en la silla, luego en la lámpara, luego en el estante encima del punto de la ruta|r
    >>|cffff9a3cManualmente desactiva el|r |T132320:0|t[Sigilo]|cffff9a3c, luego presiona tu tecla "Interactuar con el objetivo" para abrir el |cffe07cf5Cofre de Bosque del Ocaso|r. Despójalo para obtener el|r |cff4fc3f7Diario de Klaven Mortoalerta|r
    >>|cffff9a3cNOTA: Tu|r |T132320:0|t[Sigilo] |cffff9a3cdejará de funcionar temporalmente después de despojar el|r |cff4fc3f7Diario de Klaven Mortoalerta|r
    >>|cffff9a3cPrepárate para correr si no matas los |cffff5a4aAvizores de torre Defias|r en el 2.º piso. Lo más probable es que te generen amenaza permanente (aunque no te atacarán) cuando estés encima de la estantería, ya que es un punto de evasión|r
    >>|cffff9a3cSi tienes una|r |T135641:0|t[Daga] |cffff9a3cen tu inventario o equipada, puedes lanzar|r |T132282:0|t[Emboscada] |cffff9a3cen los |cffff5a4aGuardias de torre Defias|r y |cffff5a4aAvizores de torre Defias|r de dentro para matarlos instantáneamente. Prepárate para correr después de matar al primer |cffff5a4aAvizor de torre Defias|r y recuerda que puedes ser golpeado desde arriba. Esto es más lento, pero MUCHO más seguro|r
    >>|cffff9a3cTen cuidado ya que los |cffff5a4aZángano Defias deforme|r y los |cffff5a4aZánganos Defias|r pueden estar en la entrada de la torre si tienes que salir corriendo de ella|r
    .complete 2359,1 --Collect Klaven Mortwake's Journal (x1)
    .link https://www.youtube.com/watch?v=5sIew15IcG0 >> Haz clic AQUÍ para una guía en vídeo
    .mob Defias Tower Patroller
    .mob Defias Tower Sentry
step << !Dwarf Rogue
    #sticky
    #label AntiVenomStart
    .collect 6452,1 >> Fabrica un |T134437:0|t[Contraveneno]
    .aura -9991
    .itemcount 6452,<1 --Anti-Venom (<1)
    .train 7934,3 --Anti Venom spell trained
step << !Dwarf Rogue
    #optional
    #requires AntiVenomStart
    #label AntiVenomEnd
    .cast 7932 >>|cffff9a3cUsa el |T134437:0|t[Contraveneno] en tus bolsas para quitarte el perjuicio |T136230:0|t[Toque de Zanzil] |r
    .use 6452
    .aura -9991
    .itemcount 6452,1 --Anti-Venom (1)
step << Dwarf Rogue
    #optional
    #sticky
    #label AntiVenomEnd2
    .cast 20594 >>|cffff9a3cLanza |T136225:0|t[Forma de piedra] para quitarte el perjuicio |T136230:0|t[Toque de Zanzil] |r
    .aura -9991
step << Rogue
    .hs >> Usa tu Piedra de hogar para ir a Ventormenta
    .cooldown item,6948,>2,1
    .zoneskip Stormwind City
    .zoneskip Darkshore
step << Rogue
    #optional
    #completewith KlavenEnd
    .goto 1436/0,1037.42,-10628.27
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThor|r
    .fly Stormwind >> Vuela a Ventormenta
    .target Thor
    .zoneskip Stormwind City
step << !Dwarf Rogue
    #optional
    #requires AntiVenomEnd
    #completewith FirstAidEnd
    .goto 1453/0,803.77,-8582.52,20,0--c:1453,42.938,33.878
    .goto 1453/0,822.51,-8559.68,20,0--c:1453,41.544,31.330
    .goto 1453/0,820.57,-8530.27,20,0--c:1453,41.688,28.049
    .goto 1453/0,801.99,-8513.29,15 >> Viaja hacia |cff5cf05cShaina Fuller|r--c:1453,43.070,26.155
    .aura -9991
step << !Dwarf Rogue
    #requires AntiVenomEnd
    .goto 1453/0,801.99,-8513.29--c:1453,43.070,26.155
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShaina Fuller|r
    >>|cffff9a3cSi tienes un amigo|r |T626003:0|t|cFFF48CBAPaladín|r|cffff9a3c,|r |T625999:0|t|cFFFF7C0ADruida|r |cffff9a3co|r |T626006:0|t|cFF0070DDChamán|r |cffff9a3camigo, pídele en su lugar que te disipe el|r |T136230:0|t[Tacto de Zanzil] |cffff9a3cpor ti|r
    .skill firstaid,80 >> |cffff9a3cSube tus|r |T135966:0|t[Primeros auxilios] |cffff9a3cal 80|r
    .aura -9991
    .itemcount 6452,<1 --Anti-Venom (<1)
step << !Dwarf Rogue
    #label FirstAidEnd
    .goto 1453/0,801.99,-8513.29--c:1453,43.070,26.155
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShaina Fuller|r
    >>|cffff9a3cSi tienes un amigo|r |T626003:0|t|cFFF48CBAPaladín|r|cffff9a3c,|r |T625999:0|t|cFFFF7C0ADruida|r |cffff9a3co|r |T626006:0|t|cFF0070DDChamán|r |cffff9a3camigo, pídele en su lugar que te disipe el|r |T136230:0|t[Tacto de Zanzil] |cffff9a3cpor ti|r
    .train 7934 >> |cffff9a3cAprende|r |T134437:0|t[Contraveneno]
    .aura -9991
    .itemcount 6452,<1 --Anti-Venom (<1)
step << !Dwarf Rogue
    #sticky
    #label AntiVenomStart2
    .collect 6452,1 >> Fabrica un |T134437:0|t[Contraveneno]
    .aura -9991
    .itemcount 6452,<1 --Anti-Venom (<1)
    .train 7934,3 --Anti Venom spell trained
step << !Dwarf Rogue
    #sticky
    #requires AntiVenomStart2
    #label AntiVenomEnd2
    .cast 7932 >>|cffff9a3cUsa el |T134437:0|t[Contraveneno] en tus bolsas para quitarte el perjuicio |T136230:0|t[Toque de Zanzil] |r
    .use 6452
    .aura -9991
    .itemcount 6452,1 --Anti-Venom (1)
step << Rogue
    .goto 1453/0,377.47,-8752.39
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOsborne|r
    .trainer >> Aprende tus hechizos de clase
    .target Osborne the Night Man
    .train 1785,1
    .xp <20,1
    .xp >22,1
step << Rogue
    .goto 1453/0,377.47,-8752.39
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOsborne|r
    .trainer >> Aprende tus hechizos de clase
    .target Osborne the Night Man
    .train 1759,1
    .xp <22,1
    .xp >24,1
step << Rogue
    #optional
    #requires AntiVenomEnd2 << Rogue
    #completewith next
    .goto 1453/0,374.11,-8762.88,20,0
    .goto 1453/0,326.66,-8818.01,20,0
    .goto 1453/0,323.43,-8817.83,10 >> Entra al cuartel general de IV:7. Sube las escaleras hacia el |cff5cf05cMaestro Mathias Shaw|r
step << Rogue
    #label KlavenEnd
    #requires AntiVenomEnd2 << Rogue
    .goto 1453/0,362.28,-8815.23
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cMaestro Mathias Shaw|r
    >>|cffff9a3cRecuerda volver a equipar tu arma principal si cambiaste a una|r |T135641:0|t[Daga] |cffff9a3cantes|r << Rogue
    .turnin 2359 >> Entrega la misión La torre de Klaven
    .target Master Mathias Shaw
step << Warrior
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWu|r o |cff5cf05cIlsa|r
    .goto 1453/0,358.25,-8728.28,15,0
    .goto 1453/0,302.6,-8685.53,15,0
	.goto 1453/0,323.3,-8689.29
    .trainer >> Aprende tus hechizos de clase
    .target Wu Shen
    .target Ilsa Corbin
step
    .isQuestComplete 167
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWilder Cardortiga|r
    .turnin 167 >> Entrega la misión Oh, hermano...
    .goto 1453/0,501.200,-8468.601
    .target Wilder Thistlenettle
step
    .isQuestComplete 168
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cWilder Cardortiga|r
    .turnin 168 >> Entrega la misión Recolección de recuerdos
    .goto 1453/0,501.200,-8468.601
    .target Wilder Thistlenettle
step << Hunter
    .goto 1453/0,552.78,-8415.71
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cEinris Lanza Reluciente|r
    .trainer >> Aprende tus hechizos de clase
    .target Einris Brightspear
step << Hunter
    .goto 1453/0,553.22,-8422.23
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKarrina Mekenda|r
    .trainer >> Entrena los hechizos de tu mascota
    .target Karrina Mekenda
step
    .isQuestComplete 2040
    .goto 1453/0,634.800,-8390.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShoni la Shilenshiosha|r
    .turnin 2040 >> Entrega la misión Asalto subterráneo
    .target Shoni the Shilent
step << Shaman
    #completewith ShamTrain
    .goto 1453/0,558.96,-8382.54,25,0
    .goto 1453/0,520.64,-8351.460
    .zone Ironforge >> Entra en el Tranvía Subterráneo. Toma el tranvía a Forjaz
step << Shaman
    .goto 1455/0,-1086.500,-4642.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cEldrun Rompetormentas::258098|r
    .target Eldrun Stormbreaker::258098
    .accept 94494 >>Acepta la misión La llamada del agua
    .trainer >> Aprende tus hechizos de clase
    .train 2645,1 -- ghost wolf
step << Shaman
    #label ShamTrain
    .goto 1455/0,-1086.500,-4642.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cEldrun Rompetormentas::258098|r
    .target Eldrun Stormbreaker::258098
    .trainer >> Aprende tus hechizos de clase
    .train 408342,1 -- fire nova r2
    .xp <22,1
step << Shaman
    .goto 1455/0,-1330.28,-4843.6,5,0
    .zone Stormwind City >> Entra en el Tranvía Subterráneo. Toma el tranvía a Ventormenta
    .zoneskip Darkshore
    .zoneskip Ashenvale
step
    .goto 1453/0,719.67,-8550.30
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBaros Alexston|r
    .turnin 373 >>Entrega la misión La carta sin enviar
    .accept 389 >>Acepta la misión Bazil Thredd
    .target Baros Alexston
step << Warlock
    #optional
    #completewith next
    .goto 1453/0,988.44,-8942.15,20,0
    .goto 1453/0,1015.33,-8978.9,15 >> Viaja a El Cordero Degollad y baja las escaleras
step << Warlock
    .goto 1453/0,1029.89,-8971.06
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cUrsula Deline|r
    .trainer >> Aprende tus hechizos de clase
    .target Ursula Deline
step << Warlock
    .goto 1453/0,1041.54,-8983.29
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGakin el Presotenebra|r
    .accept 1716 >> Acepta la misión Devoradora de almas
    .target Gakin the Darkbinder
step << Mage
    #optional
    #completewith next
    .goto 1453/0,874.32,-9014.67,10 >> Viaja a la Torre de los Magos
step << Mage
    .goto 1453/0,885.34,-9006.15
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cElsharin|r
    .trainer >> Aprende tus hechizos de clase
    .target Elsharin
step << Priest/Paladin
    #optional
    #completewith next
    .goto 1453/0,809.52,-8579.22,20 >> Viaja a la Catedral de Ventormenta
step << Paladin
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cArthur el Leal|r
    .goto 1453/0,859.13,-8559.14,10,0
    .goto 1453/0,861.14,-8573.03
    .trainer >> Aprende tus hechizos de clase
    .target Arthur the Faithful
step << Priest
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cHermano Joshua|r
    .goto 1453/0,862.89,-8519.61
    .trainer >> Aprende tus hechizos de clase
    .target Brother Joshua
step
    .goto 1453/0,1093.3,-8779.020
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cArgos Susurro Nocturno|r
    .accept 3765 >> Acepta la misión Lejana corrupción
    .target Argos Nightwhisper
step << !Druid
    #optional
    .goto 1453/0,1330.100,-8645.400
    >>|cffff9a3cSube tu nivel de|r |T135966:0|t[Primeros auxilios] |cffff9a3cmientras esperas el barco a Costa Oscura si es necesario|r
    .zone Darkshore >> Toma el barco hacia Costa Oscura
    .skill firstaid,<1,1 -- shows if firstaid is >1
step << !Druid
    #label DarkshoreBoat
    .goto 1453/0,1330.100,-8645.400
    .zone Darkshore >> Toma el barco hacia Costa Oscura
step
    #optional
    .abandon 95999 >>Abandona la misión Se busca: incinerador Gar'im
]=], "Alliance"}
R[#R + 1] = {[=[
#forever
#version 1
<< Alliance
#group Forever Guía de Mazmorras (A)
#subgroup Mazmorras 1-20
#name 20-21 Costa Oscura/Vallefresno
#next Forever Guía de Mazmorras (A)\21-23 Vallefresno/Sierra Espolón

step << Druid
    #completewith catspirit1
	.cast 18960 >> Lanza Teletransporte a: Claro de la Luna
step << Druid
    #completewith next
    .goto 1450/1,-2400.33,7795.33--c:Moonglade,44.148,45.229
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSilva Fil'naveth|r
    .fly Teldrassil >> Vuela a Darnassus
    .skipgossip
    .timer 153,Darnassus
    .target Silva Fil'naveth
    .zoneskip Darnassus
    .zoneskip Teldrassil
step << NightElf !Druid
    #hidewindow
    #optional
    #completewith next
    .goto 1438/1,965.80,8780.95
    .zone Darnassus >> Toma el portal morado a Darnassus
step << Druid
    #label catspirit1
    .goto 1457/1,2564.600,10179.800
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMathrengyl Garroso::4217|r
    .target Mathrengyl Bearwalker::4217
    .accept 98393 >>Acepta la misión El gran espíritu felino
step << Druid
    #completewith next
	.cast 18960 >> Lanza Teletransporte a: Claro de la Luna
    .zoneskip Moonglade
step << Druid
    .goto 1450/1,-2678.900,8020.000
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDendrita Rafagaestelar::11802|r
    .target Dendrite Starblaze::11802
    .turnin 98393 >>Entrega la misión El gran espíritu felino
    .accept 98341 >>Acepta la misión El espíritu del gran felino natoviento << Skyborne
    .accept 98394 >>Acepta la misión El gran espíritu felino << !Skyborne
step << Druid !Skyborne
    .goto 1450/1,-2640.000,7338.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGran espíritu felino|r
    .turnin 98394 >>Entrega la misión El gran espíritu felino
    .accept 98396 >>Acepta la misión El gran espíritu felino
    .target Great Cat Spirit
step << Druid Skyborne
    .goto 1450/1,-2352.700,7375.600,10,0
    .goto 1450/1,-2394.300,7361.200
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cAvatar de Saeyleenan::272054|r
    .target Avatar of Saeyleenan::272054
    .turnin 98341 >>Entrega la misión El espíritu del gran felino natoviento
    .accept 98404 >>Acepta la misión El espíritu del gran felino natoviento
step << Druid
    #completewith next
    .goto 1450/1,-3046.700,7534.400
    --aura 1309054?
    .subzone 2363 >> Dirígete al Túmulo de Tempestira
step << Druid
    >>Ve al fondo de la cueva, cruza el puente, busca una estatua de gato dentro de un hueco y haz clic en el pequeño orbe junto a la estatua
    >>Despoja la |cff4fc3f7Reliquia de la garra|r
    .goto 1450/1,-3117.400,7455.300
    .complete 98404,2 << Skyborne --|1/1 Relic of the Claw
    .complete 98396,2 << !Skyborne --|1/1 Relic of the Claw
step << Druid
    >>Haz clic en el pequeño orbe junto a la estatua de gato
    >>Despoja la |cff4fc3f7Reliquia de la sombra silenciosa|r
    .goto 1450/1,-3099.200,7485.700
    .complete 98404,3  << Skyborne --|1/1 Relic of the Silent Shadow
    .complete 98396,3  << !Skyborne --|1/1 Relic of the Silent Shadow
step << Druid
    >>Haz clic en el pequeño orbe junto a la estatua de gato
    >>Despoja la |cff4fc3f7Reliquia del colmillo|r
    .goto 1450/1,-3054.100,7476.800
    .complete 98404,1  << Skyborne --|1/1 Relic of the Fang
    .complete 98396,1  << !Skyborne --|1/1 Relic of the Fang
step << Druid !Skyborne
    .goto 1450/1,-2640.000,7338.900
     >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cGran espíritu felino|r
    .turnin 98396 >>Entrega la misión El gran espíritu felino
    .accept 98731 >>Acepta la misión Bendiciones del gran espíritu felino
    .target Great Cat Spirit
step << Druid Skyborne
    .goto 1450/1,-2395.400,7361.400
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cAvatar de Saeyleenan::272054|r
    .target Avatar of Saeyleenan::272054
    .turnin 98404 >>Entrega la misión El espíritu del gran felino natoviento
    .accept 98738 >>Acepta la misión Bendiciones del gran espíritu felino natoviento
step << Druid
    .goto 1450/1,-2678.200,8021.500
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tTeletranspórtate a Claro de la Luna y habla con |cff5cf05cDendrita Rafagaestelar::11802|r
    .target Dendrite Starblaze::11802
    .usespell 18960
    .turnin 98738 >>Entrega la misión Bendiciones del gran espíritu felino natoviento << Skyborne
    .accept 98397 >>Acepta la misión A Darnassus<< Alliance
    --.accept 98362 >>Acepta la misión Viaje a Cima del Trueno << Horde
step << Druid
    #completewith catspirit2
    .goto 1450/1,-2400.33,7795.33--c:Moonglade,44.148,45.229
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSilva Fil'naveth|r
    .fly Teldrassil >> Vuela a Darnassus
    .skipgossip
    .timer 153,Darnassus
    .target Silva Fil'naveth
    .zoneskip Darnassus
    .zoneskip Teldrassil
step << Druid
    #completewith next
    .goto 1450/1,-2400.33,7795.33--c:Moonglade,44.148,45.229
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSilva Fil'naveth|r
    .fly Teldrassil >> Vuela a Darnassus
    .skipgossip
    .timer 153,Darnassus
    .target Silva Fil'naveth
    .zoneskip Darnassus
    .zoneskip Teldrassil
step << Druid
    #label catspirit2
    .goto 1457/1,2564.400,10179.900
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cMathrengyl Garroso::4217|r
    .target Mathrengyl Bearwalker::4217
    .turnin 98397 >>Entrega la misión A Darnassus
step << Druid
    .goto 1457/1,2626.51,9946.11
    .zone Teldrassil >> Viaja por el portal morado a la Aldea Rut'theran
    .zoneskip Darkshore
step << Druid
    .goto 1438/1,841.56,8640.79
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cVesprystus|r
    .fly Darkshore >> Vuela a Costa Oscura
    .target Vesprystus
    .zoneskip Darkshore
step
    .goto 1439/1,497.08,6427.72--c:1439,37.322,43.640
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBarithras Sombra Lunar|r
    .accept 947 >> Acepta la misión La cueva de las setas
    .target Barithras Moonshade
step
    #optional
    .isOnQuest 4763
    .goto 1439/1,467.08,6409.38
    >>|cffff9a3cUsa el|r |T133748:0|t[Cuenco de purificación vacío] |cffff9a3cen la Poza de la Luna de Auberdine|r
    .collect 12347,1,4763,1 --Filled Cleansing Bowl (1)
    .use 12346
step
    .goto 1439/1,489.41,6506.36--c:1439,37.439,41.839
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cArqueóloga Hollee|r
    .accept 729 >> Acepta la misión El prospector despistado
    .target Archaeologist Hollee
step
    .isQuestTurnedIn 4762
    .goto 1439/1,492.36,6581.08--c:1439,37.394,40.128
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThundris Tejevientos|r
    .accept 4763 >> Acepta la misión La corrupción de los Bosque Negro
    .target Thundris Windweaver
step
    .isOnQuest 3765
    .goto 1439/1,431.300,6454.000
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGershala Susurro Nocturno|r
    .turnin 3765 >> Entrega la misión Lejana corrupción
    .target Gershala Nightwhisper
step
.dungeon BFD
    .goto 1439/1,431.300,6454.000
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGershala Susurro Nocturno|r
    .accept 1275 >> Acepta la misión Investigaciones acerca de la corrupción
    .target Gershala Nightwhisper
step
    .isQuestTurnedIn 2138
    .goto 1439/1,397.45,6437.50--c:1439,38.843,43.416
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTharnariun Espinarbolado|r
    .accept 2139 >> Acepta la misión La esperanza de Tharnariun
    .target Tharnariun Treetender
step
    .goto 1439/1,384.35,6431.43--c:1439,39.043,43.555
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cCentinela Elissa Brisa Estelar|r arriba
    .accept 965 >> Acepta la misión La Torre de Althalaxx
    .target Sentinel Elissa Starbreeze
step
    .isOnQuest 4763
    .goto 1439/1,467.08,6409.38
    >>|cffff9a3cUsa el|r |T133748:0|t[Cuenco de purificación vacío] |cffff9a3cen la Poza de la Luna de Auberdine|r
    .collect 12347,1,4763,1 --Filled Cleansing Bowl (1)
    .use 12346
step
    #optional
    .goto 1439/1,48.66,6748.71--c:1439,44.168,36.289
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cAsterion|r
    .turnin 957 >> Entrega la misión Bashal'Aran
    .isOnQuest 957
    .target Asterion
step
    .isOnQuest 4763
    #sticky
    #label Blackwood1
    #completewith Xabraxxis
    .goto 1439/1,-489.22,6875.30,0
    .goto 1439/1,-376.56,6807.62
    >>Abre las |cffe07cf5Provisiones de grano de los Bosque Negro|r. Despójalas para obtener |T134059:0|t|cff4fc3f7[Muestra de grano Bosque Negro]|r
    >>|cffff9a3cDespojando esto invocará 2 |cffff5a4aFúrbolgs Bosque Negro|r que atacarán y correrán hacia ti. Prepárate para pelear contra ellos o reinícialos|r
    >>|cffff9a3cSi ves a |cffff5a4aXabraxxis|r gritar en el chat o ves a alguien peleando con él, ayúdalos. Abre la |cffe07cf5Bolsa demoníaca de Xabraxxis|r que deja en el suelo. Despójala para obtener el|r |cff4fc3f7Dije de corrupción|r
    .collect 12342,1,4763,1 -- Blackwood Grain Stores (1)
    .complete 4763,1 --Talisman of Corruption (1)
    .disablecheckbox
    .itemcount 12355,<1 --Talisman of Corruption (<1)
step
    .isOnQuest 2139
    .goto 1439/1,-503.63,6732.95,45,0
    .goto 1439/1,-430.27,6662.65
    >>Mata a la |cffff5a4aMadre del cubil|r
    >>|cffff9a3cTen cuidado, ya que los |cffff5a4aCachorros cardo|r pueden lanzar|r |T132152:0|t[Devastar]|cffff9a3c, un ataque cuerpo a cuerpo instantáneo que te aturde durante 2 segundos|r
    .complete 2139,1 --Den Mother (1)
    .mob Den Mother
step
    .isOnQuest 4763
    #sticky
    #requires Blackwood1
    #label Blackwood2
    #completewith Xabraxxis
    .goto 1439/1,-489.22,6875.30,0
    .goto 1439/1,-453.20,6870.500
    >>Abre las |cffe07cf5Provisiones de nueces de los Bosque Negro|r. Despójalo para obtener la |T133944:0|t|cff4fc3f7[Muestra de nuez Bosque Negro]|r
    >>|cffff9a3cDespojando esto invocará 2 |cffff5a4aFúrbolgs Bosque Negro|r que atacarán y correrán hacia ti. Prepárate para pelear contra ellos o reinícialos|r
    >>|cffff9a3cSi ves a |cffff5a4aXabraxxis|r gritar en el chat o ves a alguien peleando con él, ayúdalos. Abre la |cffe07cf5Bolsa demoníaca de Xabraxxis|r que deja en el suelo. Despójala para obtener el|r |cff4fc3f7Dije de corrupción|r
    .collect 12343,1,4763,1 -- Blackwood Nut Sample (1)
    .complete 4763,1 --Talisman of Corruption (1)
    .disablecheckbox
    .itemcount 12355,<1 --Talisman of Corruption (<1)
step
    .isOnQuest 4763
    #sticky
    #requires Blackwood2
    #label Blackwood3
    #completewith Xabraxxis
    .goto 1439/1,-489.22,6875.30,0
    .goto 1439/1,-520.66,6874.43
    >>Abre las |cffe07cf5Provisiones de fruta de los Bosque Negro|r. Despójalas para obtener la |T134013:0|t|cff4fc3f7[Muestra de fruta Bosque Negro]|r
    >>|cffff9a3cDespojando esto invocará 2 |cffff5a4aFúrbolgs Bosque Negro|r que atacarán y correrán hacia ti. Prepárate para pelear contra ellos o reinícialos|r
    >>|cffff9a3cSi ves a |cffff5a4aXabraxxis|r gritar en el chat o ves a alguien peleando con él, ayúdalos. Abre la |cffe07cf5Bolsa demoníaca de Xabraxxis|r que deja en el suelo. Despójala para obtener el|r |cff4fc3f7Dije de corrupción|r
    .collect 12341,1,4763,1 -- Blackwood Fruit Sample (1)
    .complete 4763,1 --Talisman of Corruption (1)
    .disablecheckbox
    .itemcount 12355,<1 --Talisman of Corruption (<1)
step
    .isOnQuest 4763
    #optional
    #requires Blackwood3
    #completewith Xabraxxis
    .goto 1439/1,-489.22,6875.30
    .cast 16072 >> |cffff9a3cUsa el|r |T134712:0|t[Cuenco de purificación lleno] |cffff9a3cen la |cffe07cf5Fogata|r para invocar a|r |cffff5a4aXabraxxis|r
    .timer 17,The Blackwood Corrupted RP
    .use 12347
step
    .isOnQuest 4763
    #requires Blackwood3
    #label Xabraxxis
    .goto 1439/1,-489.22,6875.30
    >>Mata a |cffff5a4aXabraxxis|r. Abre la |cffe07cf5Bolsa demoníaca de Xabraxxis|r que cae en el suelo. Despójala para obtener el |cff4fc3f7Dije de corrupción|r
    .use 12347
    .complete 4763,1 -- Talisman of Corruption (1)
    .mob Xabraxxis
step
    .goto 1439/1,-690.31,6751.29,12,0
    .goto 1439/1,-706.68,6748.23,12,0
    .goto 1439/1,-719.13,6787.530,12,0
    >>Despoja los |cff4fc3f7Boletos rudos|r y una |cff4fc3f7Oronja verde|r del suelo
    >>|cffff9a3cQuédate en la sección superior. Si no hay una |cff4fc3f7Oronja verde|r al final del lado superior, baja y consigue uno de la sala del sur abajo|r
    >>|cffff9a3cTen cuidado ya que los |cffff5a4aJinetes de olas Escama Tormentosa|r lanzan|r |T135836:0|t[Aspersión] |cffff9a3c(Ataque a distancia instantáneo: Causa daño a los enemigos cercanos y los lanza hacia atrás) - asegúrate de no estar en una posición donde te puedan tirar del nivel superior de la cueva|r
    .complete 947,1 --Scaber Stalk (5)
    .goto 1439/1,-663.45,6877.49,8,0
    .goto 1439/1,-679.17,6848.67,8,0
    .goto 1439/1,-666.73,6819.41,8,0
    .goto 1439/1,-680.48,6779.67,8,0
    .goto 1439/1,-663.45,6877.49,8,0
    .goto 1439/1,-679.17,6848.67,8,0
    .goto 1439/1,-666.73,6819.41,8,0
    .goto 1439/1,-680.48,6779.67,8,0
    .goto 1439/1,-663.45,6877.49
    .complete 947,2 --Death Cap (1)
    .goto 1439/1,-685.72,6746.49
step
    .goto 1439/1,-659.06,7246.69--c:1439,54.973,24.885
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBalthule Golpesombra|r
    .turnin 965 >> Entrega la misión La Torre de Althalaxx
    .accept 966 >> Acepta la misión La Torre de Althalaxx
    .target Balthule Shadowstrike
step
    #loop
    .goto 1439/1,-675.96,7175.82,0--c:1439,55.231,26.508
    .goto 1439/1,-739.04,7151.23,0--c:1439,56.194,27.071
    .goto 1439/1,-729.41,7172.41,0--c:1439,56.047,26.586
    .goto 1439/1,-675.96,7175.82,50,0--c:1439,55.231,26.508
    .goto 1439/1,-685.00,7153.24,50,0--c:1439,55.369,27.025
    .goto 1439/1,-710.81,7167.65,50,0--c:1439,55.763,26.695
    .goto 1439/1,-714.22,7155.56,50,0--c:1439,55.815,26.972
    .goto 1439/1,-739.04,7151.23,50,0--c:1439,56.194,27.071
    .goto 1439/1,-778.08,7127.22,50,0--c:1439,56.790,27.621
    .goto 1439/1,-810.04,7184.42,50,0--c:1439,57.278,26.311
    .goto 1439/1,-794.85,7187.78,50,0--c:1439,57.046,26.234
    .goto 1439/1,-761.97,7171.89,50,0--c:1439,56.544,26.598
    .goto 1439/1,-729.41,7172.41,50,0--c:1439,56.047,26.586
    .goto 1439/1,-709.50,7201.71,50,0--c:1439,55.743,25.915
    >>Mata |cffff5a4aFanáticas de la Facción Oscura|r. Despójalas para obtener sus |cff4fc3f7Papiros desgastados|r
    .complete 966,1 --Worn Parchment (4)
    .mob Dark Strand Fanatic
step
    .goto 1439/1,-659.06,7246.69--c:1439,54.973,24.885
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBalthule Golpesombra|r
    .turnin 966 >> Entrega la misión La Torre de Althalaxx
    .accept 967 >> Acepta la misión La Torre de Althalaxx
    .target Balthule Shadowstrike
step
    .goto 1439/1,-769.17,7744.53--c:1439,56.654,13.484
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGelkak Gyromast|r
    .accept 2098 >> Acepta la misión La búsqueda de Gyromast
    .target Gelkak Gyromast
step
    #optional
    #completewith next
    .goto 1439/1,-732.88,7596.24,0
    >>Mata a los |cffff5a4aReptadores de arrecife enfurecidos|r y a los |cffff5a4aReptadores de marea escamados|r. Despójalos para obtener la |cff4fc3f7Parte inferior de la llave de Gelkak|r
    >>|cffff9a3cTen cuidado con la habilidad|cffff5a4a |T132152:0|t[Vapulear] |rde los|r Reptadores de arrecife enfurecidos|cffff9a3c. Sus golpes cuerpo a cuerpo pueden infligirte 200 p. de daño al instante|r
    .complete 2098,3 -- Bottom of Gelkak's Key (1)
    .mob Raging Reef Crawler
    .mob Encrusted Tide Crawler
step
    .goto 1439/1,-656.25,7801.04
    >>Mata |cffff5a4aOráculos Brumagris|r y |cffff5a4aCazamareas Brumagris|r. Despójalos para obtener la |cff4fc3f7Mitad de la llave de Gelkak|r
    >>|cffff9a3cTen cuidado con el daño de|cffff5a4a |T136048:0|t[Descarga de relámpagos] |rde los|r Oráculos Brumagris|cffff9a3c; también pueden curarse con|r |T136052:0|t[Ola de sanación]|r
    >>Ten cuidado con |cffff5a4aCazamareas Brumagris|r pueden lanzar |T136016:0|t[|cff5cf05cVeneno|r] mientras luchan cuerpo a cuerpo dejando un daño en el tiempo que inflige 13 p. de daño cada 3 s durante 30 s
    >>|cffff9a3cPuedes cortar la línea de visión (LoS) de las|cffff5a4a  |T136048:0|t[Descargas de relámpagos] |rde los|r Oráculos Niebla Gris|cffff9a3c usando el barco hundido para evitar recibir su daño|r
    .complete 2098,2 -- Middle of Gelkak's Key (1)
    .mob Greymist Tidehunter
    .mob Greymist Oracle
step
    .goto 1439/1,-699.48,7591.87,45,0
    .goto 1439/1,-579.61,7505.41,45,0
    .goto 1439/1,-421.10,7372.67,45,0
    .goto 1439/1,-767.60,7805.84
    >>Mata a los |cffff5a4aReptadores de arrecife enfurecidos|r y a los |cffff5a4aReptadores de marea escamados|r. Despójalos para obtener la |cff4fc3f7Parte inferior de la llave de Gelkak|r
    >>|cffff9a3cTen cuidado con la habilidad|cffff5a4a |T132152:0|t[Vapulear] |rde los|r Reptadores de arrecife enfurecidos|cffff9a3c. Sus golpes cuerpo a cuerpo pueden infligirte 200 p. de daño al instante|r
    .complete 2098,3 -- Bottom of Gelkak's Key (1)
    .mob Raging Reef Crawler
    .mob Encrusted Tide Crawler
step
    #sticky
    #label foreststriders
    .goto 1439/1,-941.83,7756.06,55,0
    .goto 1439/1,-1080.03,7922.87,50,0
    .goto 1439/1,-1087.24,7780.51,50,0
    .goto 1439/1,-1069.55,7661.74,50,0
    .goto 1439/1,-1080.03,7922.870
    >>Mata |cffff5a4aZancudos del bosque gigantes|r. Despójalos para obtener la |cff4fc3f7Parte superior de la llave de Gelkak|r
    .complete 2098,1 -- Top of Gelkak's Key (1)
    .mob Giant Foreststrider
step << Warrior/Paladin/Rogue/Shaman
    #requires foreststriders
    .goto 1439/1,-769.17,7744.53--c:1439,56.654,13.484
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGelkak Gyromast|r
    >>|cffff9a3cEmpieza a buscar grupo para La venganza de Gyromast/|r|cffff5a4aEl Trillomajareitor 4100|r << Warrior/Paladin/Rogue/Shaman
    .turnin 2098 >> Entrega la misión La búsqueda de Gyromast
    .accept 2078 >> Acepta la misión La venganza de Gyromast
    .target Gelkak Gyromast
    .solo
step
    #requires foreststriders
    .group 2 << Warrior/Paladin/Rogue/Shaman
    .goto 1439/1,-769.17,7744.53--c:1439,56.654,13.484
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGelkak Gyromast|r
    >>|cffff9a3cEmpieza a buscar grupo para La venganza de Gyromast/|r|cffff5a4aEl Trillomajareitor 4100|r << Warrior/Paladin/Rogue/Shaman
    .turnin 2098 >> Entrega la misión La búsqueda de Gyromast
    .accept 2078 >> Acepta la misión La venganza de Gyromast
    .target Gelkak Gyromast
step
    #optional
    #completewith next
    .goto 1439/1,-713.36,7534.67--c:1439,55.802,18.290
    .gossipoption 95406 >> Habla con |cff5cf05cEl Trillomajareitor 4100|r para empezar la escolta
--  .gossipoption 87696 >> Talk to |cff5cf05cEl Trillomajareitor 4100|r to start the escort
    >>|cffff9a3cEsta misión es MUY difícil|r
    .target The Threshwackonator 4100
    .isOnQuest 2078 << Warrior/Paladin/Rogue/Shaman
step
    .goto 1439/1,-769.17,7744.53--c:1439,56.654,13.484
    #optional
    >>Escolta al |cff5cf05cEl Trillomajareitor 4100|r hasta |cff5cf05cGelkak Gyromast|r
    >>Mata a |cffff5a4aEl Trillomajareitor 4100|r cuando se vuelva hostil
    >>|cffff9a3cEsta misión es MUY difícil|r
    *Solo usa ataques a distancia mientras huyes de él, evita estar en rango de cuerpo a cuerpo << Druid
    >>|cffff9a3cIntenta hacer esta misión si puedes ya que te ahorrarás tiempo después porque ofrece|r |T134797:0|t[Elixires de Respiración acuática] |cffff9a3cpara misiones submarinas después|r << !Druid !Warlock !Shaman
    >>|cffff9a3cUsa|r |T136100:0|t[Raíces enredadoras] |cffff9a3cen él cuando se vuelva hostil, luego crea distancia y "kitea" usando hechizos de lanzamiento instantáneo|r << Druid
    >>|cffff9a3cSi no puedes matar a |cffff5a4aEl Trillomajareitor 4100|r, omite este paso|r
    .complete 2078,1 --Gyromast's Revenge (1)
    .link https://youtu.be/1WRRmKYBr9s >> |cffff9a3cHaz clic aquí para una guía en video|r
    .mob The Threshwackonator 4100
    .isOnQuest 2078 << Warrior/Paladin/Rogue/Shaman
--XX DRUID: Test if you can root
step
    #optional << Warrior/Paladin/Rogue/Shaman
    .goto 1439/1,-769.17,7744.53--c:1439,56.654,13.484
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGelkak Gyromast|r
    .turnin 2078 >> Entrega la misión La venganza de Gyromast
    .target Gelkak Gyromast
    .isQuestComplete 2078
step
    .isQuestTurnedIn 4681
    .goto 1439/1,-537.23,7543.01--c:1439,53.113,18.099
    >>Haz clic en la |cffe07cf5Tortuga marina varada|r
    .accept 4727 >> Acepta la misión Tortuga marina varada
step << Druid
    .goto 1439/1,-259.32,7839.03
    >>|cffff9a3cNada hacia mar adentro|r
    >>Abre el |cffe07cf5Arcón extraño|r. Despójalo para obtener el |cff4fc3f7Medio colgante de Agilidad acuática|r
    .collect 15883,1,272,1 --Collect Half Pendant of Aquatic Agility (x1)
step << Druid
    #completewith next
	.cast 18960 >> Lanza Teletransporte a: Claro de la Luna
step << Druid
    .goto 1450/1,-2593.82,7867.06
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLoganaar|r
    .trainer >> Aprende tus hechizos de clase
    .target Loganaar
step << Druid
    .goto 1450/1,-2212.25,7854.28
    .use 15883 >>|cffff9a3cUsa el|r |T133443:0|t[Medio colgante de Agilidad acuática] |cffff9a3cpara combinarlo con el|r |T133442:0|t[Medio colgante de Resistencia acuática] |cffff9a3cen el Santuario de Remulos|r
    .complete 272,1 --Collect Pendant of the Sea Lion (x1)
step << Druid
    #completewith next
	.cast 18960 >> Lanza Teletransporte a: Claro de la Luna
    >>|cffff9a3cEsto te ahorrará tiempo al no tener que volver corriendo|r
step << Druid
    .goto 1450/1,-2678.74,8020.00
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDendrita Rafagaestelar|r
    .turnin 272 >> Entrega la misión La prueba del león marino
    .accept 5061 >> Acepta la misión Forma acuática
    .target Dendrite Starblaze
step << Druid
    .isOnQuest 5061
    .goto 1450/1,-2489.25,7457.07
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cSindrayl|r
    .target Sindrayl
    .fly Darkshore >> Vuela a Costa Oscura
    .zoneskip Darkshore
step
    #sticky
    #optional
    .destroy 7442 >> Borra la |T134459:0|t[Llave de Gyromast] de tu inventario, ya que ya no la necesitas
step
    #completewith ReturnAuberdine
    .subzone 442 >> Regresa a Auberdine
step
    .isQuestComplete 2139
    .goto 1439/1,397.45,6437.50--c:1439,38.843,43.416
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTharnariun Espinarbolado|r
    .turnin 2139 >> Entrega la misión La esperanza de Tharnariun
    .target Tharnariun Treetender
step
    .isQuestComplete 4763
    .goto 1439/1,492.36,6581.08--c:1439,37.394,40.128
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cThundris Tejevientos|r
    .turnin 4763 >> Entrega la misión La corrupción de los Bosque Negro
    .target Thundris Windweaver
step
    .goto 1439/1,497.08,6427.72--c:1439,37.322,43.640
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cBarithras Sombra Lunar|r
    .turnin 947 >> Entrega la misión La cueva de las setas
    .accept 948 >> Acepta la misión Onus
    .target Barithras Moonshade
step
    .goto 1439/1,504.41,6402.39
    >>Haz clic en el |cffe07cf5Cartel de Se busca|r
    .accept 4740 >> Acepta la misión SE BUSCA: ¡Viscoso!
step
    #label ReturnAuberdine
    .isOnQuest 4727
    .goto 1439/1,537.75,6363.01,8,0--c:1439,36.701,45.122
    .goto 1439/1,542.99,6342.31--c:1439,36.621,45.596
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cGwennyth Bly'Leggonde|r
    .turnin 4727 >> Entrega la misión Tortuga marina varada
    .target Gwennyth Bly'Leggonde
step
    .goto 1439/1,585.76,5241.43--c:1439,35.968,70.807
    >>Haz clic en la |cffe07cf5Criatura marina varada|r
    .accept 4728 >> Acepta la misión Criatura marina varada
    .isQuestTurnedIn 4681
step
    .goto 1439/1,621.07,4989.95,0--c:1439,35.429,76.566
    .goto 1439/1,621.07,4989.95,60,0--c:1439,35.429,76.566
    .goto 1439/1,541.75,4991.52
    >>|cffff9a3cAsegúrate de verificar si |cffff5a4aViscoso|r ya está en el agua (si alguien ha fallado previamente el encuentro o dejó al |cffff5a4aCazador Brumagris|r en la oleada con la que aparece vivo)|r
    >>Mata a los |cffff5a4aGuerreros Brumagris|r y a los |cffff5a4aCazadores Brumagris|r en el campamento
    >>|cffff9a3cMuévete a la Fogata en el centro del campamento para iniciar el encuentro con |cffff5a4aViscoso|r:|r
    >>|cffff9a3c3 oleadas aparecerán del agua, cada una después de matar la oleada anterior: Oleada 1 tiene 3 nivel 12-13 |cffff5a4aCorrecostas Brumagris|r, Oleada 2 tiene 2 nivel 15-16 |cffff5a4aGuerreros Brumagris|r, y Oleada 3 tiene un nivel 19 |cffff5a4aViscoso|r y un nivel 16-17 |cffff5a4aCazador Brumagris|r. Puedes moverte lejos de la Fogata para evitar atraer la siguiente oleada|r
    .complete 4740,1 -- Murkdeep (1)
    .unitscan Murkdeep
    .mob Greymist Warrior
    .mob Greymist Hunter
    .mob Greymist Coastrunner
step
    #label Onu
    .goto 1439/1,88.81,5001.87--c:1439,43.555,76.293
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOnus|r
    .turnin 948 >> Entrega la misión Onus
    .accept 944 >> Acepta la misión La Espada del Maestro
    .target Onu
step
    #label MasterG
    .goto 1439/1,417.30,4575.82,100 >> Viaja a La Espada del Maestro
    .subzoneskip 449
    .isOnQuest 944
step
    #optional
    #completewith FunandGames
    >>Mata a los |cffff5a4aDiscípulos Crepuscular|r y a los |cffff5a4aMatones Crepuscular|r. Despójalos para obtener el |T133743:0|t[|cff4fc3f7Libro: Los Poderes inferiores|r]
    *|cffff9a3cTen cuidado ya que los |cffff5a4aMatones Crepuscular|r te pueden|r |T132343:0|t[Desarmar] |cffff9a3cdurante 6 segundos|r << Rogue/Paladin/Warrior/Shaman
    *Ten cuidado ya que los |cffff9a3cDiscípulos Crepuscular|cffff5a4a lanzan|r |T135953:0|t[Renovar] |ry un|cffff9a3c |T135915:0|t[Sanar] de 3 segundos|r
    .collect 5352,1,968,1 --Book: The Powers Below (1)
    .mob Twilight Disciple
    .mob Twilight Thug
step
    #optional
    .goto 1439/1,390.700,4542.700
    >>Descubre La Espada del Maestro
    .complete 944,1 --Enter the Master's Glaive (1)
step
    #optional
    #completewith next
    .cast 5809 >> |cffff9a3cUsa la|r |T134715:0|t[Ampolla de adivinación] |cffff9a3cy colócala en el suelo|r
    .use 5251
step
    .goto 1439/1,417.30,4575.82
    >>|cffff9a3cHaz clic en el |cffe07cf5Cuenco de visión|r del suelo|r
    .turnin 944 >> Entrega la misión La Espada del Maestro
    .accept 949 >> Acepta la misión El campamento del Martillo Crepuscular
    .use 5251
step
    #label FunandGames
    .goto 1439/1,417.49,4575.82--c:1439,38.537,86.050
    >>Haz clic en el |cffe07cf5Libro del Crepúsculo|r en el pedestal del norte
    .turnin 949 >> Entrega la misión El campamento del Martillo Crepuscular
    .accept 950 >> Acepta la misión Regresa junto a Onus
    .accept 98042 >>Acepta la misión Es todo diversión hasta que...
step
    #completewith TheryluneEnd
    >>Mata a los |cffff5a4aDiscípulos Crepuscular|r y a los |cffff5a4aMatones Crepuscular|r. Despójalos para obtener el |cff4fc3f7Ojo incomparable|r y el |T133743:0|t[|cff4fc3f7Libro: Los Poderes inferiores|r]
    *|cffff9a3cTen cuidado ya que los |cffff5a4aMatones Crepuscular|r te pueden|r |T132343:0|t[Desarmar] |cffff9a3cdurante 6 segundos|r << Rogue/Paladin/Warrior/Shaman
    *Ten cuidado ya que los |cffff9a3cDiscípulos Crepuscular|cffff5a4a lanzan|r |T135953:0|t[Renovar] |ry un|cffff9a3c |T135915:0|t[Sanar] de 3 segundos|r
    .complete 98042,1 -- Peerless Eye (1)
    .mob +Twilight Disciple
    .mob +Twilight Thug
    .collect 5352,1,968,1 --Book: The Powers Below (1)
    .disablecheckbox
step
    .goto 1439/1,409.44,4521.01--c:1439,38.660,87.305
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cTherylune|r. Esto iniciará una escolta
    >>|cffff9a3cOmite este paso si ella no está allí|r
    .accept 945 >> Acepta la misión La fuga de Therylune
    .target Therylune
step
    #label TheryluneEnd
    .goto 1439/1,288.26,4530.40
    >>|cffff9a3cAcompaña a |cff5cf05cTherylune|r fuera de La Espada del Maestro|r
    .complete 945,1 --Escort Therylune away from the Master's Glaive (1)
    .isOnQuest 945
step
    #loop
    .goto 1439/1,376.800,4608.600,40,0
    .goto 1439/1,453.100,4580.200,40,0
    .goto 1439/1,409.4366,4521.0151,40,0
    >>Mata a los |cffff5a4aDiscípulos Crepuscular|r y a los |cffff5a4aMatones Crepuscular|r. Despójalos para obtener el |cff4fc3f7Ojo incomparable|r y el |T133743:0|t[|cff4fc3f7Libro: Los Poderes inferiores|r]
    *|cffff9a3cTen cuidado ya que los |cffff5a4aMatones Crepuscular|r te pueden|r |T132343:0|t[Desarmar] |cffff9a3cdurante 6 segundos|r << Rogue/Paladin/Warrior/Shaman
    *Ten cuidado ya que los |cffff9a3cDiscípulos Crepuscular|cffff5a4a lanzan|r |T135953:0|t[Renovar] |ry un|cffff9a3c |T135915:0|t[Sanar] de 3 segundos|r
    .complete 98042,1 -- Peerless Eye (1)
    .mob +Twilight Disciple
    .mob +Twilight Thug
    .collect 5352,1,968,1 --Book: The Powers Below (1)
    .disablecheckbox
step
    #optional
    #sticky
    .isQuestTurnedIn 949
    .destroy 5251 >> Elimina la |T134715:0|t[Ampolla de adivinación] de tu inventario, ya que ya no se necesita
step
    #sticky
    #label prospector
    .goto 1439/1,601.74,4678.61--c:1439,35.724,83.696
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cProspector Tripirrem|r
    >>|cffff9a3cPuede que tengas que esperar a que reaparezca o a que otros terminen la escolta|r
    .turnin 729 >> Entrega la misión El prospector despistado
    .target Prospector Remtravel
step
    .goto 1439/1,602.01,4678.87
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con el |cff5cf05cProspector Tripirrem|r. Esto iniciará una escolta
    .accept 731,1 >> Acepta la misión El prospector despistado
    .target Prospector Remtravel
step
    #requires prospector
    >>|cffff9a3cAcompaña al |cff5cf05cProspector Tripirrem|r por la Excavación|r
    .complete 731,1
    .isOnQuest 731
step
    .isQuestTurnedIn 4681
    .goto 1439/1,803.48,4808.95--c:1439,32.644,80.711
    >>Haz clic en la |cffe07cf5Criatura marina varada|r
    .accept 4730 >> Acepta la misión Criatura marina varada
step
    .isQuestTurnedIn 4681
    .goto 1439/1,865.97,4678.43--c:1439,31.690,83.700
    >>|cffff9a3cTen cuidado con el daño de|cffff5a4a |T136048:0|t[Descarga de relámpagos] |rde los|r Oráculos Brumagris|cffff9a3c; también pueden curarse con|r |T136052:0|t[Ola de sanación]|r
    >>Haz clic en la |cffe07cf5Tortuga marina varada|r
    .accept 4731 >> Acepta la misión Tortuga marina varada
step
    .isQuestTurnedIn 4681
    .goto 1439/1,896.17,4597.04--c:1439,31.229,85.564
    >>|cffff9a3cTen cuidado con el daño de|cffff5a4a |T136048:0|t[Descarga de relámpagos] |rde los|r Oráculos Brumagris|cffff9a3c; también pueden curarse con|r |T136052:0|t[Ola de sanación]|r
    >>Haz clic en la |cffe07cf5Tortuga marina varada|r
    .accept 4732 >> Acepta la misión Tortuga marina varada
step
    .isQuestTurnedIn 4681
    .goto 1439/1,894.73,4516.04--c:1439,31.251,87.419
    >>Haz clic en la |cffe07cf5Criatura marina varada|r
    .accept 4733 >> Acepta la misión Criatura marina varada
    >>|cffff9a3cTen cuidado con el daño de|cffff5a4a |T136048:0|t[Descarga de relámpagos] |rde los|r Oráculos Brumagris|cffff9a3c; también pueden curarse con|r |T136052:0|t[Ola de sanación]|r
step
    .goto 1439/1,88.81,5001.87--c:1439,43.555,76.293
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOnus|r
    .turnin 950 >> Entrega la misión Regresa junto a Onus
    .timer 11,Return to Onu RP
    .target Onu
step
    #optional
    >>|cffff9a3cUsa el |T133743:0|t[|cff4fc3f7Libro: Los Poderes inferiores|r] para comenzar la misión|r
    .accept 968 >> Acepta la misión Los Poderes Subyacentes
    .use 5352
    .itemcount 5352,1
step
    #optional
    .goto 1439/1,33.40,4996.11--c:1439,44.401,76.425
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKerlonian Semprumbrío|r para empezar la escolta
    >>|cffff9a3cOmite este paso si no está allí. Puede tomar hasta 25 minutos para que reaparezca|r
    >>|cffff9a3cEsta misión tiene tiempo límite, tienes que escoltarlo hasta su bolsa en menos de 20 minutos|r
    .accept 5321 >> Acepta la misión El despertar
    .target Kerlonian Evershade
    .isQuestTurnedIn 731 --Only shows if Prospector was already escorted
step
    #optional
    .isOnQuest 5321
    .goto 1439/1,34.78,5001.570
    >>Abre el |cffe07cf5Cofre de Kerlonian|r. Despójalo para obtener el |T134229:0|t[|cff4fc3f7Cuerno de Despertar|r]
    .complete 5321,1 -- Horn of Awakening (1)
    .isQuestTurnedIn 731 --Only shows if Prospector was already escorted
step
    .goto 1439/1,33.40,4996.11--c:1439,44.401,76.425
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cKerlonian Semprumbrío|r para empezar la escolta
    >>|cffff9a3cOmite este paso si no está allí. Puede tomar hasta 25 minutos para que reaparezca|r
    >>|cffff9a3cEsta misión tiene tiempo límite, tienes que escoltarlo hasta su bolsa en menos de 20 minutos|r
    .accept 5321 >> Acepta la misión El despertar
    .target Kerlonian Evershade
    .itemcount 13536,<1 --Horn of Awakening
step
    .isOnQuest 5321
    .goto 1439/1,34.78,5001.570
    >>Abre el |cffe07cf5Cofre de Kerlonian|r. Despójalo para obtener el |T134229:0|t[|cff4fc3f7Cuerno de Despertar|r]
    .complete 5321,1 -- Horn of Awakening (1)
    .itemcount 13536,<1 --Horn of Awakening
step
    #label Kerlonian
    .goto 1439/1,206.400,4402.500
    >>|cffff9a3cEscolta a |cff5cf05cKerlonian|r a su bolsa |cffff9a3cen Costa Oscura|r|r
    .use 13536 >> |cffff9a3cUsa el|r |T134229:0|t[|cff4fc3f7Cuerno de Despertar|r] |cffff9a3ccada vez que |cff5cf05cKerlonian|r se quede dormido a su lado|r
    >>|cffff9a3cEvita correr por la carretera principal lo más posible. Los enemigos aparecerán sólo si estás en el camino|r
    .complete 5321,2
    .isOnQuest 5321
step
    #optional
    .abandon 2138 >> Abandona la misión La limpieza de la infección
    .abandon 1002 >> Abandona la misión La caja mecánica 323
step
    #completewith tower
    .zone Ashenvale >> Viaja al sur a Vallefresno
    .goto 1440/1,-12.70,4150.17
step
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cLiladris Rioluna|r
	.target Liladris Moonriver
    .goto 1440/1,128.01,3305.31
    .turnin 5321 >> Entrega la misión El despertar
    .isQuestComplete 5321
step
    #label tower
    .goto 1440/1,189.71,3185.77
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDelgren el Purificador|r
    .turnin 967 >> Entrega la misión La Torre de Althalaxx
    .accept 970 >> Acepta la misión La Torre de Althalaxx
    .target Delgren the Purifier
step
    #optional
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOrendil Hojagrande|r
	.target Orendil Broadleaf
    .goto 1440/1,175.87,3189.61
    .accept 1010 >> Acepta la misión Cabello de Bathran
    .xp <20,1
step
    .goto 1440/1,-102.08,3492.890
    >>Mata a los |cffff5a4aCultores de la Facción Oscura|r y a los |cffff5a4aAdeptos de la Facción Oscura|r. Despójalos para obtener la |cff4fc3f7Gema de alma resplandeciente|r
    .complete 970,1
    .mob Dark Strand Cultist
    .mob Dark Strand Adept
step
    .goto 1440/1,-102.08,3492.890
    .xp 20-1650 >>Sigue matando a los |cffff5a4amiembros de la Facción Oscura|r hasta que tengas suficiente experiencia para alcanzar el nivel 20
    .mob Dark Strand Cultist
    .mob Dark Strand Adept
    .mob Dark Strand Enforcer
    .mob Dark Strand Excavator
step
    #optional
    .goto 1440/1,-203.58,3849.97,50,0
    .goto 1440/1,-2.90,3737.73,40,0
    .goto 1440/1,-138.99,3806.92
    >>Abre los |cffe07cf5Fardo de plantas|r en el suelo. Despójalos para obtener |cff4fc3f7Cabellos de Bathran|r
    >>|cffff9a3cSe ven como pequeños sacos marrones y pueden estar parcialmente enterrados en el suelo. Pueden ser difíciles de ver|r
    >>|cffff9a3cAsegúrate de tener|r |T134916:0|t[Buscar hierbas] |cffff9a3cactivado para verlas en el minimapa|r
    .complete 1010,1 --Bathran's Hair (5)
    .isOnQuest 1010
    .skill herbalism,<1,1
step
    #optional
    .goto 1440/1,-203.58,3849.97,50,0
    .goto 1440/1,-2.90,3737.73,40,0
    .goto 1440/1,-138.99,3806.92
    >>Abre los |cffe07cf5Fardo de plantas|r en el suelo. Despójalos para obtener |cff4fc3f7Cabellos de Bathran|r
    >>|cffff9a3cSe ven como pequeños sacos marrones y pueden estar parcialmente enterrados en el suelo. Pueden ser difíciles de ver|r
    .complete 1010,1 --Bathran's Hair (5)
    .isOnQuest 1010
    .skill herbalism,1,1
step
    #optional
    .goto 1440/1,175.87,3189.61
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOrendil Hojagrande|r
    .turnin 1010 >> Entrega la misión Cabello de Bathran
    .accept 1020 >> Acepta la misión Cura de Orendil
    .target Orendil Broadleaf
    .isQuestComplete 1010
step
    #optional
    .goto 1440/1,175.87,3189.61
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOrendil Hojagrande|r
    .accept 1020 >> Acepta la misión Cura de Orendil
    .target Orendil Broadleaf
    .isQuestTurnedIn 1010
step
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDelgren el Purificador|r
	.target Delgren the Purifier
    .goto 1440/1,189.71,3185.77
    .turnin 970 >> Entrega la misión La Torre de Althalaxx
    .accept 973 >> Acepta la misión La Torre de Althalaxx
step
    #optional
    .goto 1440/1,-138.99,3806.92
    .xp 20 >> Mata enemigos hasta subir al nivel 20
step
    .goto 1440/1,175.87,3189.61
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOrendil Hojagrande|r
    .accept 1010 >> Acepta la misión Cabello de Bathran
    .target Orendil Broadleaf
step
    #optional
    .goto 1440/1,-203.58,3849.97,50,0
    .goto 1440/1,-2.90,3737.73,40,0
    .goto 1440/1,-138.99,3806.92
    >>Abre los |cffe07cf5Fardo de plantas|r en el suelo. Despójalos para obtener |cff4fc3f7Cabellos de Bathran|r
    >>|cffff9a3cSe ven como pequeños sacos marrones y pueden estar parcialmente enterrados en el suelo. Pueden ser difíciles de ver|r
    >>|cffff9a3cAsegúrate de tener|r |T134916:0|t[Buscar hierbas] |cffff9a3cactivado para verlas en el minimapa|r
    .complete 1010,1 --Bathran's Hair (5)
    .skill herbalism,<1,1
step
    .goto 1440/1,-203.58,3849.97,50,0
    .goto 1440/1,-2.90,3737.73,40,0
    .goto 1440/1,-138.99,3806.92
    >>Abre los |cffe07cf5Fardo de plantas|r en el suelo. Despójalos para obtener |cff4fc3f7Cabellos de Bathran|r
    >>|cffff9a3cSe ven como pequeños sacos marrones y pueden estar parcialmente enterrados en el suelo. Pueden ser difíciles de ver|r
    .complete 1010,1 --Bathran's Hair (5)
    .skill herbalism,1,1
step
    .goto 1440/1,175.87,3189.61
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cOrendil Hojagrande|r
    .turnin 1010 >> Entrega la misión Cabello de Bathran
    .accept 1020 >> Acepta la misión Cura de Orendil
    .target Orendil Broadleaf
step
    #optional
    #completewith TZS
    .subzone 415 >> Viaja a Astranaar
step
    #label AshenvaleEnd
    .goto 1440/1,-283.73,2827.920
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cDaelyshia|r
    .fp Astranaar >> Consigue la Ruta de Vuelo de Astranaar
	.target Daelyshia
step
    #label TZS
    .goto 1440/1,-299.30,2796.01
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cShindrell Fuegoveloz|r
    .accept 1008 >> Acepta la misión La Ensenada de Zoram
    .target Shindrell Swiftfire
step
    .goto 1440/1,-311.99,2759.11
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cCentinela Thenysil|r
    .accept 1070 >> Acepta la misión Estar de guardia en Espolón
    .target Sentinel Thenysil
step
    .goto 1440/1,-362.16,2785.640
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cFaldreas Goeth'Shael|r
    .accept 1056 >> Acepta la misión Viaje a Cima del Espolón
    .target Faldreas Goeth'Shael
step
    .goto 1440/1,-411.18,2767.19
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cRaene Correlobo|r
    .accept 991 >> Acepta la misión La limpieza de Raene
    .accept 1054 >> Acepta la misión Matanza selectiva
    .target Raene Wolfrunner
step
    .goto 1440/1,-433.09,2781.02
    >>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con la |cff5cf05cTabernera Kimlya|r
    .home >> Establece tu Piedra de hogar en Astranaar
    .target Innkeeper Kimlya
step
    .goto 1440/1,-454.43,2682.24
	>>|Tinterface/worldmap/chatbubble_64grey.blp:20|tHabla con |cff5cf05cPelturas Lunablanca|r
	.target Pelturas Whitemoon
    .turnin 1020 >> Entrega la misión Cura de Orendil
    .timer 24,Orendil's Cure RP
    .accept 1033 >> Acepta la misión Lágrima de Elune
]=], "Alliance"}
