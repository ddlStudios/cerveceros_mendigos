-- GENERADO por _suite/herramientas/leveo_rutas.py: no editar a mano.
-- Ruta de subida de RestedXP (RXPGuides), traducida y adaptada a WoW Forever por Brudda FastXP.
-- Licencia de este archivo: CC BY-NC-SA 4.0 (ver LICENCIA_RUTAS.txt).
local _, ns = ...
local R = ns.LeveoRutas or {}
ns.LeveoRutas = R
R[#R + 1] = {[=[
#forever
<< Horde
#name 1-6 Durotar
#version 11
#group Forever Guía de Mazmorras (H)
#subgroup Mazmorras 1-22
#defaultfor Troll/Orc
#next 6-10 Durotar


step
.enabledungeon RFC
#include Guía Forever (H)\1-6 Durotar
]=], "Horde"}
R[#R + 1] = {[=[
#forever
<< Horde
#name 6-10 Durotar
#version 11
#group Forever Guía de Mazmorras (H)
#subgroup Mazmorras 1-22
#defaultfor Troll/Orc
#next 10-12 Durotar

step
.enabledungeon RFC
#include Guía Forever (H)\6-10 Durotar
]=], "Horde"}
R[#R + 1] = {[=[
#forever
<< Horde
#name 10-12 Durotar
#version 11
#group Forever Guía de Mazmorras (H)
#subgroup Mazmorras 1-22
#defaultfor Troll/Orc
#next 10-12 Tirisfal (Orco/Trol) << !Hunter !Shaman !Tauren !Skyborne
#next 12-16 Los Baldíos << Orc Hunter/Troll Hunter/Orc Shaman/Troll Shaman


step
.enabledungeon ROL
.enabledungeon RFC
#include Guía Forever (H)\10-12 Durotar
]=], "Horde"}
R[#R + 1] = {[=[
#forever
<< Horde
#name 10-12 Tirisfal (Orco/Trol)
#version 11
#group Forever Guía de Mazmorras (H)
#subgroup Mazmorras 1-22
#defaultfor !Hunter !Shaman !Tauren !Skyborne !Undead
#next 12-14 Bosque de Argénteos << !Hunter !Shaman !Tauren !Skyborne !Undead

step
.enabledungeon RFC
#include Guía Forever (H)\10-12 Tirisfal (Orco/Trol)
]=], "Horde"}
