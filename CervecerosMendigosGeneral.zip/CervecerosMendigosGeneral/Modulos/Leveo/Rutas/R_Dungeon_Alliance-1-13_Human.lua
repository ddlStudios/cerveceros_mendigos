-- GENERADO por _suite/herramientas/leveo_rutas.py: no editar a mano.
-- Ruta de subida de RestedXP (RXPGuides), traducida y adaptada a WoW Forever por Brudda FastXP.
-- Licencia de este archivo: CC BY-NC-SA 4.0 (ver LICENCIA_RUTAS.txt).
local _, ns = ...
local R = ns.LeveoRutas or {}
ns.LeveoRutas = R
R[#R + 1] = {[=[
#forever
<< Alliance
#name 1-6 Villanorte
#version 1
#group Forever Guía de Mazmorras (A)
#subgroup Mazmorras 1-20
#defaultfor Human
#next 6-11 Bosque de Elwynn


step
#include Guía Forever (A)\1-6 Villanorte
]=], "Alliance"}
R[#R + 1] = {[=[
#forever
#version 1
<< Alliance
#group Forever Guía de Mazmorras (A)
#subgroup Mazmorras 1-20
#name 6-11 Bosque de Elwynn
#next 11-13 Loch Modan
#defaultfor Human

step
#include Guía Forever (A)\6-11 Bosque de Elwynn
]=], "Alliance"}
R[#R + 1] = {[=[
#forever
#version 1
<< Alliance
#group Forever Guía de Mazmorras (A)
#subgroup Mazmorras 1-20
#name 11-13 Loch Modan
#next 13-15 Páramos de Poniente
#defaultfor Human

step
    #include Guía Forever (A)\11-13 Loch Modan@NormalRouteStart-NormalRouteEnd
]=], "Alliance"}
