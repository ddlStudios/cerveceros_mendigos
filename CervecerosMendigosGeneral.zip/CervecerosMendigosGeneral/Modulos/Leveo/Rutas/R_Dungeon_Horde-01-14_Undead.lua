-- GENERADO por _suite/herramientas/leveo_rutas.py: no editar a mano.
-- Ruta de subida de RestedXP (RXPGuides), traducida y adaptada a WoW Forever por Brudda FastXP.
-- Licencia de este archivo: CC BY-NC-SA 4.0 (ver LICENCIA_RUTAS.txt).
local _, ns = ...
local R = ns.LeveoRutas or {}
ns.LeveoRutas = R
R[#R + 1] = {[=[
#forever
<< Horde
#version 11
#group Forever Guía de Mazmorras (H)
#subgroup Mazmorras 1-22
#defaultfor Undead
#name 1-6 Claros de Tirisfal
#next 6-12 Claros de Tirisfal

step
.enabledungeon RFC
#include Guía Forever (H)\1-6 Claros de Tirisfal
]=], "Horde"}
R[#R + 1] = {[=[
#forever
<< Horde
#name 6-12 Claros de Tirisfal
#displayname 6-13 Claros de Tirisfal << Paladin
#version 11
#group Forever Guía de Mazmorras (H)
#subgroup Mazmorras 1-22
#defaultfor Undead
#next 12-14 Bosque de Argénteos; 12-17 Los Baldíos

step
.enabledungeon ROL
.enabledungeon RFC
#include Guía Forever (H)\6-12 Claros de Tirisfal
]=], "Horde"}
R[#R + 1] = {[=[
#group Forever Guía de Mazmorras (H)
#subgroup Mazmorras 1-22
<< Horde
#version 11
#defaultfor !Hunter !Shaman !Tauren
#forever
#era/som--h
#name 12-14 Bosque de Argénteos
#displayname 13-15 Bosque de Argénteos << Paladin
#next 12-16 Los Baldíos


step
.enabledungeon RFC
.enabledungeon ROL
#include Guía Forever (H)\12-14 Bosque de Argénteos
]=], "Horde"}
