-- CervecerosMendigos · Leveo: flecha que apunta al siguiente lugar de la ruta (codigo propio, GPL-3.0).
-- Como funciona: tu posicion y la del destino en metros del mundo (UnitPosition / GetWorldPosFromMapPos),
-- el angulo entre los dos menos hacia donde miras (GetPlayerFacing) = cuanto girar la flecha.
-- Ademas: marca del juego en el mapa y el minimapa (opcional), y te lleva a tu cuerpo si eres fantasma.
local ADDON, ns = ...
local LV = ns.LV or {}
ns.LV = LV
local A = {}
LV.Arrow = A
local T = LV.T

local function S() return LV.S end
local function F() return S().flecha or {} end

local f, tex, dist, label

local function ApplyLook()
    if not f then return end
    local o = F()
    f:SetScale((o.escala or 100) / 100)
    f:SetAlpha((o.opacidad or 100) / 100)
    dist:SetShown(o.distancia ~= false)
    label:SetShown(o.texto ~= false)
    f:EnableMouse(not o.bloqueada)
end
A.ApplyLook = ApplyLook

local function Build()
    if f then return f end
    f = LV.mod:Frame("Button", "CMLeveoFlecha", UIParent)
    f:SetSize(56, 56)
    f:SetFrameStrata("MEDIUM")
    f:SetMovable(true); f:SetClampedToScreen(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(self)
        if F().bloqueada or (InCombatLockdown and InCombatLockdown()) then return end
        self:StartMoving()
    end)
    f:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p, _, rp, x, y = self:GetPoint()
        F().pos = { p, rp, x, y }
    end)
    tex = f:CreateTexture(nil, "ARTWORK")
    tex:SetAllPoints()
    tex:SetTexture(LV.mod.path .. "flecha.tga")
    dist = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    dist:SetPoint("TOP", f, "BOTTOM", 0, -1)
    label = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    label:SetPoint("TOP", dist, "BOTTOM", 0, -1)
    label:SetWidth(240)
    f.tex, f.dist, f.label = tex, dist, label
    local p = F().pos
    f:ClearAllPoints()
    if p then f:SetPoint(p[1], UIParent, p[2], p[3], p[4]) else f:SetPoint("TOP", UIParent, "TOP", 0, -150) end
    f:SetScript("OnUpdate", function(self, el) A.OnUpdate(self, el) end)
    f:Hide()
    ApplyLook()
    return f
end
A.Build = Build

function A.ResetPos()
    F().pos = nil
    if f then f:ClearAllPoints(); f:SetPoint("TOP", UIParent, "TOP", 0, -150) end
end

----------------------------------------------------------------------
-- A donde apunta
----------------------------------------------------------------------
local function Ghost() return UnitIsGhost and UnitIsGhost("player") and true or false end

local function CorpseSpot()
    if not (C_DeathInfo and C_DeathInfo.GetCorpseMapPosition and C_Map and C_Map.GetBestMapForUnit) then return end
    local m, guard = C_Map.GetBestMapForUnit("player"), 0
    while m and m > 0 and guard < 8 do
        local ok, pos = pcall(C_DeathInfo.GetCorpseMapPosition, m)
        if ok and pos and pos.GetXY then
            local x, y = pos:GetXY()
            if x and y and not (x == 0 and y == 0) then return { map = m, x = x * 100, y = y * 100 } end
        end
        local info = C_Map.GetMapInfo and C_Map.GetMapInfo(m)
        m = info and info.parentMapID
        guard = guard + 1
    end
end
A.CorpseSpot = CorpseSpot

-- Lugar de un paso: el primer punto al que aun no llegaste; si estan todos, el ultimo
local function FromStep(st)
    local p = T.P()
    local wps = {}
    for _, el in ipairs(st.els) do
        if (el.verb == "wp" or el.verb == "go") and not el.noArrow and T.ElShown(el) then wps[#wps + 1] = el end
    end
    for _, el in ipairs(wps) do
        if el.verb == "go" and not p.visited[T.Key(el)] then return el end
        if el.verb == "wp" and el.radius and not p.visited[T.Key(el)] then return el end
    end
    if #wps > 0 then return wps[#wps] end
    -- sin coordenadas en la ruta: el dador de la mision que toca tomar (de nuestros datos)
    for _, el in ipairs(st.els) do
        if el.verb == "accept" and T.ElShown(el) and T.ElState(el) == false then
            local g = LV.QuestGiver(el.quest)
            if g then return g end
        end
    end
end

-- La mision que tienes elegida (la que sigues en el mapa o la primera que vigilas), si no hay ruta
local function QuestSpot()
    local q = C_SuperTrack and C_SuperTrack.GetSuperTrackedQuestID and C_SuperTrack.GetSuperTrackedQuestID()
    if not q or q == 0 then
        q = C_QuestLog and C_QuestLog.GetQuestIDForQuestWatchIndex and C_QuestLog.GetQuestIDForQuestWatchIndex(1)
    end
    if not q or q == 0 then return end
    local d = LV.QuestData(q)
    if d and LV.Q.Complete(q) then
        local g = LV.QuestGiver(q)
        if g then g.label = LV.Q.Title(q); return g end
    end
    if C_QuestLog and C_QuestLog.GetNextWaypoint then
        local ok, map, x, y = pcall(C_QuestLog.GetNextWaypoint, q)
        if ok and map and x then return { map = map, x = x * 100, y = y * 100, label = LV.Q.Title(q) } end
    end
end

function A.Pick()
    if Ghost() and F().cuerpo ~= false then
        local c = CorpseSpot()
        if c then c.label = "Tu cuerpo"; return c end
    end
    if A.custom then return A.custom end
    local st = T.Current()
    if st then
        local s = FromStep(st)
        if s then return s end
        for _, o in ipairs(T.Side()) do
            s = FromStep(o)
            if s then return s end
        end
        -- "Viaja a X" sin coordenadas: el lugar del paso que viene
        for _, o in ipairs(T.Upcoming(3)) do
            s = FromStep(o)
            if s then return s end
        end
        return
    end
    if F().sinRuta then return QuestSpot() end
end

-- Un punto propio (por ejemplo desde un comando); se quita al llegar
function A.SetCustom(spot) A.custom = spot; A.Refresh() end

----------------------------------------------------------------------
-- Marca del juego en el mapa y en el minimapa
----------------------------------------------------------------------
local lastPin
local function SetPin(spot)
    if not S().marcaMapa then return end
    if not (spot and C_Map and C_Map.SetUserWaypoint and UiMapPoint and UiMapPoint.CreateFromCoordinates) then return end
    local map, x, y = spot.map, spot.x and spot.x / 100, spot.y and spot.y / 100
    if spot.wx and C_Map.GetMapPosFromWorldPos and CreateVector2D then
        local ok, m2, pos = pcall(C_Map.GetMapPosFromWorldPos, spot.inst, CreateVector2D(spot.wx, spot.wy), spot.map)
        if ok and pos then map = m2 or spot.map; x, y = pos:GetXY() end
    end
    if not (map and x and y) then return end
    local key = map .. ":" .. math.floor(x * 1000) .. ":" .. math.floor(y * 1000)
    if key == lastPin then return end
    if C_Map.CanSetUserWaypointOnMap and not C_Map.CanSetUserWaypointOnMap(map) then return end
    local ok = pcall(C_Map.SetUserWaypoint, UiMapPoint.CreateFromCoordinates(map, x, y))
    if ok then
        lastPin = key
        if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then pcall(C_SuperTrack.SetSuperTrackedUserWaypoint, true) end
    end
end
function A.ClearPin()
    if lastPin and C_Map and C_Map.ClearUserWaypoint then pcall(C_Map.ClearUserWaypoint) end
    lastPin = nil
end

----------------------------------------------------------------------
-- Dibujar
----------------------------------------------------------------------
local function Tint(rel)
    if F().colorear == false then tex:SetVertexColor(1, 1, 1); return end
    local a = math.abs(rel) % (2 * math.pi)
    if a > math.pi then a = 2 * math.pi - a end
    local t = a / math.pi                       -- 0 = de frente, 1 = de espaldas
    local k = math.max(0, (t - 0.25) / 0.75)    -- hasta 45 grados no cambia
    tex:SetVertexColor(1, 1 - 0.6 * k, 1 - 0.65 * k)
end

local function ZoneName(map)
    local info = map and C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(map)
    if info then return info.name end
end

local function Where(spot)
    local z = ZoneName(spot.map)
    if z then return "Ve a " .. z end
    return "Mira el mapa"
end

function A.Refresh()
    if not (LV.mod and LV.mod:IsEnabled()) then return end
    if not F().activa then if f then f:Hide() end; A.ClearPin(); return end
    Build()
    local spot = A.Pick()
    A.target = spot
    if spot then
        label:SetText(spot.label or "")
        f:Show()
        SetPin(spot)
    else
        f:Hide()
        A.ClearPin()
    end
end

local acc = 0
function A.OnUpdate(self, el)
    acc = acc + el
    if acc < 0.05 then return end
    acc = 0
    local s = A.target
    if not s then self:Hide(); return end
    local d, angle = LV.Distance(s)
    if not d then
        tex:SetAlpha(0.35); tex:SetRotation(0); tex:SetVertexColor(1, 1, 1)
        dist:SetText(Where(s))
        return
    end
    tex:SetAlpha(1)
    local facing = GetPlayerFacing and GetPlayerFacing()
    if facing then
        local rel = angle - facing
        tex:SetRotation(rel)
        Tint(rel)
    end
    dist:SetText(string.format("%d m", math.floor(d + 0.5)))
    if s == A.custom and d <= 10 then A.custom = nil; A.Refresh() end
end

LV.Listen("update", function() A.Refresh() end)
for _, ev in ipairs({ "PLAYER_DEAD", "PLAYER_ALIVE", "PLAYER_UNGHOST", "ZONE_CHANGED_NEW_AREA", "SUPER_TRACKING_CHANGED" }) do
    LV.On(ev, function()
        if C_Timer and C_Timer.After then C_Timer.After(0.5, A.Refresh) else A.Refresh() end
    end)
end
