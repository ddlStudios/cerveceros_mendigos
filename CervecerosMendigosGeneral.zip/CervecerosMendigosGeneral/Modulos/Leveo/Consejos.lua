-- CervecerosMendigos · Leveo: consejos y preguntas (codigo propio, GPL-3.0).
--  * "¿le ganas?" al pasar el raton o seleccionar un enemigo (bicho, no jugadores), segun tu nivel, tu equipo,
--    tu vida y tu grupo frente a su nivel y si es elite o raro
--  * puntuacion de equipo (nivel de objeto medio por calidad) para saber si vas bien equipado
--  * si mueres varias veces en una mision, te propone saltarla y te avisa cuando ya tengas nivel
--  * /leveo dime <pregunta>: que hago, donde esta, quien la da, talentos, equipo, cuanto me falta, le gano
local ADDON, ns = ...
local LV = ns.LV or {}
ns.LV = LV
local T = LV.T
local CS = {}
LV.Coach = CS

local function S() return LV.S end
local function O() return S().consejos or {} end
local function Secret(v) return v ~= nil and issecretvalue ~= nil and issecretvalue(v) and true or false end
local function Print(m) if LV.mod then LV.mod:Print(m) end end

----------------------------------------------------------------------
-- Equipo: nivel de objeto efectivo medio
----------------------------------------------------------------------
local CALIDAD = { [0] = 0.6, [1] = 0.8, [2] = 1.0, [3] = 1.12, [4] = 1.25, [5] = 1.35, [6] = 1.35, [7] = 1.1 }
local RANURAS = { 1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 }

function CS.Gear()
    local suma, n, vacias = 0, 0, 0
    for _, s in ipairs(RANURAS) do
        local link = GetInventoryItemLink and GetInventoryItemLink("player", s)
        if link then
            local ilvl = (C_Item and C_Item.GetDetailedItemLevelInfo and C_Item.GetDetailedItemLevelInfo(link))
                or (GetDetailedItemLevelInfo and GetDetailedItemLevelInfo(link))
            local q = C_Item and C_Item.GetItemQualityByID and C_Item.GetItemQualityByID(link)
            if not q and GetItemInfo then q = select(3, GetItemInfo(link)) end
            if ilvl then suma = suma + ilvl * (CALIDAD[q or 1] or 1); n = n + 1 end
        elseif s ~= 17 and s ~= 18 then
            vacias = vacias + 1
        end
    end
    if n == 0 then return nil end
    local media = suma / (n + vacias)
    local lvl = LV.Level()
    -- lo normal al subir: verdes de unos 3-5 niveles por encima del tuyo
    local esperado = lvl + 4
    local bonus = math.max(-2, math.min(2, (media - esperado) / 4))
    return { media = media, bonus = bonus, vacias = vacias, gs = math.floor(media * 16 + 0.5) }
end

function CS.GearText()
    local g = CS.Gear()
    if not g then return "sin equipo que medir" end
    local nota
    if g.bonus >= 1.2 then nota = "muy por encima de tu nivel"
    elseif g.bonus >= 0.4 then nota = "por encima de tu nivel"
    elseif g.bonus >= -0.4 then nota = "normal para tu nivel"
    elseif g.bonus >= -1.2 then nota = "un poco bajo para tu nivel"
    else nota = "bajo para tu nivel" end
    return string.format("puntuación %d (nivel de objeto medio %.0f): %s%s", g.gs, g.media, nota,
        g.vacias > 0 and (", " .. g.vacias .. " ranuras vacías") or "")
end

----------------------------------------------------------------------
-- ¿Le ganas?
----------------------------------------------------------------------
local EXTRA = { normal = 0, trivial = -1, minus = -2, rare = 0.5, elite = 1.5, rareelite = 2.5 }
local VEREDICTOS = {
    { 2, "Lo matas fácil", 0.36, 1, 0.36 },
    { -1, "Le ganas", 0.5, 1, 0.25 },
    { -2.5, "Parejo: con cuidado", 1, 0.82, 0 },
    { -4, "Difícil solo", 1, 0.5, 0.25 },
    { -99, "No le ganas solo", 1, 0.19, 0.19 },
}

function CS.Verdict(unit)
    unit = unit or "target"
    local ex = UnitExists and UnitExists(unit)
    if Secret(ex) or not ex then return end
    local pl, dead = UnitIsPlayer(unit), UnitIsDead and UnitIsDead(unit)
    if Secret(pl) or Secret(dead) or pl or dead then return end
    local can = UnitCanAttack and UnitCanAttack("player", unit)
    if Secret(can) or not can then return end
    local my, lvl = LV.Level(), UnitLevel(unit)
    local clase = UnitClassification and UnitClassification(unit) or "normal"
    if Secret(lvl) or Secret(clase) or not lvl then return end
    local bonus = 0
    local g = CS.Gear()
    if g then bonus = bonus + g.bonus end
    local hp, hpMax = UnitHealth and UnitHealth("player"), UnitHealthMax and UnitHealthMax("player")
    if not Secret(hp) and not Secret(hpMax) and tonumber(hp) and tonumber(hpMax) and hpMax > 0 then
        local f = hp / hpMax
        if f < 0.3 then bonus = bonus - 2 elseif f < 0.5 then bonus = bonus - 1 end
    end
    local n = GetNumGroupMembers and GetNumGroupMembers() or 0
    if Secret(n) then n = 0 end
    local grupo = n > 1 and math.min(5, (n - 1) * 1.5) or 0
    local margen
    if lvl == -1 or clase == "worldboss" then margen = -10
    else margen = (my + bonus + grupo) - (lvl + (EXTRA[clase] or 0)) end
    local v = VEREDICTOS[#VEREDICTOS]
    for _, x in ipairs(VEREDICTOS) do if margen >= x[1] then v = x; break end end
    -- "no le ganas" solo para calaveras y jefes: lo demas, como mucho, dificil
    if v == VEREDICTOS[#VEREDICTOS] and lvl ~= -1 and clase ~= "worldboss" then v = VEREDICTOS[#VEREDICTOS - 1] end
    return { text = v[2], r = v[3], g = v[4], b = v[5], margen = margen, clase = clase, nivel = lvl, grupo = grupo > 0 }
end

local function OnUnitTip(tip)
    if not (LV.mod and LV.mod:IsEnabled()) or O().veredicto == false then return end
    local _, unit = tip:GetUnit()
    if not unit then return end
    local v = CS.Verdict(unit)
    if v then tip:AddLine("|cff33ff99Leveo:|r " .. v.text .. (v.grupo and " (con tu grupo)" or ""), v.r, v.g, v.b) end
end

function CS.HookTooltips()
    if CS.hooked then return end
    CS.hooked = true
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Unit, function(tip) pcall(OnUnitTip, tip) end)
    elseif GameTooltip and GameTooltip.HookScript then
        GameTooltip:HookScript("OnTooltipSetUnit", function(tip) pcall(OnUnitTip, tip) end)
    end
end

-- Al seleccionar un elite o un raro, una linea en el chat (una vez cada 15 min por nombre)
local avisados = {}
LV.On("PLAYER_TARGET_CHANGED", function()
    if O().avisoElite == false then return end
    local v = CS.Verdict("target")
    if not v or not (v.clase == "elite" or v.clase == "rare" or v.clase == "rareelite") then return end
    local name = UnitName("target")
    if Secret(name) or not name then return end
    local now = GetTime()
    if avisados[name] and now - avisados[name] < 900 then return end
    avisados[name] = now
    local tipo = (v.clase == "rare" and "raro") or (v.clase == "rareelite" and "élite raro") or "élite"
    Print(string.format("%s (%s, nivel %s): %s.", name, tipo, v.nivel == -1 and "??" or v.nivel, v.text:lower()))
end)

----------------------------------------------------------------------
-- Muertes: misiones donde mueres mucho
----------------------------------------------------------------------
local function Char()
    local p = T.P()
    p.muertes = p.muertes or {}
    p.saltadas = p.saltadas or {}
    return p
end

local function StepQuests(st)
    local out = {}
    if not st then return out end
    for _, el in ipairs(st.els) do
        if el.quest and (el.verb == "complete" or el.verb == "collect") and LV.Q.On(el.quest) and not LV.Q.Complete(el.quest) then
            out[#out + 1] = el.quest
        end
    end
    return out
end

LV.On("PLAYER_DEAD", function()
    if O().muertes == false or not T.g then return end
    if IsInInstance and select(2, IsInInstance()) ~= "none" then return end
    local p = Char()
    local limite = O().limiteMuertes or 3
    for _, q in ipairs(StepQuests(T.Current())) do
        p.muertes[q] = (p.muertes[q] or 0) + 1
        if p.muertes[q] == limite then
            local d = LV.QuestData(q)
            local nivel = d and d[3] and d[3] > 0 and d[3] or LV.Level() + 1
            p.saltadas[q] = math.max(nivel + 1, LV.Level() + 2)
            Print(string.format("has muerto %d veces en «%s». Si se te atraganta, sáltala con el botón > y vuelve a nivel %d (te aviso).",
                limite, LV.Q.Title(q), p.saltadas[q]))
        end
    end
end)

LV.On("PLAYER_LEVEL_UP", function(_, level)
    if O().muertes == false then return end
    local p = Char()
    for q, nivel in pairs(p.saltadas) do
        if level and level >= nivel then
            if LV.Q.On(q) and not LV.Q.Done(q) then
                Print(string.format("ya tienes nivel para volver a «%s».", LV.Q.Title(q)))
            end
            p.saltadas[q] = nil
            p.muertes[q] = nil
        end
    end
end)

----------------------------------------------------------------------
-- Preguntas: /leveo dime <pregunta>
----------------------------------------------------------------------
local ACC = { ["á"] = "a", ["é"] = "e", ["í"] = "i", ["ó"] = "o", ["ú"] = "u", ["ü"] = "u", ["ñ"] = "n" }
local function Plain(s)
    s = (s or ""):lower():gsub("[\195][\128-\191]", function(c) return ACC[c] or c end)
    s = s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", "")
    return (s:gsub("[%p]", " "):gsub("%s+", " "):gsub("^ ", ""):gsub(" $", ""))
end
CS.Plain = Plain

local function Has(t, ...)
    for _, w in ipairs({ ... }) do if t:find(w, 1, true) then return true end end
    return false
end

-- Busca una mision por nombre: en tu registro y en la ruta cargada
function CS.FindQuest(text)
    local want = Plain(text)
    if want == "" then return end
    local best, bestLen
    local function Try(q)
        local t = Plain(LV.Q.Title(q))
        if t ~= "" and (t:find(want, 1, true) or want:find(t, 1, true)) then
            if not bestLen or #t < bestLen then best, bestLen = q, #t end
        end
    end
    if C_QuestLog and C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetInfo then
        for i = 1, C_QuestLog.GetNumQuestLogEntries() do
            local info = C_QuestLog.GetInfo(i)
            if info and info.questID and not info.isHeader then Try(info.questID) end
        end
    end
    for _, st in ipairs(T.steps or {}) do
        for _, el in ipairs(st.els) do
            if el.quest then
                Try(el.quest)
                -- el texto de la ruta trae el nombre en español ("Acepta la misión Dientes afilados")
                if not best and el.text then
                    local t = Plain(el.text)
                    if #want >= 4 and t:find(want, 1, true) then best = el.quest end
                end
            end
        end
    end
    return best
end

-- Donde esta una mision: el lugar de la ruta junto a esa mision, o el dador de nuestros datos
function CS.QuestSpot(q)
    local verbo = LV.Q.On(q) and (LV.Q.Complete(q) and "turnin" or "complete") or "accept"
    for _, st in ipairs(T.steps or {}) do
        local tiene = false
        for _, el in ipairs(st.els) do if el.quest == q and el.verb == verbo then tiene = true end end
        if tiene then
            for _, el in ipairs(st.els) do
                if (el.verb == "wp" or el.verb == "go") and not el.noArrow and T.ElShown(el) then return el, verbo end
            end
        end
    end
    return LV.QuestGiver(q), verbo
end

local AYUDA = "pregúntame: «qué hago», «dónde está <misión>», «quién da <misión>», «talentos», «equipo», «cuánto me falta», «le gano» (con un enemigo seleccionado)."

function CS.Ask(msg)
    local t = Plain(msg)
    if t == "" or Has(t, "ayuda", "help") then Print(AYUDA); return end
    if Has(t, "que hago", "ahora", "siguiente paso", "que toca") then
        local st = T.Current()
        if not st then Print("no tienes ruta cargada: /leveo ruta"); return end
        for _, l in ipairs(LV.Win.StepLines(st)) do if not l.done then Print(l.text) end end
        return
    end
    if Has(t, "talento") then
        local b = LV.Talents.Current()
        if not b then Print("no tengo talentos para tu clase."); return end
        local m = LV.Talents.Plan(b)
        if #m == 0 then Print("tu build de " .. (b.es or b.key) .. " está completa.") return end
        local t2 = {}
        for k = 1, math.min(3, #m) do t2[#t2 + 1] = LV.Talents.PointText(b, m[k]) end
        Print((b.es or b.key) .. ": " .. table.concat(t2, "; ") .. ".")
        return
    end
    if Has(t, "equipo", "gear", "bis", "armadura") and not Has(t, "le gano") then
        Print("tu equipo: " .. CS.GearText() .. ".")
        LV.Gear.Report(true)
        return
    end
    if Has(t, "cuanto me falta", "subir", "experiencia", "xp") then
        if LV.XPInfo then Print(LV.XPInfo()) else Print("nivel " .. LV.Level()) end
        return
    end
    if Has(t, "le gano", "puedo con", "lo mato", "le puedo") then
        local v = CS.Verdict("target")
        if v then Print(v.text .. ".") else Print("selecciona antes a un enemigo (bicho, no jugador).") end
        return
    end
    local resto = t:match("donde esta (.+)") or t:match("donde (.+)") or t:match("como llego a (.+)")
    if resto then
        local q = CS.FindQuest(resto)
        if not q then Print("no encuentro esa misión en tu registro ni en tu ruta."); return end
        local spot, verbo = CS.QuestSpot(q)
        if spot and LV.Arrow then
            local copia = {}
            for k, v in pairs(spot) do copia[k] = v end
            copia.label = LV.Q.Title(q)
            LV.Arrow.SetCustom(copia)
            Print(string.format("«%s»: %s. La flecha te lleva.", LV.Q.Title(q),
                verbo == "accept" and "se coge allí" or (verbo == "turnin" and "se entrega allí" or "se hace por allí")))
        else
            Print("no sé dónde queda «" .. LV.Q.Title(q) .. "».")
        end
        return
    end
    resto = t:match("quien da (.+)") or t:match("quien (.+)")
    if resto then
        local q = CS.FindQuest(resto)
        local d = q and LV.QuestData(q)
        if d and d[7] and d[7] ~= "" then
            local z = (CMLZones or {})[d[8]]
            Print(string.format("«%s» la da %s%s.", LV.Q.Title(q), d[7], z and (" en " .. z[2]) or ""))
        else
            Print("no lo sé.")
        end
        return
    end
    Print("no te he entendido. " .. AYUDA)
end
