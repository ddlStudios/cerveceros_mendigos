-- Subidoor: pantalla de subida de nivel para WoW Forever, como módulo del Hub del addon General.
-- Al subir: estadísticas de antes y después, lo que te falta del entrenador (con iconos y precio),
-- armas, grimorios de brujo, habilidades de mascota, tiempo en el nivel y récords. Todo configurable.
-- Código propio de CervecerosMendigos (idea parecida a Gnome Level Up, sin usar nada suyo).
local ADDON, ns = ...
local Hub = ns.Hub
local S = ns.Subidoor

local DEFAULTS = {
    -- Comportamiento
    duracion = 10, esperarCombate = true, clicDerechoCierra = true, atravesable = false, pausaRaton = true,
    fijarSiempre = false, bloqueada = false, ocultarJuego = true, silenciarDing = true,
    mensajeChat = true, textoChat = "¡Has alcanzado el nivel %d!", colorChat = { 1, 0.82, 0 },
    capturaCada = false, capturaHitos = false, esperaCaptura = 1.5, hitoCada = 10, nivelMaximo = 60,
    celebrarMaximo = true, esperaStats = 1.0,
    -- Contenido
    mostrarStats = true, statsSinCambio = false, soloGanancia = false, mostrarSecundarias = false,
    mostrarHabilidades = true, soloNuevas = false, soloUltimoRango = true, sinConfirmar = false,
    mostrarCostes = true, avisarAlDia = true, mostrarArmas = true, mostrarGrimorios = true,
    grimoriosSoloDemonio = true, grimoriosTodos = false, mostrarMascota = true, mascotaSoloFamilia = true,
    lineaTiempo = false, lineaPasos = 2, lineaIconos = 4, maxIconos = 24, tamIcono = 32,
    mostrarTiempo = true, compararCuenta = true, autoEscaneo = true, avisoEscaneo = true,
    -- Apariencia
    tema = "moderno", disposicion = "vertical", escala = 1, opacidad = 0.92, estrato = "HIGH",
    anchoVertical = 380, anchoHorizontal = 760, retrato = "2d", tamRetrato = 72, aro = true,
    fuente = "friz", fuentePropia = "", tamTitulo = 26, tamCabecera = 14, tamTexto = 13,
    sombra = true, contorno = false, coloresClase = true, coloresTema = true, fondoPropio = false,
    colores = { titulo = { 1, 0.82, 0 }, nombre = { 1, 1, 1 }, cabecera = { 1, 0.82, 0 }, etiqueta = { 0.9, 0.9, 0.9 },
                valor = { 1, 1, 1 }, ganancia = { 0.2, 1, 0.4 }, habilidad = { 0.25, 0.85, 1 }, tiempo = { 0.85, 0.85, 0.85 },
                aro = { 1, 0.82, 0.3 }, chispas = { 1, 0.85, 0.4 }, fondo = { 0.03, 0.04, 0.07 },
                fondo2 = { 0.10, 0.12, 0.19 }, borde = { 1, 0.82, 0.25 } },
    pos = {},
    -- Animación
    animaciones = true, modoClasico = false, velocidad = 1, escalaEntrada = true, contadores = true,
    destacarNuevas = true, brillo = true, chispas = true, numChispas = 18, tamChispa = 16,
    opacidadChispas = 0.8, efectoHito = true,
    -- Sonido
    sonido = true, sonidoElegido = "juego", canal = "Master", sonidoArchivo = "",
}

-- Datos que no son ajustes (no los borra «Restaurar valores»).
local function DatosPropios(db)
    db.historial = db.historial or {}
    db.entrenador = db.entrenador or {}
    db.armasVistas = db.armasVistas or {}
end

local pendienteStats = false
local function ActualizarStats()
    if pendienteStats then return end
    pendienteStats = true
    C_Timer.After(0.3, function()
        pendienteStats = false
        if S.mod:IsEnabled() then S.ActualizarInstantanea() end
    end)
end

----------------------------------------------------------------------
-- Ventana de historial (ventana de datos, se abre desde la pestaña)
----------------------------------------------------------------------
local hist
local function TextoHistorial()
    local db = S.mod.db
    local yo = UnitGUID("player")
    local lineas = {}
    local p = db.historial[yo]
    lineas[#lineas + 1] = "|cffffd100Este personaje|r"
    if p and next(p.niveles) then
        local total = 0
        for n = 1, 80 do
            local t = p.niveles[n]
            if t then
                total = total + t
                local rec, quien = S.Record(n)
                local marca = rec and t <= rec and "  |cff33ff66★ récord|r" or
                    (rec and ("  |cff999999récord %s%s|r"):format(S.Duracion(rec), quien and quien ~= p.nombre and (" (" .. quien .. ")") or "") or "")
                lineas[#lineas + 1] = ("Nivel %d → %d: %s%s"):format(n, n + 1, S.Duracion(t), marca)
            end
        end
        lineas[#lineas + 1] = ("|cffaaaaaaSuma de los niveles apuntados: %s|r"):format(S.Duracion(total))
    else
        lineas[#lineas + 1] = "Aún no hay niveles apuntados (se apunta cada nivel que subes con el módulo activado)."
    end
    lineas[#lineas + 1] = " "
    lineas[#lineas + 1] = "|cffffd100Otros personajes de la cuenta|r"
    local hay = false
    for guid, q in pairs(db.historial) do
        if guid ~= yo then
            local n, total = 0, 0
            for _, t in pairs(q.niveles) do n, total = n + 1, total + t end
            if n > 0 then
                hay = true
                local r, g, b = S.ColorClase(q.clase)
                lineas[#lineas + 1] = ("|cff%02x%02x%02x%s|r: %d niveles, %s"):format(r * 255, g * 255, b * 255,
                    q.nombre or "?", n, S.Duracion(total))
            end
        end
    end
    if not hay then lineas[#lineas + 1] = "Ninguno todavía." end
    return table.concat(lineas, "\n")
end

local function AbrirHistorial()
    if not hist then
        hist = Hub.UI.MakeWindow("CMSubidoorHistorial", "Subidoor: tiempo por nivel", 460, 420)
        local sf, child = Hub.UI.MakeScroll(hist, 410, 330)
        sf:SetPoint("TOPLEFT", 16, -34)
        hist.child, hist.sf = child, sf
        hist.texto = child:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        hist.texto:SetPoint("TOPLEFT", 4, -4)
        hist.texto:SetWidth(400)
        hist.texto:SetJustifyH("LEFT")
        hist.texto:SetSpacing(3)
        StaticPopupDialogs.CM_SUBIDOOR_BORRAR = { text = "¿Borrar los tiempos apuntados de este personaje?",
            button1 = YES, button2 = NO, timeout = 0, whileDead = true, hideOnEscape = true,
            OnAccept = function()
                S.mod.db.historial[UnitGUID("player")] = nil
                if hist:IsShown() then hist.texto:SetText(TextoHistorial()) end
            end }
        Hub.UI.NewButton(hist, "Borrar este personaje", 170, "BOTTOMLEFT", 16, 14,
            function() StaticPopup_Show("CM_SUBIDOOR_BORRAR") end)
        S.mod:Track(hist)
    end
    hist.texto:SetText(TextoHistorial())
    hist.child:SetHeight((hist.texto:GetStringHeight() or 100) + 20)
    if hist.sf.UpdateRange then hist.sf.UpdateRange() end
    hist:Show()
end
S.AbrirHistorial = AbrirHistorial

----------------------------------------------------------------------
-- Registro en el Hub
----------------------------------------------------------------------
local function Elegir(lista)
    local o = {}
    for _, x in ipairs(lista) do o[#o + 1] = { x[1], x[2] } end
    return o
end

local mod
mod = Hub:Register{
    key = "subidoor", dir = "Subidoor", name = "Subidoor",
    desc = "Pantalla de subida de nivel: lo que ganas (vida, maná, estadísticas, talentos), lo que te falta "
        .. "del entrenador con iconos y precio, armas, grimorios y habilidades de mascota, y tu tiempo en cada "
        .. "nivel con récords. Temas, disposiciones, animaciones y sonidos a tu gusto.",
    defaults = DEFAULTS,
    slash = { "subidoor", "cmsubida" },
    Init = function(m)
        S.mod = m
        DatosPropios(m.db)
        m:Event("PLAYER_LEVEL_UP", function(_, _, ...)
            S.OcultarAvisoJuego()
            S.AlSubir(...)
        end)
        m:Event("PLAYER_REGEN_ENABLED", function() S.FinCombate() end)
        for _, e in ipairs({ "UNIT_STATS", "UNIT_MAXHEALTH", "UNIT_MAXPOWER", "UNIT_RESISTANCES" }) do
            m:Event(e, function(_, _, unidad) if unidad == "player" then ActualizarStats() end end)
        end
        m:Event("PLAYER_EQUIPMENT_CHANGED", ActualizarStats)
        m:Event("PLAYER_ENTERING_WORLD", function()
            ActualizarStats()
            if not S.TiempoEnNivel() then C_Timer.After(3, S.PedirTiempo) end
        end)
        m:Event("TIME_PLAYED_MSG", function(_, _, total, enNivel) S.AlRecibirTiempo(total, enNivel) end)
        m:Event("TRAINER_SHOW", function() C_Timer.After(0.3, function()
            if m:IsEnabled() then S.EscanearEntrenador() end
        end) end)
    end,
    Enable = function(m)
        S.mod = m
        DatosPropios(m.db)
        S.ActualizarInstantanea()
        S.AplicarSilencio()
        if not S.TiempoEnNivel() then C_Timer.After(3, function() if m:IsEnabled() then S.PedirTiempo() end end) end
    end,
    Disable = function(m)
        S.Cerrar()
        S.AplicarSilencio()
    end,
    OnReset = function(m)
        DatosPropios(m.db)
        S.AplicarSilencio()
        S.RefrescarVentana()
    end,
    OnSlash = function(m, msg)
        local cmd, arg = (msg or ""):lower():match("^%s*(%S*)%s*(.-)%s*$")
        if cmd == "test" or cmd == "prueba" then S.Prueba(arg)
        elseif cmd == "repetir" then S.Repetir()
        elseif cmd == "historial" then AbrirHistorial()
        elseif cmd == "cerrar" then S.Cerrar()
        elseif cmd == "escanear" then
            local n = S.EscanearEntrenador()
            if n == 0 then m:Print("abre la ventana de tu entrenador de clase y vuelve a escribirlo.") end
        elseif cmd == "" then Hub:Open("subidoor")
        else m:Print("comandos: test [nivel], repetir, historial, escanear, cerrar.") end
    end,
    BuildConfig = function(m, L)
        S.mod = m
        local db = m.db
        DatosPropios(db)
        local function G(k) return function() return db[k] end end
        local function P(k, despues) return function(v) db[k] = v; S.RefrescarVentana(); if despues then despues(v) end end end
        local function Col(k) return function() local c = db.colores[k]; return c[1], c[2], c[3] end end
        local function SetCol(k) return function(r, g, b) db.colores[k] = { r, g, b }; S.RefrescarVentana() end end

        L:Button("Vista previa", 120, function() S.Prueba() end)
        L:Button("Repetir la última", 140, function() S.Repetir() end, true)
        L:Button("Tiempo por nivel", 140, AbrirHistorial, true)
        L:Text("También: /subidoor test 40 (vista previa de ese nivel), /subidoor repetir, /subidoor historial.", true)

        L:Header("Cuándo y cómo sale")
        L:Slider("Segundos en pantalla (0 = hasta que la cierres)", 0, 60, 1, G("duracion"), P("duracion"), "%d s")
        L:Check("Esperar a salir de combate para mostrarla", G("esperarCombate"), P("esperarCombate"))
        L:Check("No cerrarla mientras tenga el ratón encima", G("pausaRaton"), P("pausaRaton"))
        L:Check("Salir siempre fijada (no se cierra sola)", G("fijarSiempre"), P("fijarSiempre"))
        L:Check("Clic derecho la cierra", G("clicDerechoCierra"), P("clicDerechoCierra"))
        L:Check("Que los clics la atraviesen (sin botones ni descripciones)", G("atravesable"), P("atravesable"))
        L:Check("Bloquear la posición (desbloqueada: arrástrala)", G("bloqueada"), P("bloqueada"))
        L:Button("Volver a su sitio", 150, function() db.pos = {}; S.RefrescarVentana() end)
        L:Check("Esconder el aviso de subida del propio juego", G("ocultarJuego"), P("ocultarJuego"))
        L:Slider("Espera para leer las estadísticas nuevas", 0.5, 3, 0.25, G("esperaStats"), P("esperaStats"), "%.2f s")

        L:Header("Qué enseña")
        L:Check("Estadísticas (vida, maná, fuerza...)", G("mostrarStats"), P("mostrarStats"))
        L:Check("  Incluir las que no han cambiado", G("statsSinCambio"), P("statsSinCambio"))
        L:Check("  Solo la ganancia (sin antes → después)", G("soloGanancia"), P("soloGanancia"))
        L:Check("Estadísticas secundarias (armadura, poder de ataque, críticos...)", G("mostrarSecundarias"), P("mostrarSecundarias"))
        L:Check("Lo que te falta del entrenador", G("mostrarHabilidades"), P("mostrarHabilidades"))
        L:Check("  Solo lo nuevo de este nivel", G("soloNuevas"), P("soloNuevas"))
        L:Check("  Solo el rango más alto de cada hechizo", G("soloUltimoRango"), P("soloUltimoRango"))
        L:Check("  Precio debajo de cada icono", G("mostrarCostes"), P("mostrarCostes"))
        L:Check("  Decir «lo tienes todo al día» si no falta nada", G("avisarAlDia"), P("avisarAlDia"))
        L:Check("  Incluir hechizos sin confirmar (runas, libros, novedades aún no vistas)", G("sinConfirmar"), P("sinConfirmar", S.InvalidarLista))
        L:Slider("  Iconos como máximo", 4, 60, 1, G("maxIconos"), P("maxIconos"))
        L:Slider("  Tamaño de los iconos", 20, 48, 2, G("tamIcono"), P("tamIcono"))
        L:Check("Armas que puedes aprender con el maestro de armas", G("mostrarArmas"), P("mostrarArmas"))
        L:Check("Brujo: grimorios nuevos para tu demonio", G("mostrarGrimorios"), P("mostrarGrimorios"))
        L:Check("  Solo los de tu demonio actual", G("grimoriosSoloDemonio"), P("grimoriosSoloDemonio"))
        L:Check("  También los de niveles anteriores que tu demonio no sabe", G("grimoriosTodos"), P("grimoriosTodos"))
        L:Check("Cazador: nuevas habilidades de mascota", G("mostrarMascota"), P("mostrarMascota"))
        L:Check("  Solo las que puede aprender tu mascota", G("mascotaSoloFamilia"), P("mascotaSoloFamilia"))
        L:Check("Próximos niveles (lo que viene en el entrenador)", G("lineaTiempo"), P("lineaTiempo"))
        L:Slider("  Cuántos niveles", 1, 4, 1, G("lineaPasos"), P("lineaPasos"))
        L:Slider("  Iconos por nivel", 1, 8, 1, G("lineaIconos"), P("lineaIconos"))
        L:Check("Tiempo que has tardado en el nivel", G("mostrarTiempo"), P("mostrarTiempo"))
        L:Check("  Comparar récords con todos tus personajes", G("compararCuenta"), P("compararCuenta"))

        L:Header("Entrenador")
        L:Text("Los hechizos salen de los datos del cliente de WoW Forever. Al abrir tu entrenador, Subidoor lee "
            .. "los precios y niveles reales y confirma las novedades de Forever.", true)
        L:Check("Leer el entrenador al abrirlo", G("autoEscaneo"), P("autoEscaneo"))
        L:Check("  Avisar en el chat cuando lo lea", G("avisoEscaneo"), P("avisoEscaneo"))

        L:Header("Apariencia")
        L:Choice("Tema", Elegir(S.TEMAS), G("tema"), P("tema"))
        L:Choice("Disposición", { { "vertical", "Vertical" }, { "horizontal", "Horizontal (banda arriba)" }, { "compacta", "Compacta" } },
            G("disposicion"), P("disposicion"))
        L:Slider("Escala", 0.5, 2, 0.05, G("escala"), P("escala"), "%.2f")
        L:Slider("Opacidad del fondo", 0.2, 1, 0.05, G("opacidad"), P("opacidad"), "%.2f")
        L:Slider("Ancho en vertical", 300, 560, 10, G("anchoVertical"), P("anchoVertical"))
        L:Slider("Ancho en horizontal", 560, 1100, 10, G("anchoHorizontal"), P("anchoHorizontal"))
        L:Choice("Capa", { { "MEDIUM", "Media" }, { "HIGH", "Alta" }, { "DIALOG", "Diálogo" }, { "FULLSCREEN_DIALOG", "Por encima de todo" } },
            G("estrato"), P("estrato"))
        L:Choice("Retrato", { { "2d", "Cara (2D)" }, { "3d", "Modelo 3D" }, { "ninguno", "Sin retrato" } }, G("retrato"), P("retrato"))
        L:Slider("Tamaño del retrato", 40, 140, 4, G("tamRetrato"), P("tamRetrato"))
        L:Check("Aro alrededor del retrato", G("aro"), P("aro"))
        L:Choice("Letra", Elegir(S.FUENTES), G("fuente"), P("fuente"))
        L:Edit("Archivo de letra propio", G("fuentePropia"), P("fuentePropia"), "text", 250)
        L:Slider("Tamaño del título", 14, 44, 1, G("tamTitulo"), P("tamTitulo"))
        L:Slider("Tamaño de las cabeceras", 10, 22, 1, G("tamCabecera"), P("tamCabecera"))
        L:Slider("Tamaño del texto", 9, 20, 1, G("tamTexto"), P("tamTexto"))
        L:Check("Sombra en el texto", G("sombra"), P("sombra"))
        L:Check("Contorno en el texto", G("contorno"), P("contorno"))
        L:Check("Nombre con el color de tu clase", G("coloresClase"), P("coloresClase"))
        L:Check("Título y cabeceras con el color del tema", G("coloresTema"), P("coloresTema"))
        L:Check("Fondo y borde con mis colores (abajo)", G("fondoPropio"), P("fondoPropio"))

        L:Header("Colores")
        local nombres = { { "titulo", "Título" }, { "nombre", "Nombre (sin color de clase)" }, { "cabecera", "Cabeceras" },
            { "etiqueta", "Nombres de estadística" }, { "valor", "Valores" }, { "ganancia", "Ganancias" },
            { "habilidad", "Borde de los iconos" }, { "tiempo", "Tiempo en el nivel" }, { "aro", "Aro del retrato" },
            { "chispas", "Chispas" }, { "fondo", "Fondo (abajo)" }, { "fondo2", "Fondo (arriba)" }, { "borde", "Borde" } }
        for _, c in ipairs(nombres) do L:Color(c[2], Col(c[1]), SetCol(c[1])) end

        L:Header("Animación")
        L:Check("Animaciones", G("animaciones"), P("animaciones"))
        L:Check("Modo clásico (solo aparece y desaparece, sin adornos)", G("modoClasico"), P("modoClasico"))
        L:Slider("Velocidad", 0.25, 3, 0.05, G("velocidad"), P("velocidad"), "%.2fx")
        L:Check("Crecer al aparecer", G("escalaEntrada"), P("escalaEntrada"))
        L:Check("Números que suben poco a poco", G("contadores"), P("contadores"))
        L:Check("Iconos con borde que brilla", G("destacarNuevas"), P("destacarNuevas"))
        L:Check("Brillo detrás del título", G("brillo"), P("brillo"))
        L:Check("Chispas", G("chispas"), P("chispas"))
        L:Slider("  Cantidad", 0, 60, 1, G("numChispas"), P("numChispas"))
        L:Slider("  Tamaño", 6, 40, 1, G("tamChispa"), P("tamChispa"))
        L:Slider("  Opacidad", 0.1, 1, 0.05, G("opacidadChispas"), P("opacidadChispas"), "%.2f")
        L:Check("Celebración especial en los hitos y el nivel máximo", G("efectoHito"), P("efectoHito"))
        L:Slider("  Hito cada (niveles, 0 = nunca)", 0, 20, 1, G("hitoCada"), P("hitoCada"))
        L:Check("  Título «¡Nivel máximo!» al llegar al tope", G("celebrarMaximo"), P("celebrarMaximo"))
        L:Slider("  Nivel máximo", 10, 80, 1, G("nivelMaximo"), P("nivelMaximo"))

        L:Header("Sonido")
        L:Check("Sonido al subir", G("sonido"), P("sonido", S.AplicarSilencio))
        L:Choice("Cuál", Elegir(S.SONIDOS), G("sonidoElegido"), P("sonidoElegido", S.AplicarSilencio))
        L:Edit("Archivo de sonido propio", G("sonidoArchivo"), P("sonidoArchivo"), "text", 250)
        L:Choice("Canal", Elegir(S.CANALES), G("canal"), P("canal"))
        L:Button("Probar sonido", 130, function() S.Sonar() end)
        L:Check("Silenciar el «ding» del juego", G("silenciarDing"), P("silenciarDing", S.AplicarSilencio))

        L:Header("Chat y capturas")
        L:Check("Mensaje en el chat al subir", G("mensajeChat"), P("mensajeChat"))
        L:Edit("Texto (%d = nivel, %n = nombre)", G("textoChat"), P("textoChat"), "text", 250)
        L:Color("Color del mensaje", function() local c = db.colorChat; return c[1], c[2], c[3] end,
            function(r, g, b) db.colorChat = { r, g, b } end)
        L:Check("Captura de pantalla en cada nivel", G("capturaCada"), P("capturaCada"))
        L:Check("Captura de pantalla en los hitos", G("capturaHitos"), P("capturaHitos"))
        L:Slider("  Espera antes de la captura", 0.5, 5, 0.25, G("esperaCaptura"), P("esperaCaptura"), "%.2f s")
    end,
}
S.mod = mod
