-- Subidoor: la ventana de subida de nivel (diseño propio de CervecerosMendigos).
-- Temas hechos con colores y bordes del propio juego, tres disposiciones, retrato 2D/3D,
-- animaciones (aparición, contadores, iconos, chispas, hitos) y sonidos. Todo sale de mod.db.
local ADDON, ns = ...
local S = ns.Subidoor

local function Opt() return S.mod.db end

----------------------------------------------------------------------
-- Temas, fuentes y sonidos (listas que usa también la configuración)
----------------------------------------------------------------------
-- fondo / fondo2: degradado de abajo a arriba; borde; acento (título y cabeceras con «colores del tema»).
-- Adornos opcionales: marca = emblema (textura del juego) para la marca de agua y los lados del título;
-- franja = color de la banda detrás del título; aro / chispas = colores propios del tema.
local LOGO_ALIANZA = { tex = "Interface\\Timer\\Alliance-Logo", res = "Interface\\TargetingFrame\\UI-PVP-Alliance", resCoord = { 0, 0.62, 0, 0.62 } }
local LOGO_HORDA = { tex = "Interface\\Timer\\Horde-Logo", res = "Interface\\TargetingFrame\\UI-PVP-Horde", resCoord = { 0, 0.62, 0, 0.62 } }
local CIRCULOS = "Interface\\TargetingFrame\\UI-Classes-Circles"
-- Recortes de cada clase en UI-Classes-Circles (por si el juego no trae CLASS_ICON_TCOORDS).
local COORD_CLASE = {
    WARRIOR = { 0, 0.25, 0, 0.25 }, MAGE = { 0.25, 0.49609375, 0, 0.25 }, ROGUE = { 0.49609375, 0.7421875, 0, 0.25 },
    DRUID = { 0.7421875, 0.98828125, 0, 0.25 }, HUNTER = { 0, 0.25, 0.25, 0.5 }, SHAMAN = { 0.25, 0.49609375, 0.25, 0.5 },
    PRIEST = { 0.49609375, 0.7421875, 0.25, 0.5 }, WARLOCK = { 0.7421875, 0.98828125, 0.25, 0.5 }, PALADIN = { 0, 0.25, 0.5, 0.75 },
}
local function MarcaClase(clase)
    local c = (CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[clase]) or COORD_CLASE[clase]
    return { tex = CIRCULOS, coord = c }
end

S.TEMAS = {
    { "clase", "Mi clase (automático)" },
    { "moderno", "Moderno", fondo = { 0.03, 0.04, 0.07 }, fondo2 = { 0.10, 0.12, 0.19 }, borde = { 1, 0.82, 0.25 }, acento = { 1, 0.82, 0.2 } },
    { "clasico", "Clásico", fondo = { 0, 0, 0 }, fondo2 = { 0.08, 0.06, 0.03 }, borde = { 1, 1, 1 }, acento = { 1, 0.82, 0 },
      tex = "Interface\\DialogFrame\\UI-DialogBox-Background", edge = "Interface\\DialogFrame\\UI-DialogBox-Border", edgeSize = 32 },
    { "madera", "Madera", fondo = { 0.18, 0.10, 0.04 }, fondo2 = { 0.36, 0.22, 0.10 }, borde = { 0.62, 0.42, 0.20 }, acento = { 1, 0.86, 0.55 },
      franja = { 0.45, 0.28, 0.12 }, esquinas = true },
    { "metal", "Metal", fondo = { 0.10, 0.10, 0.11 }, fondo2 = { 0.30, 0.31, 0.33 }, borde = { 0.72, 0.74, 0.78 }, acento = { 0.86, 0.92, 1 },
      franja = { 0.45, 0.47, 0.52 }, esquinas = true },
    { "gnomeregan", "Gnomeregan", fondo = { 0.02, 0.09, 0.09 }, fondo2 = { 0.07, 0.25, 0.22 }, borde = { 0.35, 0.95, 0.75 }, acento = { 0.55, 1, 0.85 },
      marca = { tex = "Interface\\Icons\\INV_Misc_Gear_01", redonda = true }, chispas = { 0.4, 1, 0.8 }, esquinas = true },
    { "alianza", "Alianza", fondo = { 0.02, 0.06, 0.17 }, fondo2 = { 0.08, 0.18, 0.42 }, borde = { 0.95, 0.78, 0.30 }, acento = { 0.60, 0.78, 1 },
      marca = LOGO_ALIANZA, franja = { 0.12, 0.28, 0.65 }, aro = { 0.95, 0.78, 0.30 }, chispas = { 0.7, 0.85, 1 }, esquinas = true },
    { "horda", "Horda", fondo = { 0.12, 0.02, 0.02 }, fondo2 = { 0.34, 0.06, 0.04 }, borde = { 0.78, 0.62, 0.36 }, acento = { 1, 0.38, 0.26 },
      marca = LOGO_HORDA, franja = { 0.55, 0.08, 0.05 }, aro = { 0.78, 0.62, 0.36 }, chispas = { 1, 0.5, 0.2 }, esquinas = true },
}
-- Un tema por clase: colores de la clase, su emblema y sus chispas.
S.TEMAS_CLASE = {
    { "WARRIOR", "Guerrero", fondo = { 0.10, 0.05, 0.03 }, fondo2 = { 0.30, 0.15, 0.08 }, borde = { 0.78, 0.61, 0.43 }, acento = { 1, 0.78, 0.55 }, chispas = { 1, 0.5, 0.2 } },
    { "PALADIN", "Paladín", fondo = { 0.12, 0.08, 0.03 }, fondo2 = { 0.38, 0.28, 0.12 }, borde = { 1, 0.85, 0.45 }, acento = { 0.96, 0.55, 0.73 }, chispas = { 1, 0.95, 0.6 } },
    { "HUNTER", "Cazador", fondo = { 0.04, 0.08, 0.03 }, fondo2 = { 0.16, 0.26, 0.10 }, borde = { 0.67, 0.83, 0.45 }, acento = { 0.80, 0.95, 0.55 }, chispas = { 0.8, 1, 0.5 } },
    { "ROGUE", "Pícaro", fondo = { 0.03, 0.03, 0.03 }, fondo2 = { 0.14, 0.13, 0.08 }, borde = { 1, 0.96, 0.41 }, acento = { 1, 0.96, 0.41 }, chispas = { 0.9, 0.9, 0.5 } },
    { "PRIEST", "Sacerdote", fondo = { 0.08, 0.08, 0.10 }, fondo2 = { 0.30, 0.30, 0.34 }, borde = { 1, 1, 1 }, acento = { 1, 0.95, 0.80 }, chispas = { 1, 1, 0.85 } },
    { "SHAMAN", "Chamán", fondo = { 0.01, 0.04, 0.12 }, fondo2 = { 0.04, 0.18, 0.36 }, borde = { 0.2, 0.6, 1 }, acento = { 0.45, 0.75, 1 }, chispas = { 0.4, 0.8, 1 } },
    { "MAGE", "Mago", fondo = { 0.03, 0.04, 0.12 }, fondo2 = { 0.18, 0.10, 0.36 }, borde = { 0.41, 0.8, 0.94 }, acento = { 0.6, 0.9, 1 }, chispas = { 0.75, 0.6, 1 } },
    { "WARLOCK", "Brujo", fondo = { 0.05, 0.02, 0.08 }, fondo2 = { 0.20, 0.06, 0.28 }, borde = { 0.58, 0.51, 0.79 }, acento = { 0.6, 1, 0.4 }, chispas = { 0.5, 1, 0.3 } },
    { "DRUID", "Druida", fondo = { 0.05, 0.07, 0.02 }, fondo2 = { 0.22, 0.18, 0.05 }, borde = { 1, 0.49, 0.04 }, acento = { 1, 0.65, 0.25 }, chispas = { 0.6, 1, 0.4 } },
}
for _, c in ipairs(S.TEMAS_CLASE) do
    local clase = c[1]
    c.clase = clase
    c[1], c[2] = "c_" .. clase, "Clase: " .. c[2]
    c.marca = MarcaClase(clase)
    c.franja = c.fondo2
    c.aro = c.borde
    c.esquinas = true
    S.TEMAS[#S.TEMAS + 1] = c
end
local TEMA = {}
for _, t in ipairs(S.TEMAS) do TEMA[t[1]] = t end

S.FUENTES = {
    { "friz", "Friz Quadrata (la del juego)", "Fonts\\FRIZQT__.TTF" },
    { "arial", "Arial Narrow", "Fonts\\ARIALN.TTF" },
    { "skurri", "Skurri", "Fonts\\skurri.ttf" },
    { "morpheus", "Morpheus", "Fonts\\MORPHEUS.ttf" },
    { "propia", "Archivo propio (abajo)", nil },
}

-- Sonidos del juego: nombre de SOUNDKIT con número de repuesto, o archivo (id) del cliente.
S.SONIDOS = {
    { "juego", "Subida de nivel del juego", archivo = 569593 },
    { "lista", "Comprobación de listos", kit = "READY_CHECK", num = 8960 },
    { "banda", "Aviso de banda", kit = "RAID_WARNING", num = 8959 },
    { "mision", "Misión completada", kit = "IG_QUEST_LIST_COMPLETE", num = 878 },
    { "alarma", "Despertador", kit = "ALARM_CLOCK_WARNING_3", num = 12889 },
    { "propio", "Archivo propio (abajo)" },
    { "ninguno", "Ninguno" },
}
S.DING_JUEGO = 569593
S.CANALES = { { "Master", "General" }, { "SFX", "Efectos" }, { "Music", "Música" }, { "Ambience", "Ambiente" }, { "Dialog", "Diálogos" } }

-- Tema en uso. «clase» = el de la clase del personaje (si no la conoce, el moderno).
function S.Tema(clave)
    clave = clave or Opt().tema
    if clave == "clase" then
        local clase = S.MiClase and S.MiClase()
        return TEMA["c_" .. tostring(clase)] or TEMA.moderno
    end
    local t = TEMA[clave]
    if not t or not t.fondo then return TEMA.moderno end
    return t
end

function S.Color(clave)
    local db, tema = Opt(), S.Tema()
    if db.coloresTema and (clave == "titulo" or clave == "cabecera") then return unpack(tema.acento) end
    if db.coloresTema and (clave == "aro" or clave == "chispas") and tema[clave] then return unpack(tema[clave]) end
    local c = db.colores[clave] or { 1, 1, 1 }
    return c[1], c[2], c[3]
end

function S.ColorClase(clase)
    local c = RAID_CLASS_COLORS and RAID_CLASS_COLORS[clase]
    if c then return c.r, c.g, c.b end
    return 1, 1, 1
end

local function Fuente()
    local db = Opt()
    if db.fuente == "propia" and db.fuentePropia and db.fuentePropia ~= "" then return db.fuentePropia end
    for _, f in ipairs(S.FUENTES) do if f[1] == db.fuente and f[3] then return f[3] end end
    return "Fonts\\FRIZQT__.TTF"
end

local function PonerFuente(fs, tam)
    local db = Opt()
    local ok = pcall(fs.SetFont, fs, Fuente(), tam, db.contorno and "OUTLINE" or "")
    if not ok then pcall(fs.SetFont, fs, "Fonts\\FRIZQT__.TTF", tam, "") end
    if db.sombra then fs:SetShadowOffset(1, -1); fs:SetShadowColor(0, 0, 0, 1) else fs:SetShadowOffset(0, 0) end
end

function S.Sonar()
    local db = Opt()
    if not db.sonido then return end
    local canal = db.canal or "Master"
    if db.sonidoElegido == "propio" then
        if db.sonidoArchivo and db.sonidoArchivo ~= "" then pcall(PlaySoundFile, db.sonidoArchivo, canal) end
        return
    end
    for _, s in ipairs(S.SONIDOS) do
        if s[1] == db.sonidoElegido then
            if s.archivo then
                pcall(PlaySoundFile, s.archivo, canal)
            elseif s.kit then
                local id = (SOUNDKIT and SOUNDKIT[s.kit]) or s.num
                pcall(PlaySound, id, canal)
            end
            return
        end
    end
end

-- Silenciar el «ding» del juego (salvo si el sonido elegido es justo ese).
local silenciado = false
function S.AplicarSilencio()
    local db = Opt()
    local quiero = S.mod:IsEnabled() and db.silenciarDing and not (db.sonido and db.sonidoElegido == "juego")
    if quiero and not silenciado and MuteSoundFile then
        pcall(MuteSoundFile, S.DING_JUEGO); silenciado = true
    elseif not quiero and silenciado and UnmuteSoundFile then
        pcall(UnmuteSoundFile, S.DING_JUEGO); silenciado = false
    end
end

----------------------------------------------------------------------
-- Construcción de la ventana
----------------------------------------------------------------------
local f              -- ventana
local filas, iconos, chispas, cabeceras = {}, {}, {}, {}
local anim           -- estado de la animación en curso
local actual         -- info mostrada

local function NuevaFila()
    local r = CreateFrame("Frame", nil, f)
    r:SetSize(10, 18)
    r.izq = r:CreateFontString(nil, "OVERLAY")
    r.izq:SetPoint("LEFT", 0, 0)
    r.izq:SetJustifyH("LEFT")
    r.der = r:CreateFontString(nil, "OVERLAY")
    r.der:SetPoint("RIGHT", 0, 0)
    r.der:SetJustifyH("RIGHT")
    filas[#filas + 1] = r
    return r
end

local function Tooltip(self)
    local e = self.e
    if not e then return end
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    if e.objeto then
        local ok = pcall(GameTooltip.SetItemByID, GameTooltip, e.objeto)
        if not ok then GameTooltip:SetText(S.NombreHechizo(e.s) or "?") end
    else
        local ok = pcall(GameTooltip.SetSpellByID, GameTooltip, e.s)
        if not ok then GameTooltip:SetText(S.NombreHechizo(e.s) or "?") end
    end
    if e.l then GameTooltip:AddLine("Nivel " .. e.l, 0.8, 0.8, 0.8) end
    if e.c then GameTooltip:AddLine("Precio: " .. (S.Dinero(e.c) or "?"), 1, 1, 1)
    elseif not e.mascota then GameTooltip:AddLine("Precio: lo sabrás al abrir tu entrenador", 0.7, 0.7, 0.7) end
    if e.mascota then GameTooltip:AddLine("Se enseña con Adiestramiento de bestias", 0.6, 0.9, 1) end
    if e.nuevo then GameTooltip:AddLine("Visto en tu entrenador (novedad de Forever)", 0.5, 1, 0.5) end
    GameTooltip:Show()
end

local function NuevoIcono()
    local b = CreateFrame("Button", nil, f)
    b:SetSize(32, 32)
    b.borde = b:CreateTexture(nil, "BACKGROUND")
    b.borde:SetPoint("TOPLEFT", -2, 2)
    b.borde:SetPoint("BOTTOMRIGHT", 2, -2)
    b.icono = b:CreateTexture(nil, "ARTWORK")
    b.icono:SetAllPoints()
    b.icono:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    b.precio = b:CreateFontString(nil, "OVERLAY")
    b.precio:SetPoint("TOP", b, "BOTTOM", 0, -2)
    b:SetScript("OnEnter", Tooltip)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    iconos[#iconos + 1] = b
    return b
end

local function NuevaChispa()
    local t = f:CreateTexture(nil, "OVERLAY")
    t:SetTexture("Interface\\Cooldown\\star4")
    t:SetBlendMode("ADD")
    t:Hide()
    chispas[#chispas + 1] = t
    return t
end

local function Cabecera(i)
    local c = cabeceras[i]
    if not c then
        c = f:CreateFontString(nil, "OVERLAY")
        c:SetJustifyH("LEFT")
        cabeceras[i] = c
    end
    return c
end

local function GuardarPosicion()
    local db = Opt()
    local p, _, rp, x, y = f:GetPoint()
    db.pos[db.disposicion] = { p or "CENTER", rp or "CENTER", math.floor((x or 0) + 0.5), math.floor((y or 0) + 0.5) }
end

local function Colocar()
    local db = Opt()
    local p = db.pos[db.disposicion] or (db.disposicion == "horizontal" and { "TOP", "TOP", 0, -90 } or { "CENTER", "CENTER", 0, 120 })
    f:ClearAllPoints()
    f:SetPoint(p[1], UIParent, p[2], p[3], p[4])
end

function S.Cerrar()
    if not f then return end
    f:Hide()
end

local function Crear()
    if f then return end
    f = S.mod:Frame("Frame", "CMSubidoorVentana", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    f:Hide()
    f:SetClampedToScreen(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(self) if not Opt().bloqueada then self:StartMoving() end end)
    f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing(); GuardarPosicion() end)
    f:SetScript("OnMouseUp", function(_, boton) if boton == "RightButton" and Opt().clicDerechoCierra then S.Cerrar() end end)
    f.fondo = f:CreateTexture(nil, "BACKGROUND", nil, -7)
    f.fondo:SetPoint("TOPLEFT", 4, -4)
    f.fondo:SetPoint("BOTTOMRIGHT", -4, 4)
    f.destello = f:CreateTexture(nil, "BACKGROUND", nil, 2)
    f.destello:SetAllPoints(f.fondo)
    f.destello:SetColorTexture(1, 0.9, 0.5, 1)
    f.destello:SetBlendMode("ADD")
    f.destello:SetAlpha(0)
    -- Adornos del tema: franja detrás del título, marca de agua, emblemas a los lados del título, esquinas.
    f.franja = f:CreateTexture(nil, "BACKGROUND", nil, -5)
    f.franja2 = f:CreateTexture(nil, "BACKGROUND", nil, -5)
    f.marca = f:CreateTexture(nil, "BACKGROUND", nil, -3)
    f.embI = f:CreateTexture(nil, "ARTWORK")
    f.embD = f:CreateTexture(nil, "ARTWORK")
    f.mascaras = {}
    for _, t in ipairs({ f.marca, f.embI, f.embD }) do
        pcall(function()
            local m = f:CreateMaskTexture()
            m:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
            m:SetAllPoints(t)
            f.mascaras[t] = m
        end)
    end
    f.esq = {}
    for i = 1, 4 do
        local e = f:CreateTexture(nil, "OVERLAY", nil, 1)
        e:SetTexture(S.mod.path .. "esquina")
        f.esq[i] = e
    end
    f.linea = f:CreateTexture(nil, "ARTWORK")
    f.linea:SetHeight(1)
    f.brillo = f:CreateTexture(nil, "BORDER")
    f.brillo:SetTexture("Interface\\Cooldown\\star4")
    f.brillo:SetBlendMode("ADD")
    f.titulo = f:CreateFontString(nil, "OVERLAY")
    f.sub = f:CreateFontString(nil, "OVERLAY")
    f.tiempo = f:CreateFontString(nil, "OVERLAY")
    f.tiempo:SetJustifyH("CENTER")
    f.mas = f:CreateFontString(nil, "OVERLAY")
    -- Retrato 2D con máscara redonda, o modelo 3D.
    f.retrato = f:CreateTexture(nil, "ARTWORK")
    pcall(function()
        local m = f:CreateMaskTexture()
        m:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
        m:SetAllPoints(f.retrato)
        f.retrato:AddMaskTexture(m)
    end)
    f.aro = f:CreateTexture(nil, "OVERLAY")
    f.aro:SetTexture(S.mod.path .. "aro")   -- anillo propio, centrado (aro.tga)
    f.modelo = CreateFrame("PlayerModel", nil, f)
    -- Botones: cerrar y fijar (que no se cierre sola).
    f.cerrar = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    f.cerrar:SetPoint("TOPRIGHT", -2, -2)
    f.cerrar:SetScript("OnClick", S.Cerrar)
    f.fijar = CreateFrame("CheckButton", nil, f, "UICheckButtonTemplate")
    f.fijar:SetSize(22, 22)
    f.fijar:SetPoint("TOPLEFT", 6, -6)
    f.fijar:SetScript("OnClick", function(self) f.fijada = self:GetChecked() and true or false end)
    f.fijar:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT"); GameTooltip:SetText("Fijar: que no se cierre sola"); GameTooltip:Show()
    end)
    f.fijar:SetScript("OnLeave", function() GameTooltip:Hide() end)
    f:SetScript("OnHide", function()
        anim = nil
        for _, c in ipairs(chispas) do c:Hide() end
        if f.modelo then f.modelo:Hide() end
    end)
end

function S.VentanaAbierta() return f and f:IsShown() or false end

----------------------------------------------------------------------
-- Selector de temas para la configuración: una ficha por tema con sus colores y su emblema.
-- get() -> clave del tema ; set(clave). Devuelve el marco (con .alto y :Refresh()).
----------------------------------------------------------------------
function S.SelectorTemas(parent, x, y, ancho, get, set)
    local ANCHO_F, ALTO_F, HUECO = 124, 40, 6
    local cols = math.max(1, math.floor((ancho + HUECO) / (ANCHO_F + HUECO)))
    local cont = CreateFrame("Frame", nil, parent)
    cont:SetPoint("TOPLEFT", x, y)
    local filas = math.ceil(#S.TEMAS / cols)
    cont.alto = filas * (ALTO_F + HUECO)
    cont:SetSize(cols * (ANCHO_F + HUECO), cont.alto)
    cont.fichas = {}
    for i, def in ipairs(S.TEMAS) do
        local clave = def[1]
        local b = CreateFrame("Button", nil, cont, BackdropTemplateMixin and "BackdropTemplate" or nil)
        b:SetSize(ANCHO_F, ALTO_F)
        b:SetPoint("TOPLEFT", ((i - 1) % cols) * (ANCHO_F + HUECO), -math.floor((i - 1) / cols) * (ALTO_F + HUECO))
        b.fondo = b:CreateTexture(nil, "BACKGROUND")
        b.fondo:SetPoint("TOPLEFT", 3, -3); b.fondo:SetPoint("BOTTOMRIGHT", -3, 3)
        b.emb = b:CreateTexture(nil, "ARTWORK")
        b.emb:SetSize(26, 26); b.emb:SetPoint("LEFT", 6, 0)
        b.nombre = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        b.nombre:SetPoint("LEFT", 36, 0); b.nombre:SetPoint("RIGHT", -4, 0)
        b.nombre:SetJustifyH("LEFT")
        b.marca = b:CreateTexture(nil, "OVERLAY")
        b.marca:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
        b.marca:SetSize(20, 20); b.marca:SetPoint("TOPRIGHT", 4, 6)
        b.luz = b:CreateTexture(nil, "HIGHLIGHT")
        b.luz:SetAllPoints(b.fondo); b.luz:SetColorTexture(1, 1, 1, 0.12)
        b:SetScript("OnClick", function() set(clave); cont:Refresh() end)
        b:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(def[2])
            if clave == "clase" then GameTooltip:AddLine("Usa el tema de la clase de cada personaje.", 1, 1, 1, true) end
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
        b.Pintar = function()
            local t = S.Tema(clave)
            local c1, c2, bo = t.fondo, t.fondo2, t.borde
            local ok = pcall(function()
                b.fondo:SetColorTexture(1, 1, 1, 1)
                b.fondo:SetGradient("VERTICAL", CreateColor(c1[1], c1[2], c1[3], 1), CreateColor(c2[1], c2[2], c2[3], 1))
            end)
            if not ok then b.fondo:SetColorTexture(c2[1], c2[2], c2[3], 1) end
            if b.SetBackdrop then
                b:SetBackdrop({ edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12,
                                insets = { left = 3, right = 3, top = 3, bottom = 3 } })
                b:SetBackdropBorderColor(bo[1], bo[2], bo[3], 1)
            end
            if t.marca then
                local tex = t.marca
                local okT = b.emb:SetTexture(tex.tex)
                local co = tex.coord
                if okT == false and tex.res then b.emb:SetTexture(tex.res); co = tex.resCoord end
                if co then b.emb:SetTexCoord(co[1], co[2], co[3], co[4]) else b.emb:SetTexCoord(0.08, 0.92, 0.08, 0.92) end
                b.emb:Show()
                b.nombre:SetPoint("LEFT", 36, 0)
            else
                b.emb:Hide()
                b.nombre:SetPoint("LEFT", 8, 0)
            end
            b.nombre:SetText(clave == "clase" and "Mi clase (auto)" or (def[2]:gsub("^Clase: ", "")))
            b.nombre:SetTextColor(t.acento[1], t.acento[2], t.acento[3])
        end
        cont.fichas[#cont.fichas + 1] = { b, clave }
    end
    function cont:Refresh()
        local actual = get()
        for _, par in ipairs(self.fichas) do
            par[1].Pintar()
            par[1].marca:SetShown(par[2] == actual)
        end
    end
    cont:Refresh()
    return cont
end

----------------------------------------------------------------------
-- Maquetación
----------------------------------------------------------------------
local function TextoValor(st)
    local db = Opt()
    if st.k == "talentos" then return ("|cff%s+%d|r"):format("33ff66", st.d) end
    local function Num(v) return st.pct and ("%.2f%%"):format(v) or tostring(math.floor(v + 0.5)) end
    local g = st.d - (st.a or 0)
    local gr, gg, gb = S.Color("ganancia")
    local verde = ("%02x%02x%02x"):format(gr * 255, gg * 255, gb * 255)
    local signo = g >= 0 and "+" or ""
    local gan = st.pct and ("%s%.2f%%"):format(signo, g) or (signo .. math.floor(g + 0.5))
    if db.soloGanancia or not st.a then return ("|cff%s%s|r"):format(verde, gan) end
    return ("%s  »  %s  |cff%s(%s)|r"):format(Num(st.a), Num(st.d), verde, gan)
end

-- Coloca una rejilla de iconos desde (x, y) en un ancho; devuelve la y final.
local function Rejilla(lista, x, y, ancho, usados)
    local db = Opt()
    local tam = db.disposicion == "compacta" and math.floor(db.tamIcono * 0.75) or db.tamIcono
    local hueco = db.mostrarCostes and 18 or 6
    local cols = math.max(1, math.floor((ancho + 6) / (tam + 6)))
    local maxi = math.min(#lista, db.maxIconos)
    local hr, hg, hb = S.Color("habilidad")
    for i = 1, maxi do
        local e = lista[i]
        usados.n = usados.n + 1
        local b = iconos[usados.n] or NuevoIcono()
        b.e = e
        b:SetSize(tam, tam)
        local col, fila = (i - 1) % cols, math.floor((i - 1) / cols)
        b:ClearAllPoints()
        b:SetPoint("TOPLEFT", f, "TOPLEFT", x + col * (tam + 6), y - fila * (tam + hueco))
        b.icono:SetTexture(e.objeto and (GetItemIcon and GetItemIcon(e.objeto)) or S.IconoHechizo(e.s))
        b.borde:SetColorTexture(hr, hg, hb, db.destacarNuevas and e.nuevo and 1 or 0.8)
        PonerFuente(b.precio, math.max(8, db.tamTexto - 3))
        b.precio:SetText(db.mostrarCostes and e.c and S.Dinero(e.c) or "")
        b.precio:SetShown(db.mostrarCostes)
        b:EnableMouse(not db.atravesable)
        b.base = { x + col * (tam + 6), y - fila * (tam + hueco) }
        b:Show()
    end
    local filasN = math.ceil(maxi / cols)
    local fin = y - filasN * (tam + hueco)
    if #lista > maxi then
        f.mas:SetText(("y %d más..."):format(#lista - maxi))
        f.mas:ClearAllPoints()
        f.mas:SetPoint("TOPLEFT", f, "TOPLEFT", x, fin)
        f.mas:Show()
        fin = fin - 14
    end
    return fin
end

-- Pone el emblema del tema en una textura: textura del juego con su recorte, otra de repuesto si
-- el cliente no la trae, y máscara redonda para los iconos cuadrados.
local function PonerMarca(t, marca)
    local ok = t:SetTexture(marca.tex)
    local coord = marca.coord
    if ok == false and marca.res then
        t:SetTexture(marca.res)
        coord = marca.resCoord
    end
    if coord then t:SetTexCoord(coord[1], coord[2], coord[3], coord[4]) else t:SetTexCoord(0, 1, 0, 1) end
    local m = f.mascaras[t]
    if m then
        pcall(t.RemoveMaskTexture, t, m)
        if marca.redonda then pcall(t.AddMaskTexture, t, m) end
    end
end

-- Adornos del tema (todos se pueden apagar en la configuración).
local function Adornos(tema, borde, compacta)
    local db = Opt()
    local marca = tema.marca
    -- Marca de agua grande y tenue, centrada.
    if marca and db.marcaAgua then
        PonerMarca(f.marca, marca)
        f.marca:ClearAllPoints()
        f.marca:SetPoint("CENTER", f, "CENTER", 0, 0)
        f.marca:SetAlpha(db.opacidadMarca)
        f.marca:Show()
    else
        f.marca:Hide()
    end
    -- Emblemas pequeños a los lados del título.
    local tamEmb = math.floor(db.tamTitulo * 1.5)
    for i, t in ipairs({ f.embI, f.embD }) do
        if marca and db.emblemaTitulo and not compacta then
            PonerMarca(t, marca)
            t:SetSize(tamEmb, tamEmb)
            t:ClearAllPoints()
            if i == 1 then t:SetPoint("RIGHT", f.titulo, "LEFT", -8, 0) else t:SetPoint("LEFT", f.titulo, "RIGHT", 8, 0) end
            t:SetAlpha(1)
            t:Show()
        else
            t:Hide()
        end
    end
    -- Franja de color detrás del título, que se difumina hacia los lados.
    local fr = tema.franja
    if fr and db.franja then
        local a = 0.55 * db.opacidad
        for i, t in ipairs({ f.franja, f.franja2 }) do
            t:ClearAllPoints()
            t:SetPoint("TOP", f.titulo, "TOP", 0, 6)
            t:SetPoint("BOTTOM", f.sub, "BOTTOM", 0, -6)
            if i == 1 then t:SetPoint("LEFT", f, "LEFT", 4, 0); t:SetPoint("RIGHT", f, "CENTER", 0, 0)
            else t:SetPoint("LEFT", f, "CENTER", 0, 0); t:SetPoint("RIGHT", f, "RIGHT", -4, 0) end
            local okG = pcall(function()
                t:SetColorTexture(1, 1, 1, 1)
                local c0, c1 = CreateColor(fr[1], fr[2], fr[3], 0), CreateColor(fr[1], fr[2], fr[3], a)
                if i == 1 then t:SetGradient("HORIZONTAL", c0, c1) else t:SetGradient("HORIZONTAL", c1, c0) end
            end)
            if not okG then t:SetColorTexture(fr[1], fr[2], fr[3], a * 0.6) end
            t:Show()
        end
    else
        f.franja:Hide(); f.franja2:Hide()
    end
    -- Adornos en las esquinas, con el color del borde.
    local tamEsq = compacta and 28 or 40
    local puntos = { { "TOPLEFT", 3, -3, 0, 1, 0, 1 }, { "TOPRIGHT", -3, -3, 1, 0, 0, 1 },
                     { "BOTTOMLEFT", 3, 3, 0, 1, 1, 0 }, { "BOTTOMRIGHT", -3, 3, 1, 0, 1, 0 } }
    for i, e in ipairs(f.esq) do
        if tema.esquinas and db.esquinas then
            local p = puntos[i]
            e:ClearAllPoints()
            e:SetPoint(p[1], f, p[1], p[2], p[3])
            e:SetSize(tamEsq, tamEsq)
            e:SetTexCoord(p[4], p[5], p[6], p[7])
            e:SetVertexColor(borde[1], borde[2], borde[3], 0.9)
            e:Show()
        else
            e:Hide()
        end
    end
end

local function Maquetar(info)
    local db, tema = Opt(), S.Tema()
    local disp = db.disposicion
    local compacta = disp == "compacta"
    local escalaTexto = compacta and 0.85 or 1
    local pad = 16
    -- Fondo y borde del tema (o colores propios).
    local fondo, fondo2, borde = tema.fondo, tema.fondo2, tema.borde
    if db.fondoPropio then fondo, fondo2, borde = db.colores.fondo, db.colores.fondo2, db.colores.borde end
    if f.SetBackdrop then
        f:SetBackdrop({ bgFile = tema.tex, edgeFile = tema.edge or "Interface\\Tooltips\\UI-Tooltip-Border",
                        tile = tema.tex ~= nil, tileSize = 32, edgeSize = tema.edgeSize or 14,
                        insets = { left = 4, right = 4, top = 4, bottom = 4 } })
        f:SetBackdropBorderColor(borde[1], borde[2], borde[3], 1)
        f:SetBackdropColor(0, 0, 0, tema.tex and db.opacidad or 0)
    end
    f.fondo:SetShown(tema.tex == nil or db.fondoPropio)
    local okGrad = pcall(function()
        f.fondo:SetColorTexture(1, 1, 1, 1)
        f.fondo:SetGradient("VERTICAL", CreateColor(fondo[1], fondo[2], fondo[3], db.opacidad),
                            CreateColor(fondo2[1], fondo2[2], fondo2[3], db.opacidad))
    end)
    if not okGrad then f.fondo:SetColorTexture(fondo[1], fondo[2], fondo[3], db.opacidad) end
    Adornos(tema, borde, compacta)
    f.linea:SetColorTexture(S.Color("cabecera"))
    f.linea:SetAlpha(0.5)
    f:SetFrameStrata(db.estrato)
    f:SetScale(db.escala)
    f:EnableMouse(not db.atravesable)
    f.cerrar:SetShown(not db.atravesable)
    f.fijar:SetShown(not db.atravesable)
    f.fijar:SetChecked(f.fijada or false)

    for _, r in ipairs(filas) do r:Hide() end
    for _, b in ipairs(iconos) do b:Hide() end
    for _, c in ipairs(cabeceras) do c:Hide() end
    f.mas:Hide()
    PonerFuente(f.mas, math.max(8, db.tamTexto - 2))

    local anchoTotal = disp == "horizontal" and db.anchoHorizontal or (compacta and 300 or db.anchoVertical)
    local tamRetrato = compacta and 0 or (db.retrato == "ninguno" and 0 or db.tamRetrato)
    -- Modelo 3D de cuerpo entero: más alto que ancho. Cara (2D o 3D): cuadrado.
    local cuerpo = db.retrato == "3d" and db.encuadre == "cuerpo"
    local anchoRet = cuerpo and math.floor(tamRetrato * 1.5) or tamRetrato
    local altoRet = cuerpo and math.floor(tamRetrato * 2.6) or tamRetrato
    -- Columnas: vertical/compacta = una; horizontal = retrato | estadísticas | habilidades.
    local colX, colY, colAncho = {}, {}, {}
    local y = -pad
    -- Título y subtítulo.
    PonerFuente(f.titulo, math.floor(db.tamTitulo * escalaTexto))
    PonerFuente(f.sub, math.floor(db.tamTexto * escalaTexto))
    local titulo
    if info.maximo and db.celebrarMaximo then titulo = "¡NIVEL MÁXIMO!"
    elseif info.hasta - info.desde > 1 then titulo = ("¡NIVELES %d-%d!"):format(info.desde + 1, info.hasta)
    else titulo = ("¡NIVEL %d!"):format(info.hasta) end
    if info.hito and db.efectoHito and not info.maximo then titulo = "¡HITO! " .. titulo end
    f.titulo:SetText(titulo)
    f.titulo:SetTextColor(S.Color("titulo"))
    local clase = (LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[info.clase]) or info.clase or ""
    f.sub:SetText(("%s · %s%s"):format(info.nombre or "", clase, info.prueba and "  |cff999999(vista previa)|r" or (info.reconstruida and "  |cff999999(rehecha)|r" or "")))
    if db.coloresClase then f.sub:SetTextColor(S.ColorClase(info.clase)) else f.sub:SetTextColor(S.Color("nombre")) end

    local xRet, yCuerpo
    if disp == "horizontal" then
        f.titulo:ClearAllPoints(); f.titulo:SetPoint("TOP", f, "TOP", 0, y)
        y = y - db.tamTitulo - 4
        f.sub:ClearAllPoints(); f.sub:SetPoint("TOP", f, "TOP", 0, y)
        y = y - db.tamTexto - 10
        xRet = pad
        local xStats = pad + (tamRetrato > 0 and anchoRet + 14 or 0)
        local anchoStats = math.floor((anchoTotal - xStats - pad) * 0.42)
        colX = { xStats, xStats + anchoStats + 18 }
        colAncho = { anchoStats, anchoTotal - (xStats + anchoStats + 18) - pad }
        colY = { y, y }
        yCuerpo = y
    else
        if tamRetrato > 0 then
            xRet = (anchoTotal - anchoRet) / 2
            yCuerpo = y
            y = y - altoRet - 8
        end
        f.titulo:ClearAllPoints(); f.titulo:SetPoint("TOP", f, "TOP", 0, y)
        y = y - math.floor(db.tamTitulo * escalaTexto) - 4
        f.sub:ClearAllPoints(); f.sub:SetPoint("TOP", f, "TOP", 0, y)
        y = y - math.floor(db.tamTexto * escalaTexto) - 10
        colX, colAncho, colY = { pad, pad }, { anchoTotal - 2 * pad, anchoTotal - 2 * pad }, { y, nil }
    end
    f.linea:ClearAllPoints()
    f.linea:SetPoint("TOPLEFT", f, "TOPLEFT", pad, (disp == "horizontal" and yCuerpo or colY[1]) + 5)
    f.linea:SetPoint("TOPRIGHT", f, "TOPRIGHT", -pad, (disp == "horizontal" and yCuerpo or colY[1]) + 5)
    -- Brillo detrás del título.
    f.brillo:ClearAllPoints()
    f.brillo:SetPoint("CENTER", f.titulo, "CENTER")
    f.brillo:SetSize(db.tamTitulo * 6, db.tamTitulo * 2.2)
    f.brillo:SetVertexColor(S.Color("titulo"))
    f.brillo:SetShown(db.animaciones and db.brillo and not db.modoClasico)

    -- Retrato.
    f.retrato:Hide(); f.aro:Hide(); f.modelo:Hide()
    if tamRetrato > 0 then
        local ry = yCuerpo
        if db.retrato == "3d" then
            f.modelo:ClearAllPoints()
            f.modelo:SetPoint("TOPLEFT", f, "TOPLEFT", xRet, ry)
            f.modelo:SetSize(anchoRet, altoRet)
            pcall(f.modelo.SetUnit, f.modelo, "player")
            pcall(f.modelo.SetPortraitZoom, f.modelo, cuerpo and 0 or 1)
            if cuerpo then pcall(f.modelo.SetCamDistanceScale, f.modelo, db.distanciaModelo) end
            pcall(f.modelo.SetFacing, f.modelo, 0)
            f.modelo:Show()
        else
            f.retrato:ClearAllPoints()
            f.retrato:SetPoint("TOPLEFT", f, "TOPLEFT", xRet, ry)
            f.retrato:SetSize(tamRetrato, tamRetrato)
            pcall(SetPortraitTexture, f.retrato, "player")
            f.retrato:Show()
        end
        -- Aro centrado sobre la cara (no con el cuerpo entero, que no es redondo).
        if db.aro and not cuerpo then
            f.aro:ClearAllPoints()
            f.aro:SetPoint("CENTER", db.retrato == "3d" and f.modelo or f.retrato, "CENTER", 0, 0)
            f.aro:SetSize(tamRetrato * 1.16, tamRetrato * 1.16)
            f.aro:SetVertexColor(S.Color("aro"))
            f.aro:Show()
        end
    end

    local nCab = 0
    local function PonCabecera(texto, col)
        nCab = nCab + 1
        local c = Cabecera(nCab)
        PonerFuente(c, math.floor(db.tamCabecera * escalaTexto))
        c:SetTextColor(S.Color("cabecera"))
        c:SetText(texto)
        c:ClearAllPoints()
        c:SetPoint("TOPLEFT", f, "TOPLEFT", colX[col], colY[col])
        c:Show()
        colY[col] = colY[col] - math.floor(db.tamCabecera * escalaTexto) - 6
    end

    -- Estadísticas.
    local nFila = 0
    local function PonFila(st, col, orden)
        nFila = nFila + 1
        local r = filas[nFila] or NuevaFila()
        PonerFuente(r.izq, math.floor(db.tamTexto * escalaTexto))
        PonerFuente(r.der, math.floor(db.tamTexto * escalaTexto))
        r.izq:SetText(st.t)
        r.izq:SetTextColor(S.Color("etiqueta"))
        r.der:SetText(TextoValor(st))
        r.der:SetTextColor(S.Color("valor"))
        r:SetSize(colAncho[col], math.floor(db.tamTexto * escalaTexto) + 4)
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", f, "TOPLEFT", colX[col], colY[col])
        r.base = { colX[col], colY[col] }
        r.st, r.orden = st, orden
        r:Show()
        colY[col] = colY[col] - math.floor(db.tamTexto * escalaTexto) - 5
    end
    local orden = 0
    if db.mostrarStats and #info.stats > 0 then
        if not compacta then PonCabecera("Estadísticas", 1) end
        for _, st in ipairs(info.stats) do orden = orden + 1; PonFila(st, 1, orden) end
    end
    if db.mostrarSecundarias and #info.sec > 0 then
        colY[1] = colY[1] - 4
        PonCabecera("Secundarias", 1)
        for _, st in ipairs(info.sec) do orden = orden + 1; PonFila(st, 1, orden) end
    end
    -- Habilidades (en vertical van debajo de las estadísticas).
    local col = disp == "horizontal" and 2 or 1
    if disp ~= "horizontal" then colY[1] = colY[1] - 6 end
    local usados = { n = 0 }
    local function Seccion(titulo, lista)
        if #lista == 0 then return end
        PonCabecera(titulo, col)
        colY[col] = Rejilla(lista, colX[col], colY[col], colAncho[col], usados) - 6
    end
    if db.mostrarHabilidades then
        if #info.habilidades > 0 then
            Seccion(("Te falta aprender en tu entrenador (%d)"):format(#info.habilidades), info.habilidades)
        elseif db.avisarAlDia then
            PonCabecera("Entrenador: lo tienes todo al día", col)
        end
    end
    Seccion("Armas que puedes aprender", info.armas or {})
    Seccion("Grimorios nuevos para tu demonio", info.grimorios or {})
    Seccion("Nuevas habilidades de mascota", info.mascota or {})
    if info.proximos and #info.proximos > 0 then
        for _, p in ipairs(info.proximos) do Seccion(("Nivel %d"):format(p.nivel), p.lista) end
    end
    -- Tiempo en el nivel.
    local yFin = math.min(colY[1], colY[2] or colY[1])
    f.tiempo:Hide()
    if db.mostrarTiempo and info.tiempo then
        PonerFuente(f.tiempo, math.floor(db.tamTexto * escalaTexto))
        local txt = ("Nivel %d en %s"):format(info.hasta - 1, S.Duracion(info.tiempo))
        if info.esRecord and info.recordAnterior then
            txt = txt .. ("  |cff33ff66¡Récord! (antes %s)|r"):format(S.Duracion(info.recordAnterior))
        elseif info.recordAnterior then
            txt = txt .. ("  |cffaaaaaaRécord: %s%s|r"):format(S.Duracion(info.recordAnterior),
                info.recordDe and info.recordDe ~= info.nombre and (" (" .. info.recordDe .. ")") or "")
        end
        f.tiempo:SetText(txt)
        f.tiempo:SetTextColor(S.Color("tiempo"))
        f.tiempo:ClearAllPoints()
        f.tiempo:SetPoint("TOP", f, "TOP", 0, yFin - 2)
        f.tiempo:Show()
        yFin = yFin - db.tamTexto - 8
    end
    local alto = -yFin + pad - 4
    if disp == "horizontal" and tamRetrato > 0 then alto = math.max(alto, -yCuerpo + altoRet + pad) end
    f:SetSize(anchoTotal, math.max(alto, 120))
    local altoF = math.max(alto, 120)
    f.marca:SetSize(math.min(anchoTotal, altoF) * 0.85, math.min(anchoTotal, altoF) * 0.85)
end

----------------------------------------------------------------------
-- Animación (un solo OnUpdate mientras la ventana está abierta)
----------------------------------------------------------------------
local function Suave(x) return 1 - (1 - x) * (1 - x) end

local function Lanzar(n, fuerte)
    local db = Opt()
    local w, h = f:GetWidth(), f:GetHeight()
    for i = 1, n do
        local c = chispas[i] or NuevaChispa()
        local tam = (db.tamChispa or 16) * (0.6 + math.random() * 0.8) * (fuerte and 1.4 or 1)
        c:SetSize(tam, tam)
        c:SetVertexColor(S.Color("chispas"))
        c.x0, c.y0 = math.random() * w, -h * (0.55 + math.random() * 0.45)
        c.vx, c.vy = (math.random() - 0.5) * 40, 40 + math.random() * 70 * (fuerte and 1.6 or 1)
        c.vida, c.t = 1.2 + math.random() * 1.6, -math.random() * 0.8
        c:ClearAllPoints()
        c:SetPoint("CENTER", f, "TOPLEFT", c.x0, c.y0)
        c:SetAlpha(0)
        c:Show()
    end
end

local function Paso(_, dt)
    if not anim then return end
    local db = Opt()
    local vel = db.velocidad
    anim.t = anim.t + dt * vel
    local t = anim.t
    local clasico = db.modoClasico or not db.animaciones
    -- Aparición.
    local ap = math.min(1, t / 0.35)
    f:SetAlpha(anim.cerrando and math.max(0, 1 - (t - anim.cerrando) / 0.5) or Suave(ap))
    if not clasico and db.escalaEntrada then f:SetScale(db.escala * (0.88 + 0.12 * Suave(ap))) end
    if anim.cerrando and t - anim.cerrando >= 0.5 then S.Cerrar(); return end
    if not clasico then
        -- Filas de estadísticas: entran una a una, alternando lado, y su número sube.
        for _, r in ipairs(filas) do
            if r:IsShown() and r.orden then
                local p = math.max(0, math.min(1, (t - 0.25 - r.orden * 0.08) / 0.35))
                local lado = r.orden % 2 == 0 and 1 or -1
                r:SetAlpha(p)
                r:ClearAllPoints()
                r:SetPoint("TOPLEFT", f, "TOPLEFT", r.base[1] + lado * 24 * (1 - Suave(p)), r.base[2])
                if db.contadores and r.st and r.st.a and r.st.k ~= "talentos" then
                    local q = math.max(0, math.min(1, (t - 0.4 - r.orden * 0.08) / 0.7))
                    local v = r.st.a + (r.st.d - r.st.a) * Suave(q)
                    r.der:SetText(TextoValor({ k = r.st.k, a = r.st.a, d = v, pct = r.st.pct }))
                end
            end
        end
        -- Iconos: aparecen en cascada.
        local i = 0
        for _, b in ipairs(iconos) do
            if b:IsShown() then
                i = i + 1
                local p = math.max(0, math.min(1, (t - 0.6 - i * 0.05) / 0.25))
                b:SetAlpha(p)
                if db.destacarNuevas then b.borde:SetAlpha(0.6 + 0.4 * math.abs(math.sin((t - i * 0.1) * 2.5))) end
            end
        end
        -- Brillo del título y destello de hito.
        if f.brillo:IsShown() then f.brillo:SetAlpha(0.25 + 0.2 * math.sin(t * 3)) end
        if anim.destello then f.destello:SetAlpha(math.max(0, 0.45 * (1 - t / 0.9))) end
        -- Chispas.
        for _, c in ipairs(chispas) do
            if c:IsShown() then
                c.t = c.t + dt * vel
                if c.t > 0 then
                    local k = c.t / c.vida
                    if k >= 1 then
                        if anim.cerrando or t > db.duracion * 0.8 then c:Hide() else
                            c.t, c.x0 = 0, math.random() * f:GetWidth()
                        end
                    else
                        c:ClearAllPoints()
                        c:SetPoint("CENTER", f, "TOPLEFT", c.x0 + c.vx * c.t, c.y0 + c.vy * c.t)
                        c:SetAlpha(math.sin(k * math.pi) * (db.opacidadChispas or 0.8))
                    end
                end
            end
        end
    end
    -- Modelo 3D: se balancea despacio (opcional).
    if f.modelo:IsShown() and db.girarModelo then
        pcall(f.modelo.SetFacing, f.modelo, math.sin(t * 0.6) * 0.45)
    end
    -- Cierre automático (no con el ratón encima si así se quiere, ni fijada).
    if not anim.cerrando and not f.fijada and db.duracion > 0 and t >= db.duracion then
        if not (db.pausaRaton and f:IsMouseOver()) then anim.cerrando = t end
    end
end

function S.Ventana(info)
    Crear()
    actual = info
    f.fijada = Opt().fijarSiempre or false
    Colocar()
    Maquetar(info)
    local db = Opt()
    local clasico = db.modoClasico or not db.animaciones
    for _, r in ipairs(filas) do if r:IsShown() then r:SetAlpha(clasico and 1 or 0) end end
    for _, b in ipairs(iconos) do if b:IsShown() then b:SetAlpha(clasico and 1 or 0) end end
    for _, c in ipairs(chispas) do c:Hide() end
    anim = { t = 0, destello = (info.hito or info.maximo) and db.efectoHito and not clasico }
    f.destello:SetAlpha(0)
    if not clasico and db.chispas then
        local n = db.numChispas
        if (info.hito or info.maximo) and db.efectoHito then n = math.floor(n * 1.8) end
        Lanzar(n, info.hito or info.maximo)
    end
    f:SetAlpha(0)
    f:SetScript("OnUpdate", Paso)
    f:Show()
end

-- Lo que acompaña a la ventana: sonido, mensaje en el chat, captura de pantalla, ocultar el aviso del juego.
function S.Efectos(info)
    local db = Opt()
    S.Sonar()
    if db.mensajeChat and not info.prueba then
        local c = db.colorChat
        local txt = (db.textoChat or ""):gsub("%%d", tostring(info.hasta)):gsub("%%n", info.nombre or "")
        DEFAULT_CHAT_FRAME:AddMessage(txt, c[1], c[2], c[3])
    end
    if not info.prueba and (db.capturaCada or (db.capturaHitos and (info.hito or info.maximo))) and Screenshot then
        C_Timer.After(db.esperaCaptura, function() pcall(Screenshot) end)
    end
end

-- Aviso propio del juego al subir: se esconde si así se quiere (solo un rato tras subir).
local ocultarHasta = 0
local enganchados = {}
local function Esconder(frame)
    if S.mod:IsEnabled() and Opt().ocultarJuego and GetTime() < ocultarHasta then frame:Hide() end
end
function S.OcultarAvisoJuego()
    if not Opt().ocultarJuego then return end
    ocultarHasta = GetTime() + 8
    for _, nombre in ipairs({ "LevelUpDisplay", "EventToastManagerFrame" }) do
        local frame = _G[nombre]
        if frame and frame.HookScript then
            if not enganchados[nombre] then
                enganchados[nombre] = true
                frame:HookScript("OnShow", Esconder)
            end
            if frame:IsShown() then frame:Hide() end
        end
    end
end

function S.RefrescarVentana()
    if f and f:IsShown() and actual then
        Colocar()
        Maquetar(actual)
    end
end
