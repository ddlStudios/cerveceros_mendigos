-- Subidoor: núcleo. Estadísticas antes/después de subir, lo que te falta del entrenador, escaneo del
-- entrenador, tiempo jugado por nivel, récords e historial. Código propio de CervecerosMendigos.
-- Los datos de hechizos están en Datos.lua (tablas del cliente de WoW Forever; ver subidoor_datos.py).
local ADDON, ns = ...
ns.Subidoor = ns.Subidoor or {}
local S = ns.Subidoor
local D = ns.SubidoorDatos
-- Cliente moderno: en combate algunas funciones devuelven valores «secretos» que no se pueden
-- comparar ni sumar. Se tratan como desconocidos.
local issecret = issecretvalue or function() return false end
local function Num(v) if type(v) ~= "number" or issecret(v) then return nil end return v end

----------------------------------------------------------------------
-- Utilidades
----------------------------------------------------------------------
-- Y binario de 32 bits (bit.band en el juego; repliegue aritmético por si no existe).
local function Band(a, b)
    if bit and bit.band then return bit.band(a, b) end
    a, b = a % 4294967296, b % 4294967296
    local r, p = 0, 1
    for _ = 1, 32 do
        if a % 2 == 1 and b % 2 == 1 then r = r + p end
        a, b, p = math.floor(a / 2), math.floor(b / 2), p * 2
    end
    return r
end
S.Band = Band

S.CLASE_BIT = { WARRIOR = 1, PALADIN = 2, HUNTER = 4, ROGUE = 8, PRIEST = 16, SHAMAN = 64, MAGE = 128,
                WARLOCK = 256, DRUID = 1024 }

function S.MiClase()
    local _, clase = UnitClass("player")
    return clase
end

-- Bit de la raza del jugador (ChrRaces: 1 humano, 2 orco, 3 enano...): 2^(id-1).
function S.MiRazaBit()
    local _, _, id = UnitRace("player")
    if type(id) ~= "number" or id < 1 then return nil end
    return 2 ^ (id - 1)
end

local function RazaValida(mascara)
    if not mascara then return true end
    local b = S.MiRazaBit()
    if not b then return true end
    return Band(mascara, b) ~= 0
end

function S.Conocido(id, mascota)
    if not id then return false end
    if mascota then
        if IsSpellKnown then
            local ok, v = pcall(IsSpellKnown, id, true)
            if ok and v then return true end
        end
        return false
    end
    if IsPlayerSpell then
        local ok, v = pcall(IsPlayerSpell, id)
        if ok and v then return true end
    end
    if IsSpellKnown then
        local ok, v = pcall(IsSpellKnown, id)
        if ok and v then return true end
    end
    if C_SpellBook and C_SpellBook.IsSpellKnown then
        local ok, v = pcall(C_SpellBook.IsSpellKnown, id)
        if ok and v then return true end
    end
    return false
end

function S.NombreHechizo(id)
    local n
    if C_Spell and C_Spell.GetSpellName then n = C_Spell.GetSpellName(id) end
    if not n and GetSpellInfo then n = GetSpellInfo(id) end
    return n
end

function S.RangoHechizo(id)
    local r
    if C_Spell and C_Spell.GetSpellSubtext then r = C_Spell.GetSpellSubtext(id) end
    if not r and GetSpellSubtext then r = GetSpellSubtext(id) end
    return r
end

function S.IconoHechizo(id)
    local t
    if C_Spell and C_Spell.GetSpellTexture then t = C_Spell.GetSpellTexture(id) end
    if not t and GetSpellTexture then t = GetSpellTexture(id) end
    return t or 134400   -- interrogación
end

function S.Dinero(cobre)
    if not cobre then return nil end
    if GetCoinTextureString then
        local ok, txt = pcall(GetCoinTextureString, cobre)
        if ok and txt then return txt end
    end
    local o, p, c = math.floor(cobre / 10000), math.floor(cobre / 100) % 100, cobre % 100
    local t = {}
    if o > 0 then t[#t + 1] = o .. "o" end
    if p > 0 then t[#t + 1] = p .. "p" end
    if c > 0 or #t == 0 then t[#t + 1] = c .. "c" end
    return table.concat(t, " ")
end

function S.Duracion(seg)
    if not seg then return "?" end
    seg = math.floor(seg + 0.5)
    local h, m, s = math.floor(seg / 3600), math.floor(seg / 60) % 60, seg % 60
    if h > 0 then return ("%d h %02d min"):format(h, m) end
    if m > 0 then return ("%d min %02d s"):format(m, s) end
    return ("%d s"):format(s)
end

----------------------------------------------------------------------
-- Estadísticas
----------------------------------------------------------------------
local PODER = { MANA = "Maná", RAGE = "Ira", ENERGY = "Energía", FOCUS = "Concentración" }
S.ETIQUETAS = { salud = "Salud", poder = "Maná", fue = "Fuerza", agi = "Agilidad", agu = "Aguante",
                int = "Intelecto", esp = "Espíritu", talentos = "Puntos de talento" }
S.ORDEN_PRINCIPALES = { "salud", "poder", "fue", "agi", "agu", "int", "esp" }
-- Secundarias: clave, etiqueta, función que da el valor, si es porcentaje.
S.SECUNDARIAS = {
    { "armadura", "Armadura", function() local _, e = UnitArmor("player"); return e end },
    { "pa", "Poder de ataque", function() local b, p, n = UnitAttackPower("player"); return (b or 0) + (p or 0) + (n or 0) end },
    { "pad", "Poder de ataque a distancia", function() local b, p, n = UnitRangedAttackPower("player"); return (b or 0) + (p or 0) + (n or 0) end },
    { "crit", "Golpe crítico", function() return GetCritChance() end, true },
    { "critd", "Crítico a distancia", function() return GetRangedCritChance() end, true },
    { "crith", "Crítico con hechizos", function() return GetSpellCritChance(2) end, true },
    { "esquivar", "Esquivar", function() return GetDodgeChance() end, true },
    { "parar", "Parada", function() return GetParryChance() end, true },
    { "bloqueo", "Bloqueo", function() return GetBlockChance() end, true },
    { "ph", "Poder con hechizos", function() return GetSpellBonusDamage(2) end },
    { "sanacion", "Sanación", function() return GetSpellBonusHealing() end },
    { "defensa", "Defensa", function() local b, m = UnitDefense("player"); return (b or 0) + (m or 0) end },
}

function S.EtiquetaPoder()
    local _, token = UnitPowerType("player")
    return PODER[token] or "Poder"
end

function S.Instantanea()
    local function Leer(fn, ...) local ok, v = pcall(fn, ...); return ok and Num(v) or nil end
    local t = { nivel = Leer(UnitLevel, "player"), salud = Leer(UnitHealthMax, "player"),
                poder = Leer(UnitPowerMax, "player"), sec = {} }
    for i, k in ipairs({ "fue", "agi", "agu", "int", "esp" }) do
        local ok, _, valor = pcall(UnitStat, "player", i)
        t[k] = ok and Num(valor) or nil
    end
    for _, s in ipairs(S.SECUNDARIAS) do
        local ok, v = pcall(s[3])
        if ok and Num(v) then t.sec[s[1]] = v end
    end
    return t
end

----------------------------------------------------------------------
-- Entrenador: lo que falta por aprender
----------------------------------------------------------------------
local function Opt() return S.mod.db end

-- Lista de la clase: datos precargados + lo que se vio en el entrenador (precio y nivel reales).
local listaCache, listaClave
function S.ListaClase(clase)
    clase = clase or S.MiClase()
    local db = Opt()
    local visto = db.entrenador[clase] or {}
    local clave = clase .. ":" .. (db.entrenadorVersion or 0)
    if listaCache and listaClave == clave then return listaCache end
    local lista, por = {}, {}
    for _, e in ipairs(D.clases[clase] or {}) do
        local v = visto[e.s]
        local x = { s = e.s, l = (v and v.l) or e.l, c = (v and v.c) or e.c, p = e.p, r = e.r, u = e.u and not v }
        lista[#lista + 1] = x
        por[e.s] = x
    end
    -- Vistos en el entrenador y que no estaban en los datos (novedad de un parche de Forever).
    for s, v in pairs(visto) do
        if not por[s] and type(s) == "number" and v.clase ~= false then
            lista[#lista + 1] = { s = s, l = v.l or 1, c = v.c, nuevo = true }
        end
    end
    table.sort(lista, function(a, b) if a.l ~= b.l then return a.l < b.l end return a.s < b.s end)
    -- Raíz de cada familia de rangos (para «solo el último rango»).
    for _, x in ipairs(lista) do
        local raiz, n = x, 0
        while raiz.p and por[raiz.p] and n < 30 do raiz, n = por[raiz.p], n + 1 end
        x.raiz = raiz.s
    end
    listaCache, listaClave = lista, clave
    return lista
end

function S.InvalidarLista() listaCache = nil end

-- Hechizos de clase que te faltan con nivel <= `nivel`. `desde`: con «solo los del nivel nuevo»,
-- solo los de nivel > desde.
function S.Pendientes(nivel, desde)
    local db = Opt()
    local res, pendiente, porRaiz = {}, {}, {}
    for _, e in ipairs(S.ListaClase()) do
        if e.l <= nivel and RazaValida(e.r) and (not e.u or db.sinConfirmar) and not S.Conocido(e.s) then
            local previoOK = not e.p or S.Conocido(e.p) or pendiente[e.p]
            if previoOK then
                pendiente[e.s] = true
                if not (db.soloNuevas and desde and e.l <= desde) then
                    local item = { s = e.s, l = e.l, c = e.c, nuevo = e.nuevo }
                    if db.soloUltimoRango and porRaiz[e.raiz] then
                        res[porRaiz[e.raiz]] = item
                    else
                        res[#res + 1] = item
                        porRaiz[e.raiz] = #res
                    end
                end
            end
        end
    end
    return res
end

-- Próximos niveles con algo nuevo en el entrenador (línea de tiempo).
function S.Proximos(nivel, pasos, porNivel)
    local niveles, por = {}, {}
    for _, e in ipairs(S.ListaClase()) do
        if e.l > nivel and RazaValida(e.r) and (not e.u or Opt().sinConfirmar) then
            if not por[e.l] then
                if #niveles >= pasos then break end
                por[e.l] = {}
                niveles[#niveles + 1] = e.l
            end
            if #por[e.l] < porNivel then por[e.l][#por[e.l] + 1] = { s = e.s, l = e.l, c = e.c } end
        end
    end
    local res = {}
    for _, l in ipairs(niveles) do res[#res + 1] = { nivel = l, lista = por[l] } end
    return res
end

function S.ArmasPendientes(nivel)
    local db = Opt()
    local bitClase = S.CLASE_BIT[S.MiClase()] or 0
    local res, vistas = {}, {}
    for _, a in ipairs(D.armas or {}) do
        if not vistas[a.k] and Band(a.m, bitClase) ~= 0 and RazaValida(a.r) and (a.l or 0) <= nivel then
            vistas[a.k] = true
            if not S.Conocido(a.s) then
                local v = db.armasVistas[a.s]
                res[#res + 1] = { s = a.s, c = (v and v.c) or a.c, arma = true }
            end
        end
    end
    return res
end

local function LineasMascota()
    if not UnitExists("pet") then return nil end
    local fam = UnitCreatureFamily("pet")
    return fam and D.familias and D.familias[fam]
end

local function Interseca(a, b)
    if not a or not b then return false end
    for _, x in ipairs(a) do for _, y in ipairs(b) do if x == y then return true end end end
    return false
end

-- Grimorios de brujo nuevos en los niveles (desde, hasta]; con «todos», los que tu demonio no sabe.
function S.Grimorios(desde, hasta)
    local db = Opt()
    if S.MiClase() ~= "WARLOCK" then return {} end
    local lineas = LineasMascota()
    local res = {}
    for _, g in ipairs(D.grimorios or {}) do
        local enRango = g.l > desde and g.l <= hasta
        local delDemonio = not db.grimoriosSoloDemonio or not lineas or Interseca(g.d, lineas)
        if delDemonio and (enRango or (db.grimoriosTodos and g.l <= hasta and lineas and Interseca(g.d, lineas)
                and not S.Conocido(g.s, true))) then
            res[#res + 1] = { s = g.s, c = g.c, objeto = g.i, l = g.l }
        end
    end
    return res
end

-- Habilidades de mascota de cazador que se desbloquean en (desde, hasta].
function S.HabilidadesMascota(desde, hasta)
    local db = Opt()
    if S.MiClase() ~= "HUNTER" then return {} end
    local lineas = db.mascotaSoloFamilia and LineasMascota() or nil
    local res = {}
    for _, m in ipairs(D.mascotas or {}) do
        if m.l > desde and m.l <= hasta and (not lineas or Interseca(m.f, lineas)) then
            res[#res + 1] = { s = m.s, l = m.l, mascota = true }
        end
    end
    return res
end

----------------------------------------------------------------------
-- Escaneo del entrenador (precios y niveles reales de Forever)
----------------------------------------------------------------------
local escaneando = false

local function IdDeServicio(i, nombre, rango, indice)
    if C_TooltipInfo and C_TooltipInfo.GetTrainerService then
        local ok, data = pcall(C_TooltipInfo.GetTrainerService, i)
        if ok and type(data) == "table" and type(data.id) == "number" then return data.id end
    end
    if nombre then return indice[nombre .. "|" .. (rango or "")] or indice[nombre .. "|"] end
end

function S.EscanearEntrenador()
    local db = Opt()
    if escaneando or not db.autoEscaneo then return 0 end
    if not GetNumTrainerServices or not GetTrainerServiceInfo then return 0 end
    if IsTradeskillTrainer and IsTradeskillTrainer() then return 0 end
    escaneando = true
    local clase = S.MiClase()
    -- Índice nombre|rango -> hechizo de la clase y armas (nombres en el idioma del juego).
    local indice = {}
    for _, e in ipairs(D.clases[clase] or {}) do
        local n = S.NombreHechizo(e.s)
        if n then indice[n .. "|" .. (S.RangoHechizo(e.s) or "")] = e.s end
    end
    for _, a in ipairs(D.armas or {}) do
        local n = S.NombreHechizo(a.s)
        if n then indice[n .. "|"] = a.s; indice[n .. "|" .. (S.RangoHechizo(a.s) or "")] = a.s end
    end
    local filtros = {}
    if GetTrainerServiceTypeFilter and SetTrainerServiceTypeFilter then
        for _, f in ipairs({ "available", "unavailable", "used" }) do
            filtros[f] = GetTrainerServiceTypeFilter(f)
            SetTrainerServiceTypeFilter(f, 1)
        end
    end
    local armasPorId = {}
    for _, a in ipairs(D.armas or {}) do armasPorId[a.s] = true end
    local deClase = {}
    for _, e in ipairs(D.clases[clase] or {}) do deClase[e.s] = true end
    local n, cambios = GetNumTrainerServices() or 0, 0
    local servicios, esDeClase = {}, false
    for i = 1, n do
        local nombre, rango, tipo = GetTrainerServiceInfo(i)
        if tipo ~= "header" and nombre then
            local id = IdDeServicio(i, nombre, rango, indice)
            if id then
                servicios[#servicios + 1] = { id = id, c = GetTrainerServiceCost and GetTrainerServiceCost(i),
                                              l = GetTrainerServiceLevelReq and GetTrainerServiceLevelReq(i) }
                if deClase[id] then esDeClase = true end
            end
        end
    end
    -- Solo el entrenador de tu clase añade hechizos nuevos (el de equitación o el de mascotas no).
    db.entrenador[clase] = db.entrenador[clase] or {}
    for _, sv in ipairs(servicios) do
        if armasPorId[sv.id] then
            db.armasVistas[sv.id] = { c = sv.c }
            cambios = cambios + 1
        elseif esDeClase then
            db.entrenador[clase][sv.id] = { c = sv.c, l = (sv.l and sv.l > 0) and sv.l or nil }
            cambios = cambios + 1
        end
    end
    for f, v in pairs(filtros) do SetTrainerServiceTypeFilter(f, v and 1 or 0) end
    escaneando = false
    if cambios > 0 then
        db.entrenadorVersion = (db.entrenadorVersion or 0) + 1
        S.InvalidarLista()
        if db.avisoEscaneo then S.mod:Print(("entrenador leído: %d servicios guardados (precios y niveles de Forever)."):format(cambios)) end
    end
    return cambios
end

----------------------------------------------------------------------
-- Tiempo jugado (sin ensuciar el chat) e historial
----------------------------------------------------------------------
local pidiendo, silenciados = false, {}
local inicioNivel   -- { segundos jugados en el nivel al pedirlo, GetTime() de entonces }

local function Restaurar()
    for _, f in ipairs(silenciados) do f:RegisterEvent("TIME_PLAYED_MSG") end
    wipe(silenciados)
    pidiendo = false
end

function S.PedirTiempo()
    if not RequestTimePlayed or pidiendo then return end
    pidiendo = true
    for i = 1, (NUM_CHAT_WINDOWS or 10) do
        local f = _G["ChatFrame" .. i]
        if f and f.IsEventRegistered and f:IsEventRegistered("TIME_PLAYED_MSG") then
            f:UnregisterEvent("TIME_PLAYED_MSG")
            silenciados[#silenciados + 1] = f
        end
    end
    RequestTimePlayed()
    C_Timer.After(10, function() if pidiendo then Restaurar() end end)
end

function S.AlRecibirTiempo(total, enNivel)
    if pidiendo then C_Timer.After(0, Restaurar) end
    if type(enNivel) == "number" then inicioNivel = { enNivel, GetTime() } end
    local p = S.Personaje()
    p.total = total
end

-- Segundos que llevas en el nivel actual (nil si aún no se sabe).
function S.TiempoEnNivel()
    if not inicioNivel then return nil end
    return inicioNivel[1] + (GetTime() - inicioNivel[2])
end

function S.ReiniciarTiempoNivel() inicioNivel = { 0, GetTime() } end

function S.Personaje()
    local db = Opt()
    local guid = UnitGUID("player") or "?"
    local p = db.historial[guid]
    if not p then
        p = { niveles = {} }
        db.historial[guid] = p
    end
    p.nombre = UnitName("player")
    p.clase = S.MiClase()
    p.reino = GetRealmName and GetRealmName() or nil
    return p
end

-- Mejor tiempo de un nivel: de este personaje, o de toda la cuenta si se compara entre personajes.
function S.Record(nivel, excluirGuid)
    local db = Opt()
    local mejor, quien
    local yo = UnitGUID("player")
    for guid, p in pairs(db.historial) do
        if guid ~= excluirGuid and (db.compararCuenta or guid == yo) then
            local t = p.niveles[nivel]
            if t and (not mejor or t < mejor) then mejor, quien = t, p.nombre end
        end
    end
    return mejor, quien
end

----------------------------------------------------------------------
-- Subida de nivel
----------------------------------------------------------------------
local antes            -- instantánea de antes de subir (se congela al subir)
local congelada = false
local cola             -- subida pendiente de mostrar (en combate o esperando la instantánea)

-- Lo que no se pueda leer ahora (combate) se queda con el último valor bueno.
function S.ActualizarInstantanea()
    if congelada then return end
    local nueva = S.Instantanea()
    if antes then
        for k, v in pairs(antes) do if k ~= "sec" and nueva[k] == nil then nueva[k] = v end end
        for k, v in pairs(antes.sec or {}) do if nueva.sec[k] == nil then nueva.sec[k] = v end end
    end
    antes = nueva
end

local function EnCombate()
    local ok, v = pcall(InCombatLockdown)
    if ok and v and not issecret(v) then return true end
    local ok2, v2 = pcall(UnitAffectingCombat, "player")
    return ok2 and v2 and not issecret(v2) and true or false
end

-- Errores en lo que va con retraso: al chat (si no, se pierden sin avisar).
local function Seguro(que, fn, ...)
    local ok, err = pcall(fn, ...)
    if not ok and S.mod then S.mod:Print("|cffff5555error al " .. que .. ":|r " .. tostring(err)) end
    return ok
end

local function Combinar(a, b)
    if not a then return b end
    a.hasta = b.hasta
    a.despues = b.despues
    a.talentos = (a.talentos or 0) + (b.talentos or 0)
    a.tiempos = a.tiempos or {}
    for k, v in pairs(b.tiempos or {}) do a.tiempos[k] = v end
    a.esRecord, a.recordAnterior, a.recordDe = b.esRecord, b.recordAnterior, b.recordDe
    return a
end

-- Construye todo lo que enseña la ventana a partir de antes/después.
function S.Construir(sub)
    local db = Opt()
    local info = { desde = sub.desde, hasta = sub.hasta, prueba = sub.prueba, talentos = sub.talentos,
                   nombre = UnitName("player"), clase = S.MiClase(), stats = {}, sec = {} }
    local a, d = sub.antes or {}, sub.despues or {}
    for _, k in ipairs(S.ORDEN_PRINCIPALES) do
        local va, vd = a[k], d[k]
        if va and vd and (vd ~= va or db.statsSinCambio) and not (k == "poder" and S.EtiquetaPoder() ~= "Maná" and vd == va) then
            info.stats[#info.stats + 1] = { k = k, t = k == "poder" and S.EtiquetaPoder() or S.ETIQUETAS[k], a = va, d = vd }
        end
    end
    if (sub.talentos or 0) > 0 then
        info.stats[#info.stats + 1] = { k = "talentos", t = S.ETIQUETAS.talentos, a = nil, d = sub.talentos }
    end
    for _, s in ipairs(S.SECUNDARIAS) do
        local va, vd = a.sec and a.sec[s[1]], d.sec and d.sec[s[1]]
        if va and vd and math.abs(vd - va) > 0.004 then
            info.sec[#info.sec + 1] = { k = s[1], t = s[2], a = va, d = vd, pct = s[4] }
        end
    end
    info.habilidades = S.Pendientes(sub.hasta, sub.desde)
    info.armas = db.mostrarArmas and S.ArmasPendientes(sub.hasta) or {}
    info.grimorios = db.mostrarGrimorios and S.Grimorios(sub.desde, sub.hasta) or {}
    info.mascota = db.mostrarMascota and S.HabilidadesMascota(sub.desde, sub.hasta) or {}
    info.proximos = db.lineaTiempo and S.Proximos(sub.hasta, db.lineaPasos, db.lineaIconos) or {}
    -- Tiempo del último nivel subido y récord.
    local t = sub.tiempos and sub.tiempos[sub.hasta - 1]
    if t then
        info.tiempo = t
        info.recordAnterior, info.recordDe = sub.recordAnterior, sub.recordDe
        info.esRecord = sub.esRecord
    end
    info.hito = db.hitoCada > 0 and sub.hasta % db.hitoCada == 0
    info.maximo = sub.hasta >= db.nivelMaximo
    return info
end

local function Mostrar(sub)
    local info = S.Construir(sub)
    S.ultimaSub = sub
    if not sub.prueba then S.mod.db.ultimo = info end   -- se guarda antes de pintar: «repetir» siempre puede
    Seguro("mostrar la ventana", S.Ventana, info)
    Seguro("hacer los efectos", S.Efectos, info)
end

local esperando = {}   -- subidas en combate: se terminan al salir

-- Lee las estadísticas de después, junta subidas seguidas y enseña la ventana.
local function Terminar(sub)
    congelada = false
    local db = Opt()
    local previa = sub.antes
    local despues = S.Instantanea()
    -- Si el cliente aún no las ha cambiado (o no se pueden leer), se usan las ganancias del evento.
    local d = sub.delta or {}
    if (despues.fue == previa.fue and despues.salud == previa.salud or despues.salud == nil) and #d >= 4 then
        local n = {}
        for k, v in pairs(previa) do n[k] = v end
        n.sec = despues.sec
        if previa.salud and sub.saludDelta then n.salud = previa.salud + sub.saludDelta end
        if previa.poder and sub.poderDelta then n.poder = previa.poder + sub.poderDelta end
        for i, k in ipairs({ "fue", "agi", "agu", "int", "esp" }) do
            local g = Num(tonumber(d[i]))
            if previa[k] and g then n[k] = previa[k] + g end
        end
        despues = n
    end
    antes = despues
    sub.despues = despues
    sub.saludDelta, sub.poderDelta, sub.delta = nil, nil, nil
    -- Varias subidas seguidas con la ventana aún abierta: una sola ventana desde el primer nivel.
    local ultima = S.ultimaSub
    if not cola and ultima and not ultima.prueba and ultima.hasta == sub.desde and S.VentanaAbierta and S.VentanaAbierta() then
        cola = { desde = ultima.desde, hasta = ultima.hasta, antes = ultima.antes, despues = ultima.despues,
                 talentos = ultima.talentos, tiempos = ultima.tiempos, esRecord = ultima.esRecord,
                 recordAnterior = ultima.recordAnterior, recordDe = ultima.recordDe }
    end
    cola = Combinar(cola, sub)
    if db.esperarCombate and EnCombate() then return end
    local listo = cola
    cola = nil
    Mostrar(listo)
end

function S.AlSubir(nivel, saludDelta, poderDelta, talentos, ...)
    local db = Opt()
    nivel = tonumber(nivel) or (UnitLevel("player") + 1)
    -- Ganancias que trae el evento (fuerza, agilidad, aguante, intelecto, espíritu): repuesto.
    local delta = { ... }
    -- Tiempo del nivel que se deja atrás.
    local tiempos, esRecord, recAnt, recDe = {}, false, nil, nil
    local t = S.TiempoEnNivel()
    if t then
        local p = S.Personaje()
        recAnt, recDe = S.Record(nivel - 1)
        p.niveles[nivel - 1] = math.floor(t + 0.5)
        tiempos[nivel - 1] = p.niveles[nivel - 1]
        esRecord = (recAnt == nil or t < recAnt)
    end
    S.ReiniciarTiempoNivel()
    C_Timer.After(2, S.PedirTiempo)
    local previa = antes or S.Instantanea()
    congelada = true
    local sub = { desde = nivel - 1, hasta = nivel, antes = previa, talentos = tonumber(talentos) or 0, tiempos = tiempos,
                  esRecord = esRecord, recordAnterior = recAnt, recordDe = recDe,
                  saludDelta = tonumber(saludDelta), poderDelta = tonumber(poderDelta), delta = delta }
    -- Las estadísticas nuevas llegan un momento después del evento; en combate se leen al salir.
    C_Timer.After(db.esperaStats, function()
        if EnCombate() and db.esperarCombate then
            esperando[#esperando + 1] = sub
            return
        end
        Seguro("preparar la subida", Terminar, sub)
    end)
end

function S.FinCombate()
    if #esperando > 0 then
        local lista = esperando
        esperando = {}
        -- Un momento para que el cliente devuelva ya las estadísticas normales.
        C_Timer.After(0.5, function()
            for _, sub in ipairs(lista) do Seguro("preparar la subida", Terminar, sub) end
        end)
        return
    end
    if cola then
        local listo = cola
        cola = nil
        Seguro("mostrar la subida", Mostrar, listo)
    end
end


-- Vista previa: /subidoor test [nivel].
function S.Prueba(nivel)
    local yo = UnitLevel("player")
    nivel = tonumber(nivel) or math.min(yo + 1, 60)
    local a = S.Instantanea()
    local d = {}
    for k, v in pairs(a) do d[k] = v end
    d.sec = {}
    for k, v in pairs(a.sec or {}) do d.sec[k] = v + (k:find("crit") and 0.12 or 3) end
    a.salud, a.poder = math.max(1, (a.salud or 100) - 23), math.max(0, (a.poder or 100) - 15)
    for _, k in ipairs({ "fue", "agi", "agu", "int", "esp" }) do a[k] = math.max(0, (a[k] or 10) - (k == "agu" and 2 or 1)) end
    local tiempo = S.TiempoEnNivel() or 1234
    local rec = S.Record(nivel - 1)
    Mostrar({ desde = nivel - 1, hasta = nivel, antes = a, despues = d, prueba = true,
              talentos = nivel >= 10 and 1 or 0, tiempos = { [nivel - 1] = tiempo },
              esRecord = rec == nil or tiempo < rec, recordAnterior = rec })
end

-- Si la última subida no llegó a guardarse (la ventana falló), se rehace con lo que sí quedó:
-- el tiempo del nivel (historial) y lo que falta del entrenador. Las estadísticas no se pueden recuperar.
function S.Reconstruir()
    local nivel = Num(UnitLevel("player"))
    if not nivel or nivel < 2 then return nil end
    local p = S.Personaje()
    local t = p.niveles[nivel - 1]
    if not t then return nil end
    local rec, de = S.Record(nivel - 1, UnitGUID("player"))
    local info = S.Construir({ desde = nivel - 1, hasta = nivel, antes = {}, despues = {},
        talentos = nivel >= 10 and 1 or 0, tiempos = { [nivel - 1] = t },
        esRecord = rec == nil or t < rec, recordAnterior = rec, recordDe = de })
    info.reconstruida = true
    Opt().ultimo = info
    return info
end

function S.Repetir()
    local u = Opt().ultimo
    local nivel = Num(UnitLevel("player"))
    if (not u or (nivel and (u.hasta or 0) < nivel)) then
        u = S.Reconstruir() or u
    end
    if not u then S.mod:Print("todavía no has subido de nivel con Subidoor activado."); return end
    if u.reconstruida then
        S.mod:Print("la ventana de tu última subida no llegó a guardarse: la he rehecho con tu tiempo del nivel y "
            .. "lo que te falta del entrenador (las estadísticas de aquel momento no se pueden recuperar).")
    end
    Seguro("mostrar la ventana", S.Ventana, u)
    Seguro("hacer los efectos", S.Efectos, u)
end
