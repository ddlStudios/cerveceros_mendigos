-- Viajes (CervecerosMendigosGeneral) para WoW Forever (Interface 16001).
-- Panel pequeno con: el maestro de vuelo mas cercano, la distancia y el tiempo hasta tu destino (la marca
-- del mapa o una zona), la mejor ruta (a pie o volando), la piedra de hogar, el Retorno astral y los
-- portales de los magos del grupo. Aprende lo que tarda cada vuelo y lo ensena en el mapa de vuelos,
-- con una cuenta atras mientras vuelas. Comandos: /viajes (/cmviajes) [ir <zona> | ir <x> <y> | quitar | vuelos].

local ADDON, ns = ...
local Hub = ns.Hub
local UI = Hub.UI

local DEFAULTS = {
    panel = true, bloqueado = false, escala = 100, alpha = 90, ancho = 320,
    pos = { point = "TOPRIGHT", x = -220, y = -220 },
    ocultarCombate = true, ocultarInstancia = true, refresco = 1,
    verDestino = true, verPlan = true, verVuelo = true, verPiedra = true, verRetorno = true, verPortales = true, verRunas = true,
    destinoMarca = true,           -- la marca del mapa (punto de ruta) manda sobre la zona elegida
    incluirNoDescubiertos = false, -- contar maestros de vuelo que aun no tienes
    velocidad = "auto",            -- auto | pie | m60 | m100
    velPie = 7, velM60 = 11.2, velM100 = 14, velVuelo = 30, factorRuta = 1.25,
    unidades = "m",                -- m | yd
    margenVuelo = 30,              -- segundos que tiene que ahorrar el vuelo para recomendarlo
    -- Vuelos
    tooltipVuelo = true, barraVuelo = true, avisoAterrizar = true,
    barraPos = { point = "TOP", x = 0, y = -160 }, barraEscala = 100, barraBloqueada = false,
    -- Avisos
    piedraAviso = true, retornoAviso = true, portalesAviso = true, avisoSonido = true, sonido = "READY_CHECK",
}

local mod, panel, barra
local issecret = issecretvalue or function() return false end
local function Num(v) if type(v) == "number" and not issecret(v) then return v end end
local function Str(v) if type(v) == "string" and not issecret(v) and v ~= "" then return v end end
local function Call(fn, ...) if not fn then return nil end local r = { pcall(fn, ...) } if r[1] then return select(2, unpack(r)) end end

local PIEDRA, RUNA_TELE, RUNA_PORTAL, RETORNO = 6948, 17031, 17032, 556
-- Hechizo -> { "portal" | "tele", "Ciudad" }
local VIAJES_MAGO = {
    [3561] = { "tele", "Ventormenta" }, [3562] = { "tele", "Forjaz" }, [3563] = { "tele", "Entrañas" },
    [3565] = { "tele", "Darnassus" }, [3566] = { "tele", "Cima del Trueno" }, [3567] = { "tele", "Orgrimmar" },
    [10059] = { "portal", "Ventormenta" }, [11416] = { "portal", "Forjaz" }, [11417] = { "portal", "Orgrimmar" },
    [11418] = { "portal", "Entrañas" }, [11419] = { "portal", "Darnassus" }, [11420] = { "portal", "Cima del Trueno" },
}

local KITS = { { "READY_CHECK", "Comprobación de listos" }, { "IG_QUEST_LIST_COMPLETE", "Misión completada" },
               { "RAID_WARNING", "Aviso de banda" }, { "ALARM_CLOCK_WARNING_3", "Alarma" } }
local NUM_KIT = { RAID_WARNING = 8959, ALARM_CLOCK_WARNING_3 = 12889, READY_CHECK = 8960, IG_QUEST_LIST_COMPLETE = 878 }
local function Sonar()
    if not mod.db.avisoSonido then return end
    local id = (SOUNDKIT and SOUNDKIT[mod.db.sonido]) or NUM_KIT[mod.db.sonido]
    if id then pcall(PlaySound, id, "Master") end
end

----------------------------------------------------------------------
-- Formatos
----------------------------------------------------------------------
local function Miles(n)
    local s = tostring(math.floor(n + 0.5))
    while true do
        local r, k = s:gsub("^(%d+)(%d%d%d)", "%1.%2")
        s = r
        if k == 0 then return s end
    end
end
local function Dist(yd)
    if mod.db.unidades == "yd" then return Miles(yd) .. " yd" end
    local m = yd * 0.9144
    if m >= 10000 then return (string.format("%.1f", m / 1000):gsub("%.", ",")) .. " km" end
    return Miles(m) .. " m"
end
local function Tiempo(s)
    s = math.max(0, math.floor(s + 0.5))
    if s >= 3600 then return string.format("%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60) end
    return string.format("%d:%02d", s / 60, s % 60)
end
local RUMBOS = { "N", "NE", "E", "SE", "S", "SO", "O", "NO" }
-- Mundo de WoW: x crece hacia el norte e y hacia el oeste.
local function Rumbo(a, b)
    local dn, de = b.x - a.x, a.y - b.y
    if math.abs(dn) + math.abs(de) < 1 then return "" end
    local ang = math.deg((math.atan2 or function(y, x) return math.atan(y, x) end)(de, dn)) % 360
    return RUMBOS[math.floor((ang + 22.5) / 45) % 8 + 1]
end

----------------------------------------------------------------------
-- Posiciones
----------------------------------------------------------------------
local function Vec(x, y)
    if CreateVector2D then return CreateVector2D(x, y) end
    return { x = x, y = y, GetXY = function(self) return self.x, self.y end }
end
local function XY(v)
    if type(v) ~= "table" then return nil end
    if v.GetXY then local ok, x, y = pcall(v.GetXY, v); if ok then return Num(x), Num(y) end end
    return Num(v.x), Num(v.y)
end

-- Punto del mapa -> { cont, x, y } en yardas del mundo.
local function Mundo(mapID, x, y)
    if not (C_Map and C_Map.GetWorldPosFromMapPos and mapID and x and y) then return nil end
    local cont, w = Call(C_Map.GetWorldPosFromMapPos, mapID, Vec(x, y))
    local wx, wy = XY(w)
    cont = Num(cont)
    if not (cont and wx and wy) then return nil end
    return { cont = cont, x = wx, y = wy }
end

local function MapaJugador() return C_Map and Num(Call(C_Map.GetBestMapForUnit, "player")) end

local function PosJugador()
    local mapID = MapaJugador()
    if not mapID then return nil end
    local x, y = XY(Call(C_Map.GetPlayerMapPosition, mapID, "player"))
    if not x then return nil end
    local p = Mundo(mapID, x, y)
    if p then p.mapID = mapID end
    return p
end

local function Continente(mapID)
    local guard = 0
    while mapID and guard < 10 do
        local info = Call(C_Map.GetMapInfo, mapID)
        if type(info) ~= "table" then return nil end
        if info.mapType == 2 or (Enum and Enum.UIMapType and info.mapType == Enum.UIMapType.Continent) then return mapID end
        mapID = Num(info.parentMapID)
        guard = guard + 1
    end
end

local function Distancia(a, b)
    if not (a and b) or a.cont ~= b.cont then return nil end
    local dx, dy = a.x - b.x, a.y - b.y
    return math.sqrt(dx * dx + dy * dy)
end

----------------------------------------------------------------------
-- Maestros de vuelo
----------------------------------------------------------------------
local function Faccion()
    local f = Str(Call(UnitFactionGroup, "player"))
    return f == "Horde" and 1 or (f == "Alliance" and 2 or nil)
end

local function ClavePJ() return (Hub.MyName and Hub.MyName() or "?") .. "-" .. (Str(Call(GetRealmName)) or "?") end
local function Conocidos()
    local k = ClavePJ()
    mod.db.conocidos = mod.db.conocidos or {}
    mod.db.conocidos[k] = mod.db.conocidos[k] or {}
    return mod.db.conocidos[k]
end

local nodosCache, nodosCont, nodosHora = nil, nil, 0
-- Lista de maestros de vuelo del continente: { nombre, pos = {cont,x,y}, descubierto }
local function Nodos(contMap)
    if not contMap then return {} end
    if nodosCache and nodosCont == contMap and GetTime() - nodosHora < 30 then return nodosCache end
    local res, porNombre = {}, {}
    local fac = Faccion()
    local conocidos = Conocidos()
    local lista = C_TaxiMap and C_TaxiMap.GetTaxiNodesForMap and Call(C_TaxiMap.GetTaxiNodesForMap, contMap)
    if type(lista) == "table" then
        for _, n in ipairs(lista) do
            local nombre = Str(n.name)
            local f = Num(n.faction)
            if nombre and (not fac or not f or f == 0 or f == fac) then
                local x, y = XY(n.position)
                local pos = Mundo(contMap, x, y)
                if pos then
                    local desc = n.isUndiscovered ~= true or conocidos[nombre] == true
                    res[#res + 1] = { nombre = nombre, pos = pos, descubierto = desc }
                    porNombre[nombre] = true
                end
            end
        end
    end
    -- Los aprendidos al abrir el mapa de vuelos (por si el juego no da la lista del continente).
    for nombre, p in pairs(mod.db.nodos or {}) do
        if not porNombre[nombre] and p.cont and (not p.fac or not fac or p.fac == 0 or p.fac == fac) then
            res[#res + 1] = { nombre = nombre, pos = { cont = p.cont, x = p.x, y = p.y }, descubierto = conocidos[nombre] == true }
        end
    end
    nodosCache, nodosCont, nodosHora = res, contMap, GetTime()
    return res
end
local function Invalidar() nodosCache = nil end

local function Usables(nodos)
    local r = {}
    for _, n in ipairs(nodos) do if n.descubierto or mod.db.incluirNoDescubiertos then r[#r + 1] = n end end
    return r
end

local function MasCercanos(nodos, punto, cuantos)
    local l = {}
    for _, n in ipairs(nodos) do
        local d = Distancia(n.pos, punto)
        if d then l[#l + 1] = { n = n, d = d } end
    end
    table.sort(l, function(a, b) return a.d < b.d end)
    while #l > (cuantos or #l) do table.remove(l) end
    return l
end

local function PosNodo(nombre)
    for _, n in ipairs(nodosCache or {}) do if n.nombre == nombre then return n.pos end end
    local p = mod.db.nodos and mod.db.nodos[nombre]
    if p and p.cont then return { cont = p.cont, x = p.x, y = p.y } end
end

-- Tiempo de vuelo entre dos maestros: el aprendido o una estimacion (segundos, aprox).
local function TiempoVuelo(a, b)
    local t = mod.db.vuelos and mod.db.vuelos[a .. "»" .. b]
    if t then return t, false end
    local d = Distancia(PosNodo(a), PosNodo(b))
    if not d then return nil end
    return d * mod.db.factorRuta / math.max(1, mod.db.velVuelo), true
end

----------------------------------------------------------------------
-- Velocidad y destino
----------------------------------------------------------------------
local function Velocidad()
    local db = mod.db
    if db.velocidad == "pie" then return db.velPie, "a pie" end
    if db.velocidad == "m60" then return db.velM60, "en montura" end
    if db.velocidad == "m100" then return db.velM100, "en montura rápida" end
    local montado = IsMounted and Call(IsMounted) == true
    if montado then
        local v = Num(Call(GetUnitSpeed, "player"))
        if v and v > db.velPie + 0.5 then return v, "en montura" end
        return db.velM60, "en montura"
    end
    return db.velPie, "a pie"
end

local function Destino()
    local db = mod.db
    if db.destinoMarca and C_Map and C_Map.GetUserWaypoint then
        local w = Call(C_Map.GetUserWaypoint)
        if type(w) == "table" and Num(w.uiMapID) then
            local x, y = XY(w.position)
            local p = Mundo(w.uiMapID, x, y)
            if p then
                local info = Call(C_Map.GetMapInfo, w.uiMapID)
                p.nombre = (type(info) == "table" and Str(info.name) or "?") .. " (marca del mapa)"
                return p
            end
        end
    end
    local d = db.destino
    if type(d) == "table" and d.mapID then
        local p = Mundo(d.mapID, d.x, d.y)
        if p then p.nombre = d.nombre; return p end
    end
end

local function Normal(s) return (s or ""):lower():gsub("á", "a"):gsub("é", "e"):gsub("í", "i"):gsub("ó", "o"):gsub("ú", "u"):gsub("ñ", "n") end

-- Busca una zona por nombre en los continentes conocidos.
local function BuscarZona(texto)
    local q = Normal(texto)
    if q == "" or not (C_Map and C_Map.GetMapChildrenInfo) then return nil end
    local conts, vistos = {}, {}
    local mio = Continente(MapaJugador())
    for _, c in ipairs({ mio, 1414, 1415 }) do if c and not vistos[c] then vistos[c] = true; conts[#conts + 1] = c end end
    local exacta, parcial
    for _, c in ipairs(conts) do
        local hijos = Call(C_Map.GetMapChildrenInfo, c, 3, true)
        for _, h in ipairs(type(hijos) == "table" and hijos or {}) do
            local n = Str(h.name)
            if n then
                if Normal(n) == q then exacta = exacta or h
                elseif Normal(n):find(q, 1, true) then parcial = parcial or h end
            end
        end
    end
    return exacta or parcial
end

local function PonerDestino(mapID, x, y, nombre)
    mod.db.destino = { mapID = mapID, x = x, y = y, nombre = nombre }
    mod:Print("destino: " .. nombre .. ".")
end

----------------------------------------------------------------------
-- Ruta
----------------------------------------------------------------------
-- { directo = s, via = { a, b, ta, tv, tb, total, aprox } , d = yardas }
local function Planear(p, dest)
    local d = Distancia(p, dest)
    if not d then return nil end
    local vel = Velocidad()
    local plan = { d = d, directo = d / vel }
    local cont = Continente(p.mapID)
    local nodos = Usables(Nodos(cont))
    local cerca = MasCercanos(nodos, p, 3)
    local lejos = MasCercanos(nodos, dest, 3)
    for _, a in ipairs(cerca) do
        for _, b in ipairs(lejos) do
            if a.n.nombre ~= b.n.nombre then
                local tv, aprox = TiempoVuelo(a.n.nombre, b.n.nombre)
                if tv then
                    local total = a.d / vel + tv + b.d / vel
                    if not plan.via or total < plan.via.total then
                        plan.via = { a = a.n.nombre, b = b.n.nombre, ta = a.d / vel, tv = tv, tb = b.d / vel, total = total, aprox = aprox }
                    end
                end
            end
        end
    end
    return plan
end

----------------------------------------------------------------------
-- Piedra de hogar, Retorno astral y magos del grupo
----------------------------------------------------------------------
local function Restante(start, dur)
    start, dur = Num(start), Num(dur)
    if not (start and dur) then return nil end
    if start == 0 or dur <= 1.5 then return 0 end
    return math.max(0, start + dur - GetTime())
end

local function EstadoPiedra()
    local n = Num(Call(C_Item and C_Item.GetItemCount or GetItemCount, PIEDRA)) or 0
    if n <= 0 then return nil end
    local start, dur = Call(C_Container and C_Container.GetItemCooldown or GetItemCooldown, PIEDRA)
    return Restante(start, dur), Str(Call(GetBindLocation))
end

local function EstadoRetorno()
    if Hub.ClaseJugador() ~= "SHAMAN" then return nil end
    local conoce = Call(IsPlayerSpell, RETORNO) == true or Call(IsSpellKnown, RETORNO) == true
    if not conoce then return nil end
    if C_Spell and C_Spell.GetSpellCooldown then
        local cd = Call(C_Spell.GetSpellCooldown, RETORNO)
        if type(cd) == "table" then return Restante(cd.startTime, cd.duration) end
    end
    if GetSpellCooldown then return Restante(Call(GetSpellCooldown, RETORNO)) end
end

local function Unidades()
    local r = {}
    if IsInRaid and Call(IsInRaid) then
        for i = 1, 40 do r[#r + 1] = "raid" .. i end
    elseif IsInGroup and Call(IsInGroup) then
        for i = 1, 4 do r[#r + 1] = "party" .. i end
    end
    return r
end

local function MagosGrupo()
    local res = {}
    for _, u in ipairs(Unidades()) do
        if Call(UnitExists, u) and not Call(UnitIsUnit, u, "player") then
            local _, clase = Call(UnitClass, u)
            if Str(clase) == "MAGE" then
                local nivel = Num(Call(UnitLevel, u)) or 0
                local nombre = Hub.UnitFullName and Hub.UnitFullName(u) or Str(Call(UnitName, u)) or "?"
                res[#res + 1] = { nombre = nombre, nivel = nivel, portal = nivel >= 40, tele = nivel >= 20 }
            end
        end
    end
    return res
end

local function Contar(id) return Num(Call(C_Item and C_Item.GetItemCount or GetItemCount, id)) or 0 end

----------------------------------------------------------------------
-- Panel
----------------------------------------------------------------------
local lineas = {}
local MAXL = 9

local function GuardarPos(f, clave)
    local p, _, _, x, y = f:GetPoint()
    mod.db[clave] = { point = p or "CENTER", x = x or 0, y = y or 0 }
end

local function CrearPanel()
    if panel then return end
    panel = mod:Frame("Frame", "CMViajesPanel", UIParent, "BackdropTemplate")
    panel:SetSize(mod.db.ancho, 40)
    panel:SetFrameStrata("MEDIUM")
    if panel.SetBackdrop then
        panel:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                            edgeSize = 12, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
        panel:SetBackdropColor(0.05, 0.05, 0.08, 1)
        panel:SetBackdropBorderColor(0.6, 0.5, 0.3, 1)
    end
    panel.titulo = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    panel.titulo:SetPoint("TOPLEFT", 8, -7)
    panel.titulo:SetText("Viajes")
    for i = 1, MAXL do
        local fs = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        fs:SetJustifyH("LEFT"); fs:SetJustifyV("TOP")
        if i == 1 then fs:SetPoint("TOPLEFT", panel.titulo, "BOTTOMLEFT", 0, -4)
        else fs:SetPoint("TOPLEFT", lineas[i - 1], "BOTTOMLEFT", 0, -3) end
        lineas[i] = fs
    end
    panel:SetMovable(true); panel:EnableMouse(true); panel:SetClampedToScreen(true)
    panel:RegisterForDrag("LeftButton")
    panel:SetScript("OnDragStart", function(s) if not mod.db.bloqueado then s:StartMoving() end end)
    panel:SetScript("OnDragStop", function(s) s:StopMovingOrSizing(); GuardarPos(s, "pos") end)
    panel:SetScript("OnMouseUp", function(_, b) if b == "RightButton" then Hub:Open("viajes") end end)
end

local function AplicarPanel()
    if not panel then return end
    local db = mod.db
    panel:ClearAllPoints()
    panel:SetPoint(db.pos.point, UIParent, db.pos.point, db.pos.x, db.pos.y)
    panel:SetScale(db.escala / 100)
    panel:SetAlpha(db.alpha / 100)
    panel:SetWidth(db.ancho)
    for _, fs in ipairs(lineas) do fs:SetWidth(db.ancho - 16) end
end

local function Lineas()
    local db = mod.db
    local out = {}
    local p = PosJugador()
    local vel, como = Velocidad()
    if db.verDestino or db.verPlan then
        local dest = Destino()
        if dest then
            local d = p and Distancia(p, dest)
            if not d then
                out[#out + 1] = "Destino: |cffffd100" .. dest.nombre .. "|r (en otro continente)"
            else
                if db.verDestino then
                    out[#out + 1] = "Destino: |cffffd100" .. dest.nombre .. "|r · " .. Dist(d) .. " al " .. Rumbo(p, dest)
                    out[#out + 1] = "   " .. como .. ": " .. Tiempo(d / vel)
                end
                if db.verPlan then
                    local plan = Planear(p, dest)
                    local v = plan and plan.via
                    if v and v.total + db.margenVuelo < plan.directo then
                        out[#out + 1] = "   |cff55ff55Mejor volando|r: " .. v.a .. " (" .. Tiempo(v.ta) .. ") » " .. v.b
                            .. " (" .. (v.aprox and "~" or "") .. Tiempo(v.tv) .. ") » " .. Tiempo(v.tb) .. " = |cffffffff" .. Tiempo(v.total) .. "|r"
                    elseif plan then
                        out[#out + 1] = "   |cff55ff55Mejor " .. como .. "|r: no compensa volar"
                    end
                end
            end
        end
    end
    if db.verVuelo and p then
        local c = MasCercanos(Usables(Nodos(Continente(p.mapID))), p, 1)[1]
        if c then
            out[#out + 1] = "Vuelo más cercano: |cffffd100" .. c.n.nombre .. "|r · " .. Dist(c.d) .. " al " .. Rumbo(p, c.n.pos)
                .. " (" .. Tiempo(c.d / vel) .. ")"
        end
    end
    if db.verPiedra then
        local r, sitio = EstadoPiedra()
        if r then
            out[#out + 1] = "Piedra de hogar" .. (sitio and (" (" .. sitio .. ")") or "") .. ": "
                .. (r <= 0 and "|cff55ff55lista|r" or ("en " .. Tiempo(r)))
        end
    end
    if db.verRetorno then
        local r = EstadoRetorno()
        if r then out[#out + 1] = "Retorno astral: " .. (r <= 0 and "|cff55ff55listo|r" or ("en " .. Tiempo(r))) end
    end
    if db.verPortales then
        local magos = MagosGrupo()
        if #magos > 0 then
            local partes = {}
            for _, m in ipairs(magos) do
                partes[#partes + 1] = m.nombre .. (m.portal and " (portales)" or (m.tele and " (solo teletransporte)" or " (aún sin portales)"))
            end
            out[#out + 1] = "Magos del grupo: " .. table.concat(partes, ", ")
        end
    end
    if db.verRunas and Hub.ClaseJugador() == "MAGE" then
        out[#out + 1] = "Runas: " .. Contar(RUNA_TELE) .. " de teletransporte, " .. Contar(RUNA_PORTAL) .. " de portales"
    end
    return out
end

local enVuelo
local function PintarPanel()
    if not panel then return end
    local db = mod.db
    local ocultar = not db.panel or enVuelo
        or (db.ocultarCombate and InCombatLockdown and InCombatLockdown())
        or (db.ocultarInstancia and IsInInstance and Call(IsInInstance) == true)
    local out = ocultar and {} or Lineas()
    if #out == 0 then panel:Hide(); return end
    local h = 26
    for i = 1, MAXL do
        local fs = lineas[i]
        if out[i] then
            fs:SetText(out[i]); fs:Show()
            h = h + ((fs.GetStringHeight and fs:GetStringHeight()) or 12) + 3
        else fs:SetText(""); fs:Hide() end
    end
    panel:SetHeight(h)
    panel:Show()
end

----------------------------------------------------------------------
-- Vuelos: aprender nodos y tiempos, barra de cuenta atras
----------------------------------------------------------------------
local function NodoActual()
    local n = Num(Call(NumTaxiNodes)) or 0
    for i = 1, n do if Call(TaxiNodeGetType, i) == "CURRENT" then return Str(Call(TaxiNodeName, i)) end end
end

local function AprenderNodos()
    local db = mod.db
    db.nodos = db.nodos or {}
    local conocidos = Conocidos()
    local taxiMap = GetTaxiMapID and Num(Call(GetTaxiMapID))
    local lista = taxiMap and C_TaxiMap and C_TaxiMap.GetAllTaxiNodes and Call(C_TaxiMap.GetAllTaxiNodes, taxiMap)
    if type(lista) == "table" then
        for _, n in ipairs(lista) do
            local nombre = Str(n.name)
            if nombre then
                conocidos[nombre] = true
                local x, y = XY(n.position)
                local p = Mundo(taxiMap, x, y)
                if p then db.nodos[nombre] = { cont = p.cont, x = p.x, y = p.y } end
            end
        end
    else
        local n = Num(Call(NumTaxiNodes)) or 0
        for i = 1, n do
            local nombre = Str(Call(TaxiNodeName, i))
            if nombre and Call(TaxiNodeGetType, i) ~= "DISTANT" then conocidos[nombre] = true end
        end
    end
    Invalidar()
end

local vuelo   -- { origen, destino, pedido, inicio, estimado, aprox }

local function CrearBarra()
    if barra then return end
    barra = mod:Frame("StatusBar", "CMViajesBarra", UIParent)
    barra:SetSize(240, 16)
    barra:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    barra:SetStatusBarColor(0.3, 0.6, 1)
    barra:SetMinMaxValues(0, 1)
    local bg = barra:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(); bg:SetColorTexture(0, 0, 0, 0.6)
    barra.texto = barra:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    barra.texto:SetPoint("CENTER")
    barra:SetMovable(true); barra:EnableMouse(true); barra:SetClampedToScreen(true)
    barra:RegisterForDrag("LeftButton")
    barra:SetScript("OnDragStart", function(s) if not mod.db.barraBloqueada then s:StartMoving() end end)
    barra:SetScript("OnDragStop", function(s) s:StopMovingOrSizing(); GuardarPos(s, "barraPos") end)
    barra:Hide()
end
local function AplicarBarra()
    if not barra then return end
    local p = mod.db.barraPos
    barra:ClearAllPoints()
    barra:SetPoint(p.point, UIParent, p.point, p.x, p.y)
    barra:SetScale(mod.db.barraEscala / 100)
end

local function PintarBarra()
    if not (barra and vuelo and vuelo.inicio and mod.db.barraVuelo) then if barra then barra:Hide() end return end
    local pasado = GetTime() - vuelo.inicio
    local txt = vuelo.destino or "?"
    if vuelo.estimado and vuelo.estimado > 0 then
        local queda = vuelo.estimado - pasado
        barra:SetValue(math.min(1, pasado / vuelo.estimado))
        txt = txt .. ": " .. (queda >= 0 and (vuelo.aprox and "~" or "") .. Tiempo(queda) or ("+" .. Tiempo(-queda)))
    else
        barra:SetValue(0)
        txt = txt .. ": " .. Tiempo(pasado)
    end
    barra.texto:SetText(txt)
    barra:Show()
end

local function AlCogerVuelo(slot)
    if not (mod and mod.enabled) then return end
    local destino = Str(Call(TaxiNodeName, slot))
    local origen = NodoActual()
    if not (destino and origen) then return end
    local t, aprox = TiempoVuelo(origen, destino)
    vuelo = { origen = origen, destino = destino, pedido = GetTime(), estimado = t, aprox = aprox }
end

local function SeguirVuelo()
    if not vuelo then enVuelo = false; return end
    local enTaxi = Call(UnitOnTaxi, "player") == true
    if not vuelo.inicio then
        if enTaxi then vuelo.inicio = GetTime(); enVuelo = true; PintarPanel(); PintarBarra()
        elseif GetTime() - vuelo.pedido > 10 then vuelo = nil end
        return
    end
    if enTaxi then PintarBarra(); return end
    -- Aterrizado.
    local dur = GetTime() - vuelo.inicio
    if dur > 5 then
        mod.db.vuelos = mod.db.vuelos or {}
        mod.db.vuelos[vuelo.origen .. "»" .. vuelo.destino] = math.floor(dur + 0.5)
        if mod.db.avisoAterrizar then mod:Print("de " .. vuelo.origen .. " a " .. vuelo.destino .. " en " .. Tiempo(dur) .. ".") end
    end
    vuelo, enVuelo = nil, false
    if barra then barra:Hide() end
end

-- Linea con el tiempo en el tooltip del mapa de vuelos.
local function LineaTooltip(destino)
    if not (mod and mod.enabled and mod.db.tooltipVuelo) then return end
    local origen = NodoActual()
    if not (origen and destino) or origen == destino then return end
    local t, aprox = TiempoVuelo(origen, destino)
    if not t then return end
    GameTooltip:AddLine("Vuelo: " .. (aprox and "~" or "") .. Tiempo(t) .. (aprox and " (aprox., se aprende al volar)" or ""), 0.5, 0.8, 1)
    GameTooltip:Show()
end

local enganchadoFM
local function EngancharMapaVuelo()
    if enganchadoFM or not FlightMap_FlightPointPinMixin then return end
    enganchadoFM = true
    hooksecurefunc(FlightMap_FlightPointPinMixin, "OnMouseEnter", function(self)
        if not (mod and mod.enabled) then return end
        local d = self.taxiNodeData
        if d and Num(d.state) == 1 then LineaTooltip(Str(d.name)) end
    end)
end

----------------------------------------------------------------------
-- Avisos: piedra lista, retorno listo, portales del grupo
----------------------------------------------------------------------
local antes = {}
local function VigilarListos()
    local r = EstadoPiedra()
    if r ~= nil then
        if antes.piedra and antes.piedra > 0 and r <= 0 and mod.db.piedraAviso then mod:Print("la piedra de hogar ya está lista."); Sonar() end
        antes.piedra = r
    end
    local q = EstadoRetorno()
    if q ~= nil then
        if antes.retorno and antes.retorno > 0 and q <= 0 and mod.db.retornoAviso then mod:Print("Retorno astral listo."); Sonar() end
        antes.retorno = q
    end
end

local function AlLanzar(unit, spellID)
    if not mod.db.portalesAviso then return end
    spellID = Num(spellID)
    local u = Str(unit)
    if not (spellID and u) or u == "player" or not (u:find("^party") or u:find("^raid")) then return end
    local v = VIAJES_MAGO[spellID]
    if not v or v[1] ~= "portal" then return end
    local nombre = Hub.UnitFullName and Hub.UnitFullName(u) or "un mago"
    mod:Print("|cff69ccf0" .. nombre .. "|r ha abierto un portal a " .. v[2] .. ".")
    Sonar()
end

----------------------------------------------------------------------
-- Comandos
----------------------------------------------------------------------
local function OnSlash(m, msg)
    msg = (msg or ""):gsub("^%s+", ""):gsub("%s+$", "")
    local cmd, resto = msg:match("^(%S+)%s*(.*)$")
    cmd = (cmd or ""):lower()
    if cmd == "ir" then
        local x, y = resto:match("^(%d+[%.,]?%d*)%s+(%d+[%.,]?%d*)$")
        if x then
            local mapID = MapaJugador()
            if not mapID then m:Print("no se sabe en qué mapa estás."); return end
            x, y = tonumber((x:gsub(",", "."))) / 100, tonumber((y:gsub(",", "."))) / 100
            local info = Call(C_Map.GetMapInfo, mapID)
            PonerDestino(mapID, x, y, (type(info) == "table" and Str(info.name) or "?") .. string.format(" %.0f, %.0f", x * 100, y * 100))
        else
            local z = BuscarZona(resto)
            if not z then m:Print("no encuentro la zona «" .. resto .. "»."); return end
            PonerDestino(z.mapID, 0.5, 0.5, z.name)
        end
        PintarPanel()
    elseif cmd == "quitar" then
        m.db.destino = nil; m:Print("destino quitado."); PintarPanel()
    elseif cmd == "vuelos" then
        local n = 0
        for k, v in pairs(m.db.vuelos or {}) do m:Print("  " .. k .. ": " .. Tiempo(v)); n = n + 1 end
        if n == 0 then m:Print("aún no has volado con el módulo activo.") end
    elseif cmd == "panel" then
        m.db.panel = not m.db.panel; PintarPanel()
    else
        Hub:Open("viajes")
        if cmd ~= "" then m:Print("/viajes ir <zona> | ir <x> <y> | quitar | vuelos | panel") end
    end
end

----------------------------------------------------------------------
-- Pestana
----------------------------------------------------------------------
local function BuildConfig(m, L)
    local db = m.db
    local function R() AplicarPanel(); PintarPanel() end
    L:Header("Panel")
    L:Text("Maestro de vuelo más cercano, tiempo hasta tu destino y la mejor ruta, piedra de hogar y portales del grupo. El destino es la marca que pones en el mapa (clic con Ctrl) o una zona: /viajes ir Páramos de Poniente.", true)
    L:Check("Enseñar el panel", function() return db.panel end, function(v) db.panel = v; R() end)
    L:Check("Bloquear el panel (no se arrastra)", function() return db.bloqueado end, function(v) db.bloqueado = v end)
    L:Check("Ocultarlo en combate", function() return db.ocultarCombate end, function(v) db.ocultarCombate = v; R() end)
    L:Check("Ocultarlo en mazmorras y campos de batalla", function() return db.ocultarInstancia end, function(v) db.ocultarInstancia = v; R() end)
    L:Slider("Escala (%)", 50, 200, 5, function() return db.escala end, function(v) db.escala = v; R() end)
    L:Slider("Opacidad (%)", 20, 100, 5, function() return db.alpha end, function(v) db.alpha = v; R() end)
    L:Slider("Ancho", 220, 520, 10, function() return db.ancho end, function(v) db.ancho = v; R() end)
    L:Slider("Refresco (segundos)", 0.2, 5, 0.2, function() return db.refresco end, function(v) db.refresco = v end, "%.1f")
    L:Button("Volver a colocarlo", 180, function() db.pos = { point = "TOPRIGHT", x = -220, y = -220 }; R() end)

    L:Header("Qué enseña")
    L:Check("Destino, distancia y tiempo", function() return db.verDestino end, function(v) db.verDestino = v; R() end)
    L:Check("Mejor ruta (a pie o volando)", function() return db.verPlan end, function(v) db.verPlan = v; R() end)
    L:Check("Maestro de vuelo más cercano", function() return db.verVuelo end, function(v) db.verVuelo = v; R() end)
    L:Check("Piedra de hogar", function() return db.verPiedra end, function(v) db.verPiedra = v; R() end)
    L:Check("Retorno astral (chamán)", function() return db.verRetorno end, function(v) db.verRetorno = v; R() end)
    L:Check("Magos del grupo y sus portales", function() return db.verPortales end, function(v) db.verPortales = v; R() end)
    L:Check("Tus runas (mago)", function() return db.verRunas end, function(v) db.verRunas = v; R() end)

    L:Header("Destino y ruta")
    L:Check("La marca del mapa manda sobre la zona elegida", function() return db.destinoMarca end, function(v) db.destinoMarca = v; R() end)
    L:Edit("Ir a la zona", function() return type(db.destino) == "table" and db.destino.nombre or "" end, function(v)
        local z = BuscarZona(v)
        if z then PonerDestino(z.mapID, 0.5, 0.5, z.name) else m:Print("no encuentro la zona «" .. tostring(v) .. "».") end
        R(); L:Refresh()
    end, "text", 170)
    L:Button("Quitar destino", 150, function() db.destino = nil; R(); L:Refresh() end)
    L:Check("Contar maestros de vuelo que aún no tienes", function() return db.incluirNoDescubiertos end, function(v) db.incluirNoDescubiertos = v; Invalidar(); R() end)
    L:Choice("Velocidad", { { "auto", "Automática (a pie o montura)" }, { "pie", "Siempre a pie" }, { "m60", "Montura (60 %)" }, { "m100", "Montura rápida (100 %)" } },
        function() return db.velocidad end, function(v) db.velocidad = v; R() end)
    L:Edit("A pie (yardas/s)", function() return db.velPie end, function(v) db.velPie = math.max(1, v); R() end, "number", 60)
    L:Edit("Montura (yardas/s)", function() return db.velM60 end, function(v) db.velM60 = math.max(1, v); R() end, "number", 60)
    L:Edit("Montura rápida (yardas/s)", function() return db.velM100 end, function(v) db.velM100 = math.max(1, v); R() end, "number", 60)
    L:Edit("Vuelo, para estimar (yardas/s)", function() return db.velVuelo end, function(v) db.velVuelo = math.max(1, v); R() end, "number", 60)
    L:Slider("Rodeo de las rutas de vuelo (x)", 1, 2, 0.05, function() return db.factorRuta end, function(v) db.factorRuta = v; R() end, "%.2f")
    L:Slider("Segundos que tiene que ahorrar el vuelo", 0, 180, 5, function() return db.margenVuelo end, function(v) db.margenVuelo = v; R() end)
    L:Choice("Unidades", { { "m", "Metros" }, { "yd", "Yardas" } }, function() return db.unidades end, function(v) db.unidades = v; R() end)

    L:Header("Vuelos")
    L:Text("Cada vuelo que haces se apunta; hasta entonces el tiempo es una estimación (~).", true)
    L:Check("Tiempo del vuelo en el mapa de vuelos", function() return db.tooltipVuelo end, function(v) db.tooltipVuelo = v end)
    L:Check("Barra con la cuenta atrás mientras vuelas", function() return db.barraVuelo end, function(v) db.barraVuelo = v; if not v and barra then barra:Hide() end end)
    L:Check("Bloquear la barra", function() return db.barraBloqueada end, function(v) db.barraBloqueada = v end)
    L:Slider("Escala de la barra (%)", 50, 200, 5, function() return db.barraEscala end, function(v) db.barraEscala = v; AplicarBarra() end)
    L:Check("Decir en el chat lo que has tardado al aterrizar", function() return db.avisoAterrizar end, function(v) db.avisoAterrizar = v end)
    L:Button("Probar la barra", 150, function()
        CrearBarra(); AplicarBarra()
        vuelo = vuelo or { origen = "?", destino = "Prueba", pedido = GetTime(), inicio = GetTime(), estimado = 60 }
        PintarBarra()
        C_Timer.After(5, function() if vuelo and vuelo.destino == "Prueba" then vuelo = nil; if barra then barra:Hide() end end end)
    end)
    L:Button("Olvidar los tiempos aprendidos", 220, function() db.vuelos = {}; m:Print("tiempos de vuelo olvidados.") end, true)

    L:Header("Avisos")
    L:Check("Avisar cuando la piedra de hogar esté lista", function() return db.piedraAviso end, function(v) db.piedraAviso = v end)
    L:Check("Avisar cuando el Retorno astral esté listo", function() return db.retornoAviso end, function(v) db.retornoAviso = v end)
    L:Check("Avisar cuando un mago del grupo abre un portal", function() return db.portalesAviso end, function(v) db.portalesAviso = v end)
    L:Check("Sonido en los avisos", function() return db.avisoSonido end, function(v) db.avisoSonido = v end)
    L:Choice("Sonido", KITS, function() return db.sonido end, function(v) db.sonido = v; local s = db.avisoSonido; db.avisoSonido = true; Sonar(); db.avisoSonido = s end)
    L:Text("Comandos: /viajes ir <zona>, /viajes ir <x> <y> (en tu mapa), /viajes quitar, /viajes vuelos, /viajes panel.", true)
end

local acumulado = 0
mod = Hub:Register{
    key = "viajes", dir = "Viajes", name = "Viajes",
    desc = "Maestro de vuelo más cercano, tiempo hasta tu destino a pie o volando, tiempos de vuelo aprendidos, piedra de hogar y portales de los magos del grupo.",
    defaults = DEFAULTS,
    slash = { "viajes", "cmviajes" },
    OnSlash = OnSlash,
    BuildConfig = BuildConfig,
    rightHint = "enseñar u ocultar el panel",
    OnRightClick = function(m) m.db.panel = not m.db.panel; PintarPanel() end,
    OnReset = function() AplicarPanel(); AplicarBarra(); PintarPanel() end,
    Init = function(m)
        CrearPanel(); CrearBarra()
        if hooksecurefunc then
            if TakeTaxiNode then hooksecurefunc("TakeTaxiNode", AlCogerVuelo) end
            if TaxiNodeOnButtonEnter then
                hooksecurefunc("TaxiNodeOnButtonEnter", function(boton)
                    if not (mod and mod.enabled) or not boton or not boton.GetID then return end
                    local i = boton:GetID()
                    if Call(TaxiNodeGetType, i) == "REACHABLE" then LineaTooltip(Str(Call(TaxiNodeName, i))) end
                end)
            end
            EngancharMapaVuelo()
        end
        m:Event("ADDON_LOADED", function(_, _, nombre) if nombre == "Blizzard_FlightMap" then EngancharMapaVuelo() end end)
        m:Event("TAXIMAP_OPENED", function() AprenderNodos() end)
        m:Event("UNIT_SPELLCAST_SUCCEEDED", function(_, _, unit, _, spellID) AlLanzar(unit, spellID) end)
        m:Event("PLAYER_REGEN_DISABLED", function() PintarPanel() end)
        m:Event("PLAYER_REGEN_ENABLED", function() PintarPanel() end)
        m:Event("ZONE_CHANGED_NEW_AREA", function() Invalidar(); PintarPanel() end)
        m:Event("USER_WAYPOINT_UPDATED", function() PintarPanel() end)
        m:Event("GROUP_ROSTER_UPDATE", function() PintarPanel() end)
        m:OnUpdate(function(_, e)
            acumulado = acumulado + e
            if vuelo then SeguirVuelo() end
            if acumulado < m.db.refresco then return end
            acumulado = 0
            VigilarListos()
            PintarPanel()
        end)
    end,
    Enable = function()
        antes = {}
        AplicarPanel(); AplicarBarra(); PintarPanel()
    end,
    Disable = function() vuelo, enVuelo = nil, false end,
}

ns.Viajes = { Planear = Planear, Destino = Destino, Lineas = Lineas, PintarPanel = PintarPanel, Nodos = Nodos, BuscarZona = BuscarZona,
              TiempoVuelo = TiempoVuelo, AlCogerVuelo = AlCogerVuelo, Invalidar = Invalidar, Tiempo = Tiempo, Dist = Dist,
              panel = function() return panel end, barra = function() return barra end }
