-- Customizadoor: gráficos avanzados, filtros de pantalla y ambiente por lugar, como módulo del Hub.
-- Basado en Panorama 1.9.0 (© 2026 dldvlpr, GPL-3.0-or-later). Ver CREDITOS.txt.
-- Archivos: Textos (español), Nucleo (CVars, preajustes, deshacer), Filtros (capa sobre el mundo),
-- Ambiente (lugar y hora), Panel (pestaña) y este, que lo registra en el Hub.
local ADDON, ns = ...
local Hub = ns.Hub
local NS = ns.Customizadoor
local L = NS.L

local function PanoramaLoaded()
    local IsLoaded = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
    return IsLoaded and IsLoaded("Panorama") and true or false
end

local prefs = {}
for key, value in pairs(NS.prefDefaults) do prefs[key] = value end

Hub:Register{
    key = "customizadoor", dir = "Customizadoor", name = "Customizadoor",
    desc = "Ajustes gráficos que el juego solo deja cambiar con /console (distancia, sombras, agua, HDR, cámara...), "
        .. "preajustes, filtros de pantalla (tinte, viñeta, grano, cielo, bandas negras), tus propios filtros "
        .. "y ambiente según el lugar y la hora. Basado en Panorama.",
    -- Cambia ajustes del juego: empieza apagado y lo enciende quien lo quiera.
    defaultOn = false,
    defaults = { prefs = prefs },
    slash = { "customizadoor", "cmcustom" },
    Init = function(mod) NS.Load(mod.db) end,
    Enable = function(mod)
        NS.Load(mod.db)
        if NS.Prefs().guard and PanoramaLoaded() then
            mod:Print(L.MOD_PANORAMA_LOADED)
            C_Timer.After(0, function() Hub:SetEnabled(mod.key, false, true) end)
            return
        end
        NS.Start()
    end,
    Disable = function() NS.Stop() end,
    BuildConfig = function(mod, layout, parent)
        NS.Load(mod.db)
        local panel = NS.BuildPanel(parent, parent:GetParent())
        panel.Refresh = NS.RefreshPanel
        layout:Add(panel, 0)
    end,
    OnSlash = function(mod, msg) NS.HandleSlash(msg) end,
    -- «Restaurar valores» del Hub: las opciones de la pestaña Módulo ya han vuelto a su valor; con el
    -- módulo activado también se restablecen los gráficos y los filtros (se puede deshacer).
    OnReset = function(mod)
        if NS.active then NS.ResetAll() end
    end,
}

function NS.OpenOptions() Hub:Open("customizadoor") end
