-- Parte "Espia" del modulo Enemigos cercanos (PvPOutdoor) para WoW Forever (Interface 16001).
-- Funciones al estilo del addon Spy adaptadas a Forever (sin registro de combate):
--   * ficha guardada de cada enemigo visto (clase, raza, hermandad, nivel, donde y cuando)
--   * listas: Ultima hora, Matar a la vista (KOS) con motivos, Ignorados
--   * victorias / derrotas por jugador, ventana de estadisticas con busqueda y filtros
--   * informacion en el tooltip, anunciar en el chat, menu del clic derecho
--   * aviso de sigilo, aviso de hermandad KOS
--   * avisos de KOS compartidos con la hermandad y el grupo (mensajes de addon)
-- Este archivo se carga ANTES que Enemigos.lua; Enemigos.lua llama a ns.PO_Espia.Init(mod, api).

local ADDON, ns = ...
local Hub = ns.Hub
local E = {}
ns.PO_Espia = E

local issecret = issecretvalue or function() return false end
local PREFIX, PROTO = "CMEspia", "1"

local mod, DB, S, API     -- S = DB.spy (ajustes); API = funciones de Enemigos.lua

E.DEFAULTS = {
    remember = true,       -- guardar ficha de cada enemigo visto
    maxPlayers = 2000,     -- fichas maximas (se borran las mas viejas sin KOS/estadisticas)
    hourMinutes = 60,      -- "Ultima hora": minutos que abarca
    autoNear = true,       -- volver a la lista "Cerca" al detectar a alguien nuevo
    hideIgnored = true,    -- no mostrar ignorados en la lista Cerca
    kosFirst = true,       -- KOS arriba del todo en la lista
    clickTarget = true,    -- clic izquierdo en una fila = seleccionarlo como objetivo
    kosText = true, kosSound = true, kosSoundKit = "RAID_WARNING",
    kosRepeat = 120,       -- seg. antes de volver a avisar del mismo KOS
    kosGuild = true,       -- avisar si es de la misma hermandad que alguien de tu KOS
    stealthText = true, stealthSound = false,   -- la voz del modulo Voces ya dice "sigilo"
    tooltip = true,        -- lineas extra en el tooltip
    tooltipSeen = true,    -- en el tooltip, "visto N veces / hace X"
    wins = true,           -- contar victorias (muerte del enemigo con el que peleabas)
    engageSeconds = 20,    -- seg. desde la ultima pelea para contar la muerte como tuya
    announce = "PARTY",    -- canal para "Anunciar": PARTY / RAID / GUILD / SAY / INSTANCE_CHAT
    shareGuild = true,     -- enviar a la hermandad los KOS que veo
    shareGroup = true,     -- enviar al grupo/banda los KOS que veo
    receive = true,        -- recibir avisos de KOS de otros
    receiveSound = true, receiveText = true,
    acceptLists = false,   -- aceptar listas KOS que te compartan (se anaden con motivo "compartido")
    sightPins = true,      -- marcar en el mapa los KOS vistos (tuyos y compartidos)
    seenPins = false,      -- marcar en el mapa a TODOS los enemigos vistos en la ultima hora
    pinMinutes = 5,        -- minutos que dura la marca de un KOS visto
    senderGap = 3, senderLimit = 10,  -- anti-spam por emisor (seg. / avisos por minuto)
    -- ajustes finos (1.2)
    kosChat = true,        -- linea en el chat al ver a un KOS
    kosGuildText = true, kosGuildSound = true, kosGuildSoundKit = "IG_PVP_UPDATE",
    stealthSoundKit = "ALARM_CLOCK_WARNING_3",
    stealthKOSOnly = false, -- aviso de sigilo solo de jugadores KOS
    stealthGap = 2,        -- seg. minimos entre avisos de sigilo
    winsHonor = true,      -- el mensaje de muerte honorable cuenta como victoria
    winsChat = true,       -- linea en el chat al contar una victoria
    losses = true,         -- contar derrotas (quien te tenia de objetivo al morir)
    tooltipKOS = true,     -- en el tooltip, "Matar a la vista: motivo" / ignorado
    tooltipStats = true,   -- en el tooltip, victorias y derrotas
    receiveChat = true,    -- linea en el chat al recibir un aviso
    receiveSoundKit = "RAID_WARNING",
    receivePins = true,    -- marcar en el mapa los KOS que te avisan otros
    -- compartir TODOS los avistamientos (no solo KOS) con la posicion de quien los ve
    shareAll = true,       -- enviar los enemigos que veo
    shareAllGroup = true,  --   a mi grupo/banda
    shareAllGuild = true,  --   a mi hermandad
    shareAllRepeat = 60,   --   volver a enviar el mismo enemigo tras (s) si lo sigo viendo
    recvAll = true,        -- recibir los avistamientos de otros
    recvAllSameZone = true,-- solo los de mi misma zona
    recvAllMaxDist = 500,  -- y como mucho a esta distancia de mi (metros; 0 = sin limite)
    recvAllChat = true, recvAllText = true, recvAllSound = true, recvAllSoundKit = "IG_PVP_UPDATE",
    recvAllList = true,    -- meterlos en la lista Cerca (con quien los vio)
    recvAllRadar = true,   -- flecha en el radar hacia donde estan
    recvAllPins = true,    -- marca en el mapa
    recvAllRepeat = 60,    -- no repetir el aviso del mismo enemigo antes de (s)
    kosPinIcon = 7, seenPinIcon = 2,   -- icono de banda (1-8) de cada marca del mapa
    reasons = "Me ataca sin motivo;Me campea;Mata a jugadores de bajo nivel;Me mato mientras subia de nivel;" ..
        "Me quito un objetivo o recurso;Jugador muy peligroso;Insulta / mal comportamiento",
    -- lista de enemigos
    views = { hour = true, kos = true, ignore = true, zones = true, revenge = true },  -- listas que recorren < y >
    hotMinutes = 15,       -- "Zonas calientes": enemigos distintos vistos en cada zona en estos minutos
    winsPartyKill = true,  -- golpe final tuyo (evento PARTY_KILL) = victoria
    winsGroupKill = false, -- tambien cuentan las bajas que hace tu grupo
    notes = true,          -- mostrar las notas en tooltips y en la lista
    headerButtons = true,  -- botones < > E X en la cabecera de la lista
    rowMenu = true,        -- clic derecho en una fila: menu
    rowTooltip = true,     -- tooltip al pasar el raton por una fila
    xHides = true,         -- X: ademas de vaciar, ocultar la lista hasta el proximo enemigo nuevo
    statsRows = 300,       -- filas maximas de la ventana de estadisticas
    -- exportar a la app WoW Forever Guide (lo recoge su addon «Exportar personaje»)
    exportApp = true, exportKills = 10, exportDeaths = 10, exportRevenge = 10,
    -- lista de venganza: quien te ha matado alguna vez
    revenge = true,        -- llevar la lista de venganza
    revengeAuto = true,    -- anadir solo a quien te mata
    revengeChatAdd = true, -- linea en el chat al anadir a alguien por matarte
    revengeText = true, revengeSound = true, revengeSoundKit = "IG_PVP_UPDATE",
    revengeChat = true,    -- linea en el chat al verlo cerca
    revengeRepeat = 120,   -- seg. antes de volver a avisar del mismo
    revengeDone = true,    -- aviso de "venganza cumplida" al matarlo
    revengeRemove = false, -- quitarlo de la lista al vengarte
    revengeTooltip = true, -- "Te ha matado N veces" en el tooltip
    charTab = true,        -- pestaña «Venganza» en la ventana de personaje (debajo de la de Overlord)
    revengeNear = true,    -- marca VEN en la lista Cerca
}

local function Reasons()
    local out = {}
    for r in string.gmatch((S and S.reasons) or E.DEFAULTS.reasons, "[^;]+") do
        r = r:gsub("^%s+", ""):gsub("%s+$", ""):gsub("|", "")
        if r ~= "" and #out < 20 then out[#out + 1] = r end
    end
    return out
end

local CLASSES = {
    WARRIOR = true, PALADIN = true, HUNTER = true, ROGUE = true, PRIEST = true,
    DEATHKNIGHT = true, SHAMAN = true, MAGE = true, WARLOCK = true, MONK = true,
    DRUID = true, DEMONHUNTER = true, EVOKER = true,
}

----------------------------------------------------------------------
-- Utilidades
----------------------------------------------------------------------
local function Print(msg) if mod then mod:Print(msg) end end
local function Clean(v) if issecret(v) then return nil end return v end
local function Clamp(v, a, b) if v < a then return a elseif v > b then return b end return v end

local function SafeName(s)
    if type(s) ~= "string" or issecret(s) then return nil end
    s = s:gsub("|", ""):gsub("%c", ""):gsub(",", "")
    if s == "" or #s > 48 then return nil end
    return s
end

E.SafeName = function(s) return SafeName(s) end

local function ClassColor(class)
    local c = class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]
    if c then return string.format("|cff%02x%02x%02x", c.r * 255, c.g * 255, c.b * 255) end
    return "|cffffffff"
end
E.ClassColor = ClassColor

local function Ago(t)
    if not t then return "?" end
    local d = time() - t
    if d < 60 then return "hace " .. d .. " s"
    elseif d < 3600 then return "hace " .. math.floor(d / 60) .. " min"
    elseif d < 86400 then return "hace " .. math.floor(d / 3600) .. " h"
    else return "hace " .. math.floor(d / 86400) .. " d" end
end
E.Ago = Ago

local function MyName() return Hub.UnitFullName("player") end

local function ShortSender(s)
    if type(s) ~= "string" or issecret(s) then return nil end
    if Ambiguate then
        local ok, n = pcall(Ambiguate, s, "none")
        if ok and type(n) == "string" then s = n end
    end
    return SafeName(Hub.ShortName(s) or s)
end

local function MapName(mapID)
    if mapID and C_Map and C_Map.GetMapInfo then
        local ok, info = pcall(C_Map.GetMapInfo, mapID)
        if ok and info and info.name then return info.name end
    end
    return "?"
end

local function PlayerPos()
    if not (C_Map and C_Map.GetBestMapForUnit) then return nil end
    local ok, mapID = pcall(C_Map.GetBestMapForUnit, "player")
    if not ok or not mapID or issecret(mapID) then return nil end
    local ok2, pos = pcall(C_Map.GetPlayerMapPosition, mapID, "player")
    if not ok2 or not pos then return mapID end
    local x, y = pos:GetXY()
    if issecret(x) or issecret(y) or not x or x <= 0 then return mapID end
    return mapID, x, y
end

local function Kit(name)
    if not (S and SOUNDKIT) then return end
    local k = SOUNDKIT[name] or SOUNDKIT.RAID_WARNING
    if k then pcall(PlaySound, k) end
end

----------------------------------------------------------------------
-- Fichas de jugadores
----------------------------------------------------------------------
-- DB.players[nombre] = { c=claseEN, cl=claseLocal, r=raza, g=hermandad, l=nivel,
--   f=primera vez, t=ultima vez (time()), z=zona, sz=subzona, m=mapID, x, y,
--   s=veces visto, w=victorias, d=derrotas, k=KOS, kr=motivo, kt=fecha KOS, i=ignorado,
--   v=lista de venganza, vn=veces que te ha matado, vt=ultima vez que te mato, vw=venganzas cumplidas }
local inserts = 0

function E.Get(name) return name and DB and DB.players[name] end
function E.IsKOS(name) local p = E.Get(name); return p and p.k or false end
function E.IsIgnored(name) local p = E.Get(name); return p and p.i or false end
function E.IsRevenge(name) local p = E.Get(name); return p and p.v or false end

local function Ensure(name)
    local p = DB.players[name]
    if not p then
        p = { f = time(), s = 0 }
        DB.players[name] = p
        inserts = inserts + 1
        if inserts % 100 == 0 then E.Prune() end
    end
    return p
end

local function Keep(p) return p.k or p.i or (p.w and p.w > 0) or (p.d and p.d > 0) or p.kr or p.v end

function E.Prune()
    if not DB then return end
    local arr, n = {}, 0
    for name, p in pairs(DB.players) do
        n = n + 1
        if not Keep(p) then arr[#arr + 1] = { name, p.t or 0 } end
    end
    local extra = n - (S.maxPlayers or 2000)
    if extra <= 0 then return end
    table.sort(arr, function(a, b) return a[2] < b[2] end)
    for i = 1, math.min(extra, #arr) do DB.players[arr[i][1]] = nil end
end

-- Lectura completa del nombre (con reino si es de otro reino).
-- En Forever: "Nombre Apellido" (UnitName da nombre y apellido); sirve tal cual para /targetexact.
function E.UnitFullName(unit) return SafeName(Hub.UnitFullName(unit)) end

-- Actualiza la ficha con los datos de una unidad visible. isNew = primera vez en esta deteccion.
function E.Record(e, unit, isNew)
    if not DB or not e.full then return end
    local p = DB.players[e.full]
    if not p and not S.remember then return end
    p = p or Ensure(e.full)
    if e.class then p.c, p.cl = e.class, e.loc end
    if e.level and e.level ~= 0 then p.l = e.level end
    local okr, race = pcall(UnitRace, unit)
    race = okr and Clean(race)
    if race then p.r = race; e.race = race elseif e.race then p.r = e.race end
    if GetGuildInfo then
        local okg, guild = pcall(GetGuildInfo, unit)
        guild = okg and Clean(guild)
        if guild and guild ~= "" then p.g = guild; e.guild = guild end
    end
    p.t = time()
    if isNew then
        p.s = (p.s or 0) + 1
        local mapID, x, y = PlayerPos()
        p.m = mapID
        p.x = x and math.floor(x * 1000 + 0.5) / 1000 or nil
        p.y = y and math.floor(y * 1000 + 0.5) / 1000 or nil
        p.z = Clean(GetRealZoneText and GetRealZoneText())
        p.sz = Clean(GetSubZoneText and GetSubZoneText())
    end
    e.guild = e.guild or p.g
end

function E.SetKOS(name, on, reason, silent)
    name = SafeName(name)
    if not name then return end
    local p = Ensure(name)
    p.k = on and true or nil
    if on then
        p.kt = p.kt or time()
        if reason then p.kr = reason end
        p.i = nil
    else
        p.kt, p.kr = nil, nil
    end
    if not silent then Print(name .. (on and " añadido a |cffff3030Matar a la vista|r" or " quitado de Matar a la vista") ..
        (on and reason and (" (" .. reason .. ")") or "")) end
    if API then API.Refresh() end
end

function E.SetIgnore(name, on, silent)
    name = SafeName(name)
    if not name then return end
    local p = Ensure(name)
    p.i = on and true or nil
    if on then p.k, p.kt, p.kr = nil, nil, nil end
    if not silent then Print(name .. (on and " añadido a ignorados (sin avisos)" or " quitado de ignorados")) end
    if API then API.Refresh() end
end

function E.Remove(name)
    if DB and DB.players[name] then DB.players[name] = nil; Print(name .. ": ficha borrada.") end
    if API then API.Refresh() end
end

-- Listas para la ventana de enemigos. Devuelven fichas con .name.
local function ListWhere(fn, sortFn)
    local arr = {}
    for name, p in pairs(DB.players) do
        if fn(p) then arr[#arr + 1] = setmetatable({ name = name }, { __index = p }) end
    end
    table.sort(arr, sortFn or function(a, b) return (a.t or 0) > (b.t or 0) end)
    return arr
end
function E.LastHour()
    local lim = time() - (S.hourMinutes or 60) * 60
    return ListWhere(function(p) return p.t and p.t >= lim and not p.i end)
end
-- Zonas calientes: enemigos distintos vistos en cada zona en los ultimos S.hotMinutes.
function E.Hotspots()
    local lim, by = time() - (S.hotMinutes or 15) * 60, {}
    for _, p in pairs(DB.players) do
        if p.t and p.t >= lim and p.z and not p.i then
            local z = by[p.z] or { zone = p.z, n = 0, kos = 0, t = 0 }
            by[p.z] = z
            z.n = z.n + 1
            if p.k then z.kos = z.kos + 1 end
            if p.t > z.t then z.t = p.t end
        end
    end
    local out = {}
    for _, z in pairs(by) do out[#out + 1] = z end
    table.sort(out, function(a, b) if a.n ~= b.n then return a.n > b.n end return a.t > b.t end)
    return out
end

function E.KOSList() return ListWhere(function(p) return p.k end, function(a, b) return a.name < b.name end) end
function E.IgnoreList() return ListWhere(function(p) return p.i end, function(a, b) return a.name < b.name end) end
-- Venganza: los que mas veces te han matado arriba; a igualdad, el mas reciente.
-- Lo que se manda a la app WoW Forever Guide: los que más has matado, los que más te han matado y tu
-- lista de venganza (primero los pendientes). Pocas fichas y campos cortos para no alargar el texto.
local function Ficha(p)
    local f = { n = p.name, c = p.c, r = p.r, l = p.l, g = p.g, w = p.w, d = math.max(p.d or 0, p.vn or 0),
                t = p.t, z = p.z, vn = p.vn, vw = E.RevengeKills(p), vt = p.vt }
    if p.k then f.k = 1 end
    if p.v then f.v = 1 end
    return f
end
local function Primeros(arr, n)
    local out = {}
    for i = 1, math.min(n or 10, #arr) do out[#out + 1] = Ficha(arr[i]) end
    return out
end
function E.ExportApp()
    if not (DB and S and S.exportApp and DB.players) then return nil end
    local function MasReciente(a, b) return (a.t or 0) > (b.t or 0) end
    local matados = ListWhere(function(p) return (p.w or 0) > 0 end, function(a, b)
        if (a.w or 0) ~= (b.w or 0) then return (a.w or 0) > (b.w or 0) end
        return MasReciente(a, b)
    end)
    local function Muertes(p) return math.max(p.d or 0, p.vn or 0) end
    local verdugos = ListWhere(function(p) return Muertes(p) > 0 end, function(a, b)
        if Muertes(a) ~= Muertes(b) then return Muertes(a) > Muertes(b) end
        return MasReciente(a, b)
    end)
    local function Pendiente(p) return (p.vn or 0) > E.RevengeKills(p) end
    local venganza = ListWhere(function(p) return p.v end, function(a, b)
        if Pendiente(a) ~= Pendiente(b) then return Pendiente(a) end
        if (a.vn or 0) ~= (b.vn or 0) then return (a.vn or 0) > (b.vn or 0) end
        return (a.vt or 0) > (b.vt or 0)
    end)
    return { v = 1, mt = Primeros(matados, S.exportKills), mm = Primeros(verdugos, S.exportDeaths),
             ve = Primeros(venganza, S.exportRevenge) }
end
-- Registro común de lo que exportan los addons CervecerosMendigos (lo lee el addon de la app).
CervecerosMendigosExporta = CervecerosMendigosExporta or {}
CervecerosMendigosExporta.espia = function() return E.ExportApp() end

-- Veces que le has matado (todas, las mismas que el balance victorias-derrotas de su ficha). p.vw = las de
-- despues de entrar en la lista de venganza (antes de la 2.0 era lo unico que se contaba y no cuadraba con el balance).
function E.RevengeKills(p) return math.max(p.w or 0, p.vw or 0) end

function E.RevengeList()
    return ListWhere(function(p) return p.v end, function(a, b)
        if (a.vn or 0) ~= (b.vn or 0) then return (a.vn or 0) > (b.vn or 0) end
        if (a.vt or 0) ~= (b.vt or 0) then return (a.vt or 0) > (b.vt or 0) end
        return a.name < b.name
    end)
end

----------------------------------------------------------------------
-- Lista de venganza (editable: anadir, quitar, cambiar veces, notas)
----------------------------------------------------------------------
local function RevengeChanged()
    if API then API.Refresh() end
    if E.RefreshRevenge then E.RefreshRevenge() end
end

-- on = true/false. silent = sin linea en el chat.
function E.SetRevenge(name, on, silent)
    name = SafeName(name)
    if not (DB and name) then return end
    local p = Ensure(name)
    if on then
        p.v = true
        p.vt = p.vt or time()
        p.vn = p.vn or 0
    else
        p.v, p.vn, p.vt, p.vw = nil, nil, nil, nil
    end
    if not silent then Print(name .. (on and " añadido a tu |cffff8000lista de venganza|r" or " quitado de la lista de venganza")) end
    RevengeChanged()
end

-- Cambia las veces que te ha matado (para corregir la cuenta a mano).
-- Corrige a mano las veces que le has matado (lo que sale en «Le mataste»): cambia tus victorias contra el,
-- asi cuadra tambien con el balance victorias-derrotas de su ficha.
function E.SetRevengeKills(name, n)
    local p = E.Get(name)
    if not p then return end
    n = Clamp(math.floor(tonumber(n) or 0), 0, 9999)
    p.w = n > 0 and n or nil
    if (p.vw or 0) > n then p.vw = n > 0 and n or nil end
    RevengeChanged()
    if API then API.Refresh() end
end

function E.SetRevengeCount(name, n)
    local p = E.Get(name)
    if not (p and p.v) then return end
    n = math.floor(tonumber(n) or 0)
    p.vn = Clamp(n, 0, 9999)
    RevengeChanged()
end

-- Vaciar toda la lista (las fichas y estadisticas se quedan).
function E.ClearRevenge()
    if not DB then return end
    for _, p in pairs(DB.players) do p.v, p.vn, p.vt, p.vw = nil, nil, nil, nil end
    Print("lista de venganza vaciada.")
    RevengeChanged()
end

-- Anade a la lista a todos los que ya tienen derrotas tuyas registradas. Devuelve cuantos.
function E.ImportRevenge(silent)
    if not DB then return 0 end
    local n = 0
    for _, p in pairs(DB.players) do
        if (p.d or 0) > 0 and not p.v then
            p.v, p.vn, p.vt = true, p.d, p.vt or p.t
            n = n + 1
        end
    end
    if not silent then
        Print(n .. (n == 1 and " jugador añadido" or " jugadores añadidos") .. " a la lista de venganza desde tus derrotas.")
        RevengeChanged()
    end
    return n
end

local function KOSGuilds()
    local g = {}
    for _, p in pairs(DB.players) do if p.k and p.g then g[p.g] = true end end
    return g
end

----------------------------------------------------------------------
-- Victorias y derrotas
----------------------------------------------------------------------
local engaged = {}     -- nombre -> GetTime() de la ultima pelea
local counted = {}     -- nombre -> GetTime() de la ultima victoria contada (evita dobles)

function E.Engage(name) if name then engaged[name] = GetTime() end end

function E.RecordWin(name, why)
    if not (DB and S.wins and name) then return end
    local now = GetTime()
    if counted[name] and now - counted[name] < 60 then return end
    counted[name] = now
    local p = Ensure(name)
    p.w = (p.w or 0) + 1
    if S.winsChat then Print("|cff55ff55Victoria|r contra " .. name .. " (" .. p.w .. "-" .. (p.d or 0) .. ")" .. (why and (" · " .. why) or "")) end
    if p.v and S.revenge then
        p.vw = (p.vw or 0) + 1
        if S.revengeDone then
            API.Alert("¡Venganza cumplida! " .. name, 1, 0.5, 0)
            Print("|cffff8000¡Venganza cumplida!|r " .. name .. " (te ha matado " .. (p.vn or 0) .. ", le has matado " .. E.RevengeKills(p) .. ")")
        end
        if S.revengeRemove then E.SetRevenge(name, false, true) end
    end
    if API then API.Refresh() end
    if E.RefreshRevenge then E.RefreshRevenge() end
end

function E.RecordLoss(name)
    if not (DB and name and name ~= "?") then return end
    if S.losses then
        local p = Ensure(name)
        p.d = (p.d or 0) + 1
    end
    if S.revenge and S.revengeAuto then
        local p = Ensure(name)
        local nuevo = not p.v
        p.v, p.vn, p.vt = true, (p.vn or 0) + 1, time()
        if S.revengeChatAdd then
            Print(nuevo and (name .. " añadido a tu |cffff8000lista de venganza|r.")
                or (name .. " ya te ha matado " .. p.vn .. " veces (|cffff8000venganza|r)."))
        end
        RevengeChanged()
    end
end

-- Llamado con cada enemigo visible: si esta muerto y peleabas con el, cuenta victoria.
function E.CheckDead(e, unit)
    if not (S and S.wins and e.full) then return end
    local ok, dead = pcall(UnitIsDeadOrGhost, unit)
    if not ok or issecret(dead) then return end
    if dead then
        local t = engaged[e.full]
        if t and GetTime() - t <= (S.engageSeconds or 20) then
            engaged[e.full] = nil
            E.RecordWin(e.full)
        end
    end
end

-- PARTY_KILL (atacanteGUID, victimaGUID): golpe final tuyo o de tu grupo. Fiable, sin registro de combate.
function E.OnPartyKill(attacker, victim, nameOf)
    if not (S and S.wins and S.winsPartyKill) then return end
    if type(attacker) ~= "string" or type(victim) ~= "string" or issecret(attacker) or issecret(victim) then return end
    if not victim:find("^Player%-") then return end
    local me = Clean(UnitGUID("player"))
    local mine = me and attacker == me
    if not mine and not S.winsGroupKill then return end
    local name = nameOf and nameOf(victim)
    if not name and GetPlayerInfoByGUID then
        local ok, _, _, _, _, _, n = pcall(GetPlayerInfoByGUID, victim)
        if ok and type(n) == "string" and not issecret(n) then name = SafeName(n) end
    end
    if name then E.RecordWin(name, mine and "golpe final" or "baja del grupo") end
end

-- Mensaje de muerte honorable: "%s muere, rango estimado..." -> victoria.
local honorPatterns
local function BuildHonorPatterns()
    honorPatterns = {}
    for _, key in ipairs({ "COMBATLOG_HONORGAIN", "COMBATLOG_HONORGAIN_NO_RANK", "COMBATLOG_HONORGAIN_EXHAUSTION1" }) do
        local s = _G[key]
        if type(s) == "string" and not issecret(s) then
            s = s:gsub("%%%d%$([sd])", "%%%1")            -- "%1$s" -> "%s"
            if s:find("%%s") then
                local p = s:gsub("([%(%)%.%+%-%*%?%[%]%^%$])", "%%%1")
                p = p:gsub("%%s", "\1", 1)                    -- primer %s = el nombre
                p = p:gsub("%%s", ".-"):gsub("%%d", "%%d+"):gsub("\1", "(.-)")
                honorPatterns[#honorPatterns + 1] = "^" .. p .. "$"
            end
        end
    end
end

function E.OnHonorMessage(msg)
    if not (S and S.wins and S.winsHonor) or type(msg) ~= "string" or issecret(msg) then return end
    if not honorPatterns then BuildHonorPatterns() end
    for _, pat in ipairs(honorPatterns) do
        local name = msg:match(pat)
        name = SafeName(name)
        if name then E.RecordWin(name, "muerte honorable"); return end
    end
end

----------------------------------------------------------------------
-- Avisos al detectar
----------------------------------------------------------------------
local kosWarned = {}   -- nombre -> GetTime()
local revWarned = {}   -- nombre -> GetTime() (aviso de venganza, aparte del de KOS / hermandad)

-- Devuelve true si el enemigo esta ignorado (Enemigos.lua no hace sus avisos).
function E.OnDetected(e, isNew)
    if not DB or not e.full then return false end
    local p = DB.players[e.full]
    if p and p.i then return true end
    local now = GetTime()
    if p and p.k then
        if not kosWarned[e.full] or now - kosWarned[e.full] > (S.kosRepeat or 120) then
            kosWarned[e.full] = now
            if S.kosText then API.Alert("¡KOS! " .. e.full .. (p.kr and (" · " .. p.kr) or ""), 1, 0, 0.6) end
            if S.kosSound then Kit(S.kosSoundKit) end
            if S.kosChat then Print("|cffff3030Matar a la vista:|r " .. ClassColor(e.class) .. e.full .. "|r" ..
                (e.level and (" " .. (e.level == -1 and "??" or e.level)) or "") .. (p.kr and (" · " .. p.kr) or "")) end
            E.ShareSighting(e)
            E.AddSighting(e.full, e.class, e.level, nil)
        end
    elseif p and p.v and S.revenge then
        if not revWarned[e.full] or now - revWarned[e.full] > (S.revengeRepeat or 120) then
            revWarned[e.full] = now
            local veces = (p.vn or 0) > 0 and (" · te ha matado " .. p.vn .. (p.vn == 1 and " vez" or " veces")) or ""
            if S.revengeText then API.Alert("¡VENGANZA! " .. e.full .. veces, 1, 0.5, 0) end
            if S.revengeSound then Kit(S.revengeSoundKit) end
            if S.revengeChat then Print("|cffff8000Venganza:|r " .. ClassColor(e.class) .. e.full .. "|r" ..
                (e.level and (" " .. (e.level == -1 and "??" or e.level)) or "") .. veces .. (p.n and (" · " .. p.n) or "")) end
        end
    elseif isNew and S.kosGuild and e.guild then
        if KOSGuilds()[e.guild] and (not kosWarned[e.full] or now - kosWarned[e.full] > (S.kosRepeat or 120)) then
            kosWarned[e.full] = now
            if S.kosGuildText then API.Alert("Hermandad KOS: " .. e.full .. " <" .. e.guild .. ">", 1, 0.4, 0.8) end
            if S.kosGuildSound then Kit(S.kosGuildSoundKit) end
        end
    end
    return false
end

-- Sigilo: lo detecta el evento UNIT_SPELLCAST_SUCCEEDED de una unidad visible.
local stealthNames
local function BuildStealth()
    stealthNames = {}
    for _, id in ipairs({ 1784, 1785, 1786, 1787, 1856, 1857, 26889, 5215, 6783, 9913, 58984, 20580, 66, 32612 }) do
        local n = C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(id)
        if n and not issecret(n) then stealthNames[n] = true end
    end
end
local lastStealth = 0
function E.OnSpell(full, class, spellName)
    if not (S and (S.stealthText or S.stealthSound)) or not spellName then return end
    if not stealthNames then BuildStealth() end
    if not stealthNames[spellName] then return end
    if full and E.IsIgnored(full) then return end
    if S.stealthKOSOnly and not (full and E.IsKOS(full)) then return end
    local now = GetTime()
    if now - lastStealth < (S.stealthGap or 2) then return end
    lastStealth = now
    if S.stealthText then API.Alert("¡SIGILO! " .. (full or "Enemigo") .. " · " .. spellName, 0.7, 0.4, 1) end
    if S.stealthSound then Kit(S.stealthSoundKit) end
end

----------------------------------------------------------------------
-- Marcas en el mapa (KOS vistos)
----------------------------------------------------------------------
local sightings = {}   -- { name, class, level, mapID, x, y, by, expire }
function E.AddSighting(name, class, level, by, mapID, x, y)
    if not mapID then mapID, x, y = PlayerPos() end
    if not (mapID and x) then return end
    for i = #sightings, 1, -1 do if sightings[i].name == name then table.remove(sightings, i) end end
    sightings[#sightings + 1] = { name = name, class = class, level = level, mapID = mapID, x = x, y = y,
        by = by, expire = GetTime() + (S.pinMinutes or 5) * 60, when = date("%H:%M") }
    while #sightings > 30 do table.remove(sightings, 1) end
    if API then API.UpdatePins() end
end

-- Marcas para el mapa mapID: devuelve lista de { x, y, kind, lines }
function E.MapMarks(mapID)
    local out, now = {}, GetTime()
    if S.sightPins or S.receivePins then
        for i = #sightings, 1, -1 do
            local s = sightings[i]
            if now > s.expire then table.remove(sightings, i)
            elseif s.mapID == mapID and ((s.by and S.receivePins) or (not s.by and S.sightPins)) then
                out[#out + 1] = { x = s.x, y = s.y, kind = "kos", title = "KOS: " .. s.name,
                    text = (s.by and ("visto por " .. s.by) or "visto por ti") .. " a las " .. s.when }
            end
        end
    end
    if S.seenPins then
        local lim = time() - (S.hourMinutes or 60) * 60
        for name, p in pairs(DB.players) do
            if p.m == mapID and p.x and p.t and p.t >= lim and not p.i and not p.k then
                out[#out + 1] = { x = p.x, y = p.y, kind = "seen", title = name,
                    text = (p.cl or "?") .. " " .. (p.l == -1 and "??" or (p.l or "?")) .. " · " .. Ago(p.t) }
            end
        end
    end
    return out
end

----------------------------------------------------------------------
-- Mensajes de addon (avisos de KOS compartidos)
----------------------------------------------------------------------
local queue = {}       -- { msg, chan, t }
local senders = {}

local function Channels()
    local out = {}
    if S.shareGuild and IsInGuild and IsInGuild() then out[#out + 1] = "GUILD" end
    if S.shareGroup then
        if IsInGroup and LE_PARTY_CATEGORY_INSTANCE and IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then out[#out + 1] = "INSTANCE_CHAT"
        elseif IsInRaid and IsInRaid() then out[#out + 1] = "RAID"
        elseif IsInGroup and IsInGroup() then out[#out + 1] = "PARTY" end
    end
    return out
end

local function RawSend(msg, chan)
    if not (C_ChatInfo and C_ChatInfo.SendAddonMessage) then return true end
    local ok, res = pcall(C_ChatInfo.SendAddonMessage, PREFIX, msg, chan)
    if not ok then return false end
    return res == nil or res == 0 or res == true
end

local function Send(msg, chans)
    for _, chan in ipairs(chans or Channels()) do
        if not RawSend(msg, chan) then queue[#queue + 1] = { msg = msg, chan = chan, t = GetTime() } end
    end
end

-- Reintenta lo pendiente (en combate los mensajes de addon pueden bloquearse). Avisos de >60 s se descartan.
function E.Flush()
    if #queue == 0 then return end
    local now, keep = GetTime(), {}
    for _, q in ipairs(queue) do
        if now - q.t <= 60 and not RawSend(q.msg, q.chan) then keep[#keep + 1] = q end
    end
    queue = keep
end

function E.ShareSighting(e)
    if not (S.shareGuild or S.shareGroup) then return end
    local mapID, x, y = PlayerPos()
    local msg = table.concat({ PROTO, "S", e.full, e.class or "?", tostring(e.level or "?"),
        tostring(mapID or 0), tostring(x and math.floor(x * 1000 + 0.5) or 0),
        tostring(y and math.floor(y * 1000 + 0.5) or 0) }, "|")
    Send(msg)
end

-- Todos los avistamientos: PROTO|A|nombre|clase|nivel|mapa|x|y|ataca  (ataca = 1 si me esta atacando)
local lastShareAll = 0
local function ChannelsAll()
    local out = {}
    if S.shareAllGuild and IsInGuild and IsInGuild() then out[#out + 1] = "GUILD" end
    if S.shareAllGroup then
        if IsInRaid and IsInRaid() then out[#out + 1] = "RAID"
        elseif IsInGroup and IsInGroup() then out[#out + 1] = "PARTY" end
    end
    return out
end
function E.ShareAll(e, attacking)
    if not (DB and S.shareAll and e and e.full) then return false end
    local p = DB.players[e.full]
    if p and p.i then return false end
    -- los KOS ya van por su aviso propio (si esta activado)
    if p and p.k and (S.shareGuild or S.shareGroup) then return false end
    local chans = ChannelsAll()
    if #chans == 0 then return false end
    local now = GetTime()
    if now - lastShareAll < 1 then return false end   -- como mucho uno por segundo
    local mapID, x, y = PlayerPos()
    if not (mapID and x) then return false end
    lastShareAll = now
    Send(table.concat({ PROTO, "A", e.full, e.class or "?", tostring(e.level or "?"), tostring(mapID),
        tostring(math.floor(x * 10000 + 0.5)), tostring(math.floor(y * 10000 + 0.5)), attacking and "1" or "0" }, "|"), chans)
    return true
end

-- Posicion en el mundo (yardas; x crece al norte, y al oeste) de un punto del mapa.
local function WorldPos(mapID, x, y)
    if not (C_Map and C_Map.GetWorldPosFromMapPos and CreateVector2D) then return nil end
    local ok, _, v = pcall(C_Map.GetWorldPosFromMapPos, mapID, CreateVector2D(x, y))
    if not ok or not v then return nil end
    local wx, wy = v:GetXY()
    if issecret(wx) or not wx then return nil end
    return wx, wy
end
E.WorldPos = WorldPos
local COMPASS = { "N", "NE", "E", "SE", "S", "SO", "O", "NO" }
-- distancia (m) y rumbo (radianes, 0 = norte, sentido horario) de A a B en coordenadas del mundo
function E.DistBearing(ax, ay, bx, by)
    local dN, dW = bx - ax, by - ay
    local b = math.atan2(-dW, dN)
    if b < 0 then b = b + 2 * math.pi end
    return math.sqrt(dN * dN + dW * dW) * 0.9144, b
end
function E.CompassName(b) return COMPASS[(math.floor((b / (2 * math.pi)) * 8 + 0.5) % 8) + 1] end

local recvAllSenders, recvAllWarned = {}, {}
local function AntiSpamAll(sender)
    local now = GetTime()
    local r = recvAllSenders[sender] or {}
    recvAllSenders[sender] = r
    for i = #r, 1, -1 do if now - r[i] > 60 then table.remove(r, i) end end
    if #r >= 30 then return false end
    r[#r + 1] = now
    return true
end

function E.ShareList(chan)
    local names = {}
    for _, p in ipairs(E.KOSList()) do names[#names + 1] = p.name end
    if #names == 0 then Print("tu lista Matar a la vista esta vacia."); return end
    local chunk, n = {}, 0
    local function Out()
        if #chunk > 0 then Send(PROTO .. "|L|" .. table.concat(chunk, ","), { chan }); chunk = {} end
    end
    local len = 0
    for _, name in ipairs(names) do
        if len + #name + 1 > 220 then Out(); len = 0 end
        chunk[#chunk + 1] = name; len = len + #name + 1; n = n + 1
    end
    Out()
    Print(n .. " nombres de tu lista KOS enviados a " .. chan .. ".")
end

local function AntiSpam(sender)
    local now = GetTime()
    local s = senders[sender]
    if not s then s = { last = -100, recent = {} }; senders[sender] = s end
    if now - s.last < (S.senderGap or 3) then return false end
    local n = 0
    for i = #s.recent, 1, -1 do
        if now - s.recent[i] > 60 then table.remove(s.recent, i) else n = n + 1 end
    end
    if n >= (S.senderLimit or 10) then return false end
    s.recent[#s.recent + 1] = now
    s.last = now
    return true
end

function E.OnAddonMessage(prefix, text, chan, sender)
    if issecret(prefix) or prefix ~= PREFIX then return end
    if not (DB and S.receive) or issecret(text) or type(text) ~= "string" or #text > 255 then return end
    sender = ShortSender(sender)
    if not sender or Hub.IsMe(sender) then return end
    local parts = {}
    for p in string.gmatch(text .. "|", "([^|]*)|") do parts[#parts + 1] = p end
    if parts[1] ~= PROTO then return end
    if parts[2] == "S" and #parts == 8 then
        local name = SafeName(parts[3])
        if not name or E.IsIgnored(name) or not AntiSpam(sender) then return end
        local class = CLASSES[parts[4]] and parts[4] or nil
        local level = tonumber(parts[5]); if level then level = Clamp(math.floor(level), -1, 999) end
        local mapID = tonumber(parts[6]); local x, y = tonumber(parts[7]), tonumber(parts[8])
        if not (mapID and x and y) or mapID < 0 or mapID > 100000 then return end
        x, y = Clamp(x, 0, 1000) / 1000, Clamp(y, 0, 1000) / 1000
        local p = DB.players[name]
        if p or S.remember then
            p = p or Ensure(name)
            if class then p.c = class; p.cl = LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[class] or p.cl end
            if level and level ~= 0 then p.l = level end
        end
        local where = MapName(mapID) .. (x > 0 and string.format(" (%.0f, %.0f)", x * 100, y * 100) or "")
        if S.receiveChat then Print(string.format("|cffff3030KOS localizado:|r %s%s|r por %s en %s", ClassColor(class), name, sender, where)) end
        if S.receiveText then API.Alert("KOS " .. name .. " visto por " .. sender, 1, 0.2, 0.6) end
        if S.receiveSound then Kit(S.receiveSoundKit) end
        if x > 0 then E.AddSighting(name, class, level, sender, mapID, x, y) end
    elseif parts[2] == "A" and #parts == 9 then
        if not S.recvAll then return end
        local name = SafeName(parts[3])
        if not name or Hub.IsMe(name) or E.IsIgnored(name) or not AntiSpamAll(sender) then return end
        local class = CLASSES[parts[4]] and parts[4] or nil
        local level = tonumber(parts[5]); if level then level = Clamp(math.floor(level), -1, 999) end
        local mapID = tonumber(parts[6]); local x, y = tonumber(parts[7]), tonumber(parts[8])
        if not (mapID and x and y) or mapID < 1 or mapID > 100000 then return end
        x, y = Clamp(x, 0, 10000) / 10000, Clamp(y, 0, 10000) / 10000
        local attacking = parts[9] == "1"
        local myMap, mx, my = PlayerPos()
        if S.recvAllSameZone and myMap ~= mapID then return end
        -- distancia y rumbo desde mi
        local dist, bearing, wx, wy
        wx, wy = WorldPos(mapID, x, y)
        if wx and myMap and mx then
            local ax, ay = WorldPos(myMap, mx, my)
            if ax then dist, bearing = E.DistBearing(ax, ay, wx, wy) end
        end
        if (S.recvAllMaxDist or 0) > 0 and dist and dist > S.recvAllMaxDist then return end
        local p = DB.players[name]
        if p or S.remember then
            p = p or Ensure(name)
            if class then p.c = class; p.cl = LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[class] or p.cl end
            if level and level ~= 0 then p.l = level end
            p.z = MapName(mapID); p.t = time()
        end
        local where = dist and string.format("a %d m al %s", math.floor(dist + 0.5), E.CompassName(bearing))
            or ("en " .. MapName(mapID))
        if S.recvAllList and API and API.AddRemote then
            API.AddRemote({ name = name, class = class, level = level, sender = sender, wx = wx, wy = wy, mapID = mapID,
                            dist = dist, attacking = attacking })
        end
        if S.recvAllPins and x > 0 then E.AddSighting(name, class, level, sender, mapID, x, y) end
        local now = GetTime()
        if recvAllWarned[name] and now - recvAllWarned[name] < (S.recvAllRepeat or 60) and not attacking then return end
        recvAllWarned[name] = now
        local lv = level and (" " .. (level == -1 and "??" or level)) or ""
        local cl = class and LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[class] or ""
        local extra = attacking and (" |cffff3030¡está atacando a " .. sender .. "!|r") or ""
        if S.recvAllChat then
            Print(string.format("|cffff8000Avistado|r %s%s|r (%s%s) %s · lo ve %s%s", ClassColor(class), name, cl, lv, where, sender, extra))
        end
        if S.recvAllText then
            API.Alert(name .. " " .. where .. (attacking and (" ¡ataca a " .. sender .. "!") or (" (lo ve " .. sender .. ")")), 1, 0.55, 0)
        end
        if S.recvAllSound then Kit(S.recvAllSoundKit) end
    elseif parts[2] == "L" and #parts == 3 then
        if not S.acceptLists or not AntiSpam(sender) then return end
        local added = 0
        for name in string.gmatch(parts[3], "[^,]+") do
            name = SafeName(name)
            if name and not Hub.IsMe(name) then
                local p = DB.players[name]
                if not (p and (p.k or p.i)) then E.SetKOS(name, true, "Compartido por " .. sender, true); added = added + 1 end
            end
        end
        if added > 0 then Print(added .. " jugadores añadidos a tu KOS desde la lista de " .. sender .. ".") end
    end
end

----------------------------------------------------------------------
-- Anunciar en el chat
----------------------------------------------------------------------
function E.Announce(name)
    local p = E.Get(name)
    local parts = { "Enemigo: " .. name }
    if p then
        local d = {}
        if p.cl then d[#d + 1] = p.cl end
        if p.l then d[#d + 1] = (p.l == -1 and "??" or tostring(p.l)) end
        if #d > 0 then parts[#parts + 1] = table.concat(d, " ") end
        if p.g then parts[#parts + 1] = "<" .. p.g .. ">" end
        if p.z then
            parts[#parts + 1] = "en " .. p.z .. ((p.sz and p.sz ~= "") and (" / " .. p.sz) or "") ..
                (p.x and string.format(" (%.0f, %.0f)", p.x * 100, p.y * 100) or "")
        end
        if p.k then parts[#parts + 1] = "[KOS" .. (p.kr and (": " .. p.kr) or "") .. "]" end
    end
    local msg = table.concat(parts, " · ")
    local chan = S.announce or "PARTY"
    if (chan == "PARTY" or chan == "RAID" or chan == "INSTANCE_CHAT") and not (IsInGroup and IsInGroup()) then
        Print("no estas en grupo. " .. msg); return
    end
    if chan == "GUILD" and not (IsInGuild and IsInGuild()) then Print("no tienes hermandad. " .. msg); return end
    local ok = pcall(SendChatMessage, msg, chan)
    if not ok then Print("el juego no deja enviar a ese canal ahora. " .. msg) end
end

----------------------------------------------------------------------
-- Menu del clic derecho
----------------------------------------------------------------------
local function AskNote(name)
    if not StaticPopupDialogs then return end
    local function Save(txt)
        local p = E.Get(name) or (DB and SafeName(name) and Ensure(SafeName(name)))
        if not p or not txt or issecret(txt) then return end
        txt = txt:gsub("|", ""):gsub("%c", "")
        p.n = (txt ~= "") and txt:sub(1, 120) or nil
        if API then API.Refresh() end
    end
    StaticPopupDialogs["CMPO_NOTE"] = {
        text = "Nota para %s:", button1 = ACCEPT or "Aceptar", button2 = CANCEL or "Cancelar",
        hasEditBox = true, maxLetters = 120, timeout = 0, whileDead = true, hideOnEscape = true,
        OnShow = function(self)
            local eb = self.EditBox or self.editBox
            local p = E.Get(name)
            if eb and p and p.n then eb:SetText(p.n) end
        end,
        OnAccept = function(self) local eb = self.EditBox or self.editBox; Save(eb and eb:GetText()) end,
        EditBoxOnEnterPressed = function(self) Save(self:GetText()); local pp = self:GetParent(); if pp then pp:Hide() end end,
    }
    StaticPopup_Show("CMPO_NOTE", name, nil, name)
end
function E.SetNote(name, txt)
    name = SafeName(name)
    if not (DB and name) then return end
    local p = DB.players[name] or Ensure(name)
    txt = txt and txt:gsub("|", ""):gsub("%c", "") or ""
    p.n = (txt ~= "") and txt:sub(1, 120) or nil
    Print(p.n and ("nota de " .. name .. ": " .. p.n) or ("nota de " .. name .. " borrada."))
    if API then API.Refresh() end
end

local function AskReason(name)
    if not StaticPopupDialogs then return end
    StaticPopupDialogs["CMPO_KOS_REASON"] = StaticPopupDialogs["CMPO_KOS_REASON"] or {
        text = "Motivo para %s:", button1 = ACCEPT or "Aceptar", button2 = CANCEL or "Cancelar",
        hasEditBox = true, maxLetters = 60, timeout = 0, whileDead = true, hideOnEscape = true,
        OnAccept = function(self, data)
            local eb = self.EditBox or self.editBox
            local txt = eb and eb:GetText()
            if txt and not issecret(txt) then
                txt = txt:gsub("|", ""):gsub("%c", "")
                E.SetKOS(data, true, txt ~= "" and txt or nil)
            end
        end,
        EditBoxOnEnterPressed = function(self)
            local parent = self:GetParent()
            local data = parent and parent.data
            local txt = self:GetText()
            if data and txt and not issecret(txt) then E.SetKOS(data, true, (txt:gsub("|", ""):gsub("%c", ""))) end
            if parent then parent:Hide() end
        end,
    }
    StaticPopup_Show("CMPO_KOS_REASON", name, nil, name)
end

-- Ventanita para escribir un numero o un nombre (venganza).
local function AskText(key, text, maxLetters, arg, onText, initial)
    if not StaticPopupDialogs then return end
    local function Save(txt)
        if not txt or issecret(txt) then return end
        onText((txt:gsub("|", ""):gsub("%c", "")))
    end
    StaticPopupDialogs[key] = {
        text = text, button1 = ACCEPT or "Aceptar", button2 = CANCEL or "Cancelar",
        hasEditBox = true, maxLetters = maxLetters, timeout = 0, whileDead = true, hideOnEscape = true,
        OnShow = function(self)
            local eb = self.EditBox or self.editBox
            if eb then eb:SetText(initial or "") end
        end,
        OnAccept = function(self) local eb = self.EditBox or self.editBox; Save(eb and eb:GetText()) end,
        EditBoxOnEnterPressed = function(self) Save(self:GetText()); local pp = self:GetParent(); if pp then pp:Hide() end end,
    }
    StaticPopup_Show(key, arg)
end
function E.AskRevengeCount(name)
    local p = E.Get(name)
    AskText("CMPO_VEN_COUNT", "Veces que %s te ha matado:", 4, name,
        function(t) E.SetRevengeCount(name, tonumber(t) or 0) end, tostring(p and p.vn or 0))
end
function E.AskRevengeAdd()
    AskText("CMPO_VEN_ADD", "Nombre del jugador para la lista de venganza:", 60, nil,
        function(t) t = t:gsub("^%s+", ""):gsub("%s+$", ""); if t ~= "" then E.SetRevenge(t, true) end end, "")
end
E.AskNote = function(name) AskNote(name) end

function E.ShowMenu(owner, name)
    if not (MenuUtil and MenuUtil.CreateContextMenu) then
        Print("usa /pvpo kos " .. name .. " · /pvpo ignorar " .. name .. " · /pvpo anunciar " .. name)
        return
    end
    local p = E.Get(name)
    MenuUtil.CreateContextMenu(owner, function(_, root)
        root:CreateTitle(name)
        if p and p.k then
            root:CreateButton("Quitar de Matar a la vista", function() E.SetKOS(name, false) end)
        else
            root:CreateButton("|cffff3030Añadir a Matar a la vista|r", function() E.SetKOS(name, true) end)
        end
        local sub = root:CreateButton("Motivo KOS")
        for _, r in ipairs(Reasons()) do sub:CreateButton(r, function() E.SetKOS(name, true, r) end) end
        sub:CreateButton("Escribir otro...", function() AskReason(name) end)
        if p and p.kr then sub:CreateButton("Borrar motivo", function() p.kr = nil; if API then API.Refresh() end end) end
        if p and p.i then
            root:CreateButton("Quitar de ignorados", function() E.SetIgnore(name, false) end)
        else
            root:CreateButton("Ignorar (sin avisos)", function() E.SetIgnore(name, true) end)
        end
        if S.revenge then
            if p and p.v then
                local ven = root:CreateButton("|cffff8000Venganza|r (" .. (p.vn or 0) .. ")")
                ven:CreateButton("Una muerte mas", function() E.SetRevengeCount(name, (p.vn or 0) + 1) end)
                ven:CreateButton("Una muerte menos", function() E.SetRevengeCount(name, (p.vn or 0) - 1) end)
                ven:CreateButton("Una venganza mas (le has matado)", function() E.SetRevengeKills(name, E.RevengeKills(p) + 1) end)
                ven:CreateButton("Una venganza menos", function() E.SetRevengeKills(name, E.RevengeKills(p) - 1) end)
                ven:CreateButton("Cambiar veces...", function() E.AskRevengeCount(name) end)
                ven:CreateButton("Quitar de la lista de venganza", function() E.SetRevenge(name, false) end)
            else
                root:CreateButton("|cffff8000Añadir a la lista de venganza|r", function() E.SetRevenge(name, true) end)
            end
        end
        root:CreateButton((p and p.n) and "Cambiar nota..." or "Escribir nota...", function() AskNote(name) end)
        if p and p.n then root:CreateButton("Borrar nota", function() p.n = nil; if API then API.Refresh() end end) end
        root:CreateButton("Anunciar en el chat (" .. (S.announce or "PARTY") .. ")", function() E.Announce(name) end)
        if API and API.Forget then root:CreateButton("Quitar de la lista Cerca", function() API.Forget(name) end) end
        root:CreateButton("Borrar ficha", function() E.Remove(name) end)
    end)
end

----------------------------------------------------------------------
-- Tooltip
----------------------------------------------------------------------
local tooltipHooked = false
local function OnTooltipUnit(tt)
    if not (mod and mod.enabled and DB and S.tooltip) then return end
    if tt ~= GameTooltip or not tt.GetUnit then return end
    local ok, _, unit = pcall(tt.GetUnit, tt)
    if not ok or not unit or issecret(unit) then return end
    local okp, isPlayer = pcall(UnitIsPlayer, unit)
    if not okp or issecret(isPlayer) or not isPlayer then return end
    local name = E.UnitFullName(unit)
    local p = name and DB.players[name]
    if not p then return end
    if S.tooltipKOS and p.k then tt:AddLine("Matar a la vista" .. (p.kr and (": " .. p.kr) or ""), 1, 0.2, 0.2) end
    if S.tooltipKOS and p.i then tt:AddLine("Ignorado (sin avisos)", 0.6, 0.6, 0.6) end
    if S.tooltipStats and ((p.w or 0) > 0 or (p.d or 0) > 0) then
        tt:AddLine(string.format("Victorias %d · Derrotas %d", p.w or 0, p.d or 0), 0.4, 1, 0.4)
    end
    if S.revenge and S.revengeTooltip and p.v then
        tt:AddLine("Venganza: te ha matado " .. (p.vn or 0) .. ((p.vn or 0) == 1 and " vez" or " veces") ..
            (E.RevengeKills(p) > 0 and (" · le has matado " .. E.RevengeKills(p)) or ""), 1, 0.5, 0)
    end
    if S.notes and p.n then tt:AddLine("Nota: " .. p.n, 1, 0.9, 0.5, true) end
    if S.tooltipSeen and p.s and p.s > 0 then
        tt:AddLine(string.format("Visto %d %s · %s", p.s, p.s == 1 and "vez" or "veces", Ago(p.t)), 0.7, 0.7, 1)
    end
    tt:Show()
end

local function HookTooltip()
    if tooltipHooked then return end
    tooltipHooked = true
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Unit, function(tt) pcall(OnTooltipUnit, tt) end)
    elseif GameTooltip and GameTooltip.HookScript then
        pcall(GameTooltip.HookScript, GameTooltip, "OnTooltipSetUnit", function(tt) pcall(OnTooltipUnit, tt) end)
    end
end

----------------------------------------------------------------------
-- Ventana de estadisticas
----------------------------------------------------------------------
local statsWin
local SORTS = {
    { "t", "Ultima vez" }, { "name", "Nombre" }, { "l", "Nivel" }, { "g", "Hermandad" },
    { "w", "Victorias" }, { "d", "Derrotas" }, { "s", "Veces visto" },
}
local stat = { sort = "t", search = "", fKOS = false, fWL = false, fReason = false, fIgnored = false }
local ROWS_MAX = 500   -- filas creadas como mucho; se muestran S.statsRows

local function StatsList()
    local q = string.lower(stat.search or "")
    local arr = {}
    for name, p in pairs(DB.players) do
        local ok = true
        if stat.fKOS and not p.k then ok = false end
        if ok and stat.fIgnored and not p.i then ok = false end
        if ok and stat.fWL and not ((p.w or 0) > 0 or (p.d or 0) > 0) then ok = false end
        if ok and stat.fReason and not p.kr then ok = false end
        if ok and q ~= "" then
            ok = string.find(string.lower(name), q, 1, true) or (p.g and string.find(string.lower(p.g), q, 1, true))
                or (p.n and string.find(string.lower(p.n), q, 1, true))
        end
        if ok then arr[#arr + 1] = setmetatable({ name = name }, { __index = p }) end
    end
    local k = stat.sort
    table.sort(arr, function(a, b)
        if k == "name" then return a.name < b.name end
        if k == "g" then
            local ga, gb = a.g or "~", b.g or "~"
            if ga ~= gb then return ga < gb end
            return a.name < b.name
        end
        local va, vb = a[k] or 0, b[k] or 0
        if va ~= vb then return va > vb end
        return a.name < b.name
    end)
    return arr
end

local function RefreshStats()
    if not statsWin or not statsWin:IsShown() then return end
    local arr = StatsList()
    local child = statsWin.child
    local tw, tl, tk = 0, 0, 0
    for _, p in pairs(DB.players) do tw = tw + (p.w or 0); tl = tl + (p.d or 0); if p.k then tk = tk + 1 end end
    statsWin.total:SetText(string.format("%d fichas · %d mostradas · KOS %d · Victorias %d · Derrotas %d",
        (function() local n = 0 for _ in pairs(DB.players) do n = n + 1 end return n end)(), #arr, tk, tw, tl))
    local maxRows = Clamp(S.statsRows or 300, 50, ROWS_MAX)
    for i = 1, ROWS_MAX do
        local row, p = child.rows[i], (i <= maxRows) and arr[i]
        if p then
            if not row then
                row = CreateFrame("Button", nil, child)
                row:SetSize(560, 18)
                row:SetPoint("TOPLEFT", 0, -(i - 1) * 18)
                row:RegisterForClicks("AnyUp")
                row.hl = row:CreateTexture(nil, "HIGHLIGHT"); row.hl:SetAllPoints(); row.hl:SetColorTexture(1, 1, 1, 0.08)
                local function FS(x, w, j)
                    local fs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                    fs:SetPoint("LEFT", x, 0); fs:SetWidth(w); fs:SetJustifyH(j or "LEFT")
                    return fs
                end
                row.c1, row.c2, row.c3, row.c4, row.c5 = FS(2, 160), FS(164, 30, "CENTER"), FS(196, 120), FS(318, 60, "CENTER"), FS(380, 180)
                row:SetScript("OnClick", function(self, button)
                    if button == "RightButton" then E.ShowMenu(self, self.pname) end
                end)
                row:SetScript("OnEnter", function(self)
                    local pp = DB.players[self.pname]
                    if not pp then return end
                    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                    GameTooltip:AddLine(ClassColor(pp.c) .. self.pname .. "|r")
                    GameTooltip:AddLine((pp.r or "") .. " " .. (pp.cl or "") .. " " .. (pp.l == -1 and "??" or (pp.l or "?")), 1, 1, 1)
                    if pp.g then GameTooltip:AddLine("<" .. pp.g .. ">", 0.6, 1, 0.6) end
                    if pp.z then GameTooltip:AddLine("Visto en " .. pp.z .. ((pp.sz and pp.sz ~= "") and (" / " .. pp.sz) or ""), 0.8, 0.8, 0.8) end
                    GameTooltip:AddLine("Primera vez: " .. (pp.f and date("%d/%m/%y %H:%M", pp.f) or "?"), 0.8, 0.8, 0.8)
                    GameTooltip:AddLine("Ultima vez: " .. (pp.t and date("%d/%m/%y %H:%M", pp.t) or "?"), 0.8, 0.8, 0.8)
                    if pp.k then GameTooltip:AddLine("KOS" .. (pp.kr and (": " .. pp.kr) or ""), 1, 0.2, 0.2) end
                    if pp.n then GameTooltip:AddLine("Nota: " .. pp.n, 1, 0.9, 0.5, true) end
                    GameTooltip:AddLine("Clic derecho: opciones", 0.5, 0.5, 0.5)
                    GameTooltip:Show()
                end)
                row:SetScript("OnLeave", function() GameTooltip:Hide() end)
                child.rows[i] = row
            end
            row.pname = p.name
            local tag = (p.k and "|cffff3030[KOS]|r " or (p.i and "|cff888888[ign]|r " or "")) .. (p.v and "|cffff8000[V]|r " or "")
            row.c1:SetText(tag .. ClassColor(p.c) .. p.name .. "|r")
            row.c2:SetText(p.l == -1 and "??" or tostring(p.l or "?"))
            row.c3:SetText(p.g or "")
            row.c4:SetText(string.format("|cff55ff55%d|r-|cffff5555%d|r", p.w or 0, p.d or 0))
            row.c5:SetText(Ago(p.t) .. (p.z and (" · " .. p.z) or ""))
            row:Show()
        elseif row then
            row:Hide()
        end
    end
    child:SetHeight(math.max(10, math.min(#arr, maxRows) * 18))
    statsWin.scroll.UpdateRange()
end
E.RefreshStats = RefreshStats

local function BuildStats()
    local UI = Hub.UI
    statsWin = UI.MakeWindow("CMPvPOutdoorEspiaStats", "Estadisticas de enemigos", 620, 480)
    mod:Track(statsWin)
    local f = statsWin
    local search = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
    search:SetSize(160, 22); search:SetPoint("TOPLEFT", 20, -32); search:SetAutoFocus(false)
    local sl = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    sl:SetPoint("BOTTOMLEFT", search, "TOPLEFT", -4, 0); sl:SetText("Buscar nombre u hermandad")
    search:SetScript("OnTextChanged", function(self)
        local t = self:GetText()
        if issecret(t) then return end
        stat.search = t or ""; RefreshStats()
    end)
    search:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    local sortB = UI.NewButton(f, "", 150, "TOPLEFT", 190, -30, function(self)
        local idx = 1
        for i, s in ipairs(SORTS) do if s[1] == stat.sort then idx = i end end
        idx = idx % #SORTS + 1
        stat.sort = SORTS[idx][1]
        self:SetText("Orden: " .. SORTS[idx][2]); RefreshStats()
    end)
    sortB:SetText("Orden: Ultima vez")
    local function Filter(label, key, x, y)
        local cb = UI.NewCheck(f, label, x, y, function() return stat[key] end, function(v) stat[key] = v; RefreshStats() end)
        cb:Refresh()
    end
    Filter("Solo KOS", "fKOS", 350, -28)
    Filter("Con motivo", "fReason", 460, -28)
    Filter("Con victorias/derrotas", "fWL", 16, -58)
    Filter("Solo ignorados", "fIgnored", 200, -58)
    local h = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    h:SetPoint("TOPLEFT", 22, -90)
    h:SetText("Nombre                                          Nv     Hermandad                       V-D       Ultima vez")
    f.scroll, f.child = UI.MakeScroll(f, 570, 320)
    f.scroll:SetPoint("TOPLEFT", 18, -106)
    f.child.rows = {}
    f.total = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.total:SetPoint("BOTTOMLEFT", 20, 14)
    f:SetScript("OnShow", RefreshStats)
end

function E.OpenStats()
    if not DB then return end
    if not statsWin then BuildStats() end
    if statsWin:IsShown() then statsWin:Hide() else statsWin:Show(); RefreshStats() end
end

----------------------------------------------------------------------
-- Ventana de la lista de venganza (editable)
----------------------------------------------------------------------
local revWin
local REV_ROWS = 200
local revSearch = ""

local function RefreshRevenge()
    if not revWin or not revWin:IsShown() or not DB then return end
    local q = string.lower(revSearch or "")
    local arr = {}
    for _, p in ipairs(E.RevengeList()) do
        if q == "" or string.find(string.lower(p.name), q, 1, true) or (p.g and string.find(string.lower(p.g), q, 1, true))
            or (p.n and string.find(string.lower(p.n), q, 1, true)) then
            arr[#arr + 1] = p
        end
    end
    local child = revWin.child
    local total, muertes, cumplidas = 0, 0, 0
    for _, p in ipairs(E.RevengeList()) do total = total + 1; muertes = muertes + (p.vn or 0); cumplidas = cumplidas + E.RevengeKills(p) end
    revWin.total:SetText(string.format("%d en la lista · %d mostrados · te han matado %d veces · les has matado %d",
        total, #arr, muertes, cumplidas))
    revWin.empty:SetShown(#arr == 0)
    for i = 1, REV_ROWS do
        local row, p = child.rows[i], arr[i]
        if p then
            if not row then
                row = CreateFrame("Button", nil, child)
                row:SetSize(636, 22)
                row:SetPoint("TOPLEFT", 0, -(i - 1) * 22)
                row:RegisterForClicks("AnyUp")
                row.hl = row:CreateTexture(nil, "HIGHLIGHT"); row.hl:SetAllPoints(); row.hl:SetColorTexture(1, 1, 1, 0.08)
                local function FS(x, w, j)
                    local fs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                    fs:SetPoint("LEFT", x, 0); fs:SetWidth(w); fs:SetJustifyH(j or "LEFT")
                    return fs
                end
                row.c1, row.c2, row.c3, row.c4, row.c5 = FS(2, 150), FS(154, 40, "CENTER"), FS(196, 36, "CENTER"), FS(234, 100), FS(336, 150)
                local function Mini(label, x, tip, fn)
                    local b = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
                    b:SetSize(22, 18); b:SetPoint("LEFT", x, 0); b:SetText(label)
                    b:SetScript("OnClick", function() fn(row.pname) end)
                    b:SetScript("OnEnter", function(self) GameTooltip:SetOwner(self, "ANCHOR_TOP"); GameTooltip:SetText(tip); GameTooltip:Show() end)
                    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
                    return b
                end
                row.mas = Mini("|cffff8000+|r", 490, "Te ha matado una vez mas", function(n) local pp = E.Get(n); if pp then E.SetRevengeCount(n, (pp.vn or 0) + 1) end end)
                row.menos = Mini("|cffff8000-|r", 513, "Te ha matado una vez menos", function(n) local pp = E.Get(n); if pp then E.SetRevengeCount(n, (pp.vn or 0) - 1) end end)
                row.vmas = Mini("|cff55ff55+|r", 542, "Le has matado una vez mas (venganza)", function(n) local pp = E.Get(n); if pp then E.SetRevengeKills(n, E.RevengeKills(pp) + 1) end end)
                row.vmenos = Mini("|cff55ff55-|r", 565, "Le has matado una vez menos", function(n) local pp = E.Get(n); if pp then E.SetRevengeKills(n, E.RevengeKills(pp) - 1) end end)
                row.nota = Mini("N", 592, "Escribir / cambiar la nota", function(n) AskNote(n) end)
                row.quitar = Mini("X", 615, "Quitar de la lista de venganza", function(n) E.SetRevenge(n, false) end)
                row:SetScript("OnClick", function(self, button)
                    if button == "RightButton" then E.ShowMenu(self, self.pname) end
                end)
                row:SetScript("OnEnter", function(self)
                    local pp = DB.players[self.pname]
                    if not pp then return end
                    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                    GameTooltip:AddLine(ClassColor(pp.c) .. self.pname .. "|r")
                    GameTooltip:AddLine((pp.r or "") .. " " .. (pp.cl or "") .. " " .. (pp.l == -1 and "??" or (pp.l or "?")), 1, 1, 1)
                    if pp.g then GameTooltip:AddLine("<" .. pp.g .. ">", 0.6, 1, 0.6) end
                    GameTooltip:AddLine("Te ha matado " .. (pp.vn or 0) .. " veces · le has matado " .. E.RevengeKills(pp), 1, 0.5, 0)
                    if (pp.vw or 0) < E.RevengeKills(pp) then
                        GameTooltip:AddLine("(" .. (pp.vw or 0) .. " desde que esta en la lista de venganza)", 0.8, 0.8, 0.8)
                    end
                    if pp.vt then GameTooltip:AddLine("Ultima vez que te mato: " .. date("%d/%m/%y %H:%M", pp.vt), 0.8, 0.8, 0.8) end
                    if pp.z then GameTooltip:AddLine("Visto en " .. pp.z .. ((pp.sz and pp.sz ~= "") and (" / " .. pp.sz) or "") .. " · " .. Ago(pp.t), 0.8, 0.8, 0.8) end
                    if pp.k then GameTooltip:AddLine("KOS" .. (pp.kr and (": " .. pp.kr) or ""), 1, 0.2, 0.2) end
                    if pp.n then GameTooltip:AddLine("Nota: " .. pp.n, 1, 0.9, 0.5, true) end
                    GameTooltip:AddLine("Clic derecho: mas opciones (KOS, anunciar...)", 0.5, 0.5, 0.5)
                    GameTooltip:Show()
                end)
                row:SetScript("OnLeave", function() GameTooltip:Hide() end)
                child.rows[i] = row
            end
            row.pname = p.name
            row.c1:SetText((p.k and "|cffff3030[KOS]|r " or "") .. ClassColor(p.c) .. p.name .. "|r")
            row.c2:SetText("|cffff8000" .. (p.vn or 0) .. "|r")
            row.c3:SetText("|cff55ff55" .. E.RevengeKills(p) .. "|r")
            row.c4:SetText(p.vt and date("%d/%m %H:%M", p.vt) or "?")
            row.c5:SetText(p.n or "")
            row:Show()
        elseif row then
            row:Hide()
        end
    end
    child:SetHeight(math.max(10, math.min(#arr, REV_ROWS) * 22))
    revWin.scroll.UpdateRange()
end
E.RefreshRevenge = RefreshRevenge

local function BuildRevenge()
    local UI = Hub.UI
    revWin = UI.MakeWindow("CMPvPOutdoorVenganza", "Lista de venganza", 690, 470)
    mod:Track(revWin)
    local f = revWin
    local search = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
    search:SetSize(160, 22); search:SetPoint("TOPLEFT", 20, -40); search:SetAutoFocus(false)
    local sl = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    sl:SetPoint("BOTTOMLEFT", search, "TOPLEFT", -4, 0); sl:SetText("Buscar nombre, hermandad o nota")
    search:SetScript("OnTextChanged", function(self)
        local t = self:GetText()
        if issecret(t) then return end
        revSearch = t or ""; RefreshRevenge()
    end)
    search:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    UI.NewButton(f, "Añadir...", 90, "TOPLEFT", 190, -38, function() E.AskRevengeAdd() end)
    UI.NewButton(f, "Traer de derrotas", 140, "TOPLEFT", 286, -38, function() E.ImportRevenge() end)
    UI.NewButton(f, "Vaciar", 80, "TOPLEFT", 432, -38, function()
        if IsShiftKeyDown and IsShiftKeyDown() then E.ClearRevenge() else Print("Mayus+clic en Vaciar para borrar toda la lista de venganza.") end
    end)
    local h = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    h:SetPoint("TOPLEFT", 22, -72)
    h:SetText("Nombre                                   Te mató  Le mataste  Ultima vez           Nota")
    f.scroll, f.child = UI.MakeScroll(f, 640, 320)
    f.scroll:SetPoint("TOPLEFT", 18, -88)
    f.child.rows = {}
    f.empty = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    f.empty:SetPoint("TOP", f.scroll, "TOP", 0, -30)
    f.empty:SetWidth(520)
    f.empty:SetText("Nadie en la lista. Quien te mate se apunta solo; tambien puedes usar Añadir... o el clic derecho en cualquier enemigo.")
    f.total = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.total:SetPoint("BOTTOMLEFT", 20, 14)
    f:SetScript("OnShow", RefreshRevenge)
end

function E.OpenRevenge()
    if not DB then return end
    if not revWin then BuildRevenge() end
    if revWin:IsShown() then revWin:Hide() else revWin:Show(); RefreshRevenge() end
end

----------------------------------------------------------------------
-- Configuracion
----------------------------------------------------------------------
local CHANNELS = { { "PARTY", "Grupo" }, { "RAID", "Banda" }, { "GUILD", "Hermandad" }, { "SAY", "Decir" }, { "INSTANCE_CHAT", "Instancia" } }
local KITS = { { "RAID_WARNING", "Aviso de banda" }, { "ALARM_CLOCK_WARNING_3", "Alarma" }, { "IG_PVP_UPDATE", "Aviso JcJ" }, { "READY_CHECK", "Comprobacion" } }

local ICONS = { { 1, "Estrella" }, { 2, "Circulo" }, { 3, "Diamante" }, { 4, "Triangulo" },
    { 5, "Luna" }, { 6, "Cuadrado" }, { 7, "Cruz" }, { 8, "Calavera" } }

function E.BuildConfig(L)
    local function Ref() if API then API.Refresh() end end
    local function Pins() if API then API.UpdatePins() end end
    local function SoundChoice(label, key)
        L:Choice(label, KITS, function() return S[key] end, function(v) S[key] = v; Kit(v) end)
    end

    L:Header("Fichas de enemigos (estilo Spy)")
    L:Text("Cada enemigo que ves queda guardado: clase, raza, hermandad, nivel, donde y cuando lo viste, y tus victorias y derrotas contra el. Clic derecho en la lista o en las estadisticas para marcarlo como KOS o ignorarlo.", true)
    L:Check("Guardar ficha de cada enemigo visto", function() return S.remember end, function(v) S.remember = v end)
    L:Slider("Fichas maximas guardadas", 200, 10000, 100, function() return S.maxPlayers end, function(v) S.maxPlayers = v end)
    L:Slider("Lista 'Ultima hora' abarca (minutos)", 10, 240, 5, function() return S.hourMinutes end, function(v) S.hourMinutes = v; Ref() end)
    L:Slider("Filas de la ventana de estadisticas", 50, 500, 50, function() return S.statsRows end, function(v) S.statsRows = v; RefreshStats() end)
    L:Button("Estadisticas", 150, function() E.OpenStats() end)
    L:Button("Vaciar fichas (no KOS)", 170, function()
        for name, p in pairs(DB.players) do if not Keep(p) then DB.players[name] = nil end end
        Print("fichas sin KOS ni estadisticas borradas."); RefreshStats()
    end, true)

    L:Header("Lista de enemigos")
    L:Check("Botones < > E X en la cabecera de la lista", function() return S.headerButtons end, function(v) S.headerButtons = v; Ref() end)
    L:Check("   X tambien oculta la lista hasta el proximo enemigo nuevo", function() return S.xHides end, function(v) S.xHides = v end)
    L:Text("Listas que recorren < y > (Cerca siempre esta):", true)
    L:Check("   Ultima hora", function() return S.views.hour end, function(v) S.views.hour = v; Ref() end)
    L:Check("   Matar a la vista (KOS)", function() return S.views.kos end, function(v) S.views.kos = v; Ref() end)
    L:Check("   Venganza", function() return S.views.revenge end, function(v) S.views.revenge = v; Ref() end)
    L:Check("   Ignorados", function() return S.views.ignore end, function(v) S.views.ignore = v; Ref() end)
    L:Check("   Zonas calientes", function() return S.views.zones end, function(v) S.views.zones = v; Ref() end)
    L:Slider("Zonas calientes: enemigos vistos en los ultimos (minutos)", 5, 120, 5, function() return S.hotMinutes end, function(v) S.hotMinutes = v; Ref() end)
    L:Check("Mostrar las notas de cada enemigo (tooltip y lista)", function() return S.notes end, function(v) S.notes = v end)
    L:Check("Volver a 'Cerca' al detectar a alguien nuevo", function() return S.autoNear end, function(v) S.autoNear = v end)
    L:Check("KOS arriba del todo", function() return S.kosFirst end, function(v) S.kosFirst = v; Ref() end)
    L:Check("No mostrar ignorados en 'Cerca'", function() return S.hideIgnored end, function(v) S.hideIgnored = v; Ref() end)
    L:Check("Clic izquierdo en una fila: seleccionar como objetivo", function() return S.clickTarget end,
        function(v) S.clickTarget = v; Ref() end)
    L:Text("En combate el juego no deja cambiar a quien apunta cada fila: las filas nuevas en combate se ven pero no se pueden clicar hasta salir de combate.", true)
    L:Check("Clic derecho en una fila: menu (KOS, ignorar, anunciar...)", function() return S.rowMenu end, function(v) S.rowMenu = v end)
    L:Check("Tooltip al pasar el raton por una fila", function() return S.rowTooltip end, function(v) S.rowTooltip = v end)

    L:Header("Matar a la vista (KOS)")
    L:Check("Mensaje grande al ver a un KOS", function() return S.kosText end, function(v) S.kosText = v end)
    L:Check("Linea en el chat al ver a un KOS", function() return S.kosChat end, function(v) S.kosChat = v end)
    L:Check("Sonido al ver a un KOS", function() return S.kosSound end, function(v) S.kosSound = v end)
    SoundChoice("Sonido de KOS", "kosSoundKit")
    L:Slider("Volver a avisar del mismo KOS tras (segundos)", 30, 900, 30, function() return S.kosRepeat end, function(v) S.kosRepeat = v end)
    L:Text("Motivos del menu (separados por ;). Pulsa Intro para guardar:", true)
    L:Edit("Motivos", function() return S.reasons end, function(v)
        if type(v) == "string" and not issecret(v) then S.reasons = v:gsub("|", "") end
    end, "text", 340)
    L:Button("Motivos por defecto", 170, function() S.reasons = E.DEFAULTS.reasons; L:Refresh() end)
    L:Check("Avisar si es de la misma hermandad que alguien de tu KOS", function() return S.kosGuild end, function(v) S.kosGuild = v end)
    L:Check("   Mensaje grande", function() return S.kosGuildText end, function(v) S.kosGuildText = v end)
    L:Check("   Sonido", function() return S.kosGuildSound end, function(v) S.kosGuildSound = v end)
    SoundChoice("   Sonido de hermandad KOS", "kosGuildSoundKit")

    L:Header("Lista de venganza")
    L:Text("Quien te mata queda apuntado en tu lista de venganza: cuantas veces te ha matado, cuando y cuantas veces te has vengado. La lista se puede editar: añadir y quitar jugadores, corregir las veces y escribir notas (ventana Venganza o clic derecho en cualquier enemigo).", true)
    L:Check("Llevar la lista de venganza", function() return S.revenge end, function(v) S.revenge = v; Ref() end)
    L:Check("   Pestaña «Venganza» en la ventana de personaje (debajo de la de Overlord)",
        function() return S.charTab end, function(v) S.charTab = v; if E.CharTabUpdate then E.CharTabUpdate() end end)
    L:Check("   Apuntar solo a quien me mata", function() return S.revengeAuto end, function(v) S.revengeAuto = v end)
    L:Check("   Linea en el chat al apuntarlo", function() return S.revengeChatAdd end, function(v) S.revengeChatAdd = v end)
    L:Check("Mensaje grande al verlo cerca", function() return S.revengeText end, function(v) S.revengeText = v end)
    L:Check("Linea en el chat al verlo cerca", function() return S.revengeChat end, function(v) S.revengeChat = v end)
    L:Check("Sonido al verlo cerca", function() return S.revengeSound end, function(v) S.revengeSound = v end)
    SoundChoice("Sonido de venganza", "revengeSoundKit")
    L:Slider("Volver a avisar del mismo tras (segundos)", 30, 900, 30, function() return S.revengeRepeat end, function(v) S.revengeRepeat = v end)
    L:Check("Marca VEN en la lista Cerca", function() return S.revengeNear end, function(v) S.revengeNear = v; Ref() end)
    L:Check("Linea en el tooltip (veces que te ha matado)", function() return S.revengeTooltip end, function(v) S.revengeTooltip = v end)
    L:Check("Aviso de «venganza cumplida» al matarlo", function() return S.revengeDone end, function(v) S.revengeDone = v end)
    L:Check("   Quitarlo de la lista al vengarme", function() return S.revengeRemove end, function(v) S.revengeRemove = v end)
    L:Button("Ver lista de venganza", 180, function() E.OpenRevenge() end)
    L:Button("Añadir jugador...", 150, function() E.AskRevengeAdd() end, true)
    L:Button("Traer de mis derrotas", 180, function() E.ImportRevenge() end)
    L:Text("Si alguien de tu lista de venganza tambien es KOS, sale el aviso de KOS (va primero).", true)

    L:Header("Exportar a la app WoW Forever Guide")
    L:Text("Si usas el addon «WoW Forever Guide - Exportar personaje», al exportar se mandan a la app estas tres listas "
        .. "(nombre, clase, raza, nivel, hermandad, victorias y derrotas, última vez y zona, KOS y venganza). Sin coordenadas ni notas.", true)
    L:Check("Mandar las listas a la app", function() return S.exportApp end, function(v) S.exportApp = v end)
    L:Slider("   Los que más has matado", 0, 25, 1, function() return S.exportKills end, function(v) S.exportKills = v end)
    L:Slider("   Los que más te han matado", 0, 25, 1, function() return S.exportDeaths end, function(v) S.exportDeaths = v end)
    L:Slider("   Lista de venganza (primero los pendientes)", 0, 25, 1, function() return S.exportRevenge end, function(v) S.exportRevenge = v end)

    L:Header("Sigilo")
    L:Check("Mensaje grande cuando un enemigo visible entra en sigilo", function() return S.stealthText end, function(v) S.stealthText = v end)
    L:Check("Sonido de sigilo (la voz del modulo Voces ya lo dice)", function() return S.stealthSound end, function(v) S.stealthSound = v end)
    SoundChoice("Sonido de sigilo", "stealthSoundKit")
    L:Check("Solo avisar del sigilo de jugadores KOS", function() return S.stealthKOSOnly end, function(v) S.stealthKOSOnly = v end)
    L:Slider("Pausa minima entre avisos de sigilo (segundos)", 0, 15, 1, function() return S.stealthGap end, function(v) S.stealthGap = v end)
    L:Text("Solo funciona con enemigos que tienes a la vista (Forever no da el registro de combate).", true)

    L:Header("Victorias y derrotas")
    L:Check("Contar victorias (muere el enemigo con el que peleabas)", function() return S.wins end, function(v) S.wins = v end)
    L:Check("   Tu golpe final cuenta (evento del juego, el metodo mas fiable)", function() return S.winsPartyKill end, function(v) S.winsPartyKill = v end)
    L:Check("   Tambien las bajas de tu grupo", function() return S.winsGroupKill end, function(v) S.winsGroupKill = v end)
    L:Check("   El mensaje de muerte honorable tambien cuenta", function() return S.winsHonor end, function(v) S.winsHonor = v end)
    L:Check("   Linea en el chat con cada victoria", function() return S.winsChat end, function(v) S.winsChat = v end)
    L:Slider("La muerte cuenta como tuya hasta (segundos tras pelear)", 5, 60, 5, function() return S.engageSeconds end, function(v) S.engageSeconds = v end)
    L:Check("Contar derrotas (quien te tenia de objetivo al morir)", function() return S.losses end, function(v) S.losses = v end)

    L:Header("Tooltip y chat")
    L:Check("Lineas extra en el tooltip de los enemigos", function() return S.tooltip end, function(v) S.tooltip = v end)
    L:Check("   KOS con su motivo / ignorado", function() return S.tooltipKOS end, function(v) S.tooltipKOS = v end)
    L:Check("   Victorias y derrotas", function() return S.tooltipStats end, function(v) S.tooltipStats = v end)
    L:Check("   'Visto N veces / hace X'", function() return S.tooltipSeen end, function(v) S.tooltipSeen = v end)
    L:Choice("Canal para 'Anunciar'", CHANNELS, function() return S.announce end, function(v) S.announce = v end)

    L:Header("Compartir avisos de KOS")
    L:Check("Avisar a mi hermandad cuando veo a un KOS", function() return S.shareGuild end, function(v) S.shareGuild = v end)
    L:Check("Avisar a mi grupo/banda cuando veo a un KOS", function() return S.shareGroup end, function(v) S.shareGroup = v end)
    L:Check("Recibir avisos de KOS de otros", function() return S.receive end, function(v) S.receive = v end)
    L:Check("   Mensaje grande al recibir", function() return S.receiveText end, function(v) S.receiveText = v end)
    L:Check("   Linea en el chat al recibir", function() return S.receiveChat end, function(v) S.receiveChat = v end)
    L:Check("   Sonido al recibir", function() return S.receiveSound end, function(v) S.receiveSound = v end)
    SoundChoice("   Sonido al recibir", "receiveSoundKit")
    L:Check("Aceptar listas KOS que me compartan", function() return S.acceptLists end, function(v) S.acceptLists = v end)
    L:Button("Compartir mi KOS: hermandad", 210, function() E.ShareList("GUILD") end)
    L:Button("grupo", 90, function()
        local c = (IsInRaid and IsInRaid()) and "RAID" or "PARTY"
        if IsInGroup and IsInGroup() then E.ShareList(c) else Print("no estas en grupo.") end
    end, true)
    L:Slider("Pausa minima entre avisos del mismo emisor (segundos)", 1, 30, 1, function() return S.senderGap end, function(v) S.senderGap = v end)
    L:Slider("Avisos por minuto aceptados de cada emisor", 1, 30, 1, function() return S.senderLimit end, function(v) S.senderLimit = v end)

    L:Header("Compartir todos los avistamientos (grupo y hermandad)")
    L:Text("Cada enemigo que ves se manda, con tu posición, a quien lleve este addon en tu grupo o hermandad; "
        .. "a ellos les sale a qué distancia y hacia dónde está (y al revés). Así ves también lo que ven los demás.", true)
    L:Check("Enviar los enemigos que veo", function() return S.shareAll end, function(v) S.shareAll = v end)
    L:Check("   a mi grupo/banda", function() return S.shareAllGroup end, function(v) S.shareAllGroup = v end)
    L:Check("   a mi hermandad", function() return S.shareAllGuild end, function(v) S.shareAllGuild = v end)
    L:Slider("   Volver a enviar el mismo enemigo tras (segundos)", 15, 300, 15, function() return S.shareAllRepeat end, function(v) S.shareAllRepeat = v end)
    L:Check("Recibir los avistamientos de otros", function() return S.recvAll end, function(v) S.recvAll = v end)
    L:Check("   Solo los de mi misma zona", function() return S.recvAllSameZone end, function(v) S.recvAllSameZone = v end)
    L:Slider("   Como mucho a esta distancia de mí (metros, 0 = sin límite)", 0, 2000, 50, function() return S.recvAllMaxDist end, function(v) S.recvAllMaxDist = v end)
    L:Check("   Línea en el chat", function() return S.recvAllChat end, function(v) S.recvAllChat = v end)
    L:Check("   Mensaje grande", function() return S.recvAllText end, function(v) S.recvAllText = v end)
    L:Check("   Sonido", function() return S.recvAllSound end, function(v) S.recvAllSound = v end)
    SoundChoice("   Sonido", "recvAllSoundKit")
    L:Check("   Meterlos en la lista Cerca (con quién los vio)", function() return S.recvAllList end, function(v) S.recvAllList = v end)
    L:Check("   Flecha en el radar hacia donde están", function() return S.recvAllRadar end, function(v) S.recvAllRadar = v end)
    L:Check("   Marca en el mapa", function() return S.recvAllPins end, function(v) S.recvAllPins = v; Pins() end)
    L:Slider("   No repetir el aviso del mismo enemigo antes de (segundos)", 10, 600, 10, function() return S.recvAllRepeat end, function(v) S.recvAllRepeat = v end)

    L:Header("Mapa")
    L:Check("Marcar en el mapa los KOS que veo yo", function() return S.sightPins end, function(v) S.sightPins = v; Pins() end)
    L:Check("Marcar en el mapa los KOS que me avisan otros", function() return S.receivePins end, function(v) S.receivePins = v; Pins() end)
    L:Slider("Duracion de la marca de un KOS (minutos)", 1, 30, 1, function() return S.pinMinutes end, function(v) S.pinMinutes = v end)
    L:Choice("Icono de los KOS", ICONS, function() return S.kosPinIcon end, function(v) S.kosPinIcon = v; Pins() end)
    L:Check("Marcar en el mapa a todos los enemigos de la ultima hora", function() return S.seenPins end, function(v) S.seenPins = v; Pins() end)
    L:Choice("Icono de los enemigos vistos", ICONS, function() return S.seenPinIcon end, function(v) S.seenPinIcon = v; Pins() end)
end

----------------------------------------------------------------------
-- Comandos (/pvpo kos <nombre> ...). Devuelve true si lo ha atendido.
----------------------------------------------------------------------
function E.Slash(cmd, rawArg)
    local name = rawArg and rawArg:match("^(%S+)")
    local rest = rawArg and rawArg:match("^%S+%s+(.+)$")
    if cmd == "kos" then
        if not name then for _, p in ipairs(E.KOSList()) do Print("KOS: " .. p.name .. (p.kr and (" · " .. p.kr) or "")) end; return true end
        E.SetKOS(name, not E.IsKOS(name), rest); return true
    elseif cmd == "ignorar" or cmd == "ignore" then
        if not name then for _, p in ipairs(E.IgnoreList()) do Print("Ignorado: " .. p.name) end; return true end
        E.SetIgnore(name, not E.IsIgnored(name)); return true
    elseif cmd == "nota" and name then E.SetNote(name, rest); return true
    elseif cmd == "stats" or cmd == "estadisticas" then E.OpenStats(); return true
    elseif cmd == "venganza" or cmd == "ven" then
        if not name then E.OpenRevenge(); return true end
        local low = name:lower()
        if (low == "diag" or low == "dialog" or low == "diagnostico") and E.CharTabDiag then E.CharTabDiag(Print); return true end
        local full = (rawArg:gsub("^%s+", ""):gsub("%s+$", ""))
        E.SetRevenge(full, not E.IsRevenge(full)); return true
    elseif cmd == "anunciar" and name then E.Announce(name); return true
    elseif cmd == "compartir" then E.ShareList((name or "guild"):upper() == "GRUPO" and "PARTY" or "GUILD"); return true
    end
    return false
end

----------------------------------------------------------------------
-- Arranque (lo llama Enemigos.lua en su Init)
----------------------------------------------------------------------
function E.Init(m, api)
    mod, API = m, api
    DB = m.db
    DB.players = DB.players or {}
    -- «/pvpo venganza dialog» (en vez de «diag») apuntaba un jugador llamado así: se quita si es solo eso
    for _, n in ipairs({ "dialog", "diag", "diagnostico", "Dialog", "Diag", "Diagnostico" }) do
        local p = DB.players[n]
        if p and not p.c and not p.r and not p.l and (p.vn or 0) == 0 and (p.d or 0) == 0 and (p.w or 0) == 0 then DB.players[n] = nil end
    end
    S = DB.spy
    if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then pcall(C_ChatInfo.RegisterAddonMessagePrefix, PREFIX) end
    HookTooltip()
    -- Primera vez con la lista de venganza: entran los que ya te habian matado (derrotas guardadas).
    if not DB.revengeImported then
        DB.revengeImported = true
        E.ImportRevenge(true)
    end
    E.Prune()
end

-- Para VenganzaPj.lua (pestaña de la ventana de personaje).
function E.Settings() return S end
function E.Active() return mod ~= nil and mod.enabled and S ~= nil end
E.AgoText = function(t) return Ago(t) end

function E.Rebind(m) DB = m.db; DB.players = DB.players or {}; S = DB.spy end
function E.Reset() wipe(kosWarned); wipe(revWarned); wipe(engaged); wipe(sightings); queue = {} end
