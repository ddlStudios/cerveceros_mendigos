-- Pestaña «Venganza» en la ventana de personaje de WoW Forever (debajo de la de Overlord).
-- Parte del modulo Enemigos cercanos (PvPOutdoor). Se carga despues de Espia.lua (usa ns.PO_Espia).
--
-- Como esta hecha la ventana de Forever (Blizzard_UIPanels_Game/Camelot/CharacterFrame.lua):
--   pestañas laterales = CharacterFrame.ModeTabs.Tabs (plantilla CharacterFrameModeSideTabTemplate),
--   mitad izquierda = CharacterFrameLeftPaneHost (fondo UI-Character-Info-General-BG),
--   mitad derecha  = CharacterFrameRightPaneHost (fondo UI-Character-Info-Stat-BG), que se puede plegar.
-- Para no ensuciar (taint) la ventana de Blizzard NO se toca CHARACTERFRAME_SUBFRAMES ni sus tablas:
-- la pestaña es nuestra (misma plantilla) y el panel se pone ENCIMA del contenido, con los mismos fondos.
local ADDON, ns = ...
local E = ns.PO_Espia
if not E then return end

local NOMBRE = "Venganza"
local ICONO = "Interface/ICONS/Ability_Warrior_Revenge"
local tab, panel, left, right
local rows = {}
local selected            -- nombre del enemigo elegido
local offset = 0          -- desplazamiento de la lista de la derecha
local ROW_H, MAX_ROWS = 28, 13

local function S() return E.Settings() end
local function Wanted() return E.Active() and S() and S().revenge and S().charTab end
local function Kills(p) return E.RevengeKills(p) end

local function Atlas(tex, atlas, useSize)
    if not (tex and tex.SetAtlas) then return false end
    local ok = pcall(tex.SetAtlas, tex, atlas, useSize)
    return ok
end

local function ClassIcon(tex, class)
    local tc = class and CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[class]
    if tc then
        tex:SetTexture("Interface\\TargetingFrame\\UI-Classes-Circles")
        tex:SetTexCoord(tc[1], tc[2], tc[3], tc[4])
    else
        tex:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
        tex:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    end
end

local function List()
    local arr = E.RevengeList()
    -- primero los que tienen la venganza pendiente (te han matado mas veces que tu a ellos)
    local pend, done = {}, {}
    for _, p in ipairs(arr) do
        if (p.vn or 0) > Kills(p) then pend[#pend + 1] = p else done[#done + 1] = p end
    end
    for _, p in ipairs(done) do pend[#pend + 1] = p end
    return pend
end

local function Collapsed()
    return CharacterFrame and CharacterFrame.IsRightPaneCollapsed and CharacterFrame:IsRightPaneCollapsed() == true
end

----------------------------------------------------------------------
-- Pintar
----------------------------------------------------------------------
local Refresh

local function PaintLeft(arr)
    local p
    for _, x in ipairs(arr) do if x.name == selected then p = x end end
    if not p then p = arr[1]; selected = p and p.name end
    left.empty:SetShown(p == nil)
    left.body:SetShown(p ~= nil)
    left.count:SetText(#arr > 0 and ("%d en la lista · %d pendientes"):format(#arr, (function()
        local n = 0; for _, x in ipairs(arr) do if (x.vn or 0) > Kills(x) then n = n + 1 end end; return n end)()) or "")
    if not p then return end
    local b = left.body
    ClassIcon(b.icon, p.c)
    b.name:SetText(E.ClassColor(p.c) .. p.name .. "|r" .. (p.k and " |cffff3030[KOS]|r" or ""))
    local lv = p.l and ((p.l == -1) and "??" or tostring(p.l)) or nil
    local info = {}
    if p.r then info[#info + 1] = p.r end
    if p.cl then info[#info + 1] = p.cl end
    if lv then info[#info + 1] = "nivel " .. lv end
    b.info:SetText(table.concat(info, " ") .. (p.g and ("  <" .. p.g .. ">") or ""))
    local vn, kills = p.vn or 0, Kills(p)
    b.bar:SetMinMaxValues(0, math.max(1, vn))
    b.bar:SetValue(math.min(kills, math.max(1, vn)))
    if kills >= vn and vn > 0 then b.bar:SetStatusBarColor(0.2, 0.85, 0.2) else b.bar:SetStatusBarColor(1, 0.5, 0) end
    b.barText:SetText(("%d / %d venganzas"):format(kills, vn))
    if vn == 0 then
        b.status:SetText("Apuntado a mano (aún no te ha matado)")
    elseif kills >= vn then
        b.status:SetText(kills > vn and ("|cff55ff55¡Venganza cumplida!|r Le llevas %d de ventaja"):format(kills - vn)
            or "|cff55ff55¡Venganza cumplida!|r Estáis en paz")
    else
        local f = vn - kills
        b.status:SetText(("Te falta%s |cffff8000%d|r para estar en paz"):format(f == 1 and "" or "n", f))
    end
    b.deaths:SetText(vn)
    b.kills:SetText(kills)
    local last = p.vt and ("Última vez que te mató: " .. date("%d/%m/%y %H:%M", p.vt)) or "Última vez que te mató: ?"
    if p.z then last = last .. "\nVisto en " .. p.z .. ((p.sz and p.sz ~= "") and (" / " .. p.sz) or "") .. " · " .. E.AgoText(p.t) end
    b.last:SetText(last)
    b.note:SetText(p.n and ("Nota: " .. p.n) or "")
    b.kos:SetText(p.k and "Quitar KOS" or "KOS")
    local idx = 1
    for i, x in ipairs(arr) do if x.name == p.name then idx = i end end
    b.prev:SetEnabled(idx > 1)
    b.next:SetEnabled(idx < #arr)
    b.pos:SetText(idx .. "/" .. #arr)
end

local function PaintRight(arr)
    right:SetShown(not Collapsed())
    if not right:IsShown() then return end
    right.sub:SetText(#arr == 1 and "1 jugador" or (#arr .. " jugadores"))
    offset = math.max(0, math.min(offset, #arr - MAX_ROWS))
    for i = 1, MAX_ROWS do
        local row, p = rows[i], arr[i + offset]
        if p then
            row.pname = p.name
            ClassIcon(row.icon, p.c)
            row.name:SetText(E.ClassColor(p.c) .. p.name .. "|r")
            local vn, kills = p.vn or 0, Kills(p)
            row.score:SetText(("|cffff8000%d|r-|cff55ff55%d|r"):format(vn, kills))
            row.sel:SetShown(p.name == selected)
            row:Show()
        else
            row.pname = nil
            row:Hide()
        end
    end
    right.empty:SetShown(#arr == 0)
end

Refresh = function()
    if not (panel and panel:IsShown()) then return end
    local arr = List()
    PaintLeft(arr)
    PaintRight(arr)
end

local function Step(d)
    local arr = List()
    for i, x in ipairs(arr) do
        if x.name == selected then
            local n = arr[i + d]
            if n then selected = n.name end
            break
        end
    end
    -- que el elegido se vea en la lista de la derecha
    for i, x in ipairs(arr) do
        if x.name == selected then
            if i <= offset then offset = i - 1 elseif i > offset + MAX_ROWS then offset = i - MAX_ROWS end
        end
    end
    Refresh()
end

----------------------------------------------------------------------
-- Construir
----------------------------------------------------------------------
local function Btn(parent, text, w, fn, tip)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(w, 22)
    b:SetText(text)
    b:SetScript("OnClick", fn)
    if tip then
        b:SetScript("OnEnter", function(self) GameTooltip:SetOwner(self, "ANCHOR_TOP"); GameTooltip:SetText(tip); GameTooltip:Show() end)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end
    return b
end

local function Sel() return selected and E.Get(selected) end

local function BuildPanel()
    panel = CreateFrame("Frame", "CMVenganzaPjPanel", CharacterFrame)
    panel:SetFrameStrata("HIGH")              -- los paneles de la derecha de Blizzard tambien van en HIGH
    panel:SetFrameLevel(math.min(9000, (CharacterFrame:GetFrameLevel() or 1) + 900))
    panel:EnableMouse(true)
    panel:Hide()
    panel:SetScript("OnShow", function() Refresh() end)
    local acc = 0
    panel:SetScript("OnUpdate", function(_, el)   -- notas, KOS... cambian desde otros sitios
        acc = acc + el
        if acc >= 1 then acc = 0; Refresh() end
    end)

    -- Mitad izquierda: el enemigo elegido, como la ficha de rango de Overlord.
    left = CreateFrame("Frame", nil, panel)
    left:SetAllPoints(CharacterFrameLeftPaneHost)
    left:EnableMouse(true)
    local bg = left:CreateTexture(nil, "BACKGROUND")
    if Atlas(bg, "UI-Character-Info-General-BG", true) then bg:SetPoint("TOPLEFT") else bg:SetAllPoints(); bg:SetColorTexture(0.12, 0.07, 0.05, 1) end
    left.title = left:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    left.title:SetPoint("TOP", 0, -18)
    left.title:SetText("Lista de venganza")
    left.count = left:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    left.count:SetPoint("TOP", left.title, "BOTTOM", 0, -4)
    left.empty = left:CreateFontString(nil, "ARTWORK", "GameFontDisableLarge")
    left.empty:SetPoint("CENTER", 0, 20)
    left.empty:SetWidth(320)
    left.empty:SetText("Nadie te ha matado todavía.\nQuien te mate entra aquí solo.")

    local b = CreateFrame("Frame", nil, left)
    b:SetAllPoints()
    left.body = b
    local glow = b:CreateTexture(nil, "BACKGROUND", nil, 1)
    glow:SetSize(250, 250); glow:SetPoint("CENTER", b, "TOP", 0, -128)
    if not Atlas(glow, "UI-Character-Info-Honor-Bar-BG-Glow", false) then glow:Hide() end
    local ring = b:CreateTexture(nil, "BORDER")
    ring:SetSize(190, 170); ring:SetPoint("CENTER", b, "TOP", 0, -128)
    if not Atlas(ring, "pvpqueue-sidebar-honorbar-background", false) then ring:Hide() end
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetSize(96, 96); b.icon:SetPoint("CENTER", b, "TOP", 0, -128)
    b.prev = Btn(b, "<", 28, function() Step(-1) end, "Anterior")
    b.prev:SetPoint("CENTER", b, "TOP", -150, -128)
    b.next = Btn(b, ">", 28, function() Step(1) end, "Siguiente")
    b.next:SetPoint("CENTER", b, "TOP", 150, -128)
    b.pos = b:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
    b.pos:SetPoint("TOP", b.next, "BOTTOM", 0, -4)
    b.name = b:CreateFontString(nil, "ARTWORK", "GameFontHighlightLarge")
    b.name:SetPoint("TOP", 0, -218)
    local line = b:CreateTexture(nil, "BORDER")
    line:SetPoint("TOP", b.name, "BOTTOM", 0, 2)
    if not Atlas(line, "UI-Character-Info-Honor-LevelBG", true) then line:Hide() end
    b.info = b:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    b.info:SetPoint("TOP", b.name, "BOTTOM", 0, -6)

    b.bar = CreateFrame("StatusBar", nil, b)
    b.bar:SetSize(300, 20)
    b.bar:SetPoint("TOP", 0, -262)
    b.bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    local bbg = b.bar:CreateTexture(nil, "BACKGROUND")
    bbg:SetAllPoints(); bbg:SetColorTexture(0.25, 0.05, 0.03, 0.9)
    b.barText = b.bar:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    b.barText:SetPoint("CENTER")
    b.status = b:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    b.status:SetPoint("TOP", b.bar, "BOTTOM", 0, -8)

    local function Stat(x, color, label, minusTip, plusTip, set)
        local n = b:CreateFontString(nil, "ARTWORK", "GameFontHighlightHuge")
        n:SetPoint("TOP", b, "TOP", x, -318)
        n:SetTextColor(color[1], color[2], color[3])
        local l = b:CreateFontString(nil, "ARTWORK", "GameFontNormal")
        l:SetPoint("TOP", n, "BOTTOM", 0, -2)
        l:SetText(label)
        local minus = Btn(b, "-", 24, function() local p = Sel(); if p then set(p, -1) end end, minusTip)
        minus:SetPoint("TOPRIGHT", l, "BOTTOM", -2, -4)
        local plus = Btn(b, "+", 24, function() local p = Sel(); if p then set(p, 1) end end, plusTip)
        plus:SetPoint("TOPLEFT", l, "BOTTOM", 2, -4)
        return n, minus, plus
    end
    b.deaths, b.dMinus, b.dPlus = Stat(-95, { 1, 0.5, 0 }, "Te ha matado", "Una muerte menos", "Una muerte más",
        function(p, d) E.SetRevengeCount(selected, (p.vn or 0) + d); Refresh() end)
    b.kills, b.kMinus, b.kPlus = Stat(95, { 0.33, 1, 0.33 }, "Le has matado", "Una venganza menos", "Una venganza más",
        function(p, d) E.SetRevengeKills(selected, Kills(p) + d); Refresh() end)

    b.last = b:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    b.last:SetPoint("TOP", 0, -394)
    b.last:SetWidth(360)
    b.note = b:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
    b.note:SetPoint("TOP", b.last, "BOTTOM", 0, -2)
    b.note:SetWidth(360)
    b.noteBtn = Btn(b, "Nota", 70, function() if selected then E.AskNote(selected) end end, "Escribir o cambiar la nota")
    b.noteBtn:SetPoint("BOTTOM", b, "BOTTOM", -114, 12)
    b.kos = Btn(b, "KOS", 90, function()
        local p = Sel(); if p then E.SetKOS(selected, not p.k); Refresh() end
    end, "Matar a la vista")
    b.kos:SetPoint("LEFT", b.noteBtn, "RIGHT", 4, 0)
    b.del = Btn(b, "Quitar", 70, function()
        if selected then E.SetRevenge(selected, false); selected = nil; Refresh() end
    end, "Quitar de la lista de venganza")
    b.del:SetPoint("LEFT", b.kos, "RIGHT", 4, 0)
    b.all = Btn(b, "Lista", 60, function() if E.OpenRevenge then E.OpenRevenge() end end, "Abrir la ventana con la lista completa")
    b.all:SetPoint("LEFT", b.del, "RIGHT", 4, 0)

    -- Mitad derecha: la lista, como la de rangos de Overlord.
    right = CreateFrame("Frame", nil, panel)
    right:SetAllPoints(CharacterFrameRightPaneHost)
    right:EnableMouse(true)
    local rbg = right:CreateTexture(nil, "BACKGROUND")
    if Atlas(rbg, "UI-Character-Info-Stat-BG", true) then rbg:SetPoint("TOPLEFT") else rbg:SetAllPoints(); rbg:SetColorTexture(0.1, 0.06, 0.04, 1) end
    local stone = right:CreateTexture(nil, "BORDER")
    stone:SetPoint("TOPLEFT")
    if not Atlas(stone, "UI-Character-Info-Stat-StoneBG3", true) then stone:Hide() end
    right.title = right:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    right.title:SetPoint("TOP", 0, -20)
    right.title:SetText("Venganza")
    right.sub = right:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    right.sub:SetPoint("TOP", right.title, "BOTTOM", 0, -3)
    local div = right:CreateTexture(nil, "ARTWORK")
    div:SetPoint("TOP", right.sub, "BOTTOM", 0, -6)
    if not Atlas(div, "UI-Character-Info-ScrollLine", true) then div:Hide() end
    right.empty = right:CreateFontString(nil, "ARTWORK", "GameFontDisable")
    right.empty:SetPoint("CENTER", 0, 30)
    right.empty:SetText("Lista vacía")
    right:EnableMouseWheel(true)
    right:SetScript("OnMouseWheel", function(_, delta) offset = offset - delta; Refresh() end)
    for i = 1, MAX_ROWS do
        local row = CreateFrame("Button", nil, right)
        row:SetSize(205, ROW_H)
        row:SetPoint("TOPLEFT", 14, -72 - (i - 1) * ROW_H)
        row:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        row.sel = row:CreateTexture(nil, "BACKGROUND")
        row.sel:SetAllPoints()
        row.sel:SetColorTexture(0.55, 0.5, 0.08, 0.85)
        row.sel:Hide()
        local hl = row:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints(); hl:SetColorTexture(1, 1, 1, 0.08)
        row.icon = row:CreateTexture(nil, "ARTWORK")
        row.icon:SetSize(20, 20); row.icon:SetPoint("LEFT", 4, 0)
        row.name = row:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
        row.name:SetPoint("LEFT", row.icon, "RIGHT", 6, 0)
        row.name:SetWidth(120); row.name:SetJustifyH("LEFT")
        row.score = row:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
        row.score:SetPoint("RIGHT", -6, 0)
        row:SetScript("OnClick", function(self, button)
            if not self.pname then return end
            if button == "RightButton" then E.ShowMenu(self, self.pname) return end
            selected = self.pname
            Refresh()
        end)
        rows[i] = row
    end
end

----------------------------------------------------------------------
-- Pestaña y enganches con la ventana de personaje
----------------------------------------------------------------------
local function BlizzTabs() return CharacterFrame and CharacterFrame.ModeTabs and CharacterFrame.ModeTabs.Tabs end

local function MarkTabs(ours)
    for _, t in ipairs(BlizzTabs() or {}) do
        if t.SetChecked then
            if ours then t:SetChecked(false) else t:SetChecked(t.frameName == CharacterFrame.activeSubframe) end
        end
    end
    if tab and tab.SetChecked then tab:SetChecked(ours) end
end

local function SetTitle(text)
    if text then
        if CharacterFrame.SetTitle then pcall(CharacterFrame.SetTitle, CharacterFrame, text) end
    elseif CharacterFrame.UpdateTitle then
        pcall(CharacterFrame.UpdateTitle, CharacterFrame)
    end
end

local function HidePanel()
    if not (panel and panel:IsShown()) then return end
    panel:Hide()
    MarkTabs(false)
    SetTitle(nil)
end

local function ShowPanel()
    if not Wanted() then return end
    if not panel then BuildPanel() end
    panel:Show()
    MarkTabs(true)
    SetTitle("Venganza")
    Refresh()
end

local function PlaceTab()
    if not tab then return end
    local last
    for _, t in ipairs(BlizzTabs() or {}) do if t:IsShown() then last = t end end
    tab:ClearAllPoints()
    if last then tab:SetPoint("TOPLEFT", last, "BOTTOMLEFT", 0, -2)
    else tab:SetPoint("TOPLEFT", CharacterFrame, "TOPRIGHT", 0, -30) end
end

local hooked = false
local function Build()
    if tab or not (CharacterFrame and BlizzTabs() and CharacterFrameLeftPaneHost and CharacterFrameRightPaneHost) then return end
    local parent = CharacterFrame.ModeTabs
    local ok, t = pcall(CreateFrame, "Frame", "CMVenganzaPjTab", parent, "CharacterFrameModeSideTabTemplate")
    if not ok or not t then
        ok, t = pcall(CreateFrame, "Frame", "CMVenganzaPjTab", parent, "LargeSideTabButtonTemplate")
    end
    if not ok or not t then return end
    tab = t
    tab.tooltipText = "Lista de venganza"
    tab.frameName = nil
    if type(tab.Icon) == "table" then
        tab.Icon:SetTexture(ICONO)
        if tab.UpdateIconInterior then pcall(tab.UpdateIconInterior, tab) end
    end
    -- la plantilla de Blizzard llama a CharacterFrame:OnModeTabClicked; la nuestra abre el panel
    local function OnUp(_, button, upInside)
        if button == "LeftButton" and upInside then
            if panel and panel:IsShown() then return end
            ShowPanel()
        end
    end
    if tab.SetCustomOnMouseUpHandler then tab:SetCustomOnMouseUpHandler(OnUp) end
    tab.customMouseUpHandler = OnUp
    if not tab.SetCustomOnMouseUpHandler then tab:SetScript("OnMouseUp", function(self, b) OnUp(self, b, true) end) end
    PlaceTab()

    if not hooked then
        hooked = true
        -- otra pestaña, o un atajo (C, U...) que cambia de pagina: fuera nuestro panel
        if CharacterFrame.OnModeTabClicked then hooksecurefunc(CharacterFrame, "OnModeTabClicked", function() HidePanel() end) end
        if CharacterFrame.ShowSubFrame then hooksecurefunc(CharacterFrame, "ShowSubFrame", function() HidePanel() end) end
        -- al plegar/desplegar la mitad derecha Blizzard repinta y marca su pestaña: se vuelve a marcar la nuestra
        if CharacterFrame.RefreshDisplay then
            hooksecurefunc(CharacterFrame, "RefreshDisplay", function()
                if panel and panel:IsShown() then MarkTabs(true); SetTitle("Venganza"); Refresh() end
            end)
        end
        if CharacterFrame.UpdateTabLayout then hooksecurefunc(CharacterFrame, "UpdateTabLayout", PlaceTab) end
        CharacterFrame:HookScript("OnShow", function() PlaceTab(); if tab then tab:SetShown(Wanted() and true or false) end end)
        CharacterFrame:HookScript("OnHide", function() HidePanel() end)
    end
end

-- Lo llaman la opcion de la configuracion y el modulo al activarse/desactivarse.
function E.CharTabUpdate()
    if Wanted() then
        Build()
        if tab then tab:Show(); PlaceTab() end
    else
        HidePanel()
        if tab then tab:Hide() end
    end
end
E.CharTabRefresh = function() Refresh() end
E.CharTabShow = function() Build(); ShowPanel() end   -- para las pruebas y /pvpo venganza pj

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function() E.CharTabUpdate() end)
