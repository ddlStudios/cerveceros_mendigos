-- Pestaña «Venganza» en la ventana de personaje de WoW Forever (debajo de la de Overlord).
-- Parte del modulo Enemigos cercanos (PvPOutdoor). Se carga despues de Espia.lua (usa ns.PO_Espia).
--
-- Como esta hecha la ventana de Forever (Blizzard_UIPanels_Game/Camelot/CharacterFrame.lua):
--   pestañas laterales = CharacterFrame.ModeTabs.Tabs (plantilla CharacterFrameModeSideTabTemplate),
--   mitad izquierda = CharacterFrameLeftPaneHost (fondo UI-Character-Info-General-BG),
--   mitad derecha  = CharacterFrameRightPaneHost (fondo UI-Character-Info-Stat-BG), que se puede plegar.
-- Para no ensuciar (taint) la ventana de Blizzard NO se toca CHARACTERFRAME_SUBFRAMES ni sus tablas:
-- la pestaña es nuestra (misma plantilla) y el panel se pone ENCIMA del contenido, con los mismos fondos.
local ADDON, ns = ...
local E = ns.PO_Espia
if not E then return end

local NOMBRE = "Venganza"
local ICONO = "Interface/ICONS/Ability_Warrior_Revenge"
local LOGO = "Interface\\AddOns\\" .. ADDON .. "\\logo.tga"   -- el de Cerveceros Mendigos, para el retrato
-- Las paginas de la ventana de personaje (Overlord = PVPRankFrame)
local PAGINAS = { "PaperDollFrame", "ReputationFrame", "TokenFrame", "PVPRankFrame", "SkillsFrame", "StatisticsFrame" }
local tab, panel, left, right
local rows = {}
local selected            -- nombre del enemigo elegido
local offset = 0          -- desplazamiento de la lista de la derecha
local ROW_H, MAX_ROWS = 28, 13   -- 13 filas desde -76: acaban en -440 (el hueco mide 464)

local function S() return E.Settings() end
local function Wanted() return E.Active() and S() and S().revenge and S().charTab end
local function Kills(p) return E.RevengeKills(p) end

local function Atlas(tex, atlas, useSize)
    if not (tex and tex.SetAtlas) then return false end
    local ok = pcall(tex.SetAtlas, tex, atlas, useSize)
    return ok
end

local function ClassIcon(tex, class)
    local tc = class and CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[class]
    if tc then
        tex:SetTexture("Interface\\TargetingFrame\\UI-Classes-Circles")
        tex:SetTexCoord(tc[1], tc[2], tc[3], tc[4])
    else
        tex:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
        tex:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    end
end

local function List()
    local arr = E.RevengeList()
    -- primero los que tienen la venganza pendiente (te han matado mas veces que tu a ellos)
    local pend, done = {}, {}
    for _, p in ipairs(arr) do
        if (p.vn or 0) > Kills(p) then pend[#pend + 1] = p else done[#done + 1] = p end
    end
    for _, p in ipairs(done) do pend[#pend + 1] = p end
    return pend
end

local function Collapsed()
    return CharacterFrame and CharacterFrame.IsRightPaneCollapsed and CharacterFrame:IsRightPaneCollapsed() == true
end

----------------------------------------------------------------------
-- Pintar
----------------------------------------------------------------------
local Refresh
local MarkTabs   -- se define abajo (pestañas)
local HidePanel  -- se define abajo
local SeHaIdo    -- se define abajo (¿el jugador se ha ido a otra pagina?)
local VigilarRaton -- se define abajo (clics en otras pestañas)

local function PaintLeft(arr)
    local p
    for _, x in ipairs(arr) do if x.name == selected then p = x end end
    if not p then p = arr[1]; selected = p and p.name end
    left.empty:SetShown(p == nil)
    left.body:SetShown(p ~= nil)
    left.count:SetText(#arr > 0 and ("%d en la lista · %d pendientes"):format(#arr, (function()
        local n = 0; for _, x in ipairs(arr) do if (x.vn or 0) > Kills(x) then n = n + 1 end end; return n end)()) or "")
    if not p then return end
    local b = left.body
    ClassIcon(b.icon, p.c)
    b.name:SetText(E.ClassColor(p.c) .. p.name .. "|r" .. (p.k and " |cffff3030[KOS]|r" or ""))
    local lv = p.l and ((p.l == -1) and "??" or tostring(p.l)) or nil
    local info = {}
    if p.r then info[#info + 1] = p.r end
    if p.cl then info[#info + 1] = p.cl end
    if lv then info[#info + 1] = "nivel " .. lv end
    b.info:SetText(table.concat(info, " ") .. (p.g and ("  <" .. p.g .. ">") or ""))
    local vn, kills = p.vn or 0, Kills(p)
    b.bar:SetMinMaxValues(0, math.max(1, vn))
    b.bar:SetValue(math.min(kills, math.max(1, vn)))
    if kills >= vn and vn > 0 then b.bar:SetStatusBarColor(0.2, 0.85, 0.2) else b.bar:SetStatusBarColor(1, 0.5, 0) end
    b.barText:SetText(("%d / %d venganzas"):format(kills, vn))
    if vn == 0 then
        b.status:SetText("Apuntado a mano (aún no te ha matado)")
    elseif kills >= vn then
        b.status:SetText(kills > vn and ("|cff55ff55¡Venganza cumplida!|r Le llevas %d de ventaja"):format(kills - vn)
            or "|cff55ff55¡Venganza cumplida!|r Estáis en paz")
    else
        local f = vn - kills
        b.status:SetText(("Te falta%s |cffff8000%d|r para estar en paz"):format(f == 1 and "" or "n", f))
    end
    b.deaths:SetText(vn)
    b.kills:SetText(kills)
    local last = p.vt and ("Última vez que te mató: " .. date("%d/%m/%y %H:%M", p.vt)) or "Última vez que te mató: ?"
    if p.z then last = last .. "\nVisto en " .. p.z .. ((p.sz and p.sz ~= "") and (" / " .. p.sz) or "") .. " · " .. E.AgoText(p.t) end
    b.last:SetText(last)
    b.note:SetText(p.n and ("Nota: " .. p.n) or "")
    b.kos:SetText(p.k and "Quitar KOS" or "KOS")
    local idx = 1
    for i, x in ipairs(arr) do if x.name == p.name then idx = i end end
    b.prev:SetEnabled(idx > 1)
    b.next:SetEnabled(idx < #arr)
    b.pos:SetText(idx .. " / " .. #arr)
end

local function PaintRight(arr)
    right:SetShown(not Collapsed())
    if not right:IsShown() then return end
    right.sub:SetText(#arr == 1 and "1 jugador" or (#arr .. " jugadores"))
    offset = math.max(0, math.min(offset, #arr - MAX_ROWS))
    for i = 1, MAX_ROWS do
        local row, p = rows[i], arr[i + offset]
        if p then
            row.pname = p.name
            ClassIcon(row.icon, p.c)
            row.name:SetText(E.ClassColor(p.c) .. p.name .. "|r")
            local vn, kills = p.vn or 0, Kills(p)
            row.score:SetText(("|cffff8000%d|r-|cff55ff55%d|r"):format(vn, kills))
            row.sel:SetShown(p.name == selected)
            row:Show()
        else
            row.pname = nil
            row:Hide()
        end
    end
    right.empty:SetShown(#arr == 0)
end

Refresh = function()
    if not (panel and panel:IsShown()) then return end
    if tab and type(tab.SelectedTexture) == "table" and not tab.SelectedTexture:IsShown() then MarkTabs(true) end
    local arr = List()
    PaintLeft(arr)
    PaintRight(arr)
end

local function Step(d)
    local arr = List()
    for i, x in ipairs(arr) do
        if x.name == selected then
            local n = arr[i + d]
            if n then selected = n.name end
            break
        end
    end
    -- que el elegido se vea en la lista de la derecha
    for i, x in ipairs(arr) do
        if x.name == selected then
            if i <= offset then offset = i - 1 elseif i > offset + MAX_ROWS then offset = i - MAX_ROWS end
        end
    end
    Refresh()
end

----------------------------------------------------------------------
-- Construir
----------------------------------------------------------------------
local function Btn(parent, text, w, fn, tip)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(w, 22)
    b:SetText(text)
    b:SetScript("OnClick", fn)
    if tip then
        b:SetScript("OnEnter", function(self) GameTooltip:SetOwner(self, "ANCHOR_TOP"); GameTooltip:SetText(tip); GameTooltip:Show() end)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end
    return b
end

local function Sel() return selected and E.Get(selected) end

-- Fondo macizo que tapa TODO el hueco (si no, se transparenta lo de Overlord que sigue debajo).
local function Base(f, r, g, b)
    local t = f:CreateTexture(nil, "BACKGROUND", nil, -8)
    t:SetAllPoints()
    t:SetColorTexture(r, g, b, 1)
    return t
end

-- Flecha de pasar pagina (como las del libro de hechizos).
local function Arrow(parent, dir, fn, tip)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(30, 30)
    local base = "Interface\\Buttons\\UI-SpellbookIcon-" .. (dir < 0 and "Prev" or "Next") .. "Page-"
    b:SetNormalTexture(base .. "Up")
    b:SetPushedTexture(base .. "Down")
    b:SetDisabledTexture(base .. "Disabled")
    b:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
    b:SetScript("OnClick", fn)
    if tip then
        b:SetScript("OnEnter", function(self) GameTooltip:SetOwner(self, "ANCHOR_TOP"); GameTooltip:SetText(tip); GameTooltip:Show() end)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end
    return b
end

-- Marco dorado fino alrededor de una barra.
local function Border(f, r, g, b)
    local function line(p1, p2, w, h)
        local t = f:CreateTexture(nil, "OVERLAY")
        t:SetColorTexture(r, g, b, 1)
        t:SetPoint(p1); t:SetPoint(p2)
        if w then t:SetWidth(w) else t:SetHeight(h) end
    end
    line("TOPLEFT", "TOPRIGHT", nil, 1); line("BOTTOMLEFT", "BOTTOMRIGHT", nil, 1)
    line("TOPLEFT", "BOTTOMLEFT", 1, nil); line("TOPRIGHT", "BOTTOMRIGHT", 1, nil)
end

-- Todo va dentro del hueco de Blizzard (mitad izquierda 398 x 464): nada se sale por abajo.
local function BuildPanel()
    -- Como Overlord (PVPRankFrame): a la altura del contenido de la ventana, para no tapar el boton de plegar
    -- ni el marco; la mitad derecha en HIGH, como su panel lateral (CharacterFrameSidePaneTemplate).
    panel = CreateFrame("Frame", "CMVenganzaPjPanel", CharacterFrame)
    panel:SetFrameLevel((CharacterFrameLeftPaneHost:GetFrameLevel() or CharacterFrame:GetFrameLevel() or 1) + 1)
    panel:EnableMouse(true)
    panel:Hide()
    panel:SetScript("OnShow", function() Refresh() end)
    local acc = 0
    panel:SetScript("OnUpdate", function(_, el)   -- notas, KOS... cambian desde otros sitios
        if VigilarRaton() then return end
        acc = acc + el
        if acc >= 0.25 then
            acc = 0
            if SeHaIdo() then HidePanel(true) return end
            Refresh()
        end
    end)

    -- Mitad izquierda: el enemigo elegido, como la ficha de rango de Overlord.
    left = CreateFrame("Frame", nil, panel)
    left:SetAllPoints(CharacterFrameLeftPaneHost)
    left:EnableMouse(true)
    Base(left, 0.07, 0.05, 0.04)
    local bg = left:CreateTexture(nil, "BACKGROUND", nil, -7)
    if Atlas(bg, "UI-Character-Info-General-BG", true) then bg:SetPoint("TOPLEFT") else bg:Hide() end
    left.count = left:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
    left.count:SetPoint("TOP", 0, -16)   -- centrado: arriba a la izquierda lo tapa el retrato redondo
    left.empty = left:CreateFontString(nil, "ARTWORK", "GameFontDisableLarge")
    left.empty:SetPoint("CENTER", 0, 20)
    left.empty:SetWidth(320)
    left.empty:SetText("Nadie te ha matado todavía.\nQuien te mate entra aquí solo.")

    local b = CreateFrame("Frame", nil, left)
    b:SetAllPoints()
    left.body = b
    local CY = -112   -- centro del aro
    local glow = b:CreateTexture(nil, "BACKGROUND", nil, 1)
    glow:SetSize(250, 266); glow:SetPoint("CENTER", b, "TOP", 0, CY)
    if not Atlas(glow, "UI-Character-Info-Honor-Bar-BG-Glow", false) then glow:Hide() end
    local ring = b:CreateTexture(nil, "BORDER")
    ring:SetSize(200, 178); ring:SetPoint("CENTER", b, "TOP", 0, CY - 1)
    if not Atlas(ring, "pvpqueue-sidebar-honorbar-background", false) then ring:Hide() end
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetSize(84, 84); b.icon:SetPoint("CENTER", b, "TOP", 0, CY)
    b.prev = Arrow(b, -1, function() Step(-1) end, "Anterior")
    b.prev:SetPoint("CENTER", b, "TOP", -140, CY)
    b.next = Arrow(b, 1, function() Step(1) end, "Siguiente")
    b.next:SetPoint("CENTER", b, "TOP", 140, CY)
    b.pos = b:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    b.pos:SetPoint("CENTER", b, "TOP", 0, CY - 86)

    b.name = b:CreateFontString(nil, "ARTWORK", "GameFontHighlightLarge")
    b.name:SetPoint("TOP", 0, -212)
    b.info = b:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    b.info:SetPoint("TOP", b.name, "BOTTOM", 0, -3)
    local line = b:CreateTexture(nil, "BORDER")
    line:SetPoint("BOTTOM", b.info, "BOTTOM", 0, -10)
    if not Atlas(line, "UI-Character-Info-Honor-LevelBG", true) then line:Hide() end

    b.bar = CreateFrame("StatusBar", nil, b)
    b.bar:SetSize(300, 18)
    b.bar:SetPoint("TOP", 0, -262)
    b.bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    local bbg = b.bar:CreateTexture(nil, "BACKGROUND")
    bbg:SetAllPoints(); bbg:SetColorTexture(0.18, 0.06, 0.03, 1)
    Border(b.bar, 0.82, 0.66, 0.2)
    b.barText = b.bar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.barText:SetPoint("CENTER")
    b.status = b:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    b.status:SetPoint("TOP", b.bar, "BOTTOM", 0, -6)

    -- numeros grandes en blanco y la etiqueta en amarillo (como «Muertes honorables» de Overlord), con - y + a los lados
    local function Stat(x, label, minusTip, plusTip, set)
        local n = b:CreateFontString(nil, "ARTWORK", "GameFontHighlightHuge")
        n:SetPoint("TOP", b, "TOP", x, -304)
        local l = b:CreateFontString(nil, "ARTWORK", "GameFontNormal")
        l:SetPoint("TOP", n, "BOTTOM", 0, -2)
        l:SetText(label)
        local minus = Btn(b, "-", 22, function() local p = Sel(); if p then set(p, -1) end end, minusTip)
        minus:SetPoint("CENTER", b, "TOP", x - 44, -318)
        local plus = Btn(b, "+", 22, function() local p = Sel(); if p then set(p, 1) end end, plusTip)
        plus:SetPoint("CENTER", b, "TOP", x + 44, -318)
        return n, minus, plus
    end
    b.deaths, b.dMinus, b.dPlus = Stat(-100, "Te ha matado", "Una muerte menos", "Una muerte más",
        function(p, d) E.SetRevengeCount(selected, (p.vn or 0) + d); Refresh() end)
    b.kills, b.kMinus, b.kPlus = Stat(100, "Le has matado", "Una venganza menos", "Una venganza más",
        function(p, d) E.SetRevengeKills(selected, Kills(p) + d); Refresh() end)

    b.last = b:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    b.last:SetPoint("TOP", 0, -360)
    b.last:SetWidth(350)
    b.note = b:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
    b.note:SetPoint("TOP", b.last, "BOTTOM", 0, -2)
    b.note:SetWidth(350); b.note:SetMaxLines(1)
    b.kos = Btn(b, "KOS", 84, function()
        local p = Sel(); if p then E.SetKOS(selected, not p.k); Refresh() end
    end, "Matar a la vista")
    b.kos:SetPoint("BOTTOMRIGHT", b, "BOTTOM", -3, 24)
    b.noteBtn = Btn(b, "Nota", 76, function() if selected then E.AskNote(selected) end end, "Escribir o cambiar la nota")
    b.noteBtn:SetPoint("RIGHT", b.kos, "LEFT", -6, 0)
    b.del = Btn(b, "Quitar", 76, function()
        if selected then E.SetRevenge(selected, false); selected = nil; Refresh() end
    end, "Quitar de la lista de venganza")
    b.del:SetPoint("BOTTOMLEFT", b, "BOTTOM", 3, 24)
    b.all = Btn(b, "Lista", 76, function() if E.OpenRevenge then E.OpenRevenge() end end, "Abrir la ventana con la lista completa")
    b.all:SetPoint("LEFT", b.del, "RIGHT", 6, 0)

    -- Mitad derecha: la lista, como la de rangos de Overlord (cabecera de piedra y filas con icono).
    right = CreateFrame("Frame", nil, panel)
    right:SetFrameStrata("HIGH")
    right:SetAllPoints(CharacterFrameRightPaneHost)
    right:EnableMouse(true)
    Base(right, 0.06, 0.05, 0.04)
    local rbg = right:CreateTexture(nil, "BACKGROUND", nil, -7)
    rbg:SetAllPoints()   -- como Blizzard: el fondo de la derecha ocupa todo el hueco
    if not Atlas(rbg, "UI-Character-Info-Stat-BG", false) then rbg:Hide() end
    local stone = right:CreateTexture(nil, "BORDER")
    stone:SetPoint("TOPLEFT"); stone:SetPoint("TOPRIGHT")
    if Atlas(stone, "UI-Character-Info-Stat-StoneBG3", true) then stone:SetPoint("TOPRIGHT") else stone:Hide() end
    local div = right:CreateTexture(nil, "OVERLAY")
    div:SetPoint("TOPLEFT", -6, 0); div:SetPoint("BOTTOMLEFT", -6, 0)
    if Atlas(div, "common-framedivider", true) then div:SetPoint("BOTTOMLEFT", -6, 0) else div:Hide() end
    right.title = right:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    right.title:SetPoint("TOP", 2, -22)
    right.title:SetText("Venganza")
    right.sub = right:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    right.sub:SetPoint("TOP", right.title, "BOTTOM", 0, -4)
    right.empty = right:CreateFontString(nil, "ARTWORK", "GameFontDisable")
    right.empty:SetPoint("CENTER", 0, 30)
    right.empty:SetText("Lista vacía")
    right:EnableMouseWheel(true)
    right:SetScript("OnMouseWheel", function(_, delta) offset = offset - delta; Refresh() end)
    for i = 1, MAX_ROWS do
        local row = CreateFrame("Button", nil, right)
        row:SetPoint("TOPLEFT", 12, -76 - (i - 1) * ROW_H)
        row:SetPoint("TOPRIGHT", -10, -76 - (i - 1) * ROW_H)
        row:SetHeight(ROW_H - 2)
        row:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        row.sel = row:CreateTexture(nil, "BACKGROUND")
        row.sel:SetAllPoints()
        row.sel:SetColorTexture(0.45, 0.4, 0.06, 0.9)   -- la fila elegida, como la del rango actual de Overlord
        row.sel:Hide()
        local hl = row:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints(); hl:SetColorTexture(1, 0.85, 0.3, 0.12)
        row.icon = row:CreateTexture(nil, "ARTWORK")
        row.icon:SetSize(22, 22); row.icon:SetPoint("LEFT", 4, 0)
        row.name = row:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
        row.name:SetPoint("LEFT", row.icon, "RIGHT", 8, 0)
        row.name:SetPoint("RIGHT", row, "RIGHT", -44, 0)
        row.name:SetJustifyH("LEFT"); row.name:SetMaxLines(1)
        row.score = row:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
        row.score:SetPoint("RIGHT", -6, 0)
        row:SetScript("OnClick", function(self, button)
            if not self.pname then return end
            if button == "RightButton" then E.ShowMenu(self, self.pname) return end
            selected = self.pname
            Refresh()
        end)
        rows[i] = row
    end
end

----------------------------------------------------------------------
-- Pestaña y enganches con la ventana de personaje
----------------------------------------------------------------------
local function BlizzTabs() return CharacterFrame and CharacterFrame.ModeTabs and CharacterFrame.ModeTabs.Tabs end

-- Todas las pestañas de Blizzard, se vean o no: las de la lista y los demas hijos del contenedor (Overlord puede ir suelta).
local function AllBlizzTabs()
    local list, seen = {}, {}
    local function add(t) if t and t ~= tab and not seen[t] and (type(t.SetChecked) == "function" or type(t.SelectedTexture) == "table") then seen[t] = true; list[#list + 1] = t end end
    for _, t in ipairs(BlizzTabs() or {}) do add(t) end
    local parent = CharacterFrame and CharacterFrame.ModeTabs
    if parent and parent.GetChildren then for _, t in ipairs({ parent:GetChildren() }) do add(t) end end
    return list
end

-- La textura dorada de «elegida» (SelectedTexture) se ve desde que se crea la pestaña: hay que apagarla a mano.
local function Check(t, v)
    if t.SetChecked then pcall(t.SetChecked, t, v) end
    if type(t.SelectedTexture) == "table" and t.SelectedTexture.SetShown then t.SelectedTexture:SetShown(v and true or false) end
end

function MarkTabs(ours)
    if ours then
        for _, t in ipairs(AllBlizzTabs()) do Check(t, false) end
    elseif CharacterFrame.SetSelectedModeTabByFrame then
        pcall(CharacterFrame.SetSelectedModeTabByFrame, CharacterFrame, CharacterFrame.activeSubframe)
    else
        for _, t in ipairs(AllBlizzTabs()) do Check(t, t.frameName ~= nil and t.frameName == CharacterFrame.activeSubframe) end
    end
    if tab then Check(tab, ours) end
end

local function TitleFS()
    local tc = CharacterFrame.TitleContainer
    local tt = (type(tc) == "table" and type(tc.TitleText) == "table" and tc.TitleText) or _G.CharacterFrameTitleText
    if type(tt) == "table" and tt.GetText then return tt end
end
local function PortraitTex()
    local tex = type(CharacterFrame.GetPortrait) == "function" and CharacterFrame:GetPortrait()
    if type(tex) == "table" and tex.SetTexture then return tex end
end
-- Lo que habia antes de abrir Venganza (titulo y retrato), y lo que pusimos nosotros
local antes, puesto = {}, {}
local function GuardarAntes()
    local tt, tex = TitleFS(), PortraitTex()
    antes.titulo = tt and tt:GetText()
    antes.retrato = tex and tex.GetTexture and tex:GetTexture()
end
local function ApuntarPuesto()
    local tt, tex = TitleFS(), PortraitTex()
    puesto.titulo = tt and tt:GetText()
    puesto.retrato = tex and tex.GetTexture and tex:GetTexture()
end
local function SetTitle(text)
    if text then
        if CharacterFrame.SetTitle then pcall(CharacterFrame.SetTitle, CharacterFrame, text) end
        local tc = CharacterFrame.TitleContainer
        local tt = (type(tc) == "table" and type(tc.TitleText) == "table" and tc.TitleText) or _G.CharacterFrameTitleText
        if type(tt) == "table" and tt.SetText and tt.GetText and tt:GetText() ~= text then tt:SetText(text) end
    elseif CharacterFrame.UpdateTitle then
        pcall(CharacterFrame.UpdateTitle, CharacterFrame)
    end
end

-- El retrato redondo de arriba a la izquierda: Overlord pone su emblema; nosotros el icono de Venganza.
local function SetPortrait(ours)
    if ours then
        local tex = type(CharacterFrame.GetPortrait) == "function" and CharacterFrame:GetPortrait()
        if type(tex) == "table" and tex.SetTexture then
            if not (SetPortraitToTexture and pcall(SetPortraitToTexture, tex, LOGO)) then tex:SetTexture(LOGO) end
        end
    elseif type(CharacterFrame.UpdatePortrait) == "function" then
        pcall(CharacterFrame.UpdatePortrait, CharacterFrame)
    end
end

-- La pagina de Blizzard que estaba abierta se OCULTA mientras se ve la nuestra (como hace ShowSubFrame).
-- Si se dejara abierta debajo: se transparenta, y al pulsar su pestaña ToggleCharacter cree que ya esta abierta,
-- no hace nada y quedan las dos pestañas marcadas.
-- ============================================================================================================
-- Paginas de la ventana de personaje. En Forever la de Overlord NO es una pagina de Blizzard (ni PVPRankFrame ni
-- CHARACTERFRAME_SUBFRAMES): es un cuadro sin nombre que cuelga de CharacterFrame y que se enseña con su pestaña.
-- Por eso no se fía de nombres ni de funciones de Blizzard:
--   «pagina» = lo que cuelga de la ventana con tamaño de pagina (>= 300 de ancho) y no es el marco de la ventana
--   (NineSlice, retrato, titulo, cerrar, mitades, pestañas...), o una pagina conocida/registrada.
-- Al abrir Venganza se ocultan TODAS las paginas visibles; con Venganza abierta no debe verse ninguna: si aparece
-- una, el jugador se ha ido a otra pestaña y Venganza se quita (sin volver a enseñar las ocultas).
-- ============================================================================================================
local MARCO = { NineSlice = true, PortraitContainer = true, TitleContainer = true, Bg = true, Background = true,
    TopTileStreaks = true, CloseButton = true, Inset = true, ModeTabs = true, LeftPaneHost = true, RightPaneHost = true,
    RightPaneToggleButton = true, TabIndicators = true, Divider = true, Footer = true, PortraitButton = true }
local ocultas = {}            -- paginas que hemos ocultado al abrir (para devolverlas si se cierra la ventana)
local yaVisibles = {}         -- las que no se pudieron ocultar (en combate, protegidas): no cuentan
local abiertoEn = 0
local activaAlAbrir
local ultimaPestana, ultimaPestanaEn = nil, 0   -- la ultima pestaña de Blizzard pulsada (para marcarla al irse)

local function EsMarco(f)
    if f == panel or f == CharacterFrame.ModeTabs or f == CharacterFrameLeftPaneHost or f == CharacterFrameRightPaneHost then return true end
    for k in pairs(MARCO) do if CharacterFrame[k] == f then return true end end
    local n = f.GetName and f:GetName()
    if n and (n == "CharacterFrameCloseButton" or n == "CharacterFrameRightPaneToggleButton" or n == "CharacterFrameTabIndicators"
        or n == "CharacterFrameModeTabs" or n:find("^CMVenganza")) then return true end
    return false
end

local function Nombradas()
    local list, seen = {}, {}
    local function add(f)
        if type(f) == "string" then f = _G[f] end
        if type(f) == "table" and f ~= panel and f.IsShown and not seen[f] then seen[f] = true; list[#list + 1] = f end
    end
    if type(CHARACTERFRAME_SUBFRAMES) == "table" then for _, n in pairs(CHARACTERFRAME_SUBFRAMES) do add(n) end end
    for _, n in ipairs(PAGINAS) do add(n) end
    add(CharacterFrame.activeSubframe)
    return list, seen
end

-- Todas las paginas (visibles o no): las conocidas y lo que cuelga de la ventana con tamaño de pagina.
local function Paginas()
    local list, seen = Nombradas()
    if CharacterFrame.GetChildren then
        for _, f in ipairs({ CharacterFrame:GetChildren() }) do
            if not seen[f] and not EsMarco(f) then
                local ok, w = pcall(f.GetWidth, f)
                if ok and type(w) == "number" and w >= 300 then seen[f] = true; list[#list + 1] = f end
            end
        end
    end
    for f in pairs(ocultas) do if not seen[f] then seen[f] = true; list[#list + 1] = f end end
    return list
end

local function Protegida(f) return InCombatLockdown and InCombatLockdown() and f.IsProtected and f:IsProtected() end

local function OcultarPaginas()
    ocultas, yaVisibles = {}, {}
    for _, f in ipairs(Paginas()) do
        if f:IsShown() then
            if Protegida(f) then yaVisibles[f] = true else f:Hide(); ocultas[f] = true end
        end
    end
end

local function HayPaginaVisible()
    for _, f in ipairs(Paginas()) do
        if f:IsShown() and not yaVisibles[f] then return f end
    end
end

-- Devolver lo que se oculto (al cerrar la ventana, o si al quitar Venganza no ha quedado ninguna pagina a la vista).
local function DevolverPaginas()
    for f in pairs(ocultas) do
        if not f:IsShown() and not Protegida(f) then f:Show() end
    end
    ocultas = {}
end

-- Con Venganza abierta, ¿se ha ido el jugador a otra pagina?
function SeHaIdo()
    if CharacterFrame.activeSubframe ~= activaAlAbrir then return true end
    return HayPaginaVisible() ~= nil
end

local function AlMostrarse()
    if not (panel and panel:IsShown()) then return end
    if GetTime() - abiertoEn < 0.3 then return end   -- lo que se mueve justo al abrir no cuenta
    if SeHaIdo() then HidePanel(true) end
end

local vigiladas = {}
local function Vigilar(f)
    if type(f) == "table" and f ~= panel and f.HookScript and not vigiladas[f] then
        vigiladas[f] = true
        pcall(f.HookScript, f, "OnShow", AlMostrarse)
    end
end

-- Pestañas de Blizzard (las de la lista y lo que cuelga del contenedor): apuntar la ultima pulsada.
local vigiladasTab = {}
local function VigilarPestanas()
    local function add(t)
        if type(t) == "table" and t ~= tab and t.HookScript and not vigiladasTab[t] then
            vigiladasTab[t] = true
            pcall(t.HookScript, t, "OnMouseDown", function(self) ultimaPestana, ultimaPestanaEn = self, GetTime() end)
        end
    end
    for _, t in ipairs(BlizzTabs() or {}) do add(t) end
    local mt = CharacterFrame.ModeTabs
    if mt and mt.GetChildren then for _, t in ipairs({ mt:GetChildren() }) do add(t) end end
end

local function VigilarTodo()
    for _, f in ipairs(Paginas()) do Vigilar(f) end
    if CharacterFrame.GetChildren then
        for _, f in ipairs({ CharacterFrame:GetChildren() }) do if not EsMarco(f) then Vigilar(f) end end
    end
    VigilarPestanas()
end

-- /pvpo venganza diag: que ve el addon (para cuando algo no cuadre en una version del juego)
function E.CharTabDiag(print)
    local function nombre(f) return type(f) == "table" and f.GetName and (f:GetName() or "(sin nombre)") or tostring(f) end
    local n = 0; for _ in pairs(ocultas) do n = n + 1 end
    print("Venganza: panel " .. ((panel and panel:IsShown()) and "ABIERTO" or "cerrado")
        .. " · pagina activa: " .. tostring(CharacterFrame and CharacterFrame.activeSubframe)
        .. " · ocultadas por nosotros: " .. n)
    local vis = {}
    for _, f in ipairs(Paginas()) do vis[#vis + 1] = nombre(f) .. (f:IsShown() and "=SI" or "=no") .. (ocultas[f] and "(oculta)" or "") end
    print("Paginas: " .. table.concat(vis, ", "))
    local hijos = {}
    if CharacterFrame and CharacterFrame.GetChildren then
        for _, f in ipairs({ CharacterFrame:GetChildren() }) do
            if f.IsShown and f:IsShown() then
                local ok, w = pcall(f.GetWidth, f)
                hijos[#hijos + 1] = nombre(f) .. "[" .. ((ok and type(w) == "number") and math.floor(w) or "?") .. (EsMarco(f) and ",marco" or "") .. "]"
            end
        end
    end
    print("Visible en la ventana: " .. table.concat(hijos, ", "))
end

-- ============================================================================================================
-- Clics en otras pestañas, mirando el RATON: la pestaña de Overlord de Forever no esta con las de Blizzard ni avisa
-- de nada, y si su pagina estaba oculta por nosotros cree que ya esta abierta y no hace nada al pulsarla.
-- Pestaña ajena = lo pulsado (o algo de lo que cuelga) con aspecto de pestaña (SetChecked / SelectedTexture /
-- customMouseUpHandler) que no es la nuestra, y esta en la lista de Blizzard o en nuestra misma columna.
-- ============================================================================================================
local function Debajo()
    if GetMouseFoci then
        local ok, foci = pcall(GetMouseFoci)
        if ok and type(foci) == "table" then return foci[1] end
    end
    if GetMouseFocus then local ok, f = pcall(GetMouseFocus); if ok then return f end end
end

local function EsDeNuestroPanel(f)
    local p = f
    for _ = 1, 12 do
        if not p then return false end
        if p == panel or p == tab then return true end
        p = p.GetParent and p:GetParent()
    end
    return false
end

local function PestanaAjena(f)
    if type(f) ~= "table" or EsDeNuestroPanel(f) then return nil end
    local t = f
    for _ = 1, 4 do
        if type(t) ~= "table" then return nil end
        if type(t.SetChecked) == "function" or type(t.SelectedTexture) == "table" or t.customMouseUpHandler then break end
        t = t.GetParent and t:GetParent()
    end
    if type(t) ~= "table" or t == tab then return nil end
    for _, b in ipairs(AllBlizzTabs()) do if b == t then return t end end
    -- misma columna que la nuestra (asi esta la de Overlord)
    local okA, a = pcall(t.GetLeft, t)
    local okB, b = pcall(tab.GetLeft, tab)
    if okA and okB and type(a) == "number" and type(b) == "number" and math.abs(a - b) <= 20 then return t end
    return nil
end

local raton = { abajo = false, sobre = nil }
function VigilarRaton()
    local down = IsMouseButtonDown and IsMouseButtonDown("LeftButton") and true or false
    if down and not raton.abajo then raton.sobre = PestanaAjena(Debajo()) end   -- al pulsar: ¿sobre otra pestaña?
    local soltado = raton.abajo and not down
    raton.abajo = down
    if soltado and raton.sobre then
        local t = raton.sobre
        raton.sobre = nil
        ultimaPestana, ultimaPestanaEn = t, GetTime()
        HidePanel()   -- si la pestaña no enseña nada (creia que ya estaba abierta), a los 0,2 s se devuelve su pagina
        return true
    end
    return false
end

-- porIrse = el jugador se ha ido a otra pagina (no se devuelve nada: esa pagina ya la ha puesto el juego)
function HidePanel(porIrse)
    if not (panel and panel:IsShown()) then return end
    panel:Hide()
    if not CharacterFrame:IsShown() then
        DevolverPaginas()              -- ventana cerrada: todo como estaba para la proxima vez
    elseif not porIrse then
        -- quitada por un enganche de Blizzard: si en un momento no ha quedado ninguna pagina a la vista, se devuelven
        if C_Timer and C_Timer.After then
            C_Timer.After(0.2, function()
                if not (panel and panel:IsShown()) and CharacterFrame:IsShown() and not HayPaginaVisible() then DevolverPaginas() end
            end)
        elseif not HayPaginaVisible() then DevolverPaginas() end
    else
        ocultas = {}
    end
    -- pestañas: fuera la nuestra; la que toca, la de la pagina activa si es la que se ve, o la ultima pulsada
    if raton.sobre then ultimaPestana, ultimaPestanaEn, raton.sobre = raton.sobre, GetTime(), nil end
    if tab then Check(tab, false) end
    local activa = type(CharacterFrame.activeSubframe) == "string" and _G[CharacterFrame.activeSubframe]
    if type(activa) == "table" and activa.IsShown and activa:IsShown() then
        MarkTabs(false)
    elseif ultimaPestana and GetTime() - ultimaPestanaEn < 2 then
        for _, t in ipairs(AllBlizzTabs()) do Check(t, t == ultimaPestana) end
    end
    -- titulo y retrato: si se ve una pagina de Blizzard, los pone Blizzard; si otra pagina (Overlord de Forever) ya
    -- puso los suyos, no se tocan; si nadie ha cambiado nada (Overlord no hizo nada), se deja lo de antes de abrir
    local tt, tex = TitleFS(), PortraitTex()
    local tituloAhora = tt and tt:GetText()
    local retratoAhora = tex and tex.GetTexture and tex:GetTexture()
    if type(activa) == "table" and activa.IsShown and activa:IsShown() then
        SetTitle(nil); SetPortrait(false)
    elseif tituloAhora == puesto.titulo and retratoAhora == puesto.retrato then
        if tt and antes.titulo then tt:SetText(antes.titulo) else SetTitle(nil) end
        if tex and antes.retrato then tex:SetTexture(antes.retrato) else SetPortrait(false) end
        -- y si a los 0,2 s se devuelve una pagina de Blizzard, que lo ponga Blizzard
        if C_Timer and C_Timer.After then
            C_Timer.After(0.25, function()
                if panel and panel:IsShown() then return end
                local a = type(CharacterFrame.activeSubframe) == "string" and _G[CharacterFrame.activeSubframe]
                if type(a) == "table" and a.IsShown and a:IsShown() then SetTitle(nil); SetPortrait(false) end
            end)
        end
    end
end

local function ShowPanel()
    if not Wanted() then return end
    if not panel then BuildPanel() end
    activaAlAbrir = CharacterFrame.activeSubframe
    GuardarAntes()
    OcultarPaginas()
    abiertoEn = GetTime()
    VigilarTodo()
    panel:Show()
    MarkTabs(true)
    SetTitle("Venganza")
    SetPortrait(true)
    ApuntarPuesto()
    Refresh()
    if C_Timer and C_Timer.After then
        C_Timer.After(0, function() if panel:IsShown() then MarkTabs(true); SetTitle("Venganza"); SetPortrait(true); ApuntarPuesto() end end)
    end
end

-- La pestaña va debajo de la ULTIMA pestaña de Blizzard que se ve (normalmente la de Overlord), nunca encima de una.
-- Blizzard enseña la de Overlord tarde (al cargar su ventana) y no siempre recoloca: por eso se mira la que queda mas
-- abajo en pantalla, y se vuelve a colocar cada vez que una pestaña aparece o desaparece y al abrir la ventana.
-- Todas las pestañas de Blizzard que se ven: las de la lista (en su orden, que es el que usa UpdateTabLayout) y,
-- por si alguna version del juego cuelga la de Overlord u otra fuera de la lista, los demas hijos del contenedor.
local function ShownBlizzTabs()
    local list, seen = {}, {}
    local function add(t)
        if t and t ~= tab and not seen[t] then
            seen[t] = true
            local n = t.GetNumPoints and t:GetNumPoints()   -- sin anclas no se dibuja: no cuenta
            if t.IsShown and t:IsShown() and (type(n) ~= "number" or n > 0) then list[#list + 1] = t end
        end
    end
    for _, t in ipairs(BlizzTabs() or {}) do add(t) end
    local parent = CharacterFrame and CharacterFrame.ModeTabs
    if parent and parent.GetChildren then
        for _, t in ipairs({ parent:GetChildren() }) do add(t) end
    end
    return list
end

local function LastBlizzTab()
    local list = ShownBlizzTabs()
    -- 1) como Blizzard: cada pestaña va debajo de la anterior que se ve, asi que la ultima de la lista es la de abajo
    local last = list[#list]
    -- 2) si ya tienen posicion en pantalla, manda la que de verdad queda mas abajo (nunca tapar ninguna)
    local lowB = last and last.GetBottom and last:GetBottom()
    for _, t in ipairs(list) do
        local b = t.GetBottom and t:GetBottom()
        if b and (not lowB or b < lowB - 1) then last, lowB = t, b end
    end
    return last
end

local function PlaceTab()
    if not tab then return end
    local last = LastBlizzTab()
    tab:ClearAllPoints()
    if last then tab:SetPoint("TOPLEFT", last, "BOTTOMLEFT", 0, -2)
    else tab:SetPoint("TOPLEFT", CharacterFrame, "TOPRIGHT", 0, -30) end
end

local function PlaceTabSoon()
    PlaceTab()
    if C_Timer and C_Timer.After then   -- y otra vez cuando Blizzard ya ha colocado las suyas
        C_Timer.After(0, PlaceTab)
        C_Timer.After(0.3, PlaceTab)
    end
end

local hooked = false
local function Build()
    if tab or not (CharacterFrame and BlizzTabs() and CharacterFrameLeftPaneHost and CharacterFrameRightPaneHost) then return end
    local parent = CharacterFrame.ModeTabs
    local ok, t = pcall(CreateFrame, "Frame", "CMVenganzaPjTab", parent, "CharacterFrameModeSideTabTemplate")
    if not ok or not t then
        ok, t = pcall(CreateFrame, "Frame", "CMVenganzaPjTab", parent, "LargeSideTabButtonTemplate")
    end
    if not ok or not t then return end
    tab = t
    tab.tooltipText = "Lista de venganza"
    tab.frameName = nil
    if type(tab.Icon) == "table" then
        tab.Icon:SetTexture(ICONO)
        if tab.UpdateIconInterior then pcall(tab.UpdateIconInterior, tab) end
    end
    -- la plantilla de Blizzard llama a CharacterFrame:OnModeTabClicked; la nuestra abre el panel
    local function OnUp(_, button, upInside)
        if button == "LeftButton" and upInside then
            if panel and panel:IsShown() then return end
            ShowPanel()
        end
    end
    if tab.SetCustomOnMouseUpHandler then tab:SetCustomOnMouseUpHandler(OnUp) end
    tab.customMouseUpHandler = OnUp
    if not tab.SetCustomOnMouseUpHandler then tab:SetScript("OnMouseUp", function(self, b) OnUp(self, b, true) end) end
    Check(tab, false)   -- nace con el brillo de «elegida» puesto
    pcall(PlaceTab)     -- si colocarla fallara, que no deje sin poner los enganches de abajo

    if not hooked then
        hooked = true
        local function H(t, k, fn) if type(t) == "table" and type(t[k]) == "function" then pcall(hooksecurefunc, t, k, fn) end end
        -- otra pestaña, o un atajo (C, U...) que cambia de pagina: fuera nuestro panel
        H(CharacterFrame, "OnModeTabClicked", function() HidePanel() end)
        H(CharacterFrame, "ShowSubFrame", function() HidePanel() end)
        -- al plegar/desplegar la mitad derecha Blizzard repinta y marca su pestaña: se vuelve a marcar la nuestra
        H(CharacterFrame, "RefreshDisplay", function()
            if panel and panel:IsShown() then MarkTabs(true); SetTitle("Venganza"); SetPortrait(true); ApuntarPuesto(); Refresh() end
        end)
        H(CharacterFrame, "UpdateTabLayout", PlaceTabSoon)
        H(_G, "ToggleCharacter", function() HidePanel() end)
        local vigiladas = {}
        local function Vigilar(t)
            if t and t ~= tab and not vigiladas[t] and t.HookScript then
                vigiladas[t] = true
                pcall(t.HookScript, t, "OnShow", PlaceTabSoon)
                pcall(t.HookScript, t, "OnHide", PlaceTabSoon)
                -- por si en esta version la pestaña no pasa por OnModeTabClicked/ShowSubFrame
                pcall(t.HookScript, t, "OnMouseUp", function(_, button) if button == "LeftButton" then HidePanel() end end)
            end
        end
        local function VigilarTodas()
            for _, t in ipairs(BlizzTabs() or {}) do Vigilar(t) end
            local parent = CharacterFrame.ModeTabs
            if parent and parent.GetChildren then for _, t in ipairs({ parent:GetChildren() }) do Vigilar(t) end end
        end
        pcall(VigilarTodas)
        pcall(CharacterFrame.HookScript, CharacterFrame, "OnShow", function()
            pcall(VigilarTodas)   -- por si alguna pestaña se ha creado despues
            PlaceTabSoon()
            if tab then
                tab:SetShown(Wanted() and true or false)
                if not (panel and panel:IsShown()) then Check(tab, false) end
            end
        end)
        pcall(CharacterFrame.HookScript, CharacterFrame, "OnHide", function() HidePanel() end)
    end
end

-- Lo llaman la opcion de la configuracion y el modulo al activarse/desactivarse.
function E.CharTabUpdate()
    if Wanted() then
        Build()
        if tab then tab:Show(); PlaceTabSoon() end
    else
        HidePanel()
        if tab then tab:Hide() end
    end
end
E.CharTabRefresh = function() Refresh() end
E.CharTabShow = function() Build(); ShowPanel() end   -- para las pruebas y /pvpo venganza pj

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function() E.CharTabUpdate() end)
