-- Modulo "Enemigos cercanos" (PvPOutdoor) para WoW Forever (cliente moderno, Interface 16001)
-- 1) Alerta de enemigos cercanos  2) Habilidades clave del enemigo
-- 3) Alerta de casteos peligrosos 4) Registro de muertes + marcas en el mapa
--
-- El cliente de Forever restringe el registro de combate y muchos datos de unidades
-- ("valores secretos"), asi que NO se usa COMBAT_LOG_EVENT_UNFILTERED: los enemigos se
-- detectan por placas de nombre (nameplates), objetivo, foco y mouseover.
-- Activa las placas de enemigos (Mayus+V) para ver a todos los cercanos.

local ADDON, ns = ...
local Hub = ns.Hub
local Espia = ns.PO_Espia
local issecret = issecretvalue or function() return false end

local mod            -- se asigna en Register
local DB             -- = mod.db
local unlocked = false

local DEFAULTS = {
    outdoorOnly = true,   -- no actuar en instancias / BG / arenas
    sound = true,         -- interruptor general de sonidos
    enemyTTL = 90,        -- seg. sin ver a un enemigo antes de quitarlo de la lista
    activeTTL = 20,       -- seg. sin verlo a partir de los que sale en gris («hace X s»)
    dangerLevelDiff = 10, -- alerta si el enemigo es >= nivel propio + esto (o ??)
    groupSize = 3,        -- alerta de grupo a partir de N enemigos
    longCast = 2.5,       -- casteos >= esto (seg) se muestran aunque no sean peligrosos
    show = { enemies = true, cds = true, casts = true, map = true },
    alerts = { group = true, danger = true, new = true, cast = true, attack = true, behind = true },  -- sonido de cada aviso
    radar = { on = true, radius = 190, all = false, max = 8, scale = 100 },  -- flechas hacia los enemigos que no ves
    behindAlert = true,   -- aviso «¡Enemigo a tu espalda!» si aparece uno detras de la camara
    behindRepeat = 30,    -- seg. minimos entre avisos de espalda del mismo enemigo
    attackAlert = true,   -- aviso «¡X te ataca!» cuando un enemigo te tiene de objetivo y estas en combate
    attackRepeat = 20,    -- seg. minimos entre avisos de ataque del mismo enemigo
    deathHint = true,     -- si te matan sin ver a nadie y tienes las placas apagadas, decirlo en el chat
    alertText = true,     -- mensaje grande en pantalla
    alertSeconds = 3,     -- duracion del mensaje grande
    groupCooldown = 15,   -- seg. minimos entre avisos de grupo
    listMax = 10,         -- filas de la lista de enemigos (1-15)
    cdMax = 10,           -- iconos de habilidades a la vez (3-10)
    cdLow = 20, cdHigh = 80,  -- % de tiempo restante: verde por debajo / rojo por encima
    castWidth = 260,      -- ancho de las barras de casteo
    bgAlpha = 45,         -- opacidad (%) del fondo de la lista al mover/mostrar
    scale = { list = 100, cds = 100, casts = 100, alert = 100 },  -- escala (%) de cada marco
    deathMax = 50,        -- muertes guardadas
    pos = {},
    deaths = {},
    view = "near",        -- lista mostrada: near / hour / kos / ignore / zones
    -- de donde salen los enemigos (ademas de placas, objetivo, foco y raton)
    sources = {
        soft = true,      -- objetivo suave (el enemigo que el juego resalta delante de ti)
        chain = true,     -- el objetivo de tu objetivo, de tu foco, del raton y de cada placa
        group = true,     -- los objetivos de tus companeros de grupo / banda
        chat = true,      -- enemigos que hacen un emote o hablan (/decir, /gritar) cerca de ti
        dmeter = true,    -- medidor de daño del juego (C_DamageMeter): quien te pega aunque no lo veas (clase siempre; nombre al acabar)
        vignette = true,  -- marcas del mapa de jugadores con recompensa JcJ (C_VignetteInfo, tipo PvPBounty)
        recap = true,     -- al morir, el resumen de muerte del juego dice quien te ha pegado (aunque no lo vieras)
        plates = false,   -- encender las placas de nombre de los enemigos (sin ellas solo se ve lo que tocas)
        farPlates = true, -- subir la distancia de las placas al maximo que deje el juego (nameplateMaxDistance), como ISpy Forever
        softRange = false,-- objetivo suave de enemigos siempre y a 45 m (SoftTargetEnemy 3, SoftTargetEnemyRange 45), como Forever Alert
        offscreen = true, -- placas tambien fuera de pantalla (CVar nameplateShowOffscreen): ve a los que vienen por la espalda o desde arriba
    },
    -- pausa en sitios neutrales
    neutralPause = true,  -- no avisar en los pueblos neutrales de la lista
    neutralMode = "silencio", -- en esos sitios: "silencio" = sigue detectando sin avisos (salvo si te atacan) / "apagado" = no hace nada
    sanctuaryPause = true,-- ni en zonas santuario
    neutralZones = "Bahía del Botín;Trinquete;Gadgetzan;Vista Eterna;Capilla de la Esperanza de la Luz;" ..
        "Fuerte Cenarion;Claro de la Luna;Bastión Fauces de Madera;Feria de la Luna Negra;" ..
        "Booty Bay;Ratchet;Everlook;Light's Hope Chapel;Cenarion Hold;Moonglade;Timbermaw Hold;Darkmoon Faire",
    -- marca encima de la placa de nombre
    plate = { on = true, kos = true, targeting = true, all = false, size = 26, y = 6,
              kosIcon = 8, targetIcon = 7, allIcon = 2 },
    -- ping de Blizzard sobre un enemigo (clic central en la fila, o /click CMPvPOutdoorPing)
    ping = { on = true, kind = "WARNING", restore = true, button = true },
    spy = Espia.DEFAULTS, -- ajustes estilo Spy (Espia.lua)
}

----------------------------------------------------------------------
-- Utilidades
----------------------------------------------------------------------
local function Print(msg) if mod then mod:Print(msg) end end

local function Clean(v)
    if issecret(v) then return nil end
    return v
end

-- Pausa en pueblos neutrales / santuarios: se calcula al cambiar de zona (y cada pocos segundos).
local neutralHere = false
local function ZoneList()
    local t = {}
    for z in string.gmatch((DB and DB.neutralZones) or "", "[^;]+") do
        z = z:gsub("^%s+", ""):gsub("%s+$", "")
        if z ~= "" then t[strlower(z)] = true end
    end
    return t
end
local function EvalZone()
    neutralHere = false
    if not DB then return end
    if DB.sanctuaryPause then
        local f = (C_PvP and C_PvP.GetZonePVPInfo) or GetZonePVPInfo
        local ok, kind = pcall(f or function() end)
        if ok and kind == "sanctuary" then neutralHere = true; return end
    end
    if DB.neutralPause then
        local list = ZoneList()
        for _, fn in ipairs({ GetSubZoneText, GetRealZoneText, GetMinimapZoneText }) do
            local ok, z = pcall(fn or function() end)
            if ok and type(z) == "string" and not issecret(z) and z ~= "" and list[strlower(z)] then
                neutralHere = true; return
            end
        end
    end
end

local function Active()
    if not DB or not mod or not mod.enabled then return false end
    if DB.outdoorOnly then
        local ok, inInstance = pcall(IsInInstance)
        if ok and inInstance then return false end
    end
    if neutralHere and DB.neutralMode == "apagado" then return false end
    return true
end
-- En pueblo neutral / santuario en modo silencio: se detecta y se lista, pero sin avisos de enemigo nuevo,
-- grupo ni peligro (solo KOS, venganza y «te ataca»).
local function Quiet() return neutralHere and DB and DB.neutralMode ~= "apagado" end

-- Facción por raza (para los enemigos que solo se conocen por su GUID).
local RACE_FACTION = {
    Human = "Alliance", Dwarf = "Alliance", NightElf = "Alliance", Gnome = "Alliance", Draenei = "Alliance",
    Worgen = "Alliance", Orc = "Horde", Scourge = "Horde", Tauren = "Horde", Troll = "Horde",
    BloodElf = "Horde", Goblin = "Horde",
}
-- true / false, o nil si el juego lo oculta (valor secreto) o falla.
local function Bool(f, ...)
    if not f then return nil end
    local ok, v = pcall(f, ...)
    if not ok or issecret(v) then return nil end
    return v and true or false
end
local function GuidIsEnemy(guid)
    if not GetPlayerInfoByGUID then return false end
    local ok, _, _, _, engRace = pcall(GetPlayerInfoByGUID, guid)
    if not ok or issecret(engRace) or not engRace then return false end
    local okf, mine = pcall(UnitFactionGroup, "player")
    local theirs = RACE_FACTION[engRace]
    return okf and theirs ~= nil and mine ~= nil and not issecret(mine) and theirs ~= mine or false
end
-- Devuelve si es un jugador enemigo y, si no se ha podido saber, el motivo ("oculto": el juego lo esconde).
local function IsEnemyPlayer(unit)
    if Bool(UnitExists, unit) == false then return false end
    local player = Bool(UnitIsPlayer, unit)
    if player == false then return false end
    local enemy = Bool(UnitIsEnemy, "player", unit)
    if player and enemy ~= nil then return enemy end
    -- El juego oculta algo (en combate o en ciertas zonas): se mira por el GUID y la raza...
    local ok, guid = pcall(UnitGUID, unit)
    guid = ok and Clean(guid)
    local isPlayerGuid = type(guid) == "string" and guid:find("^Player%-") ~= nil
    if type(guid) == "string" and not isPlayerGuid then return false end
    if isPlayerGuid and GuidIsEnemy(guid) then return true end
    if player or isPlayerGuid then
        -- ...y si eso tampoco, por su faccion o porque se le puede atacar.
        local okf, theirs = pcall(UnitFactionGroup, unit)
        local okm, mine = pcall(UnitFactionGroup, "player")
        if okf and okm and theirs and mine and not issecret(theirs) and not issecret(mine)
           and (theirs == "Alliance" or theirs == "Horde") then
            return theirs ~= mine
        end
        local atk = Bool(UnitCanAttack, "player", unit)
        if atk ~= nil then return atk end
        if isPlayerGuid and enemy == false then return false end
    end
    return false, "oculto"
end

local function InCombat()
    local ok, c = pcall(UnitAffectingCombat, "player")
    return ok and not issecret(c) and c or false
end

local function TargetsMe(unit)
    local ok, res = pcall(function()
        if UnitIsUnit(unit .. "target", "player") then return true end
        return false
    end)
    return ok and res
end

local function ClassColor(class)
    local c = class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]
    if c then return string.format("|cff%02x%02x%02x", c.r * 255, c.g * 255, c.b * 255) end
    return "|cffffffff"
end

local function FormatTime(t)
    if t >= 60 then return math.floor(t / 60) .. ":" .. string.format("%02d", math.floor(t % 60))
    elseif t >= 10 then return tostring(math.floor(t + 0.5))
    else return string.format("%.1f", t) end
end

local function SpellName(id)
    if C_Spell and C_Spell.GetSpellName then return C_Spell.GetSpellName(id) end
    return nil
end

local function SpellInfo(id)
    if C_Spell and C_Spell.GetSpellInfo then
        local info = C_Spell.GetSpellInfo(id)
        if info then return info.name, info.iconID end
    end
    return nil
end

-- kit = nombre en SOUNDKIT; flag = clave de DB.alerts que lo controla
local function Sound(kit, flag)
    if not DB or not DB.sound then return end
    if flag and DB.alerts[flag] == false then return end
    if SOUNDKIT and SOUNDKIT[kit] then PlaySound(SOUNDKIT[kit]) end
end

----------------------------------------------------------------------
-- Marcos
----------------------------------------------------------------------
local MAX_ROWS, MAX_ICONS = 15, 10
local listFrame, cdFrame, alertFrame
local castBars = {}
local movables = {}
local enemies, cds = {}, {}
local lastGroupAlert, lastNewSound = 0, 0
local lastTargeter, lastInCombat
local lastAttackAlert = 0
local closedUntilNew = false
local pins = {}
local keyCD, keyIcon, dangerSpells = {}, {}, {}

local PlaceRowsRef   -- se asigna mas abajo (PlaceRows)

local function Alert(text, r, g, b, sub)
    if not DB or not DB.alertText or not alertFrame then return end
    alertFrame.text:SetText(text)
    -- sub puede ser un valor secreto (nombre oculto en combate): se puede ENSEÑAR aunque el addon no pueda leerlo
    if alertFrame.sub then
        if not pcall(alertFrame.sub.SetText, alertFrame.sub, sub or "") then alertFrame.sub:SetText("") end
    end
    alertFrame.text:SetTextColor(r or 1, g or 0.2, b or 0.2)
    alertFrame.t = 0
    alertFrame:SetAlpha(1)
    alertFrame:Show()
end

local function MakeMovable(f, key, point, x, y)
    f.key, f.defPoint, f.defX, f.defY = key, point, x, y
    f:SetMovable(true)
    f:SetClampedToScreen(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function(self) if unlocked then self:StartMoving() end end)
    f:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local p, _, rp, px, py = self:GetPoint()
        DB.pos[self.key] = { p, rp, px, py }
        if self.topLeft and self:GetLeft() and self:GetTop() then
            local l, t = self:GetLeft(), self:GetTop()
            self:ClearAllPoints()
            self:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", l, t)
            DB.pos[self.key] = { "TOPLEFT", "BOTTOMLEFT", l, t }
        end
    end)
    f.bg = f:CreateTexture(nil, "BACKGROUND")
    f.bg:SetAllPoints(f)
    f.bg:SetColorTexture(0, 0, 0, 0.45)
    f.bg:Hide()
    movables[#movables + 1] = f
end

local function ApplyPos(f)
    f.tlDone = false
    f:ClearAllPoints()
    local p = DB.pos[f.key]
    if p then f:SetPoint(p[1], UIParent, p[2], p[3], p[4])
    else f:SetPoint(f.defPoint, UIParent, f.defPoint, f.defX, f.defY) end
end

local function ApplyLayout()
    if not DB or not listFrame then return end
    local s = DB.scale
    listFrame:SetScale((s.list or 100) / 100)
    cdFrame:SetScale((s.cds or 100) / 100)
    alertFrame:SetScale((s.alert or 100) / 100)
    local a = (DB.bgAlpha or 45) / 100
    for _, f in ipairs(movables) do
        f.bg:SetColorTexture(0, 0, 0, a)
    end
    for _, bar in ipairs(castBars) do
        bar:SetScale((s.casts or 100) / 100)
        bar:SetWidth(DB.castWidth or 260)
    end
    cdFrame:SetWidth(math.max(1, DB.cdMax) * 38)
    if PlaceRowsRef then PlaceRowsRef() end
end

----------------------------------------------------------------------
-- 1) ENEMIGOS CERCANOS
----------------------------------------------------------------------
local function CountEnemies()
    local n = 0
    for _ in pairs(enemies) do n = n + 1 end
    return n
end

local function IsDangerLevel(level)
    if not level then return false end
    if level == -1 then return true end
    local mine = Clean(UnitLevel("player"))
    return mine and level >= mine + DB.dangerLevelDiff or false
end

local function CheckGroupAlert()
    local n = CountEnemies()
    local now = GetTime()
    if n >= DB.groupSize and now - lastGroupAlert > DB.groupCooldown then
        lastGroupAlert = now
        Alert("¡GRUPO ENEMIGO CERCA (" .. n .. ")!", 1, 0.5, 0)
        Sound("RAID_WARNING", "group")
    end
end

local UpdatePlateMark, HidePlateMark   -- marca sobre la placa (se definen mas abajo)

-- Parte comun a todas las fuentes: avisos de nuevo enemigo, KOS, ignorados y peligro.
local function AfterDetect(e, isNew, now, targetsMe)
    e.ignored = Espia.OnDetected(e, isNew)
    if e.ignored then return end
    -- Te ataca (te tiene de objetivo y estas en combate): siempre, tambien en pueblos neutrales.
    if targetsMe and DB.attackAlert and InCombat() and (not e.attackWarned or now - e.attackWarned > (DB.attackRepeat or 20)) then
        e.attackWarned = now
        lastAttackAlert = now
        local n = 0
        for _, x in pairs(enemies) do if x.attackWarned and now - x.attackWarned < 10 then n = n + 1 end end
        local lv = e.level and (" " .. ((e.level == -1) and "??" or e.level)) or ""
        Alert(n > 1 and ("¡" .. n .. " ENEMIGOS TE ATACAN!") or ("¡" .. e.name .. " (" .. (e.loc or "?") .. lv .. ") TE ATACA!"), 1, 0, 0)
        Sound("RAID_WARNING", "attack")
    end
    -- compartir con grupo/hermandad (con mi posicion); de nuevo si sigue aqui tras un rato o si empieza a atacarme
    if e.full and not e.remote and Espia.ShareAll then
        local rep = (DB.spy and DB.spy.shareAllRepeat) or 60
        if isNew or not e.sharedAt or now - e.sharedAt > rep or (targetsMe and not e.sharedAtk) then
            if Espia.ShareAll(e, targetsMe) then e.sharedAt = now; e.sharedAtk = targetsMe or e.sharedAtk end
        end
    end
    if Quiet() then return end
    if isNew then
        if closedUntilNew then closedUntilNew = false end
        if DB.spy.autoNear and DB.view ~= "near" then DB.view = "near" end
        if now - lastNewSound > 3 then
            lastNewSound = now
            Sound("IG_PVP_UPDATE", "new")
        end
        CheckGroupAlert()
    end
    if e.level and not e.warned and IsDangerLevel(e.level) then
        e.warned = true
        local lv = (e.level == -1) and "??" or e.level
        Alert("¡PELIGRO! " .. e.name .. " (" .. (e.loc or "?") .. " " .. lv .. ")", 1, 0, 0)
        Sound("RAID_WARNING", "danger")
    end
end

-- Enemigos nuevos detectados en esta sesión por cada fuente (para /pvpo diagnostico).
local bySource = {}
local function SourceOf(unit)
    if unit:find("^nameplate%d+$") then return "placas" end
    if unit:find("target$") and unit ~= "target" then return (unit:find("^party") or unit:find("^raid")) and "grupo" or "cadena" end
    return ({ target = "objetivo", focus = "foco", mouseover = "raton", softenemy = "suave" })[unit] or unit
end

local BehindCameraRef   -- se asigna mas abajo
local hidden = { n = 0, last = 0 }   -- jugadores que el juego no deja saber si son enemigos (para el diagnostico)
local function ScanUnit(unit)
    if not DB or not DB.show.enemies or not Active() then return end
    local isEnemy, why = IsEnemyPlayer(unit)
    if not isEnemy and why == "oculto" and unit:find("^nameplate%d+$") then
        hidden.n = hidden.n + 1; hidden.last = GetTime()
    end
    if not isEnemy then
        if HidePlateMark and unit:find("^nameplate%d+$") then HidePlateMark(unit) end
        return
    end
    local now = GetTime()
    local guid = Clean(UnitGUID(unit))
    local key = guid or unit
    local full = Espia.UnitFullName(unit)
    local name = full or "Jugador"
    local e = enemies[key]
    local isNew = false
    if not e and guid and full then
        -- ya estaba por otra fuente sin unidad (registro de combate, chat): se junta
        for k, x in pairs(enemies) do if x.full == full then e = x; enemies[k] = nil; enemies[key] = x; break end end
    end
    if not e then
        isNew = true
        e = { name = name, first = now }
        enemies[key] = e
        local src = SourceOf(unit)
        bySource[src] = (bySource[src] or 0) + 1
    end
    e.seen = now
    e.remote = nil
    e.name = name
    e.full = full
    local loc, eng = UnitClass(unit)
    loc, eng = Clean(loc), Clean(eng)
    if eng then e.loc, e.class = loc, eng end
    local lvl = Clean(UnitLevel(unit))
    if lvl then e.level = lvl end
    local targetsMe = TargetsMe(unit)
    if targetsMe then lastTargeter = { e = e, t = now } end
    if InCombat() then lastInCombat = { e = e, t = now } end
    if full and (targetsMe or ((unit == "target" or unit == "focus") and InCombat())) then Espia.Engage(full) end
    if e.seenRecord == nil or isNew or now - e.seenRecord > 5 then
        e.seenRecord = now
        Espia.Record(e, unit, isNew)
    end
    Espia.CheckDead(e, unit)
    AfterDetect(e, isNew, now, targetsMe)
    if DB.behindAlert and not e.ignored and BehindCameraRef and BehindCameraRef(unit)
       and (not e.behindWarned or now - e.behindWarned > (DB.behindRepeat or 30)) then
        e.behindWarned = now
        local lv = e.level and (" " .. ((e.level == -1) and "??" or e.level)) or ""
        Alert("¡ENEMIGO A TU ESPALDA! " .. e.name .. " (" .. (e.loc or "?") .. lv .. ")", 1, 0.3, 0)
        Sound("RAID_WARNING", "behind")
    end
    if UpdatePlateMark and unit:find("^nameplate%d+$") then UpdatePlateMark(unit, e, targetsMe) end
end

-- Enemigo detectado sin unidad (emote o /decir cerca): GUID -> GetPlayerInfoByGUID.
local function ScanGUID(guid, author, src)
    src = src or "chat"
    if not DB or not DB.show.enemies or not DB.sources[src] or not Active() then return end
    if type(guid) ~= "string" or issecret(guid) or not guid:find("^Player%-") then return end
    local me = Clean(UnitGUID("player"))
    if me and guid == me then return end
    if not GetPlayerInfoByGUID then return end
    local ok, locClass, engClass, locRace, engRace, _, pname, prealm = pcall(GetPlayerInfoByGUID, guid)
    if not ok or issecret(engRace) or not engRace then return end
    local okf, myFaction = pcall(UnitFactionGroup, "player")
    local theirs = RACE_FACTION[engRace]
    if not (okf and theirs and myFaction) or issecret(myFaction) or theirs == myFaction then return end
    local full
    if type(pname) == "string" and not issecret(pname) and pname ~= "" then
        full = pname
        -- en Forever el 2o valor puede ser el apellido; si es otro reino se ignora (se guarda el nombre)
        if type(prealm) == "string" and not issecret(prealm) and prealm ~= "" and Hub.UnitFullName and
           Constants and Constants.CharacterNameSeparatorConsts and not pname:find(prealm, 1, true) then
            full = pname .. (Constants.CharacterNameSeparatorConsts.CHARACTERNAME_SURNAME_SEPARATOR or " ") .. prealm
        end
    elseif type(author) == "string" and not issecret(author) and author ~= "" then
        full = Hub.ShortName(author)
    end
    full = full and Espia.SafeName(full)
    local now = GetTime()
    local e = enemies[guid]
    if not e and full then
        for _, x in pairs(enemies) do if x.full == full then e = x; break end end
    end
    local isNew = not e
    if not e then
        e = { name = full or "Jugador", first = now }; enemies[guid] = e
        bySource[src] = (bySource[src] or 0) + 1
    end
    e.seen, e.name, e.full = now, full or e.name, full or e.full
    if not issecret(engClass) and engClass then e.class, e.loc = engClass, Clean(locClass) end
    if not issecret(locRace) and locRace then e.race = locRace end
    if src == "chat" then e.byChat = true else e.byLog = true end
    if e.seenRecord == nil or isNew or now - e.seenRecord > 5 then
        e.seenRecord = now
        Espia.Record(e, nil, isNew)
    end
    AfterDetect(e, isNew, now)
end

----------------------------------------------------------------------
-- Fuente: medidor de daño del juego (Blizzard_DamageMeter / C_DamageMeter)
-- «Daño recibido» trae, por cada golpe, quien te lo dio: su clase (unitClassFilename, NUNCA secreta, ni en
-- combate) y su nombre (secreto en combate: se ve en el aviso, pero no se puede leer). Al acabar el combate
-- todo es legible y «Daño a enemigos» da GUID y faccion de los jugadores que has golpeado.
----------------------------------------------------------------------
local dmWarned = {}
local function ClassName(cls)
    return (LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[cls]) or cls
end
local function ReadDamageTaken()
    if not (DB and DB.sources.dmeter and Active() and C_DamageMeter and Enum and Enum.DamageMeterType and Enum.DamageMeterSessionType) then return end
    local me = Clean(UnitGUID("player"))
    if not me then return end
    local ok, src = pcall(C_DamageMeter.GetCombatSessionSourceFromType, Enum.DamageMeterSessionType.Current, Enum.DamageMeterType.DamageTaken, me)
    if not ok or type(src) ~= "table" or issecret(src) or type(src.combatSpells) ~= "table" then return end
    local now = GetTime()
    for _, sp in ipairs(src.combatSpells) do
        local d = type(sp) == "table" and sp.combatSpellDetails
        if type(d) == "table" then
            local cls = d.unitClassFilename
            local mob, pet = d.isMob, d.isPet
            -- los bichos no tienen clase ("" en el medidor de Blizzard)
            if type(cls) == "string" and not issecret(cls) and cls ~= "" and not (mob == true and not issecret(mob)) and not (pet == true and not issecret(pet)) then
                local name = d.unitName
                local readable = type(name) == "string" and not issecret(name) and name ~= ""
                local key = readable and name or ("?" .. cls)
                if readable then
                    for _, x in pairs(enemies) do if x.full == name or x.name == name then x.seen = now end end
                end
                if DB.attackAlert and now - lastAttackAlert > 3 and (not dmWarned[key] or now - dmWarned[key] > (DB.attackRepeat or 20)) then
                    dmWarned[key] = now
                    Alert("¡Te pega un " .. ClassName(cls) .. " que no ves!", 1, 0.1, 0.1, name)
                    Sound("RAID_WARNING", "attack")
                end
            end
        end
    end
end
-- Al acabar el combate: los jugadores enemigos que has golpeado (GUID y faccion legibles) a la lista y las fichas.
local function ReadEnemyDamage()
    if not (DB and DB.sources.dmeter and Active() and C_DamageMeter and Enum and Enum.DamageMeterType) then return end
    local ok, sess = pcall(C_DamageMeter.GetCombatSessionFromType, Enum.DamageMeterSessionType.Current, Enum.DamageMeterType.EnemyDamageTaken)
    if not ok or type(sess) ~= "table" or type(sess.combatSources) ~= "table" then return end
    for _, cs in ipairs(sess.combatSources) do
        local guid = type(cs) == "table" and Clean(cs.sourceGUID)
        if type(guid) == "string" and guid:find("^Player%-") then ScanGUID(guid, Clean(cs.name), "dmeter") end
    end
end

----------------------------------------------------------------------
-- Fuente: marcas del mapa (vignettes) de jugadores con recompensa JcJ: se ven desde lejos, en todo el mapa.
----------------------------------------------------------------------
local vigSeen = {}
local function ScanVignettes()
    if not (DB and DB.sources.vignette and Active() and C_VignetteInfo and C_VignetteInfo.GetVignettes) then return end
    local ok, list = pcall(C_VignetteInfo.GetVignettes)
    if not ok or type(list) ~= "table" then return end
    local bounty = Enum and Enum.VignetteType and Enum.VignetteType.PvPBounty
    for _, vg in ipairs(list) do
        local oki, info = pcall(C_VignetteInfo.GetVignetteInfo, vg)
        local og = oki and type(info) == "table" and Clean(info.objectGUID)
        if type(og) == "string" and og:find("^Player%-") and og ~= Clean(UnitGUID("player")) then
            local before = enemies[og]
            ScanGUID(og, Clean(info.name), "vignette")
            if enemies[og] and not before and not vigSeen[og] then
                vigSeen[og] = true
                local isBounty = bounty and info.type == bounty
                Alert((isBounty and "Recompensa JcJ: " or "En el mapa: ") .. (enemies[og].name or "?"), 1, 0.6, 0)
                Sound("RAID_WARNING", "new")
            end
        end
    end
end

local function WantPlates()
    if not DB or (InCombatLockdown and InCombatLockdown()) then return end
    local get = (C_CVar and C_CVar.GetCVar) or GetCVar
    local set = (C_CVar and C_CVar.SetCVar) or SetCVar
    if not set then return end
    if DB.sources.plates then
        local ok, v = pcall(get, "nameplateShowEnemies")
        if ok and v ~= "1" then pcall(set, "nameplateShowEnemies", "1") end
    end
    -- Cambia una opcion del juego guardando la tuya para dejarla como estaba al desactivarlo.
    DB._cvarPrev = DB._cvarPrev or {}
    local function Want(on, cvar, value, better)
        local okc, cur = pcall(get, cvar)
        if not okc or cur == nil or issecret(cur) then return end
        if on then
            if better(cur) then
                if DB._cvarPrev[cvar] == nil then DB._cvarPrev[cvar] = cur end
                pcall(set, cvar, value)
            end
        elseif DB._cvarPrev[cvar] ~= nil then
            pcall(set, cvar, DB._cvarPrev[cvar]); DB._cvarPrev[cvar] = nil
        end
    end
    Want(DB.sources.farPlates, "nameplateMaxDistance", "60", function(c) return (tonumber(c) or 60) < 60 end)
    Want(DB.sources.softRange, "SoftTargetEnemy", "3", function(c) return c ~= "3" end)
    Want(DB.sources.softRange, "SoftTargetEnemyRange", "45", function(c) return (tonumber(c) or 45) < 45 end)
    -- Sin esto el juego solo da placa a lo que la camara tiene delante: lo que viene por detras o desde arriba no existe.
    local ok, v = pcall(get, "nameplateShowOffscreen")
    if ok and v ~= nil then
        if DB.sources.offscreen and v ~= "1" then
            DB._offscreenPrev = v
            pcall(set, "nameplateShowOffscreen", "1")
        elseif not DB.sources.offscreen and DB._offscreenPrev ~= nil and v == "1" then
            pcall(set, "nameplateShowOffscreen", DB._offscreenPrev)   -- se deja como lo tenias
            DB._offscreenPrev = nil
        end
    end
end

-- (BehindCameraRef se asigna tras definir BehindCamera)
-- ¿La placa de esta unidad esta detras de la camara? (Forever: C_NamePlateManager.IsNamePlateUnitBehindCamera)
local function BehindCamera(unit)
    local f = C_NamePlateManager and C_NamePlateManager.IsNamePlateUnitBehindCamera
    if not f or not unit:find("^nameplate%d+$") then return false end
    local ok, v = pcall(f, unit)
    return ok and not issecret(v) and v == true
end
BehindCameraRef = BehindCamera

----------------------------------------------------------------------
-- Radar: flechas alrededor del centro de la pantalla hacia los enemigos que NO tienes delante.
-- Con las placas fuera de pantalla (nameplateShowOffscreen) el juego deja la placa de lo que no ves pegada
-- al borde de la pantalla, o la marca «detras de la camara»: su posicion dice hacia donde esta.
----------------------------------------------------------------------
local function MyWorld()
    if not (C_Map and C_Map.GetBestMapForUnit and Espia.WorldPos) then return nil end
    local ok, mapID = pcall(C_Map.GetBestMapForUnit, "player")
    if not ok or not mapID or issecret(mapID) then return nil end
    local okp, pos = pcall(C_Map.GetPlayerMapPosition, mapID, "player")
    if not okp or not pos then return nil end
    local x, y = pos:GetXY()
    if not x or issecret(x) then return nil end
    return Espia.WorldPos(mapID, x, y)
end
local function RemoteWhere(e)
    if not (e.wx and Espia.DistBearing) then return nil end
    local ax, ay = MyWorld()
    if not ax then return nil end
    return Espia.DistBearing(ax, ay, e.wx, e.wy)
end

local radarFrame, radarArrows = nil, {}
local function RadarArrow(i)
    local a = radarArrows[i]
    if a then return a end
    a = CreateFrame("Frame", nil, radarFrame)
    a:SetSize(40, 40)
    a.tex = a:CreateTexture(nil, "OVERLAY")
    a.tex:SetAllPoints()
    a.tex:SetTexture("Interface\\Minimap\\MinimapArrow")
    a.text = a:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    a.text:SetPoint("TOP", a, "BOTTOM", 0, 2)
    radarArrows[i] = a
    return a
end
local function UpdateRadar()
    local R = DB and DB.radar
    if not (R and R.on and DB.show.enemies and Active() and C_NamePlate and C_NamePlate.GetNamePlateForUnit) then
        if radarFrame then radarFrame:Hide() end
        return
    end
    if not radarFrame then
        radarFrame = CreateFrame("Frame", "CMPvPOutdoorRadar", UIParent)
        radarFrame:SetAllPoints(UIParent)
        radarFrame:SetFrameStrata("HIGH")
        radarFrame:EnableMouse(false)
    end
    radarFrame:Show()
    local cx, cy = UIParent:GetCenter()
    local W, H = UIParent:GetWidth(), UIParent:GetHeight()
    local n = 0
    if cx and cy and W and H then
        local us = UIParent:GetEffectiveScale() or 1
        for i = 1, 40 do
            local u = "nameplate" .. i
            if n >= (R.max or 8) then break end
            if UnitExists(u) and IsEnemyPlayer(u) then
                local behind = BehindCamera(u)
                local px, py
                local okp, plate = pcall(C_NamePlate.GetNamePlateForUnit, u)
                if okp and plate and plate.GetCenter then
                    local x, y = plate:GetCenter()
                    if type(x) == "number" and type(y) == "number" and not issecret(x) then
                        local sc = (plate.GetEffectiveScale and plate:GetEffectiveScale() or us) / us
                        px, py = x * sc, y * sc
                    end
                end
                local angle
                if behind then
                    -- a la espalda: abajo, inclinada hacia el lado por donde queda
                    angle = math.pi
                    if px then angle = math.pi - math.max(-1, math.min(1, (px - cx) / (W / 2))) * 0.7 end
                elseif px then
                    local m = 40
                    if R.all or px < m or px > W - m or py < m or py > H - m then
                        angle = math.atan2(px - cx, py - cy)   -- 0 = arriba, en el sentido de las agujas del reloj
                    end
                end
                if angle then
                    n = n + 1
                    local a = RadarArrow(n)
                    local r = R.radius or 190
                    local sz = 40 * (R.scale or 100) / 100
                    a:SetSize(sz, sz)
                    a:ClearAllPoints()
                    a:SetPoint("CENTER", UIParent, "BOTTOMLEFT", cx + r * math.sin(angle), cy + r * math.cos(angle))
                    if a.tex.SetRotation then a.tex:SetRotation(-angle) end
                    local guid = Clean(UnitGUID(u))
                    local e = guid and enemies[guid]
                    local nm = (e and e.name) or Espia.UnitFullName(u) or "?"
                    local cl = e and e.class
                    a.text:SetText((cl and ClassColor(cl) or "|cffff4040") .. nm .. "|r" .. (behind and " |cffff8000(detrás)|r" or ""))
                    a:Show()
                end
            end
        end
    end
    if cx and DB.spy and DB.spy.recvAllRadar and GetPlayerFacing then
        local okf, facing = pcall(GetPlayerFacing)
        if okf and type(facing) == "number" and not issecret(facing) then
            local now = GetTime()
            for _, e in pairs(enemies) do
                if n >= (R.max or 8) then break end
                if e.remote and e.wx and now - e.seen <= (DB.activeTTL or 20) * 3 then
                    local dist, b = RemoteWhere(e)
                    if dist then
                        n = n + 1
                        local angle = b + facing
                        local a = RadarArrow(n)
                        local r = R.radius or 190
                        local sz = 40 * (R.scale or 100) / 100
                        a:SetSize(sz, sz)
                        a:ClearAllPoints()
                        a:SetPoint("CENTER", UIParent, "BOTTOMLEFT", cx + r * math.sin(angle), cy + r * math.cos(angle))
                        if a.tex.SetRotation then a.tex:SetRotation(-angle) end
                        a.text:SetText((e.class and ClassColor(e.class) or "|cffff4040") .. e.name .. "|r " .. math.floor(dist + 0.5)
                            .. " m |cff66bbff(" .. e.remote .. ")|r")
                        a:Show()
                    end
                end
            end
        end
    end
    for i = n + 1, #radarArrows do radarArrows[i]:Hide() end
end

local function Diagnostic()
    local get = (C_CVar and C_CVar.GetCVar) or GetCVar
    local ok, v = pcall(get, "nameplateShowEnemies")
    local okd, d = pcall(get, "nameplateMaxDistance")
    Print("placas de enemigos: " .. ((ok and v == "1") and "|cff55ff55encendidas|r" or "|cffff5555APAGADAS|r (solo ves a quien seleccionas o tocas con el ratón; enciéndelas con V o en la configuración)")
        .. ((okd and d) and (" · distancia " .. tostring(d)) or ""))
    local oko, o = pcall(get, "nameplateShowOffscreen")
    if oko and o ~= nil then
        Print("placas fuera de pantalla (por la espalda / desde arriba): " .. (o == "1" and "|cff55ff55sí|r" or "|cffff5555NO|r (solo ves lo que tienes delante)"))
    end
    local partes = {}
    for k, n in pairs(bySource) do partes[#partes + 1] = k .. " " .. n end
    table.sort(partes)
    Print("detectados en esta sesión por fuente: " .. (#partes > 0 and table.concat(partes, ", ") or "ninguno todavía"))
    Print(("en la lista ahora: %d (se quitan tras %d s sin verlos)"):format(CountEnemies(), DB.enemyTTL))
    Print("jugadores que el juego no dejó saber si eran enemigos: " .. hidden.n
        .. (hidden.n > 0 and (" (el último hace " .. math.floor(GetTime() - hidden.last) .. " s)") or ""))
end
ns.PO_Diagnostic = Diagnostic

local function ScanAll()
    local src = DB.sources
    for i = 1, 40 do
        local u = "nameplate" .. i
        if UnitExists(u) then
            ScanUnit(u)
            if src.chain then ScanUnit(u .. "target") end
        end
    end
    ScanUnit("target")
    ScanUnit("focus")
    ScanUnit("mouseover")
    if src.soft then ScanUnit("softenemy") end
    if src.chain then
        ScanUnit("targettarget"); ScanUnit("focustarget"); ScanUnit("mouseovertarget"); ScanUnit("pettarget")
    end
    if src.group then
        if IsInRaid and IsInRaid() then
            for i = 1, math.min(40, GetNumGroupMembers and GetNumGroupMembers() or 0) do ScanUnit("raid" .. i .. "target") end
        elseif IsInGroup and IsInGroup() then
            for i = 1, 4 do ScanUnit("party" .. i .. "target"); ScanUnit("partypet" .. i .. "target") end
        end
    end
end

-- Marca encima de la placa de nombre (KOS / te tiene de objetivo / todos). Marcos normales (no
-- protegidos) hijos de la placa; nunca se tocan placas prohibidas (IsForbidden, p. ej. en instancias).
local plateMarks = {}   -- placa -> marco
local function PlateOf(unit)
    if not (C_NamePlate and C_NamePlate.GetNamePlateForUnit) then return nil end
    local ok, plate = pcall(C_NamePlate.GetNamePlateForUnit, unit)
    if not ok or not plate or issecret(plate) then return nil end
    if plate.IsForbidden and plate:IsForbidden() then return nil end
    return plate
end
local function MarkFor(plate)
    local f = plateMarks[plate]
    if f then return f end
    f = CreateFrame("Frame", nil, plate)
    f:SetFrameStrata("HIGH")
    f.tex = f:CreateTexture(nil, "OVERLAY")
    f.tex:SetAllPoints()
    f:Hide()
    plateMarks[plate] = f
    return f
end
HidePlateMark = function(unit)
    if unit then
        local plate = PlateOf(unit)
        if plate and plateMarks[plate] then plateMarks[plate]:Hide() end
    else
        for _, f in pairs(plateMarks) do f:Hide() end
    end
end
UpdatePlateMark = function(unit, e, targetsMe)
    local P = DB.plate
    local plate = PlateOf(unit)
    if not plate then return end
    local icon
    if P.on and not e.ignored then
        if P.targeting and targetsMe then icon = P.targetIcon
        elseif P.kos and e.full and Espia.IsKOS(e.full) then icon = P.kosIcon
        elseif P.all then icon = P.allIcon end
    end
    local f = plateMarks[plate]
    if not icon then if f then f:Hide() end return end
    f = f or MarkFor(plate)
    f:SetSize(P.size or 26, P.size or 26)
    f:ClearAllPoints()
    f:SetPoint("BOTTOM", plate, "TOP", 0, P.y or 6)
    f.tex:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_" .. icon)
    f:Show()
end

-- Filas clicables: botones seguros (SecureActionButtonTemplate) con macro "/targetexact Nombre".
-- Son marcos de primer nivel anclados a UIParent (no hijos de la lista) para que la lista
-- siga pudiendo mostrarse/ocultarse en combate. En combate NO se pueden mostrar, ocultar,
-- mover ni cambiar a quien apuntan: cada fila conserva su jugador y las entradas nuevas se
-- pintan con el texto de la lista (sin clic) hasta salir de combate.
local VIEWS = { { "near", "Cerca" }, { "hour", "Ultima hora" }, { "kos", "Matar a la vista" }, { "revenge", "Venganza" },
                { "ignore", "Ignorados" }, { "zones", "Zonas calientes" } }
local rows, rowsBuilt = {}, false
local ROW_H = 14
local guard = CreateFrame("Frame")

local function Locked() return InCombatLockdown and InCombatLockdown() end

local function RowTooltip(self)
    if not DB.spy.rowTooltip then return end
    local name = self.pname
    local p = name and Espia.Get(name)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:AddLine(name or "?", 1, 0.82, 0)
    if p then
        GameTooltip:AddLine(((p.r or "") .. " " .. (p.cl or "") .. " " .. (p.l == -1 and "??" or (p.l or ""))), 1, 1, 1)
        if p.g then GameTooltip:AddLine("<" .. p.g .. ">", 0.6, 1, 0.6) end
        if p.z then GameTooltip:AddLine("Visto en " .. p.z .. ((p.sz and p.sz ~= "") and (" / " .. p.sz) or "") .. " · " .. Espia.Ago(p.t), 0.8, 0.8, 0.8) end
        if (p.w or 0) > 0 or (p.d or 0) > 0 then GameTooltip:AddLine(string.format("Victorias %d · Derrotas %d", p.w or 0, p.d or 0), 0.4, 1, 0.4) end
        if p.k then GameTooltip:AddLine("KOS" .. (p.kr and (": " .. p.kr) or ""), 1, 0.2, 0.2) end
    end
    if p and p.n and DB.spy.notes then GameTooltip:AddLine("Nota: " .. p.n, 1, 0.9, 0.5, true) end
    if DB.spy.clickTarget then GameTooltip:AddLine("Clic izquierdo: objetivo", 0.5, 0.5, 0.5) end
    if PingMacro(name) then GameTooltip:AddLine("Clic central: ping sobre el", 0.5, 0.5, 0.5) end
    if DB.spy.rowMenu then GameTooltip:AddLine("Clic derecho: KOS, ignorar, anunciar...", 0.5, 0.5, 0.5) end
    GameTooltip:Show()
end

local function BuildRows()
    if rowsBuilt then return true end
    if Locked() then return false end
    for i = 1, MAX_ROWS do
        local b = CreateFrame("Button", "CMPvPOutdoorEnemyRow" .. i, UIParent, "SecureActionButtonTemplate")
        b:SetSize(226, ROW_H)
        b:SetFrameStrata("MEDIUM")
        b:RegisterForClicks("AnyUp", "AnyDown")
        b.hl = b:CreateTexture(nil, "HIGHLIGHT"); b.hl:SetAllPoints(); b.hl:SetColorTexture(1, 1, 1, 0.12)
        b:HookScript("OnClick", function(self, button, down)
            if not mod.enabled or down then return end
            if button == "RightButton" and self.pname and DB.spy.rowMenu then Espia.ShowMenu(self, self.pname) end
        end)
        b:SetScript("OnEnter", RowTooltip)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
        b:Hide()
        rows[i] = b
    end
    rowsBuilt = true
    return true
end

-- Macro de ping de Blizzard sobre un jugador: /targetexact + /ping [@target] tipo (+ volver al objetivo anterior).
local PING_KINDS = { { "WARNING", "Aviso" }, { "ATTACK", "Atacar" }, { "ASSIST", "Ayuda" }, { "ON_MY_WAY", "Voy" } }
local function PingMacro(name)
    local P = DB.ping
    if not (name and P.on) then return nil end
    local slash = SLASH_PING1
    if type(slash) ~= "string" or issecret(slash) or slash == "" then return nil end
    local word = _G["PING_TYPE_" .. (P.kind or "WARNING")]
    if type(word) ~= "string" or issecret(word) then word = "" end
    local m = "/targetexact " .. name .. "\n" .. slash .. " [@target,exists] " .. word
    if P.restore then m = m .. "\n/targetlasttarget" end
    return m
end
ns.PO_PingMacro = function(name) return DB and PingMacro(name) end

local function SetRowTarget(b, name)
    local want = (name and DB.spy.clickTarget) and ("/targetexact " .. name) or nil
    local ping = PingMacro(name)
    if b.secName == name and b.secMacro == want and b.secPing == ping then return end
    b.secName, b.secMacro, b.secPing = name, want, ping
    b:SetAttribute("type1", want and "macro" or nil)
    b:SetAttribute("macrotext1", want)
    b:SetAttribute("type3", ping and "macro" or nil)
    b:SetAttribute("macrotext3", ping)
end

-- Boton de ping del primer enemigo de la lista (para una tecla: macro "/click CMPvPOutdoorPing").
local pingBtn
local function SyncPingButton(arr)
    if Locked() then return end
    if not pingBtn then
        if not DB.ping.button then return end
        pingBtn = CreateFrame("Button", "CMPvPOutdoorPing", UIParent, "SecureActionButtonTemplate")
        pingBtn:RegisterForClicks("AnyUp", "AnyDown")
        pingBtn:Hide()
    end
    local first
    if DB.ping.button then
        for _, en in ipairs(arr or {}) do if en.name and not Espia.IsIgnored(en.name) then first = en.name; break end end
    end
    local mac = PingMacro(first)
    if pingBtn.mac == mac then return end
    pingBtn.mac = mac
    pingBtn:SetAttribute("type", mac and "macro" or nil)
    pingBtn:SetAttribute("macrotext", mac)
end

local function HideRows()
    if not rowsBuilt then return end
    if Locked() then
        guard:RegisterEvent("PLAYER_REGEN_ENABLED")
        return
    end
    for _, b in ipairs(rows) do SetRowTarget(b, nil); b.pname = nil; b:Hide() end
end
guard:SetScript("OnEvent", function(self)
    self:UnregisterAllEvents()
    if not mod.enabled or not listFrame or not listFrame:IsShown() then HideRows() end
end)

local function PlaceRows()
    if not rowsBuilt or Locked() then return end
    local left, top = listFrame:GetLeft(), listFrame:GetTop()
    if not left or not top then return end
    local sc = listFrame:GetScale()
    for i, b in ipairs(rows) do
        b:SetScale(sc)
        b:ClearAllPoints()
        b:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left, top - 3 - ROW_H * i)
    end
end

-- La lista se ancla siempre por arriba a la izquierda para que crecer/encoger no mueva las filas.
local function AnchorTopLeft(f)
    local left, top = f:GetLeft(), f:GetTop()
    if not left or not top then return end
    f:ClearAllPoints()
    f:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left, top)
    DB.pos[f.key] = { "TOPLEFT", "BOTTOMLEFT", left, top }
    return true
end

local function Entries(view)
    local S, out = DB.spy, {}
    if view == "near" then
        local arr = {}
        for _, e in pairs(enemies) do
            e.kos = e.full and Espia.IsKOS(e.full) or false
            if not (e.ignored and S.hideIgnored) then arr[#arr + 1] = e end
        end
        local now = GetTime()
        for _, e in ipairs(arr) do e.away = now - e.seen > (DB.activeTTL or 20) end
        table.sort(arr, function(a, b)
            if a.away ~= b.away then return not a.away end
            if S.kosFirst and a.kos ~= b.kos then return a.kos end
            return a.first < b.first
        end)
        for _, e in ipairs(arr) do
            local lv = e.level and (e.level == -1 and "|cffff0000??|r" or tostring(e.level)) or "?"
            local ven = S.revenge and S.revengeNear and e.full and Espia.IsRevenge(e.full)
            local mark = e.kos and "|cffff3030KOS |r" or (ven and "|cffff8000VEN |r") or (IsDangerLevel(e.level) and "|cffff0000! |r" or "")
            local col = (e.ignored or e.away) and "|cff888888" or ClassColor(e.class)
            local ago = e.away and ("  |cff777777hace " .. math.floor(now - e.seen) .. " s|r") or ""
            if e.remote then
                local dist, b = RemoteWhere(e)
                ago = ago .. "  |cff66bbff[" .. e.remote .. (dist and string.format(" %d m %s", math.floor(dist + 0.5), Espia.CompassName(b)) or "") .. "]|r"
            end
            out[#out + 1] = { name = e.full, text = mark .. col .. e.name .. "|r  " .. (e.loc or "") .. " " .. lv .. ago }
        end
    elseif view == "zones" then
        for _, z in ipairs(Espia.Hotspots()) do
            out[#out + 1] = { text = "|cffffd100" .. z.zone .. "|r  " .. z.n .. (z.n == 1 and " enemigo" or " enemigos") ..
                (z.kos > 0 and ("  |cffff3030KOS " .. z.kos .. "|r") or "") .. "  |cff999999" .. Espia.Ago(z.t) .. "|r" }
        end
    else
        local list = (view == "hour" and Espia.LastHour()) or (view == "kos" and Espia.KOSList())
            or (view == "revenge" and Espia.RevengeList()) or Espia.IgnoreList()
        for _, p in ipairs(list) do
            local lv = p.l and (p.l == -1 and "??" or tostring(p.l)) or "?"
            local extra = (view == "kos" and p.kr)
                or (view == "revenge" and ("|cffff8000x" .. (p.vn or 0) .. "|r" .. ((p.vw or 0) > 0 and (" |cff55ff55+" .. p.vw .. "|r") or "") ..
                    "|cff999999" .. (p.vt and (" · " .. Espia.Ago(p.vt)) or "")))
                or Espia.Ago(p.t)
            out[#out + 1] = { name = p.name, text = ((p.k and view ~= "kos") and "|cffff3030KOS |r" or "") ..
                ClassColor(p.c) .. p.name .. "|r " .. lv .. "  |cff999999" .. extra .. "|r" }
        end
    end
    return out
end

local function ViewOn(v)
    if v == "revenge" and not DB.spy.revenge then return false end
    return v == "near" or (DB.spy.views and DB.spy.views[v])
end

local function ViewName(v) for _, x in ipairs(VIEWS) do if x[1] == v then return x[2] end end return v end

local function UpdateEnemyList()
    local now = GetTime()
    for key, e in pairs(enemies) do
        if now - e.seen > DB.enemyTTL then enemies[key] = nil end
    end
    if not DB.show.enemies or not Active() then
        listFrame:Hide(); HideRows()
        if HidePlateMark then HidePlateMark() end
        return
    end

    if not ViewOn(DB.view or "near") then DB.view = "near" end
    local view = DB.view or "near"
    local arr = Entries(view)
    local combat = Locked()
    local anyLocked = false
    if combat and rowsBuilt then for _, b in ipairs(rows) do if b:IsShown() then anyLocked = true end end end
    local hide = not unlocked and not anyLocked and (closedUntilNew or (#arr == 0 and view == "near"))
    if hide then listFrame:Hide(); HideRows(); return end
    listFrame:Show()
    for _, b in ipairs(listFrame.hdr or {}) do b:SetShown(DB.spy.headerButtons) end
    if not listFrame.tlDone and not combat and not unlocked then listFrame.tlDone = AnchorTopLeft(listFrame) end

    local n = #arr
    if view == "near" then
        if unlocked and n == 0 then listFrame.title:SetText("Enemigos cerca (arrastra)")
        else
            local col = (n >= DB.groupSize) and "|cffff3030" or "|cffffd100"
            listFrame.title:SetText(col .. "Enemigos cerca: " .. n .. "|r")
        end
    else
        listFrame.title:SetText("|cffffd100" .. ViewName(view) .. ": " .. n .. "|r")
    end

    local maxRows = math.max(1, math.min(MAX_ROWS, DB.listMax))
    local slots = {}
    if combat then
        -- cada fila clicable conserva su jugador; las entradas nuevas van a las filas libres (sin clic)
        local used = {}
        for i = 1, maxRows do
            local b = rows[i]
            if b and b:IsShown() and b.pname then
                local found
                for _, en in ipairs(arr) do if en.name == b.pname then found = en; break end end
                slots[i] = found or { name = b.pname, text = "|cff777777" .. b.pname .. " (fuera)|r" }
                if found then used[found] = true end
            end
        end
        local j = 1
        for i = 1, maxRows do
            if not slots[i] and not (rows[i] and rows[i]:IsShown()) then
                while arr[j] and used[arr[j]] do j = j + 1 end
                if arr[j] then slots[i] = arr[j]; used[arr[j]] = true; j = j + 1 end
            end
        end
    else
        if view == "near" then SyncPingButton(arr) end
        for i = 1, maxRows do slots[i] = arr[i] end
        if BuildRows() then
            PlaceRows()
            for i = 1, MAX_ROWS do
                local b, en = rows[i], slots[i]
                if en and en.name then
                    SetRowTarget(b, en.name); b.pname = en.name; b:Show()
                else
                    SetRowTarget(b, nil); b.pname = nil; b:Hide()
                end
            end
        end
    end

    local shown = 0
    for i = 1, MAX_ROWS do
        local fs, en = listFrame.rows[i], (i <= maxRows) and slots[i]
        if en then fs:SetText(en.text); shown = i else fs:SetText("") end
    end
    if not combat or listFrame:GetHeight() < 20 + 14 * shown then
        listFrame:SetHeight(20 + 14 * shown)
    end
    listFrame.bg:Show()
end

PlaceRowsRef = PlaceRows

local function CycleView(step)
    local idx = 1
    for i, v in ipairs(VIEWS) do if v[1] == DB.view then idx = i end end
    for _ = 1, #VIEWS do
        idx = (idx - 1 + step) % #VIEWS + 1
        if ViewOn(VIEWS[idx][1]) then break end
    end
    DB.view = VIEWS[idx][1]
    closedUntilNew = false
    UpdateEnemyList()
end

local function ShowView(view)
    if not ViewOn(view) then Print("esa lista esta desactivada en la configuracion."); return end
    DB.view = view
    closedUntilNew = false
    UpdateEnemyList()
end

----------------------------------------------------------------------
-- 2) HABILIDADES CLAVE DEL ENEMIGO (UNIT_SPELLCAST_SUCCEEDED)
----------------------------------------------------------------------
-- {idDeHechizo, cooldown en segundos}. Se compara por NOMBRE, asi vale para cualquier rango.
local KEY_SPELLS = {
    -- Picaro
    { 408, 20 }, { 2094, 180 }, { 1766, 10 }, { 1856, 180 }, { 1776, 10 },
    { 2983, 180 }, { 5277, 180 }, { 14177, 180 }, { 36554, 30 }, { 31224, 90 }, { 14185, 480 },
    -- Mago
    { 2139, 24 }, { 45438, 300 }, { 1953, 15 }, { 122, 25 }, { 11958, 384 }, { 12472, 180 },
    -- Paladin
    { 853, 60 }, { 642, 300 }, { 1022, 300 }, { 633, 3600 }, { 1044, 25 }, { 10278, 300 },
    -- Guerrero
    { 5246, 180 }, { 100, 15 }, { 20252, 30 }, { 6552, 10 }, { 72, 12 }, { 1719, 300 },
    { 12292, 180 }, { 871, 300 }, { 676, 60 },
    -- Druida
    { 5211, 60 }, { 16979, 15 }, { 22812, 60 }, { 29166, 180 }, { 18562, 15 },
    -- Brujo
    { 6789, 120 }, { 5484, 40 }, { 19647, 24 }, { 17928, 40 }, { 18288, 180 },
    -- Sacerdote
    { 8122, 30 }, { 6346, 180 }, { 15487, 45 }, { 10060, 120 }, { 33206, 180 },
    -- Cazador
    { 5384, 30 }, { 19503, 30 }, { 1499, 30 }, { 19577, 60 }, { 19263, 300 }, { 23989, 300 },
    -- Chaman
    { 8042, 6 }, { 8177, 15 }, { 16188, 180 }, { 2484, 15 }, { 57994, 6 }, { 51514, 45 },
    -- Razas
    { 20572, 120 }, { 20549, 120 }, { 7744, 120 }, { 20589, 60 }, { 20594, 180 },
    { 20580, 120 }, { 28730, 120 }, { 20600, 180 }, { 20577, 120 }, { 59752, 120 },
}
local function BuildKeySpells()
    for _, s in ipairs(KEY_SPELLS) do
        local name, icon = SpellInfo(s[1])
        if name and not keyCD[name] then keyCD[name] = s[2]; keyIcon[name] = icon end
    end
end

local function AddCD(src, spell)
    local total = keyCD[spell]
    cds[src .. "|" .. spell] = { src = src, spell = spell, icon = keyIcon[spell],
                                 expire = GetTime() + total, total = total }
end

local function UpdateCDs()
    local now = GetTime()
    local arr = {}
    for k, c in pairs(cds) do
        if c.expire <= now then cds[k] = nil else arr[#arr + 1] = c end
    end
    table.sort(arr, function(a, b) return a.expire < b.expire end)
    if not DB.show.cds or not Active() or (#arr == 0 and not unlocked) then
        cdFrame:Hide(); return
    end
    cdFrame:Show()
    local maxIcons = math.max(1, math.min(MAX_ICONS, DB.cdMax))
    local lo, hi = DB.cdLow / 100, DB.cdHigh / 100
    for i = 1, MAX_ICONS do
        local b, c = cdFrame.icons[i], arr[i]
        if c and i <= maxIcons then
            local rem = c.expire - now
            b.tex:SetTexture(c.icon)
            b.time:SetText(FormatTime(rem))
            local pct = rem / c.total
            if pct < lo then b.time:SetTextColor(0.1, 1, 0.1)
            elseif pct <= hi then b.time:SetTextColor(1, 0.6, 0)
            else b.time:SetTextColor(1, 0.1, 0.1) end
            b.name:SetText(string.sub(c.src or "", 1, 8))
            b:Show()
        else
            b:Hide()
        end
    end
end

local function OnSpellSucceeded(unit, _, spellID)
    if not DB or not Active() then return end
    if issecret(unit) or type(unit) ~= "string" then return end
    if not (unit == "target" or unit == "focus" or unit == "mouseover"
            or string.find(unit, "^nameplate")) then return end
    if issecret(spellID) or not spellID then return end
    if not IsEnemyPlayer(unit) then return end
    local name = Clean(SpellName(spellID))
    if not name then return end
    local full = Espia.UnitFullName(unit)
    if full and Espia.IsIgnored(full) then return end
    Espia.OnSpell(full, nil, name)
    if not keyCD[name] or not DB.show.cds then return end
    AddCD(Hub.UnitFullName(unit) or "Enemigo", name)
end

----------------------------------------------------------------------
-- 3) ALERTA DE CASTEOS
----------------------------------------------------------------------
local function BuildDangerSpells()
    local ids = {
        118, 12824, 12825, 12826, 28272, 28271, 61305, 61721, 61780,   -- polimorfia
        5782, 6213, 6215, 5484, 6358, 710, 2637, 18657, 18658,         -- miedo, aullido, seduccion, destierro, hibernar
        51514, 605, 20066, 33786, 9484, 9485, 10955,                   -- hex, control mental, arrepentimiento, ciclon, grilletes
        11366, 8129, 10797,                                            -- piroexplosion, mana burn, estrella
    }
    for _, id in ipairs(ids) do
        local n = SpellName(id)
        if n then dangerSpells[n] = true end
    end
end

local function CreateCastBar(unit, key, y)
    local f = mod:Frame("StatusBar", "CMPvPOutdoorCast_" .. unit, UIParent)
    f:SetSize(DB.castWidth or 260, 24)
    f:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    f:SetMinMaxValues(0, 1)
    f.unit = unit
    MakeMovable(f, key, "CENTER", 0, y)
    f.icon = f:CreateTexture(nil, "ARTWORK")
    f.icon:SetSize(24, 24)
    f.icon:SetPoint("RIGHT", f, "LEFT", -2, 0)
    f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    f.text:SetPoint("CENTER", 0, 0)
    f.bg2 = f:CreateTexture(nil, "BACKGROUND")
    f.bg2:SetAllPoints(f); f.bg2:SetColorTexture(0, 0, 0, 0.6)
    f:Hide()
    return f
end

-- Casteo con datos secretos (en combate restringido): sin nombre ni tiempos legibles,
-- pero la barra se anima con el objeto de duracion del propio juego.
local function SecretCast(bar)
    local unit = bar.unit
    local dur
    if UnitCastingDuration then dur = UnitCastingDuration(unit) end
    if not dur and UnitChannelDuration then dur = UnitChannelDuration(unit) end
    if not dur or not bar.SetTimerDuration then bar:Hide(); return end
    bar:SetTimerDuration(dur)
    bar:SetStatusBarColor(1, 0.6, 0)
    bar.text:SetText("¡Casteo enemigo!")
    bar.icon:SetTexture(nil)
    bar:Show()
end

local function DoCheckCast(bar)
    local unit = bar.unit
    if not DB.show.casts or not Active() then bar:Hide(); return end
    if unlocked then
        bar:SetMinMaxValues(0, 1)
        bar:SetValue(0.6); bar:SetStatusBarColor(1, 0.5, 0)
        bar.text:SetText("Casteo " .. unit .. " (arrastra)")
        bar.icon:SetTexture(nil); bar:Show(); return
    end
    if not IsEnemyPlayer(unit) then bar:Hide(); return end

    -- UnitCastingInfo: nombre, texto, icono, inicio, fin, _, castID, noInterrumpible, spellID
    local name, _, tex, st, et, _, _, ni = UnitCastingInfo(unit)
    local channel = false
    if issecret(name) then SecretCast(bar); return end
    if not name then
        -- UnitChannelInfo: nombre, texto, icono, inicio, fin, _, noInterrumpible, spellID
        name, _, tex, st, et, _, ni = UnitChannelInfo(unit)
        channel = true
        if issecret(name) then SecretCast(bar); return end
    end
    if not name then bar.curStart = nil; bar:Hide(); return end
    if issecret(st) or issecret(et) or issecret(ni) or issecret(tex) then SecretCast(bar); return end

    local total = (et - st) / 1000
    local rem = et / 1000 - GetTime()
    if rem < 0 then rem = 0 end
    local dangerous = dangerSpells[name]
    if not dangerous and total < DB.longCast then bar:Hide(); return end

    bar:SetMinMaxValues(0, total)
    bar:SetValue(channel and rem or (total - rem))
    bar.icon:SetTexture(tex)
    if ni then
        bar:SetStatusBarColor(0.5, 0.5, 0.6)
        bar.text:SetText(name .. "  (no interrumpible)  " .. string.format("%.1f", rem))
    elseif dangerous then
        bar:SetStatusBarColor(1, 0.1, 0.1)
        bar.text:SetText("¡INTERRUMPE! " .. name .. "  " .. string.format("%.1f", rem))
    else
        bar:SetStatusBarColor(1, 0.6, 0)
        bar.text:SetText(name .. "  " .. string.format("%.1f", rem))
    end
    if bar.curStart ~= st then
        bar.curStart = st
        if dangerous and not ni then Sound("ALARM_CLOCK_WARNING_3", "cast") end
    end
    bar:Show()
end

local function CheckCast(bar)
    local ok = pcall(DoCheckCast, bar)
    if not ok then bar:Hide() end
end

local function RefreshCasts()
    for _, bar in ipairs(castBars) do CheckCast(bar) end
end

----------------------------------------------------------------------
-- 4) REGISTRO DE MUERTES + MARCAS EN EL MAPA
----------------------------------------------------------------------
local function UpdatePins()
    for _, p in ipairs(pins) do p:Hide() end
    if not DB or not mod.enabled or not WorldMapFrame or not WorldMapFrame:IsVisible() then return end
    local mapID = WorldMapFrame:GetMapID()
    local canvas = WorldMapFrame:GetCanvas()
    local w, h = canvas:GetWidth(), canvas:GetHeight()
    local n = 0
    local list = {}
    for _, d in ipairs(DB.deaths) do
        if DB.show.map and d.mapID == mapID and d.x and d.x > 0 then list[#list + 1] = { death = d, x = d.x, y = d.y } end
    end
    for _, m in ipairs(Espia.MapMarks(mapID)) do list[#list + 1] = { mark = m, x = m.x, y = m.y } end
    for _, item in ipairs(list) do
        local d = item.death
        do
            n = n + 1
            local p = pins[n]
            if not p then
                p = CreateFrame("Frame", nil, canvas)
                p:SetSize(16, 16)
                p:SetFrameStrata("HIGH")
                p.tex = p:CreateTexture(nil, "OVERLAY")
                p.tex:SetAllPoints(p)
                p.tex:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_8")
                p:EnableMouse(true)
                p:SetScript("OnEnter", function(self)
                    local mk = self.mark
                    if mk then
                        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                        GameTooltip:AddLine(mk.title, 1, 0.3, 0.3)
                        GameTooltip:AddLine(mk.text, 1, 1, 1)
                        GameTooltip:Show()
                        return
                    end
                    local dd = self.death
                    if not dd then return end
                    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                    GameTooltip:AddLine("Muerte: " .. dd.when, 1, 0.2, 0.2)
                    GameTooltip:AddLine("Killer: " .. dd.killer ..
                        (dd.class and (" (" .. dd.class .. (dd.level and (" " .. (dd.level == -1 and "??" or dd.level)) or "") .. ")") or ""), 1, 1, 1)
                    if dd.sub and dd.sub ~= "" then GameTooltip:AddLine(dd.sub, 0.6, 0.6, 1) end
                    GameTooltip:Show()
                end)
                p:SetScript("OnLeave", function() GameTooltip:Hide() end)
                pins[n] = p
            end
            p.death, p.mark = d, item.mark
            local icon = 8
            if item.mark then icon = (item.mark.kind == "kos") and (DB.spy.kosPinIcon or 7) or (DB.spy.seenPinIcon or 2) end
            p.tex:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_" .. icon)
            p:ClearAllPoints()
            p:SetPoint("CENTER", canvas, "TOPLEFT", item.x * w, -item.y * h)
            p:Show()
        end
    end
end

-- Enemigos del resumen de muerte del juego (C_DeathRecap, sin argumento = la ultima muerte; el 1.o es el golpe final).
-- Devuelve una lista { {e = enemigo, dmg = daño}, ... } o nil si el juego aun no tiene el resumen.
local function RecapAttackers()
    if not (DB.sources.recap and C_DeathRecap and C_DeathRecap.GetRecapEvents) then return nil end
    local okh, has = pcall(C_DeathRecap.HasRecapEvents)
    if okh and has == false then return nil end
    local ok, evs = pcall(C_DeathRecap.GetRecapEvents)
    if not ok or type(evs) ~= "table" or issecret(evs) then return nil end
    local list, byKey = {}, {}
    local me = Clean(UnitGUID("player"))
    for _, ev in ipairs(evs) do
        if type(ev) == "table" then
            local guid, name = Clean(ev.sourceGUID), Clean(ev.sourceName)
            local e
            if type(guid) == "string" and guid:find("^Player%-") and guid ~= me then
                ScanGUID(guid, name, "recap")
                e = enemies[guid]
            elseif guid == nil and type(name) == "string" and name ~= "" then
                -- sin GUID: solo si es un enemigo ya conocido (en la lista o con ficha)
                for _, x in pairs(enemies) do if x.full == name or x.name == name then e = x; break end end
                if not e and Espia.Get and Espia.Get(name) then e = { name = name, full = name } end
            end
            if e then
                local k = e.full or e.name
                if not byKey[k] then byKey[k] = { e = e, dmg = 0 }; list[#list + 1] = byKey[k] end
                local amt = Clean(ev.amount)
                if type(amt) == "number" then byKey[k].dmg = byKey[k].dmg + amt end
            end
        end
    end
    return list
end

local function DescribeKiller(e)
    local lv = e.level and (" " .. ((e.level == -1) and "??" or e.level)) or ""
    return e.name .. ((e.loc or lv ~= "") and (" (" .. (e.loc or "?") .. lv .. ")") or "")
end

local function RecordDeath(late)
    if not Active() then return end
    local now = GetTime()
    local killer, others
    local recap = RecapAttackers()
    if recap and recap[1] then
        killer = recap[1].e
        if #recap > 1 then
            others = {}
            for i = 2, #recap do others[#others + 1] = recap[i].e.name end
        end
    end
    if late then
        -- el resumen llego tarde: solo se corrige la ultima muerte si se quedo sin asesino
        local d = DB.deaths[1]
        if not (killer and d and d.killer == "?" and d.t and now - d.t < 10) then return end
        d.killer, d.class, d.level = killer.name, killer.loc, killer.level
        if killer.full then Espia.RecordLoss(killer.full) end
        Print("Resumen de muerte: te ha matado " .. DescribeKiller(killer) ..
              (others and (" · también te pegaron: " .. table.concat(others, ", ")) or ""))
        return
    end
    if not killer and lastTargeter and now - lastTargeter.t < 20 then killer = lastTargeter.e end
    -- nadie te tenia de objetivo (o el juego lo oculta): el ultimo enemigo visto mientras peleabas
    if not killer and lastInCombat and now - lastInCombat.t < 10 then killer = lastInCombat.e end

    local mapID = C_Map.GetBestMapForUnit("player")
    local x, y
    if mapID then
        local pos = C_Map.GetPlayerMapPosition(mapID, "player")
        if pos then x, y = pos:GetXY() end
    end
    local d = {
        killer = killer and killer.name or "?",
        class = killer and killer.loc or nil,
        level = killer and killer.level or nil,
        zone = GetRealZoneText(), sub = GetSubZoneText(),
        mapID = mapID, x = x, y = y, when = date("%d/%m %H:%M"), t = now,
    }
    if killer and killer.full then Espia.RecordLoss(killer.full) end
    table.insert(DB.deaths, 1, d)
    while #DB.deaths > math.max(1, DB.deathMax) do table.remove(DB.deaths) end
    Print("Muerte registrada: " .. (killer and DescribeKiller(killer) or "?") .. " en " .. (d.zone or "?") ..
          ((x and x > 0) and string.format(" %.0f,%.0f", x * 100, y * 100) or "") ..
          (others and (" · también te pegaron: " .. table.concat(others, ", ")) or ""))
    -- el resumen de muerte puede tardar un poco en estar listo
    if not killer and DB.sources.recap and C_Timer and C_Timer.After then
        C_Timer.After(1.5, function() RecordDeath(true) end)
    end
    if not killer and DB.deathHint then
        local get = (C_CVar and C_CVar.GetCVar) or GetCVar
        local ok, v = pcall(get, "nameplateShowEnemies")
        if ok and v ~= "1" then
            Print("No he visto a quien te ha matado: tienes las |cffff5555placas de enemigos apagadas|r y sin ellas solo veo a quien "
                .. "seleccionas o tocas con el ratón. Enciéndelas con V o en la configuración (Fuentes de detección).")
        elseif now - hidden.last < 30 then
            Print("No he visto a quien te ha matado: había jugadores cerca pero |cffff5555el juego ocultaba si eran enemigos|r "
                .. "(" .. hidden.n .. " veces en esta sesión). Haz una captura de esto y de /pvpo diagnostico.")
        else
            Print("No he visto a quien te ha matado: no había ninguna placa de jugador enemigo cerca en los últimos segundos. "
                .. "Mira /pvpo diagnostico y la distancia de las placas.")
        end
    end
    lastTargeter = nil
end

----------------------------------------------------------------------
-- Mover marcos / prueba
----------------------------------------------------------------------
local function SetUnlocked(v, silent)
    unlocked = v
    for _, f in ipairs(movables) do
        f:EnableMouse(v)
        if v then f.bg:Show() else f.bg:Hide() end
    end
    if alertFrame then
        if v then
            alertFrame.text:SetText("Aqui saldran los avisos (arrastra)")
            alertFrame.text:SetTextColor(1, 0.5, 0)
            alertFrame:SetAlpha(1); alertFrame:Show()
        else
            alertFrame:Hide()
        end
    end
    if DB and listFrame then UpdateEnemyList(); UpdateCDs(); RefreshCasts() end
    if not silent then
        Print(v and "marcos desbloqueados: arrastralos con el raton. /pvpo lock para fijar." or "marcos fijados.")
    end
end

local function DoTest()
    local now = GetTime()
    local fake = {
        { "Asesino", "ROGUE", "Pícaro", 60 }, { "Magox", "MAGE", "Mago", -1 },
        { "Pala", "PALADIN", "Paladín", 58 }, { "Cazador", "HUNTER", "Cazador", 60 },
    }
    for i, f in ipairs(fake) do
        enemies["test" .. i] = { name = f[1], class = f[2], loc = f[3], level = f[4], seen = now, first = now + i, warned = true }
    end
    for i, id in ipairs({ 408, 2139, 853, 2094 }) do
        local name, icon = SpellInfo(id)
        if name then
            cds["test" .. i] = { src = fake[i][1], spell = name, icon = icon,
                                 expire = now + 5 + i * 8, total = 40 }
        end
    end
    Alert("¡PRUEBA DE ALERTA!", 1, 0.5, 0)
    Print("datos de prueba creados.")
end

----------------------------------------------------------------------
-- Creacion de marcos (una vez, al activar por primera vez)
----------------------------------------------------------------------
local function BuildFrames()
    alertFrame = mod:Frame("Frame", nil, UIParent)
    alertFrame:SetSize(600, 40)
    alertFrame:SetFrameStrata("HIGH")
    alertFrame.text = alertFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    alertFrame.text:SetPoint("CENTER")
    alertFrame.sub = alertFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
    alertFrame.sub:SetPoint("TOP", alertFrame.text, "BOTTOM", 0, -2)
    MakeMovable(alertFrame, "alert", "TOP", 0, -170)
    alertFrame.bg:SetAllPoints(alertFrame)
    alertFrame:Hide()
    alertFrame:SetScript("OnUpdate", function(self, elapsed)
        if unlocked then return end
        self.t = (self.t or 0) + elapsed
        local dur = DB.alertSeconds or 3
        if self.t > dur then self:Hide(); return end
        if self.t > dur - 1 then self:SetAlpha(dur - self.t) end
    end)

    listFrame = mod:Frame("Frame", "CMPvPOutdoorEnemyList", UIParent)
    listFrame:SetSize(230, 20)
    MakeMovable(listFrame, "enemies", "TOPLEFT", 20, -200)
    listFrame.topLeft = true
    listFrame.title = listFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    listFrame.title:SetPoint("TOPLEFT", 4, -3)
    listFrame.title:SetWidth(150); listFrame.title:SetJustifyH("LEFT")
    if listFrame.title.SetWordWrap then listFrame.title:SetWordWrap(false) end
    listFrame.rows = {}
    for i = 1, MAX_ROWS do
        local fs = listFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        fs:SetPoint("TOPLEFT", 4, -3 - 14 * i)
        fs:SetJustifyH("LEFT")
        fs:SetWidth(222)
        if fs.SetWordWrap then fs:SetWordWrap(false) end
        listFrame.rows[i] = fs
    end
    -- botones de la cabecera: < > (cambiar lista), E (estadisticas), X (vaciar / atajos)
    listFrame.hdr = {}
    local function TitleButton(label, x, tip, onClick)
        local b = CreateFrame("Button", nil, listFrame)
        b:SetSize(16, 16)
        b:SetPoint("TOPRIGHT", x, -1)
        b.t = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        b.t:SetPoint("CENTER"); b.t:SetText(label)
        b.hl = b:CreateTexture(nil, "HIGHLIGHT"); b.hl:SetAllPoints(); b.hl:SetColorTexture(1, 1, 1, 0.2)
        b:RegisterForClicks("AnyUp")
        b:SetScript("OnClick", onClick)
        b:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            for i, line in ipairs(tip) do GameTooltip:AddLine(line, 1, i == 1 and 0.82 or 1, i == 1 and 0 or 1) end
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
        return b
    end
    listFrame.hdr[#listFrame.hdr + 1] = TitleButton("<", -58, { "Lista anterior", "Cerca / Ultima hora / Matar a la vista / Venganza / Ignorados / Zonas" }, function() CycleView(-1) end)
    listFrame.hdr[#listFrame.hdr + 1] = TitleButton(">", -40, { "Lista siguiente", "Cerca / Ultima hora / Matar a la vista / Venganza / Ignorados / Zonas" }, function() CycleView(1) end)
    listFrame.hdr[#listFrame.hdr + 1] = TitleButton("E", -22, { "Estadisticas", "Fichas, victorias y derrotas de cada enemigo" }, function() Espia.OpenStats() end)
    listFrame.hdr[#listFrame.hdr + 1] = TitleButton("X", -4, { "Vaciar y cerrar", "Clic: vacia la lista Cerca y la oculta hasta el proximo enemigo nuevo",
        "Mayus+clic: sonidos si/no", "Ctrl+clic: desactivar el modulo" }, function()
        if IsControlKeyDown and IsControlKeyDown() then Hub:SetEnabled("enemigos", false); return end
        if IsShiftKeyDown and IsShiftKeyDown() then
            DB.sound = not DB.sound; Print("sonidos: " .. (DB.sound and "SI" or "NO")); return
        end
        wipe(enemies)
        DB.view = "near"
        closedUntilNew = DB.spy.xHides and true or false
        UpdateEnemyList()
    end)
    listFrame:Hide()

    cdFrame = mod:Frame("Frame", "CMPvPOutdoorCDs", UIParent)
    cdFrame:SetSize(MAX_ICONS * 38, 52)
    MakeMovable(cdFrame, "cds", "TOP", 0, -140)
    cdFrame.icons = {}
    for i = 1, MAX_ICONS do
        local b = CreateFrame("Frame", nil, cdFrame)
        b:SetSize(34, 34)
        b:SetPoint("TOPLEFT", (i - 1) * 38, -2)
        b.tex = b:CreateTexture(nil, "ARTWORK"); b.tex:SetAllPoints(b)
        b.tex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        b.shade = b:CreateTexture(nil, "OVERLAY"); b.shade:SetAllPoints(b)
        b.shade:SetColorTexture(0, 0, 0, 0.55)
        b.time = b:CreateFontString(nil, "OVERLAY", "NumberFontNormalLarge")
        b.time:SetPoint("CENTER", 0, 0)
        b.name = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        b.name:SetPoint("TOP", b, "BOTTOM", 0, -1)
        b:Hide()
        cdFrame.icons[i] = b
    end
    cdFrame:Hide()

    castBars[1] = CreateCastBar("target", "cast_target", -120)
    castBars[2] = CreateCastBar("focus", "cast_focus", -160)
    for _, bar in ipairs(castBars) do
        bar.acc = 0
        bar:SetScript("OnUpdate", function(self, elapsed)
            self.acc = self.acc + elapsed
            if self.acc > 0.05 then self.acc = 0; CheckCast(self) end
        end)
    end
    for _, f in ipairs(movables) do ApplyPos(f) end
    AnchorTopLeft(listFrame)
    ApplyLayout()
end

----------------------------------------------------------------------
-- Configuracion (pestana)
----------------------------------------------------------------------
local function NeedEnabled()
    if mod.enabled and listFrame then return true end
    Print("activa primero el modulo (casilla de arriba).")
    return false
end

local function Pct(v) return math.floor((v or 0) + 0.5) end

local function BuildConfig(m, L)
    DB = m.db
    L:Header("Que mostrar")
    local function Show(key, label)
        L:Check(label, function() return DB.show[key] end, function(v) DB.show[key] = v; UpdatePins() end)
    end
    Show("enemies", "Lista de enemigos cercanos")
    Show("cds", "Habilidades clave del enemigo (cooldowns)")
    Show("casts", "Alerta de casteos del objetivo y el foco")
    Show("map", "Marcas de tus muertes en el mapa")

    L:Header("Cuando actuar")
    L:Check("Solo en el mundo abierto (no instancias, campos de batalla ni arenas)",
        function() return DB.outdoorOnly end, function(v) DB.outdoorOnly = v end)
    L:Slider("Quitar a un enemigo de la lista tras (segundos sin verlo)", 10, 900, 10,
        function() return DB.enemyTTL end, function(v) DB.enemyTTL = v end)
    L:Slider("Ponerlo en gris («hace X s») tras (segundos sin verlo)", 5, 120, 5,
        function() return DB.activeTTL end, function(v) DB.activeTTL = v end)

    L:Header("Avisos")
    L:Check("Sonidos activados (interruptor general)", function() return DB.sound end, function(v) DB.sound = v end)
    L:Check("   Sonido al detectar un enemigo nuevo",
        function() return DB.alerts.new end, function(v) DB.alerts.new = v end)
    L:Check("   Sonido de alerta de grupo enemigo",
        function() return DB.alerts.group end, function(v) DB.alerts.group = v end)
    L:Check("   Sonido de alerta de peligro (nivel)",
        function() return DB.alerts.danger end, function(v) DB.alerts.danger = v end)
    L:Check("   Sonido de casteo peligroso",
        function() return DB.alerts.cast end, function(v) DB.alerts.cast = v end)
    L:Check("Avisar cuando un enemigo te ataca («¡X te ataca!»), también en pueblos neutrales",
        function() return DB.attackAlert end, function(v) DB.attackAlert = v end)
    L:Check("   Sonido del aviso de ataque", function() return DB.alerts.attack end, function(v) DB.alerts.attack = v end)
    L:Slider("   Repetir el aviso del mismo enemigo tras (segundos)", 5, 120, 5,
        function() return DB.attackRepeat end, function(v) DB.attackRepeat = v end)
    L:Check("Si te matan sin verlo y tienes las placas apagadas, avisar en el chat",
        function() return DB.deathHint end, function(v) DB.deathHint = v end)
    L:Check("Mensaje grande en pantalla", function() return DB.alertText end, function(v) DB.alertText = v end)
    L:Slider("Duracion del mensaje grande (segundos)", 1, 8, 0.5,
        function() return DB.alertSeconds end, function(v) DB.alertSeconds = v end, "%.1f")
    L:Slider("Pausa entre avisos de grupo (segundos)", 3, 60, 1,
        function() return DB.groupCooldown end, function(v) DB.groupCooldown = v end)

    L:Header("Umbrales")
    L:Slider("Alerta de grupo desde (enemigos)", 2, 10, 1,
        function() return DB.groupSize end, function(v) DB.groupSize = v end)
    L:Slider("Peligro si lleva +niveles que tu", 1, 60, 1,
        function() return DB.dangerLevelDiff end, function(v) DB.dangerLevelDiff = v end)
    L:Slider("Casteos largos desde (segundos)", 0, 6, 0.5,
        function() return DB.longCast end, function(v) DB.longCast = v end, "%.1f")
    L:Slider("Cooldown en verde por debajo de (% restante)", 5, 50, 5,
        function() return DB.cdLow end, function(v) DB.cdLow = v end, "%d%%")
    L:Slider("Cooldown en rojo por encima de (% restante)", 50, 95, 5,
        function() return DB.cdHigh end, function(v) DB.cdHigh = v end, "%d%%")

    L:Header("Aspecto y posicion")
    L:Slider("Filas de la lista de enemigos", 1, 15, 1,
        function() return DB.listMax end, function(v) DB.listMax = v end)
    L:Slider("Iconos de habilidades a la vez", 3, 10, 1,
        function() return DB.cdMax end, function(v) DB.cdMax = v; ApplyLayout() end)
    L:Slider("Ancho de las barras de casteo", 150, 400, 10,
        function() return DB.castWidth end, function(v) DB.castWidth = v; ApplyLayout() end)
    L:Slider("Escala de la lista", 50, 200, 5,
        function() return Pct(DB.scale.list) end, function(v) DB.scale.list = v; ApplyLayout() end, "%d%%")
    L:Slider("Escala de las habilidades", 50, 200, 5,
        function() return Pct(DB.scale.cds) end, function(v) DB.scale.cds = v; ApplyLayout() end, "%d%%")
    L:Slider("Escala de las barras de casteo", 50, 200, 5,
        function() return Pct(DB.scale.casts) end, function(v) DB.scale.casts = v; ApplyLayout() end, "%d%%")
    L:Slider("Escala del mensaje grande", 50, 250, 5,
        function() return Pct(DB.scale.alert) end, function(v) DB.scale.alert = v; ApplyLayout() end, "%d%%")
    L:Slider("Opacidad del fondo al mover los marcos", 0, 100, 5,
        function() return Pct(DB.bgAlpha) end, function(v) DB.bgAlpha = v; ApplyLayout() end, "%d%%")
    local move
    move = L:Button(unlocked and "Fijar marcos" or "Mover marcos", 150, function()
        if not NeedEnabled() then return end
        SetUnlocked(not unlocked)
        move:SetText(unlocked and "Fijar marcos" or "Mover marcos")
    end)
    L:Button("Probar", 120, function() if NeedEnabled() then DoTest() end end, true)
    L:Add({ Refresh = function() move:SetText(unlocked and "Fijar marcos" or "Mover marcos") end }, 0)

    L:Header("Registro de muertes")
    L:Slider("Muertes guardadas", 10, 100, 10,
        function() return DB.deathMax end, function(v) DB.deathMax = v end)
    L:Button("Ver muertes (chat)", 150, function()
        if #DB.deaths == 0 then Print("sin muertes registradas.") end
        for i = 1, math.min(10, #DB.deaths) do
            local d = DB.deaths[i]
            Print(string.format("%d) %s - %s en %s%s", i, d.when, d.killer, d.zone or "?",
                (d.sub and d.sub ~= "") and (" / " .. d.sub) or ""))
        end
    end)
    L:Button("Borrar muertes", 150, function()
        DB.deaths = {}; UpdatePins(); Print("registro de muertes borrado.")
    end, true)

    L:Header("Listas")
    L:Text("La lista tiene seis vistas: Cerca, Ultima hora, Matar a la vista, Venganza, Ignorados y Zonas calientes. Cambia con < y > en su cabecera. E abre las estadisticas y X la vacia (Mayus+X sonidos, Ctrl+X desactiva el modulo).", true)
    L:Button("Ver Ultima hora", 130, function() if NeedEnabled() then ShowView("hour") end end)
    L:Button("Ver KOS", 90, function() if NeedEnabled() then ShowView("kos") end end, true)
    L:Button("Ver ignorados", 120, function() if NeedEnabled() then ShowView("ignore") end end, true)
    L:Button("Ver Cerca", 100, function() if NeedEnabled() then ShowView("near") end end, true)
    L:Button("Ver zonas calientes", 160, function() if NeedEnabled() then ShowView("zones") end end)
    L:Button("Ver venganza", 120, function() if NeedEnabled() then ShowView("revenge") end end, true)
    L:Button("Editar venganza", 140, function() if NeedEnabled() then Espia.OpenRevenge() end end, true)

    L:Header("Donde buscar enemigos")
    L:Text("Siempre: placas de nombre, tu objetivo, tu foco y el raton. Ademas:", true)
    L:Check("Objetivo suave (el enemigo que el juego resalta delante de ti)", function() return DB.sources.soft end, function(v) DB.sources.soft = v end)
    L:Check("Objetivo de tu objetivo, de tu foco, del raton y de cada placa", function() return DB.sources.chain end, function(v) DB.sources.chain = v end)
    L:Check("Objetivos de tus compañeros de grupo y banda", function() return DB.sources.group end, function(v) DB.sources.group = v end)
    L:Check("Enemigos que hacen un emote o hablan (/decir, /gritar) cerca", function() return DB.sources.chat end, function(v) DB.sources.chat = v end)
    L:Check("Al morir, mirar el resumen de muerte del juego (quien te ha pegado, aunque viniera por la espalda)",
        function() return DB.sources.recap end, function(v) DB.sources.recap = v end)
    L:Check("Encender las placas de nombre de los enemigos (sin ellas solo ves a quien seleccionas o tocas)",
        function() return DB.sources.plates end, function(v) DB.sources.plates = v; WantPlates() end)
    L:Check("Subir la distancia de las placas al máximo que deje el juego (los ves desde más lejos)",
        function() return DB.sources.farPlates end, function(v) DB.sources.farPlates = v; WantPlates() end)
    L:Check("Objetivo suave de enemigos siempre activo y a 45 m (cambia cómo apunta el juego; quitarlo lo deja como estaba)",
        function() return DB.sources.softRange end, function(v) DB.sources.softRange = v; WantPlates() end)
    L:Check("Placas también fuera de pantalla: detecta a los que vienen por la espalda o desde arriba",
        function() return DB.sources.offscreen end, function(v) DB.sources.offscreen = v; WantPlates() end)
    L:Check("Radar: flechas hacia los enemigos que no tienes en pantalla (detrás, a los lados, arriba)",
        function() return DB.radar.on end, function(v) DB.radar.on = v; UpdateRadar() end)
    L:Check("   También hacia los que sí ves en pantalla", function() return DB.radar.all end, function(v) DB.radar.all = v end)
    L:Slider("   Distancia de las flechas al centro", 80, 400, 10, function() return DB.radar.radius end, function(v) DB.radar.radius = v end)
    L:Slider("   Tamaño de las flechas (%)", 50, 200, 10, function() return DB.radar.scale end, function(v) DB.radar.scale = v end)
    L:Slider("   Flechas a la vez", 1, 15, 1, function() return DB.radar.max end, function(v) DB.radar.max = v end)
    L:Check("Medidor de daño del juego: avisa de quien te pega aunque no lo veas (su clase y su nombre)",
        function() return DB.sources.dmeter end, function(v) DB.sources.dmeter = v end)
    L:Check("Jugadores con recompensa JcJ marcados en el mapa (se ven desde lejos)",
        function() return DB.sources.vignette end, function(v) DB.sources.vignette = v; ScanVignettes() end)
    L:Check("Aviso «¡Enemigo a tu espalda!» cuando aparece uno detrás de la cámara",
        function() return DB.behindAlert end, function(v) DB.behindAlert = v end)
    L:Check("   Sonido del aviso de espalda", function() return DB.alerts.behind end, function(v) DB.alerts.behind = v end)
    L:Slider("   Repetir el aviso del mismo enemigo tras (segundos)", 5, 120, 5,
        function() return DB.behindRepeat end, function(v) DB.behindRepeat = v end)
    L:Button("Diagnóstico", 120, function() Diagnostic() end)
    L:Text("El diagnóstico dice en el chat si tienes las placas encendidas y cuántos "
        .. "enemigos ha encontrado cada fuente (también con /pvpo diagnostico).", true)

    L:Header("Zonas neutrales")
    L:Check("No avisar en los pueblos neutrales de la lista", function() return DB.neutralPause end, function(v) DB.neutralPause = v; EvalZone() end)
    L:Check("No avisar en zonas santuario", function() return DB.sanctuaryPause end, function(v) DB.sanctuaryPause = v; EvalZone() end)
    L:Choice("En esos sitios", { { "silencio", "Detectar en silencio (avisa solo si te atacan, KOS o venganza)" },
        { "apagado", "No hacer nada (ni lista ni avisos)" } },
        function() return DB.neutralMode end, function(v) DB.neutralMode = v; EvalZone(); UpdateEnemyList() end)
    L:Text("Pueblos (zona o subzona, separados por ;). Intro para guardar. /pvpo neutral añade o quita la zona donde estas.", true)
    L:Edit("Pueblos", function() return DB.neutralZones end, function(v)
        if type(v) == "string" and not issecret(v) then DB.neutralZones = v:gsub("|", ""); EvalZone() end
    end, "text", 340)
    L:Button("Añadir/quitar la zona actual", 210, function() mod.def.OnSlash(mod, "neutral"); L:Refresh() end)
    L:Button("Lista por defecto", 150, function() DB.neutralZones = DEFAULTS.neutralZones; EvalZone(); L:Refresh() end, true)

    local ICONS = { { 1, "Estrella" }, { 2, "Circulo" }, { 3, "Diamante" }, { 4, "Triangulo" },
        { 5, "Luna" }, { 6, "Cuadrado" }, { 7, "Cruz" }, { 8, "Calavera" } }
    local function Plates() for _, f in pairs(plateMarks) do f:Hide() end; ScanAll() end
    L:Header("Marca sobre la placa de nombre")
    L:Check("Poner una marca encima de la placa de algunos enemigos", function() return DB.plate.on end, function(v) DB.plate.on = v; Plates() end)
    L:Check("   Si te tiene de objetivo", function() return DB.plate.targeting end, function(v) DB.plate.targeting = v; Plates() end)
    L:Choice("   Icono", ICONS, function() return DB.plate.targetIcon end, function(v) DB.plate.targetIcon = v; Plates() end)
    L:Check("   Si es KOS", function() return DB.plate.kos end, function(v) DB.plate.kos = v; Plates() end)
    L:Choice("   Icono", ICONS, function() return DB.plate.kosIcon end, function(v) DB.plate.kosIcon = v; Plates() end)
    L:Check("   A todos los demas enemigos", function() return DB.plate.all end, function(v) DB.plate.all = v; Plates() end)
    L:Choice("   Icono", ICONS, function() return DB.plate.allIcon end, function(v) DB.plate.allIcon = v; Plates() end)
    L:Slider("Tamaño de la marca", 12, 64, 2, function() return DB.plate.size end, function(v) DB.plate.size = v; Plates() end)
    L:Slider("Altura sobre la placa", -20, 40, 1, function() return DB.plate.y end, function(v) DB.plate.y = v; Plates() end)

    L:Header("Ping sobre un enemigo")
    L:Check("Clic central en una fila: ping de Blizzard sobre ese enemigo", function() return DB.ping.on end, function(v) DB.ping.on = v; UpdateEnemyList() end)
    L:Choice("Tipo de ping", PING_KINDS, function() return DB.ping.kind end, function(v) DB.ping.kind = v; UpdateEnemyList() end)
    L:Check("Volver a tu objetivo anterior despues del ping", function() return DB.ping.restore end, function(v) DB.ping.restore = v; UpdateEnemyList() end)
    L:Check("Boton para una tecla (ping al primer enemigo de 'Cerca')", function() return DB.ping.button end, function(v) DB.ping.button = v; UpdateEnemyList() end)
    L:Text("Para usarlo con una tecla crea una macro con  /click CMPvPOutdoorPing  y ponla en tu barra. En combate el juego no deja cambiar a quien apunta: usa el enemigo que habia al empezar.", true)

    Espia.BuildConfig(L)
end

----------------------------------------------------------------------
-- Comandos antiguos (/pvpo, /cmpvp)
----------------------------------------------------------------------
local function OnSlash(m, msg)
    local cmd, arg = string.match(strlower(msg or ""), "^(%S*)%s*(.-)$")
    local rawArg = string.match(msg or "", "^%S*%s*(.-)$") or ""
    if Espia.Slash(cmd, rawArg ~= "" and rawArg or nil) then return end
    if cmd == "" or cmd == "config" then Hub:Open("enemigos")
    elseif cmd == "lista" then
        local v = ({ cerca = "near", hora = "hour", kos = "kos", ignorados = "ignore", zonas = "zones", venganza = "revenge" })[arg] or "near"
        ShowView(v)
    elseif cmd == "neutral" then
        local z = (GetSubZoneText and GetSubZoneText()) or ""
        if z == "" or issecret(z) then z = (GetRealZoneText and GetRealZoneText()) or "" end
        if z == "" or issecret(z) then Print("no se lee el nombre de esta zona."); return end
        local list, out, found = {}, {}, false
        for x in string.gmatch(DB.neutralZones or "", "[^;]+") do
            x = x:gsub("^%s+", ""):gsub("%s+$", "")
            if strlower(x) == strlower(z) then found = true elseif x ~= "" then out[#out + 1] = x end
        end
        if not found then out[#out + 1] = z end
        DB.neutralZones = table.concat(out, ";")
        EvalZone()
        Print(z .. (found and " ya no es zona neutral (vuelve a avisar)." or " añadida a las zonas neutrales (no avisa aqui)."))
    elseif cmd == "minimap" then
        local c = ns.DB.minimap.enemigos
        Hub:SetModuleButton("enemigos", c.hide and true or false)
    elseif cmd == "voz" then Hub:Open("voces")
    elseif cmd == "vozinfo" then if ns.PO_VoiceDiag then ns.PO_VoiceDiag() end
    elseif cmd == "voztest" then if ns.PO_VoiceTest then ns.PO_VoiceTest() end
    elseif cmd == "unlock" then SetUnlocked(true)
    elseif cmd == "lock" then SetUnlocked(false)
    elseif cmd == "test" then DoTest()
    elseif cmd == "toggle" and DB.show[arg] ~= nil then
        DB.show[arg] = not DB.show[arg]
        Print(arg .. ": " .. (DB.show[arg] and "ON" or "OFF"))
        UpdatePins()
    elseif cmd == "sound" then
        DB.sound = not DB.sound; Print("sonido: " .. (DB.sound and "ON" or "OFF"))
    elseif cmd == "outdoor" then
        DB.outdoorOnly = not DB.outdoorOnly
        Print("solo outdoor: " .. (DB.outdoorOnly and "ON" or "OFF"))
    elseif cmd == "group" and tonumber(arg) then
        DB.groupSize = tonumber(arg); Print("alerta de grupo a partir de " .. arg)
    elseif cmd == "level" and tonumber(arg) then
        DB.dangerLevelDiff = tonumber(arg); Print("alerta de nivel +" .. arg)
    elseif cmd == "longcast" and tonumber(arg) then
        DB.longCast = tonumber(arg); Print("casteos largos desde " .. arg .. "s")
    elseif cmd == "log" then
        if #DB.deaths == 0 then Print("sin muertes registradas.") end
        for i = 1, math.min(10, #DB.deaths) do
            local d = DB.deaths[i]
            Print(string.format("%d) %s - %s en %s%s", i, d.when, d.killer, d.zone or "?",
                (d.sub and d.sub ~= "") and (" / " .. d.sub) or ""))
        end
    elseif cmd == "clear" then
        DB.deaths = {}; UpdatePins(); Print("registro de muertes borrado.")
    elseif cmd == "diagnostico" or cmd == "diag" then Diagnostic()
    else
        Print("/pvpo = configuracion | voz | vozinfo | voztest | unlock | lock | test | sound | outdoor | log | clear | minimap | diagnostico")
        Print("/pvpo toggle enemies|cds|casts|map  -  /pvpo group <n>  |  level <n>  |  longcast <seg>")
        Print("/pvpo lista cerca|hora|kos|venganza|ignorados|zonas | kos [nombre [motivo]] | ignorar [nombre] | stats | anunciar <nombre> | compartir [grupo]")
        Print("/pvpo venganza = ventana de la lista de venganza  |  /pvpo venganza <nombre> = añadirlo o quitarlo")
    end
end

----------------------------------------------------------------------
-- Registro en el Hub
----------------------------------------------------------------------
local hooked = false

local function Init(m)
    DB = m.db
    DB.voice = nil   -- la voz vive ahora en el modulo "voces"
    -- ajustes de versiones antiguas (otoriPvpOutdoorDB / PvPOutdoorDB)
    if not DB._legacyChecked then
        DB._legacyChecked = true
        local old = otoriPvpOutdoorDB or PvPOutdoorDB
        if old and #DB.deaths == 0 and old ~= _G.CervecerosMendigosPvpOutdoorDB then
            for k, v in pairs(old) do
                if k ~= "voice" and k ~= "minimap" and type(v) ~= "nil" and k ~= "scale" then DB[k] = v end
            end
            Hub.CopyDefaults(DB, DEFAULTS)
        end
    end
    if type(DB.alerts) ~= "table" then DB.alerts = {} end
    Hub.CopyDefaults(DB, DEFAULTS)
    if not DB._deteccion2 then   -- una vez: los valores de antes eran cortos (25 s y 8 filas)
        DB._deteccion2 = true
        if DB.enemyTTL == 25 then DB.enemyTTL = 90 end
        if DB.listMax == 8 then DB.listMax = 10 end
    end
    DB.minimap = nil
    Espia.Init(m, {
        Alert = function(...) Alert(...) end,
        Refresh = function() if listFrame then UpdateEnemyList() end; Espia.RefreshStats() end,
        UpdatePins = function() UpdatePins() end,
        -- avistamiento que manda otro jugador (grupo/hermandad)
        AddRemote = function(r)
            for _, x in pairs(enemies) do if x.full == r.name and not x.remote then return end end   -- ya lo veo yo
            local key = "remote:" .. r.name
            local e, now = enemies[key], GetTime()
            if not e then e = { first = now }; enemies[key] = e end
            e.name, e.full = r.name, r.name
            if r.class then e.class = r.class; e.loc = LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[r.class] or e.loc end
            if r.level then e.level = r.level end
            e.seen, e.remote, e.wx, e.wy, e.attacking = now, r.sender, r.wx, r.wy, r.attacking
            if listFrame then UpdateEnemyList() end
        end,
        Forget = function(name)
            for k, e in pairs(enemies) do if e.full == name then enemies[k] = nil end end
            UpdateEnemyList()
        end,
    })
    BuildKeySpells()
    BuildDangerSpells()
    BuildFrames()
    if WorldMapFrame and not hooked then
        hooked = true
        WorldMapFrame:HookScript("OnShow", function() if mod.enabled then UpdatePins() end end)
        hooksecurefunc(WorldMapFrame, "OnMapChanged", function() if mod.enabled then UpdatePins() end end)
    end

    m:Event("PLAYER_ENTERING_WORLD", function() wipe(enemies); HidePlateMark(); EvalZone(); WantPlates() end)
    for _, ev in ipairs({ "ZONE_CHANGED", "ZONE_CHANGED_INDOORS", "ZONE_CHANGED_NEW_AREA" }) do
        m:Event(ev, function() EvalZone() end)
    end
    m:Event("NAME_PLATE_UNIT_REMOVED", function(_, _, unit) HidePlateMark(unit) end)
    m:Event("PLAYER_SOFT_ENEMY_CHANGED", function() if DB.sources.soft then ScanUnit("softenemy") end end)
    m:Event("UNIT_TARGET", function(_, _, unit)
        if type(unit) ~= "string" or issecret(unit) then return end
        if DB.sources.chain and unit:find("^nameplate") then ScanUnit(unit .. "target"); ScanUnit(unit)
        elseif DB.sources.group and (unit:find("^party") or unit:find("^raid")) then ScanUnit(unit .. "target") end
    end)
    local function OnChat(_, _, _, author, _, _, _, _, _, _, _, _, _, guid) ScanGUID(guid, author) end
    for _, ev in ipairs({ "CHAT_MSG_TEXT_EMOTE", "CHAT_MSG_EMOTE", "CHAT_MSG_SAY", "CHAT_MSG_YELL" }) do m:Event(ev, OnChat) end
    m:Event("PARTY_KILL", function(_, _, attacker, victim) Espia.OnPartyKill(attacker, victim, function(guid)
        local e = enemies[guid]; return e and e.full end) end)
    m:Event("NAME_PLATE_UNIT_ADDED", function(_, _, unit) ScanUnit(unit) end)
    m:Event("NAME_PLATE_UNIT_BEHIND_CAMERA_CHANGED", function(_, _, unit, behind)
        if type(unit) == "string" and not issecret(unit) and behind == true then ScanUnit(unit) end
    end)
    m:Event("PLAYER_TARGET_CHANGED", function() ScanUnit("target"); RefreshCasts() end)
    m:Event("PLAYER_FOCUS_CHANGED", function() ScanUnit("focus"); RefreshCasts() end)
    m:Event("UPDATE_MOUSEOVER_UNIT", function() ScanUnit("mouseover") end)
    local function CastStart(_, _, unit)
        if unit == "target" or unit == "focus" then RefreshCasts() end
    end
    m:Event("UNIT_SPELLCAST_START", CastStart)
    m:Event("UNIT_SPELLCAST_CHANNEL_START", CastStart)
    m:Event("UNIT_SPELLCAST_SUCCEEDED", function(_, _, ...) OnSpellSucceeded(...) end)
    m:Event("PLAYER_DEAD", function() RecordDeath() end)
    m:Event("CHAT_MSG_ADDON", function(_, _, prefix, text, chan, sender) Espia.OnAddonMessage(prefix, text, chan, sender) end)
    m:Event("CHAT_MSG_COMBAT_HONOR_GAIN", function(_, _, text) Espia.OnHonorMessage(text) end)
    m:Event("PLAYER_REGEN_ENABLED", function()
        Espia.Flush(); UpdateEnemyList(); WantPlates()
        ReadDamageTaken(); ReadEnemyDamage()   -- al acabar el combate el medidor ya se puede leer entero
    end)
    -- Al entrar en combate o recibir un golpe: mirar ya las placas (no esperar al siguiente repaso).
    local lastHitScan = 0
    m:Event("PLAYER_REGEN_DISABLED", function() ScanAll() end)
    local dmAcc = 0
    m:Event("DAMAGE_METER_CURRENT_SESSION_UPDATED", function()
        local now = GetTime()
        if now - dmAcc > 0.25 then dmAcc = now; ReadDamageTaken() end
    end)
    m:Event("VIGNETTES_UPDATED", function() ScanVignettes() end)
    m:Event("VIGNETTE_MINIMAP_UPDATED", function() ScanVignettes() end)
    m:Event("UNIT_COMBAT", function(_, _, unit)
        if unit ~= "player" then return end
        local now = GetTime()
        if now - lastHitScan > 0.25 then lastHitScan = now; ScanAll() end
    end)

    local acc, scanAcc, flushAcc = 0, 0, 0
    m:OnUpdate(function(_, elapsed)
        acc = acc + elapsed
        scanAcc = scanAcc + elapsed
        flushAcc = flushAcc + elapsed
        if scanAcc >= 0.5 then scanAcc = 0; ScanAll() end
        if flushAcc >= 5 then flushAcc = 0; Espia.Flush(); EvalZone() end
        if acc < 0.1 then return end
        acc = 0
        UpdateEnemyList()
        UpdateCDs()
        UpdateRadar()
    end)
end

mod = Hub:Register{
    key = "enemigos", dir = "PvpOutdoor", name = "Enemigos cercanos",
    desc = "Lista de enemigos jugadores cercanos (clic para seleccionarlos) con alerta de grupo y de peligro por nivel, fichas guardadas de cada enemigo, listas Ultima hora, Matar a la vista (KOS) e Ignorados, victorias y derrotas, avisos de KOS compartidos con hermandad y grupo, aviso de sigilo, cooldowns de sus habilidades clave, alerta de casteos peligrosos y marcas en el mapa.",
    defaults = DEFAULTS,
    legacyDB = "CervecerosMendigosPvpOutdoorDB",
    slash = { "pvpo", "cmpvp" },
    Init = Init,
    Enable = function(m)
        if not listFrame then return end
        for _, f in ipairs(movables) do ApplyPos(f) end
        ApplyLayout()
        RefreshCasts()
        UpdatePins()
        if Espia.CharTabUpdate then Espia.CharTabUpdate() end
    end,
    Disable = function(m)
        if listFrame then SetUnlocked(false, true) end
        wipe(enemies)
        HideRows()
        HidePlateMark()
        Espia.Reset()
        for _, p in ipairs(pins) do p:Hide() end
        if Espia.CharTabUpdate then Espia.CharTabUpdate() end
    end,
    BuildConfig = BuildConfig,
    OnSlash = OnSlash,
    OnReset = function(m)
        DB = m.db
        Espia.Rebind(m)
        DB.voice = nil
        DB._legacyChecked = true
        if listFrame then
            for _, f in ipairs(movables) do ApplyPos(f) end
            ApplyLayout()
        end
    end,
}
